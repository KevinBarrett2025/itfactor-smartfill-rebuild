import SwiftUI
import AVFoundation

/// Professional export interface for Self Tape Studio
/// Provides export options and manages export workflow
/// SURGICAL FIX: Now uses SessionExportManager for Smart Fill and professional quality
///
/// KEYFRAME PHOTOS: Photos are excluded from video export and serve as thumbnail reference images only.
/// Video thumbnails are generated using the app's existing AVAssetImageGenerator-based thumbnail system,
/// following cross-platform best practices for iOS, Android, and PC compatibility.
struct ExportManagerView: View {
    let takes: [EnhancedTake]
    let project: Project  // STEP 2B: Add direct project parameter
    let session: ProjectSession  // STEP 2B: Add direct session parameter
    let repository: ProjectsRepository  // CRITICAL FIX: Add repository parameter
    let onDismiss: () -> Void
    
    @StateObject private var exportEngine = ExportEngine.shared
    @StateObject private var exportResultsStore = ExportResultsStore()  // SWIFTUI FIX: Observable store for export data
    @State private var exportOptions = ExportOptions()
    @State private var showingExportResults = false
    @State private var exportError: ExportError?
    @State private var showingFilePicker = false
    @State private var estimatedFileSize: String = "Calculating..."
    
    // SURGICAL FIX: Add SessionExportManager progress tracking
    @State private var sessionExportProgress: Float = 0.0
    @State private var isSessionExporting = false
    @State private var currentExportOperation = ""
    
    // PERFORMANCE FIX: Cache goodTakes to prevent infinite loop
    @State private var cachedGoodTakes: [EnhancedTake] = []
    @State private var cachedSkippedTakes: [EnhancedTake] = []
    @State private var takesProcessed = false
    
    // ENHANCED: Video marker export support
    @State private var videoMarkers: [String: [VideoMarker]] = [:]  // takeID -> markers
    @State private var loadingMarkers = false
    
    // PERFORMANCE FIX: Use cached computed properties instead of live computation
    private var goodTakes: [EnhancedTake] {
        return cachedGoodTakes
    }
    
    private var skippedTakes: [EnhancedTake] {
        return cachedSkippedTakes
    }
    
    // SURGICAL FIX: Use SessionExportManager export status
    private var isExporting: Bool {
        return isSessionExporting || exportEngine.isExporting
    }
    
    private var exportProgress: Float {
        return isSessionExporting ? sessionExportProgress : exportEngine.exportProgress
    }
    
    private var exportOperationText: String {
        return isSessionExporting ? currentExportOperation : exportEngine.currentExportOperation
    }
    
    // PERFORMANCE FIX: Move take processing to onAppear with caching
    private func processTakes() {
        guard !takesProcessed else { return }
        
        var goodTakesList: [EnhancedTake] = []
        var skippedTakesList: [EnhancedTake] = []
        
        for take in takes {
            // FILTER: Skip merged videos - they shouldn't be re-exported
            if take.fileName.contains("_Merged_") || take.fileName.contains("Merged") {
                print("🚫 ExportManager: Skipping merged video \(take.fileName)")
                skippedTakesList.append(take)
                continue
            }
            
            // CRITICAL FIX: Skip keyframe photos - they are for thumbnail reference only, not video export
            // CORRECTION: Keyframe photos should be handled by AVAssetImageGenerator for thumbnail generation
            if take.fileName.lowercased().hasSuffix(".jpg") || take.fileName.lowercased().hasSuffix(".jpeg") || take.fileName.lowercased().hasSuffix(".png") {
                print("📸 ExportManager: Skipping keyframe photo \(take.fileName) - used for thumbnail reference only")
                skippedTakesList.append(take)
                continue
            }
            
            // Use the passed session data directly
            if let projectTake = session.takes.first(where: { projectTake in
                projectTake.filePath == take.filePath ||
                projectTake.filePath.hasSuffix(take.fileName) ||
                URL(fileURLWithPath: projectTake.filePath).lastPathComponent == take.fileName
            }) {
                print("🎯 Found ProjectTake for \(take.fileName): rating = \(projectTake.rating), takeType = \(projectTake.takeType)")
                
                // CRITICAL FIX: Include BOTH regular takes AND slates with good ratings
                // ENHANCED: Only process actual video content (no photos)
                if (projectTake.rating == .good) &&
                   (projectTake.takeType == .regular || projectTake.takeType == .slate) {
                    goodTakesList.append(take)
                    print("✅ Including \(projectTake.takeType.displayName) video: \(take.fileName) (rating: \(projectTake.rating))")
                } else if projectTake.takeType == .merged {
                    print("🚫 ExportManager: Skipping merged video type \(take.fileName)")
                    skippedTakesList.append(take)
                } else {
                    print("🚫 ExportManager: Skipping take \(take.fileName) - rating: \(projectTake.rating), type: \(projectTake.takeType)")
                    skippedTakesList.append(take)
                }
            } else {
                print("❌ Could not find ProjectTake for \(take.fileName)")
                skippedTakesList.append(take)
            }
        }
        
        cachedGoodTakes = goodTakesList
        cachedSkippedTakes = skippedTakesList
        takesProcessed = true
        
        print("📊 Export processing complete: \(goodTakesList.count) good video takes, \(skippedTakesList.count) skipped")
        print("📸 Note: Keyframe photos are excluded - they serve as thumbnail reference images")
        if !skippedTakesList.isEmpty {
            let skippedNames = skippedTakesList.map { $0.fileName }
            print("🚫 Skipped: \(skippedNames.joined(separator: ", "))")
        }
    }

    var body: some View {
        NavigationStack {
            ZStack {
                BrandBackground()
                    .ignoresSafeArea()
                
                VStack(spacing: 0) {
                    if isExporting {
                        exportProgressView
                    } else {
                        exportConfigurationView
                    }
                }
            }
            .navigationTitle("Export Takes")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    Button("Cancel") {
                        if isExporting {
                            // SURGICAL FIX: Cancel appropriate export process
                            if isSessionExporting {
                                // TODO: Add cancellation support to SessionExportManager
                                isSessionExporting = false
                            } else {
                                exportEngine.cancelExport()
                            }
                        }
                        onDismiss()
                    }
                    .font(.body)
                }
                
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("Export") {
                        performExport()
                    }
                    .font(.body)
                    .fontWeight(.semibold)
                    .disabled(isExporting || goodTakes.isEmpty)
                }
            }
        }
        .sheet(isPresented: $showingExportResults) {
            // SWIFTUI FIX: Use ObservableObject store to avoid closure capture issues
            ExportResultsView(
                exportResultsStore: exportResultsStore,
                onDismiss: {
                    showingExportResults = false
                    exportResultsStore.clear() // Clear data when dismissed
                    onDismiss()
                }
            )
        }
        .alert("Export Error", isPresented: Binding(get: { exportError != nil }, set: { _ in exportError = nil })) {
            Button("OK") { exportError = nil }
        } message: {
            Text(exportError?.errorDescription ?? "Unknown error")
        }
        .onAppear {
            processTakes()  // PERFORMANCE FIX: Cache takes processing on appear
            calculateEstimatedFileSize()
            loadVideoMarkers()
            // STEP 2B: Debug logging
            print("🎬 ExportManager opened with \(takes.count) takes, \(session.takes.count) session takes")
            for (index, take) in takes.enumerated() {
                if let projectTake = session.takes.first(where: { pt in pt.filePath.hasSuffix(take.fileName) }) {
                    print("  Take \(index + 1): \(take.fileName) → rating: \(projectTake.rating)")
                }
            }
        }
        .onChange(of: exportOptions.quality) { _, _ in
            calculateEstimatedFileSize()
        }
        .onChange(of: exportOptions.mode) { _, _ in
            calculateEstimatedFileSize()
        }
    }
    
    // MARK: - Export Configuration View
    
    @ViewBuilder
    private var exportConfigurationView: some View {
        ScrollView {
            VStack(spacing: 20) {
                // FIXED: Better header spacing and sizing
                VStack(spacing: 12) {
                    Image(systemName: "film.fill")
                        .font(.system(size: 50))
                        .foregroundStyle(Theme.primary)
                    
                    VStack(spacing: 6) {
                        if goodTakes.isEmpty {
                            Text("No Takes to Export")
                                .font(.title3)
                                .fontWeight(.semibold)
                                .foregroundStyle(.red)
                            
                            Text("Only takes marked with ✅ will be exported")
                                .font(.subheadline)
                                .foregroundStyle(.gray)
                                .multilineTextAlignment(.center)
                        } else {
                            Text("\(goodTakes.count) Good Takes Ready")
                                .font(.title3)
                                .fontWeight(.semibold)
                                .foregroundStyle(.white)
                            
                            Text("Enhanced export with Smart Fill support")
                                .font(.subheadline)
                                .foregroundStyle(.gray)
                                .multilineTextAlignment(.center)
                        }
                    }
                }
                .padding(.top, 20)
                
                // STEP 2A: Show take filter status
                if !goodTakes.isEmpty || !skippedTakes.isEmpty {
                    takeFilterStatusView
                }
                
                // STEP 2A: Take preview list - only show good takes
                if !goodTakes.isEmpty {
                    ScrollView(.horizontal, showsIndicators: false) {
                        HStack(spacing: 12) {
                            ForEach(goodTakes) { take in
                                TakePreviewCard(take: take)
                            }
                        }
                        .padding(.horizontal, 24)
                    }
                    .frame(height: 80)
                }
                
                // Export options - only show if we have good takes
                if !goodTakes.isEmpty {
                    exportOptionsView
                }
                
                // Estimated file size
                if !goodTakes.isEmpty {
                    estimatedFileSizeView
                }
            }
            .padding(.bottom, 32)
        }
    }
    
    // STEP 2A: Take filter status view
    @ViewBuilder
    private var takeFilterStatusView: some View {
        VStack(spacing: 12) {
            HStack {
                VStack(alignment: .leading, spacing: 4) {
                    HStack(spacing: 8) {
                        Image(systemName: "checkmark.circle.fill")
                            .foregroundStyle(.green)
                            .font(.caption)
                        Text("Exporting: \(goodTakes.count) takes")
                            .font(.caption)
                            .foregroundStyle(.white)
                    }
                    
                    if !skippedTakes.isEmpty {
                        HStack(spacing: 8) {
                            Image(systemName: "xmark.circle.fill")
                                .foregroundStyle(.red)
                                .font(.caption)
                            Text("Skipping: \(skippedTakes.count) takes")
                                .font(.caption)
                                .foregroundStyle(.gray)
                        }
                    }
                }
                
                Spacer()
            }
            
            if !skippedTakes.isEmpty {
                Text("💡 Tip: Mark takes with ✅ to include them in export")
                    .font(.caption2)
                    .foregroundStyle(.gray)
                    .multilineTextAlignment(.center)
            }
        }
        .padding(16)
        .background(
            RoundedRectangle(cornerRadius: 12)
                .fill(Color.white.opacity(0.05))
                .overlay(
                    RoundedRectangle(cornerRadius: 12)
                        .stroke(Color.white.opacity(0.1), lineWidth: 1)
                )
        )
        .padding(.horizontal, 24)
    }
    
    // FIXED: Smaller font sizes for export options
    @ViewBuilder
    private var exportOptionsView: some View {
        VStack(spacing: 16) {
            // Export mode
            ExportOptionSection(title: "Export Mode") {
                VStack(spacing: 6) {
                    ForEach(ExportMode.allCases, id: \.self) { mode in
                        ExportModeRow(
                            mode: mode,
                            isSelected: exportOptions.mode == mode
                        ) {
                            exportOptions.mode = mode
                        }
                    }
                }
            }
            
            // Quality settings
            ExportOptionSection(title: "Quality") {
                VStack(spacing: 6) {
                    ForEach(ExportQuality.allCases, id: \.self) { quality in
                        ExportQualityRow(
                            quality: quality,
                            isSelected: exportOptions.quality == quality
                        ) {
                            exportOptions.quality = quality
                        }
                    }
                }
            }
            
            // File format
            ExportOptionSection(title: "Format") {
                HStack(spacing: 10) {
                    ForEach(OutputFormat.allCases, id: \.self) { format in
                        Button(action: { exportOptions.outputFormat = format }) {
                            HStack(spacing: 6) {
                                Text(format.displayName)
                                    .font(.subheadline)
                                
                                if exportOptions.outputFormat == format {
                                    Image(systemName: "checkmark.circle.fill")
                                        .foregroundStyle(Theme.primary)
                                        .font(.caption)
                                }
                            }
                            .padding(.horizontal, 12)
                            .padding(.vertical, 8)
                            .background(
                                RoundedRectangle(cornerRadius: 8)
                                    .fill(exportOptions.outputFormat == format ? Theme.primary.opacity(0.2) : Color.white.opacity(0.1))
                                    .overlay(
                                        RoundedRectangle(cornerRadius: 8)
                                            .stroke(exportOptions.outputFormat == format ? Theme.primary : Color.white.opacity(0.2), lineWidth: 1)
                                    )
                            )
                        }
                        .foregroundStyle(.white)
                    }
                    
                    Spacer()
                }
            }
        }
        .padding(.horizontal, 24)
    }
    
    @ViewBuilder
    private var estimatedFileSizeView: some View {
        VStack(spacing: 8) {
            HStack {
                Text("Estimated Size:")
                    .font(.subheadline)
                    .foregroundStyle(.gray)
                
                Spacer()
                
                Text(estimatedFileSize)
                    .font(.subheadline)
                    .fontWeight(.medium)
                    .foregroundStyle(.white)
            }
            .padding(.horizontal, 24)
            
            if exportOptions.mode != .separateFiles {
                Text("Merged video may be smaller due to compression")
                    .font(.caption)
                    .foregroundStyle(.gray)
                    .padding(.horizontal, 24)
            }
        }
    }
    
    // MARK: - Export Progress View
    
    @ViewBuilder
    private var exportProgressView: some View {
        VStack(spacing: 32) {
            Spacer()
            
            // Progress animation
            VStack(spacing: 24) {
                ZStack {
                    Circle()
                        .stroke(Color.white.opacity(0.2), lineWidth: 8)
                        .frame(width: 120, height: 120)
                    
                    Circle()
                        .trim(from: 0, to: CGFloat(exportProgress))
                        .stroke(Theme.primary, style: StrokeStyle(lineWidth: 8, lineCap: .round))
                        .frame(width: 120, height: 120)
                        .rotationEffect(.degrees(-90))
                        .animation(.easeInOut, value: exportProgress)
                    
                    VStack(spacing: 4) {
                        Text("\(Int(exportProgress * 100))%")
                            .font(.title2)
                            .fontWeight(.bold)
                            .foregroundStyle(.white)
                        
                        Text("Exporting")
                            .font(.caption)
                            .foregroundStyle(.gray)
                    }
                }
                
                VStack(spacing: 8) {
                    Text(exportOperationText)
                        .font(.headline)
                        .foregroundStyle(.white)
                        .multilineTextAlignment(.center)
                    
                    if !exportOperationText.isEmpty {
                        Text("Please wait while we process your takes...")
                            .font(.body)
                            .foregroundStyle(.gray)
                            .multilineTextAlignment(.center)
                    }
                }
                .padding(.horizontal, 40)
            }
            
            Spacer()
            
            // Cancel button
            Button("Cancel Export") {
                if isSessionExporting {
                    isSessionExporting = false
                } else {
                    exportEngine.cancelExport()
                }
                onDismiss()
            }
            .font(.body)
            .foregroundStyle(.red)
            .padding(.bottom, 32)
        }
    }

    // ENHANCED: Video marker loading and summary
    private var hasVideoMarkers: Bool {
        !videoMarkers.isEmpty
    }
    
    private var totalMarkerCount: Int {
        videoMarkers.values.reduce(0) { $0 + $1.count }
    }
    
    @ViewBuilder
    private var markerSummaryView: some View {
        VStack(spacing: 12) {
            HStack {
                Image(systemName: "flag.filled.and.flag.crossed")
                    .font(.title2)
                    .foregroundStyle(.orange)
                
                Text("\(totalMarkerCount) markers across \(videoMarkers.count) takes")
                    .font(.body)
                    .foregroundStyle(.white)
                
                Spacer()
            }
            
            ScrollView(.horizontal, showsIndicators: false) {
                HStack(spacing: 8) {
                    ForEach(Array(videoMarkers.keys), id: \.self) { takeID in
                        if let markers = videoMarkers[takeID],
                           let take = takes.first(where: { $0.id.uuidString == takeID }) {
                            MarkerPreviewBadge(take: take, markers: markers)
                        }
                    }
                }
                .padding(.horizontal, 4)
            }
        }
        .padding(16)
        .background(
            RoundedRectangle(cornerRadius: 12)
                .fill(Color.orange.opacity(0.1))
                .overlay(
                    RoundedRectangle(cornerRadius: 12)
                        .stroke(Color.orange.opacity(0.3), lineWidth: 1)
                )
        )
    }
    
    // ENHANCED: Load video markers for all takes
    private func loadVideoMarkers() {
        loadingMarkers = true
        
        Task { @MainActor in
            var loadedMarkers: [String: [VideoMarker]] = [:]
            
            for take in takes {
                // STEP 2B: Use passed session data directly instead of SessionManager
                if let projectTake = session.takes.first(where: { projectTake in
                    projectTake.filePath == take.filePath ||
                    projectTake.filePath.hasSuffix(take.fileName) ||
                    URL(fileURLWithPath: projectTake.filePath).lastPathComponent == take.fileName
                }) {
                    // Convert TakeVideoMarkers to VideoMarkers
                    let markers = projectTake.videoMarkers.map { takeMarker in
                        VideoMarker(
                            timestamp: takeMarker.timestamp,
                            title: takeMarker.title,
                            description: takeMarker.description,
                            type: VideoMarker.MarkerType(rawValue: takeMarker.type.rawValue) ?? .note
                        )
                    }
                    
                    if !markers.isEmpty {
                        loadedMarkers[take.id.uuidString] = markers
                    }
                }
            }
            
            videoMarkers = loadedMarkers
            loadingMarkers = false
            
            // Update export options to include markers by default if any exist
            if hasVideoMarkers && !exportOptions.includeVideoMarkers {
                exportOptions.includeVideoMarkers = true
            }
            
            print("📍 ExportManager: Loaded markers for \(videoMarkers.count) takes")
        }
    }

    // SURGICAL FIX: Replace ExportEngine call with SessionExportManager
    private func performExport() {
        print("🚀 SURGICAL FIX: Using SessionExportManager instead of ExportEngine")
        print("🚀 ExportManager: Starting export with \(goodTakes.count) good takes")
        print("🚀 ExportManager: Good takes: \(goodTakes.map { $0.fileName }.joined(separator: ", "))")

        // SURGICAL FIX: Convert to SessionExportManager format
        isSessionExporting = true
        sessionExportProgress = 0.0
        currentExportOperation = "Preparing export with Smart Fill..."
        
        Task {
            do {
                // STEP 1: Convert EnhancedTake to SessionExportManager.TakeMetadata
                let takeMetadataList: [SessionExportManager.TakeMetadata] = try await convertToTakeMetadata(goodTakes)
                
                // STEP 2: Create SmartFillSessionData
                let smartFillSessionData = SmartFillSessionData(session: session, project: project)
                
                // STEP 3: Convert export options to SessionExportManager format
                let sessionExportOptions = convertToSessionExportOptions(exportOptions)
                
                // STEP 4: Generate professional output filename
                let outputFileName = generateOutputFileName()
                
                await MainActor.run {
                    currentExportOperation = "Starting SessionExportManager export..."
                }
                
                print("✅ SURGICAL FIX: Calling SessionExportManager.exportMergedAudition")
                
                // STEP 5: Call SessionExportManager with all the sophisticated features
                SessionExportManager.exportMergedAudition(
                    from: takeMetadataList,
                    sessionData: smartFillSessionData,
                    outputFileName: outputFileName,
                    options: sessionExportOptions,
                    progressHandler: { progress in
                        DispatchQueue.main.async {
                            self.sessionExportProgress = progress
                            self.currentExportOperation = "Processing with SessionExportManager... \(Int(progress * 100))%"
                        }
                    }
                ) { result in
                    DispatchQueue.main.async {
                        self.isSessionExporting = false
                        
                        switch result {
                        case .success(let outputURL):
                            print("✅ SURGICAL FIX: SessionExportManager export SUCCESS")
                            self.handleSessionExportSuccess(outputURL: outputURL)
                            
                        case .failure(let error):
                            print("❌ SURGICAL FIX: SessionExportManager export FAILURE - \(error.localizedDescription)")
                            self.exportError = ExportError.processingFailed(error.localizedDescription)
                        }
                    }
                }
                
            } catch {
                await MainActor.run {
                    self.isSessionExporting = false
                    self.exportError = ExportError.processingFailed("SessionExportManager preparation failed: \(error.localizedDescription)")
                    print("❌ SURGICAL FIX: SessionExportManager preparation failed - \(error)")
                }
            }
        }
    }
    
    // SURGICAL FIX: Convert EnhancedTake to SessionExportManager.TakeMetadata
    // CORRECTED: Only processes video takes - keyframe photos are for thumbnail reference only
    private func convertToTakeMetadata(_ enhancedTakes: [EnhancedTake]) async throws -> [SessionExportManager.TakeMetadata] {
        var takeMetadataList: [SessionExportManager.TakeMetadata] = []
        
        for enhancedTake in enhancedTakes {
            do {
                // CRITICAL FIX: Only process video files - photos are filtered out in processTakes()
                let videoURL = try VideoFileManager.shared.getVideoURL(for: enhancedTake.fileName)
                let asset = AVAsset(url: videoURL)  // Proper AVAsset from video file
                
                print("🎬 Loaded video asset: \(enhancedTake.fileName)")
                
                // Find corresponding ProjectTake for Smart Fill data
                let projectTake = session.takes.first { projectTake in
                    projectTake.filePath == enhancedTake.filePath ||
                    projectTake.filePath.hasSuffix(enhancedTake.fileName) ||
                    URL(fileURLWithPath: projectTake.filePath).lastPathComponent == enhancedTake.fileName
                }
                
                let takeMetadata = SessionExportManager.TakeMetadata(
                    asset: asset,
                    isGood: true, // CRITICAL FIX: All takes in goodTakes are already filtered to be good
                    trimRange: nil, // Could be enhanced later
                    cropRect: nil,  // Could be enhanced later
                    isSlatePhoto: false, // CORRECTION: No photos are processed here anymore
                    thumbnailImage: nil, // CORRECTION: Thumbnails generated by AVAssetImageGenerator from video
                    takeNumber: enhancedTake.takeNumber,
                    fileName: enhancedTake.fileName,
                    capturedOrientation: projectTake?.capturedOrientation,
                    overrideSmartFill: projectTake?.overrideSmartFill,
                    projectTake: projectTake
                )
                
                takeMetadataList.append(takeMetadata)
                print("✅ Converted \(enhancedTake.fileName) to TakeMetadata (isGood: true, video only, Smart Fill: \(projectTake?.capturedOrientation?.rawValue ?? "unknown"))")
                
            } catch {
                print("❌ Failed to convert \(enhancedTake.fileName) to TakeMetadata: \(error)")
                throw error
            }
        }
        
        print("🎯 SessionExportManager will process \(takeMetadataList.count) video takes only")
        print("📸 Keyframe photos remain as separate reference images for thumbnail generation")
        
        return takeMetadataList
    }
    
    // SURGICAL FIX: Convert ExportOptions to SessionExportManager.ExportOptions
    private func convertToSessionExportOptions(_ options: ExportOptions) -> SessionExportManager.ExportOptions {
        // Map quality levels
        let sessionQuality: SessionExportManager.ExportQuality
        switch options.quality {
        case .low:
            sessionQuality = .low
        case .medium:
            sessionQuality = .medium
        case .high:
            sessionQuality = .high
        case .maximum:
            sessionQuality = .maximum
        }
        
        // Map format
        let sessionFormat: SessionExportManager.ExportFormat
        switch options.outputFormat {
        case .mov:
            sessionFormat = .mov
        case .mp4:
            sessionFormat = .mp4
        }
        
        return SessionExportManager.ExportOptions(
            quality: sessionQuality,
            format: sessionFormat,
            includeSlate: false, // CORRECTION: No slate photos - only video content
            slateDuration: 0, // CORRECTION: Not needed - no photo conversion
            includeAudio: true,
            enableSmartFill: true, // Always enable Smart Fill for sophisticated processing
            smartFillSettings: SmartFillSettings(), // Use default Smart Fill settings
            renderSize: CGSize(width: 1920, height: 1080)
        )
    }
    
    // SURGICAL FIX: Generate professional output filename
    private func generateOutputFileName() -> String {
        let projectName = project.title.replacingOccurrences(of: " ", with: "_")
        let sessionTypeName: String
        switch session.type {
        case .selfTape:
            sessionTypeName = "SelfTape"
        case .callback:
            sessionTypeName = "Callback"
        case .chemistryRead:
            sessionTypeName = "ChemistryRead"
        case .inPerson:
            sessionTypeName = "InPerson"
        }
        
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyyMMdd_HHmm"
        let timestamp = dateFormatter.string(from: Date())
        
        return "STS_\(projectName)_\(sessionTypeName)_\(timestamp)"
    }
    
    // SURGICAL FIX: Handle SessionExportManager success
    private func handleSessionExportSuccess(outputURL: URL) {
        // Convert to ExportedFile format that ExportResultsStore expects
        let fileSize = (try? FileManager.default.attributesOfItem(atPath: outputURL.path)[.size] as? Int64) ?? 0
        
        // Convert good takes to UnifiedTake format for ExportedFile
        let unifiedTakes = goodTakes.map { enhancedTake in
            UnifiedTake(from: enhancedTake)
        }
        
        let exportedFile = ExportedFile(
            url: outputURL,
            filename: outputURL.lastPathComponent,
            fileSize: fileSize,
            unifiedTakes: unifiedTakes,
            exportOptions: exportOptions,
            createdAt: Date()
        )
        
        print("✅ SURGICAL FIX: SessionExportManager success converted to ExportedFile")
        
        // Post notification
        NotificationCenter.default.post(
            name: Notification.Name("STSExportCompleted"),
            object: nil,
            userInfo: [
                "sessionID": session.id,
                "projectID": project.id,
                "exportedFiles": 1
            ]
        )
        
        // Set results for display
        exportResultsStore.setExportResults(
            files: [exportedFile],
            project: project,
            session: session,
            originalTakes: goodTakes,
            repository: repository
        )
        
        showingExportResults = true
        print("✅ SURGICAL FIX: Export results displayed")
    }
    
    // CRITICAL FIX: Calculate actual file sizes from filesystem instead of using take.fileSize (which defaults to 0)
    private func calculateEstimatedFileSize() {
        // Show "Calculating..." while we determine actual sizes
        estimatedFileSize = "Calculating..."
        
        Task { @MainActor in
            var totalActualSize: Int64 = 0
            var calculatedTakes = 0
            
            // Calculate actual file sizes from filesystem
            for take in goodTakes {
                do {
                    // CRITICAL: Use VideoFileManager to find the actual video file
                    let videoURL = try VideoFileManager.shared.getVideoURL(for: take.fileName)
                    let resources = try videoURL.resourceValues(forKeys: [.fileSizeKey])
                    let actualFileSize = resources.fileSize ?? 0
                    
                    totalActualSize += Int64(actualFileSize)
                    calculatedTakes += 1
                    
                    print("📊 ExportManager: \(take.fileName) actual size: \(ByteCountFormatter.string(fromByteCount: Int64(actualFileSize), countStyle: .file))")
                    
                } catch {
                    print("❌ ExportManager: Could not get file size for \(take.fileName): \(error)")
                    // Fallback to stored file size if filesystem calculation fails
                    totalActualSize += take.fileSize
                }
            }
            
            let compressionRatio = exportOptions.quality.estimatedCompressionRatio
            let estimatedBytes: Int64
            
            if exportOptions.mode == .separateFiles {
                estimatedBytes = Int64(Double(totalActualSize) * compressionRatio)
            } else {
                // Merged videos are typically smaller due to eliminating duplicate headers/metadata
                estimatedBytes = Int64(Double(totalActualSize) * compressionRatio * 0.9)
            }
            
            estimatedFileSize = ByteCountFormatter.string(fromByteCount: estimatedBytes, countStyle: .file)
            
            print("✅ ExportManager: File size calculation complete - \(calculatedTakes) takes, total: \(ByteCountFormatter.string(fromByteCount: totalActualSize, countStyle: .file)), estimated: \(estimatedFileSize)")
        }
    }
}

// MARK: - Supporting Extensions

extension DateFormatter {
    func then(_ closure: (DateFormatter) -> Void) -> DateFormatter {
        closure(self)
        return self
    }
}

// MARK: - Supporting Views

struct TakePreviewCard: View {
    let take: EnhancedTake
    
    var body: some View {
        VStack(spacing: 4) {
            RoundedRectangle(cornerRadius: 8)
                .fill(take.isSlate ? Theme.primary.opacity(0.3) : Color.white.opacity(0.2))
                .frame(width: 60, height: 40)
                .overlay(
                    VStack(spacing: 2) {
                        Image(systemName: take.isSlate ? "person.crop.rectangle" : "video.fill")
                            .font(.caption)
                            .foregroundStyle(.white)
                        
                        Text(take.formattedDuration)
                            .font(.system(.caption2, design: .monospaced))
                            .foregroundStyle(.white.opacity(0.8))
                    }
                )
            
            Text(take.isSlate ? "Slate" : "Take \(take.takeNumber)")
                .font(.caption2)
                .foregroundStyle(.gray)
        }
    }
}

struct ExportOptionSection<Content: View>: View {
    let title: String
    let content: Content
    
    init(title: String, @ViewBuilder content: () -> Content) {
        self.title = title
        self.content = content()
    }
    
    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text(title)
                .font(.subheadline)
                .fontWeight(.medium)
                .foregroundStyle(.white)
            
            content
        }
    }
}

struct ExportModeRow: View {
    let mode: ExportMode
    let isSelected: Bool
    let onSelect: () -> Void
    
    var body: some View {
        Button(action: onSelect) {
            HStack(spacing: 12) {
                Image(systemName: mode.icon)
                    .font(.body)
                    .foregroundStyle(isSelected ? Theme.primary : .white.opacity(0.6))
                    .frame(width: 24)
                
                VStack(alignment: .leading, spacing: 2) {
                    Text(mode.displayName)
                        .font(.subheadline)
                        .fontWeight(.medium)
                        .foregroundStyle(.white)
                    
                    Text(modeDescription(for: mode))
                        .font(.caption)
                        .foregroundStyle(.gray)
                }
                
                Spacer()
                
                if isSelected {
                    Image(systemName: "checkmark.circle.fill")
                        .font(.body)
                        .foregroundStyle(Theme.primary)
                }
            }
            .padding(.horizontal, 12)
            .padding(.vertical, 10)
            .background(
                RoundedRectangle(cornerRadius: 10)
                    .fill(isSelected ? Theme.primary.opacity(0.2) : Color.white.opacity(0.05))
                    .overlay(
                        RoundedRectangle(cornerRadius: 10)
                            .stroke(isSelected ? Theme.primary : Color.white.opacity(0.1), lineWidth: 1)
                    )
            )
        }
    }
    
    private func modeDescription(for mode: ExportMode) -> String {
        switch mode {
        case .separateFiles:
            return "Export each take as individual files"
        case .mergedVideo:
            return "Combine all takes into one video"
        case .mergedWithSlate:
            return "Slate first, then takes in order"
        }
    }
}

struct ExportQualityRow: View {
    let quality: ExportQuality
    let isSelected: Bool
    let onSelect: () -> Void
    
    var body: some View {
        Button(action: onSelect) {
            HStack(spacing: 12) {
                VStack(spacing: 1) {
                    ForEach(0..<qualityBars(for: quality), id: \.self) { _ in
                        Rectangle()
                            .fill(isSelected ? Theme.primary : .white.opacity(0.6))
                            .frame(width: 3, height: 4)
                    }
                    ForEach(qualityBars(for: quality)..<4, id: \.self) { _ in
                        Rectangle()
                            .fill(.white.opacity(0.2))
                            .frame(width: 3, height: 4)
                    }
                }
                .frame(width: 24, height: 20)
                
                VStack(alignment: .leading, spacing: 2) {
                    Text(quality.displayName)
                        .font(.subheadline)
                        .fontWeight(.medium)
                        .foregroundStyle(.white)
                    
                    Text(qualityDescription(for: quality))
                        .font(.caption)
                        .foregroundStyle(.gray)
                }
                
                Spacer()
                
                if isSelected {
                    Image(systemName: "checkmark.circle.fill")
                        .font(.body)
                        .foregroundStyle(Theme.primary)
                }
            }
            .padding(.horizontal, 12)
            .padding(.vertical, 10)
            .background(
                RoundedRectangle(cornerRadius: 10)
                    .fill(isSelected ? Theme.primary.opacity(0.2) : Color.white.opacity(0.05))
                    .overlay(
                        RoundedRectangle(cornerRadius: 10)
                            .stroke(isSelected ? Theme.primary : Color.white.opacity(0.1), lineWidth: 1)
                    )
            )
        }
    }
    
    private func qualityBars(for quality: ExportQuality) -> Int {
        switch quality {
        case .low: return 1
        case .medium: return 2
        case .high: return 3
        case .maximum: return 4
        }
    }
    
    private func qualityDescription(for quality: ExportQuality) -> String {
        switch quality {
        case .low:
            return "Good for sharing, smaller files"
        case .medium:
            return "Balanced quality and file size"
        case .high:
            return "Best for most uses"
        case .maximum:
            return "No compression, largest files"
        }
    }
}

// MARK: - Marker Preview Badge
struct MarkerPreviewBadge: View {
    let take: EnhancedTake
    let markers: [VideoMarker]
    
    var body: some View {
        VStack(spacing: 4) {
            HStack(spacing: 2) {
                ForEach(Array(markers.prefix(3)), id: \.id) { marker in
                    Circle()
                        .fill(marker.type.color)
                        .frame(width: 4, height: 4)
                }
                
                if markers.count > 3 {
                    Text("+\(markers.count - 3)")
                        .font(.system(size: 8))
                        .foregroundStyle(.white)
                }
            }
            
            Text("T\(take.takeNumber)")
                .font(.caption2)
                .foregroundStyle(.white.opacity(0.8))
        }
        .padding(.horizontal, 8)
        .padding(.vertical, 4)
        .background(
            RoundedRectangle(cornerRadius: 6)
                .fill(Color.black.opacity(0.3))
        )
    }
}

// MARK: - Preview

// STEP 2B: Update preview to include required parameters
#Preview {
    let sampleSession = ProjectSession(
        type: .selfTape,
        takes: [
            ProjectTake(filePath: "/path/to/take1.mov", durationSeconds: 45.2, rating: .good),
            ProjectTake(filePath: "/path/to/slate.mov", durationSeconds: 8.5, rating: .unrated)
        ]
    )
    
    let sampleProject = Project(title: "Test Project")
    
    ExportManagerView(
        takes: [
            EnhancedTake(
                fileName: "Test_Take1.mov",
                projectID: UUID(),
                sessionID: UUID(),
                filePath: "/path/to/take1.mov",
                duration: 45.2,
                fileSize: 15_000_000,
                cameraPosition: "back",
                sceneNumber: 1,
                takeNumber: 1
            ),
            EnhancedTake(
                fileName: "SLATE_Test.mov",
                projectID: UUID(),
                sessionID: UUID(),
                filePath: "/path/to/slate.mov",
                duration: 8.5,
                fileSize: 3_000_000,
                cameraPosition: "back",
                sceneNumber: 1,
                takeNumber: 0,
                isSlate: true
            )
        ],
        project: sampleProject,
        session: sampleSession,
        repository: InMemoryProjectsRepository()  // CRITICAL FIX: Add repository parameter
    ) {
        print("Export dismissed")
    }
}
