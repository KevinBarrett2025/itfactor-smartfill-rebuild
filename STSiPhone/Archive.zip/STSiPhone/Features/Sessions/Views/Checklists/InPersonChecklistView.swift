import SwiftUI

public struct InPersonChecklistView: View {
    @State private var checkedItems: Set<Int> = []
    @Environment(\.dismiss) private var dismiss
    let onComplete: (() -> Void)?
    
    private let inPersonItems = [
        ("Date & Time", "calendar.badge.plus", "Add audition appointment to your calendar app"),
        ("Location & Parking", "map.fill", "Research location, parking options, and travel time"),
        ("Bring Headshot & Resume", "doc.text.fill", "Bring multiple copies, stapled together"),
        ("Know Your Submitted Materials", "person.crop.square.fill", "Review the headshot/resume you originally submitted"),
        ("ID & Health Requirements", "checkmark.shield.fill", "Bring valid ID and check any COVID/health policies"),
        ("Arrive Early", "clock.badge.checkmark", "Plan to arrive 10-15 minutes early, no more")
    ]
    
    public init(onComplete: (() -> Void)? = nil) {
        self.onComplete = onComplete
    }
    
    public var body: some View {
        NavigationStack {
            ZStack {
                BrandBackground()
                    .ignoresSafeArea()
                
                VStack(spacing: 20) {
                    // Header
                    VStack(spacing: 8) {
                        Image(systemName: "building.2.crop.circle.badge.checkmark")
                            .font(.system(size: 60))
                            .foregroundStyle(Theme.primary)
                        
                        Text("In-Person Checklist")
                            .font(Theme.Font.title)
                            .foregroundStyle(Theme.textPrimary)
                        
                        Text("Essential preparation for your in-person audition")
                            .font(Theme.Font.body)
                            .foregroundStyle(.gray)
                            .multilineTextAlignment(.center)
                    }
                    .padding(.top, 20)
                    
                    // Checklist
                    List {
                        ForEach(Array(inPersonItems.enumerated()), id: \.offset) { index, item in
                            ChecklistRow(
                                title: item.0,
                                icon: item.1,
                                description: item.2,
                                isChecked: checkedItems.contains(index)
                            ) {
                                if checkedItems.contains(index) {
                                    checkedItems.remove(index)
                                } else {
                                    checkedItems.insert(index)
                                }
                            }
                            .listRowBackground(Color.clear)
                            .listRowSeparator(.hidden)
                        }
                    }
                    .listStyle(.plain)
                    .scrollContentBackground(.hidden)
                    
                    // Continue Button
                    Button(action: {
                        if let onComplete = onComplete {
                            onComplete()
                        } else {
                            dismiss()
                        }
                    }) {
                        HStack(spacing: 8) {
                            Text(allItemsChecked ? "🏢 Ready for In-Person" : "Continue Anyway")
                                .font(.headline.bold())
                                .padding(.vertical, 8)
                        }
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 18)
                        .background(allItemsChecked ? Color.green.gradient : Color.orange.gradient)
                        .foregroundStyle(.white)
                        .clipShape(Capsule())
                        .shadow(color: .black.opacity(0.20), radius: 8, x: 0, y: 4)
                    }
                    .padding(.horizontal, 24)
                    .padding(.bottom, 34)
                }
            }
            .navigationBarHidden(true)
        }
    }
    
    private var allItemsChecked: Bool {
        checkedItems.count == inPersonItems.count
    }
}

private struct ChecklistRow: View {
    let title: String
    let icon: String
    let description: String
    let isChecked: Bool
    let onToggle: () -> Void
    
    var body: some View {
        Button(action: onToggle) {
            STSCard {
                HStack(spacing: 16) {
                    Image(systemName: icon)
                        .font(.title2)
                        .foregroundStyle(Theme.primary)
                        .frame(width: 30)
                    
                    VStack(alignment: .leading, spacing: 4) {
                        Text(title)
                            .font(Theme.Font.body)
                            .foregroundStyle(Theme.textPrimary)
                        
                        Text(description)
                            .font(Theme.Font.caption)
                            .foregroundStyle(.secondary)
                    }
                    
                    Spacer()
                    
                    Image(systemName: isChecked ? "checkmark.circle.fill" : "circle")
                        .font(.title2)
                        .foregroundStyle(isChecked ? .green : .gray)
                }
            }
        }
        .buttonStyle(PlainButtonStyle())
    }
}

#Preview {
    InPersonChecklistView()
}
