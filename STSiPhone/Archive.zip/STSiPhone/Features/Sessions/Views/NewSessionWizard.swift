import SwiftUI

public struct NewSessionWizard: View {
    let projectID: UUID
    let repo: ProjectsRepository
    let onComplete: () -> Void
    
    @Environment(\.dismiss) private var dismiss
    @State private var currentStep = 1
    @State private var selectedType: SessionType = .selfTape
    @State private var notes: String = ""
    @State private var locationLabel: String = ""
    @State private var locationAddress: String = ""
    @State private var contactName: String = ""
    @State private var contactEmail: String = ""
    
    // NEW: Type-specific fields
    @State private var roleName: String = ""
    @State private var callbackNotes: String = ""
    @State private var parkingInfo: String = ""
    @State private var sessionDate: Date = Date()
    @State private var showingCalendarResult = false
    @State private var calendarMessage: String = ""
    
    // STREAMLINED: Replace SessionRunner with direct ActorMustKnowsView
    @State private var createdSession: ProjectSession?
    @State private var showingActorMustKnows = false
    
    private let totalSteps = 3
    
    public init(projectID: UUID, repo: ProjectsRepository, onComplete: @escaping () -> Void) {
        self.projectID = projectID
        self.repo = repo
        self.onComplete = onComplete
    }
    
    public var body: some View {
        NavigationStack {
            ZStack {
                BrandBackground()
                    .ignoresSafeArea()
                
                VStack(spacing: 0) {
                    // Progress Indicator
                    progressIndicator
                    
                    // Content
                    TabView(selection: $currentStep) {
                        ForEach(1...totalSteps, id: \.self) { step in
                            ScrollView {
                                VStack(spacing: 24) {
                                    stepContent(for: step)
                                }
                                .padding(.horizontal, 24)
                                .padding(.vertical, 32)
                            }
                            .tag(step)
                        }
                    }
                    .tabViewStyle(PageTabViewStyle(indexDisplayMode: .never))
                    
                    // Navigation Button
                    navigationButton
                }
            }
            .navigationTitle("New Session")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    if currentStep > 1 {
                        Button {
                            withAnimation(.easeInOut(duration: 0.3)) {
                                currentStep -= 1
                            }
                        } label: {
                            Image(systemName: "chevron.left")
                                .font(.title2)
                                .foregroundStyle(Theme.textPrimary)
                        }
                    }
                }
                
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("Cancel") {
                        dismiss()
                    }
                    .foregroundStyle(Theme.textPrimary)
                }
            }
            // STREAMLINED: Replace SessionRunner with direct ActorMustKnowsView
            .sheet(isPresented: $showingActorMustKnows) {
                if let session = createdSession, let project = repo.project(by: projectID) {
                    ActorMustKnowsView(
                        project: project,
                        session: session,
                        onComplete: {
                            showingActorMustKnows = false
                            createdSession = nil
                        }
                    )
                }
            }
        }
    }
    
    private var progressIndicator: some View {
        HStack(spacing: 8) {
            ForEach(1...totalSteps, id: \.self) { stepNumber in
                Circle()
                    .fill(stepNumber <= currentStep ? Theme.primary : Theme.surface.opacity(0.3))
                    .frame(width: 12, height: 12)
            }
        }
        .padding(.vertical, 16)
    }
    
    @ViewBuilder
    private func stepContent(for step: Int) -> some View {
        switch step {
        case 1:
            typeStep
        case 2:
            fieldsStep
        case 3:
            readyStep
        default:
            EmptyView()
        }
    }
    
    private var typeStep: some View {
        VStack(alignment: .leading, spacing: 20) {
            VStack(alignment: .leading, spacing: 8) {
                Text("Session Type")
                    .font(Theme.Font.title)
                    .foregroundStyle(Theme.textPrimary)
                
                Text("What type of session would you like to create?")
                    .font(Theme.Font.body)
                    .foregroundStyle(.gray)
            }
            
            VStack(spacing: 16) {
                ForEach(SessionType.allCases, id: \.self) { type in
                    Button {
                        selectedType = type
                    } label: {
                        STSCard {
                            HStack {
                                VStack(alignment: .leading, spacing: 4) {
                                    Text(type.rawValue)
                                        .font(Theme.Font.headline)
                                        .foregroundStyle(Theme.textPrimary)
                                    
                                    Text(type.description)
                                        .font(Theme.Font.caption)
                                        .foregroundStyle(.gray)
                                }
                                
                                Spacer()
                                
                                Image(systemName: selectedType == type ? "checkmark.circle.fill" : "circle")
                                    .font(.title2)
                                    .foregroundStyle(selectedType == type ? Theme.primary : .gray)
                            }
                        }
                    }
                    .buttonStyle(PlainButtonStyle())
                }
            }
        }
    }
    
    private var fieldsStep: some View {
        VStack(alignment: .leading, spacing: 20) {
            VStack(alignment: .leading, spacing: 8) {
                Text("Session Details")
                    .font(Theme.Font.title)
                    .foregroundStyle(Theme.textPrimary)
                
                Text(sessionTypeDescription)
                    .font(Theme.Font.body)
                    .foregroundStyle(.gray)
            }
            
            ScrollView {
                VStack(spacing: 16) {
                    // Type-specific fields
                    switch selectedType {
                    case .selfTape:
                        // Different Role flow
                        STSCard {
                            VStack(alignment: .leading, spacing: 12) {
                                Text("Role Details")
                                    .font(Theme.Font.headline)
                                    .foregroundStyle(Theme.textPrimary)
                                
                                TextField("Role name (if different from project)", text: $roleName)
                                    .textFieldStyle(.roundedBorder)
                                
                                Text("💡 Leave blank if same role as project")
                                    .font(Theme.Font.caption)
                                    .foregroundStyle(.secondary)
                            }
                        }
                        
                    case .callback:
                        // Callback flow
                        STSCard {
                            VStack(alignment: .leading, spacing: 12) {
                                Text("Callback Notes")
                                    .font(Theme.Font.headline)
                                    .foregroundStyle(Theme.textPrimary)
                                
                                TextField("Notes from casting director", text: $callbackNotes, axis: .vertical)
                                    .textFieldStyle(.roundedBorder)
                                    .lineLimit(3...6)
                            }
                        }
                        
                        STSCard {
                            VStack(alignment: .leading, spacing: 12) {
                                Text("New Sides")
                                    .font(Theme.Font.headline)
                                    .foregroundStyle(Theme.textPrimary)
                                
                                Button {
                                    // TODO: Implement sides upload
                                    print("📄 Upload callback sides")
                                } label: {
                                    HStack(spacing: 8) {
                                        Image(systemName: "doc.badge.plus")
                                            .foregroundStyle(Theme.primary)
                                        Text("Upload Callback Sides")
                                            .font(Theme.Font.body)
                                            .foregroundStyle(Theme.primary)
                                    }
                                    .padding(.vertical, 8)
                                    .padding(.horizontal, 12)
                                    .background(Theme.surface.opacity(0.3))
                                    .clipShape(Capsule())
                                }
                                
                                Text("📄 Upload any new sides received for callback")
                                    .font(Theme.Font.caption)
                                    .foregroundStyle(.secondary)
                            }
                        }
                        
                    case .inPerson, .chemistryRead:
                        // In-Person flow
                        STSCard {
                            VStack(alignment: .leading, spacing: 12) {
                                Text("Location Details")
                                    .font(Theme.Font.headline)
                                    .foregroundStyle(Theme.textPrimary)
                                
                                TextField("Venue/Office name", text: $locationLabel)
                                    .textFieldStyle(.roundedBorder)
                                
                                TextField("Full address", text: $locationAddress)
                                    .textFieldStyle(.roundedBorder)
                            }
                        }
                        
                        STSCard {
                            VStack(alignment: .leading, spacing: 12) {
                                Text("Date & Time")
                                    .font(Theme.Font.headline)
                                    .foregroundStyle(Theme.textPrimary)
                                
                                DatePicker("Audition Date & Time", selection: $sessionDate, displayedComponents: [.date, .hourAndMinute])
                                    .datePickerStyle(.compact)
                            }
                        }
                        
                        STSCard {
                            VStack(alignment: .leading, spacing: 12) {
                                Text("Parking Information")
                                    .font(Theme.Font.headline)
                                    .foregroundStyle(Theme.textPrimary)
                                
                                TextField("Parking instructions, costs, or alternatives", text: $parkingInfo, axis: .vertical)
                                    .textFieldStyle(.roundedBorder)
                                    .lineLimit(2...4)
                                
                                Text("🚗 Help future you find parking easily")
                                    .font(Theme.Font.caption)
                                    .foregroundStyle(.secondary)
                            }
                        }
                    }
                    
                    // Universal notes field
                    STSCard {
                        VStack(alignment: .leading, spacing: 12) {
                            Text("Additional Notes")
                                .font(Theme.Font.headline)
                                .foregroundStyle(Theme.textPrimary)
                            
                            TextField("Session notes (optional)", text: $notes, axis: .vertical)
                                .textFieldStyle(.roundedBorder)
                                .lineLimit(3...6)
                        }
                    }
                }
            }
        }
    }
    
    private var sessionTypeDescription: String {
        switch selectedType {
        case .selfTape:
            return "Recording a different role or additional take"
        case .callback:
            return "Follow-up session with casting director"
        case .inPerson:
            return "On-location audition appointment"
        case .chemistryRead:
            return "Reading with other actors at casting"
        }
    }

    private var readyStep: some View {
        VStack(alignment: .center, spacing: 32) {
            Image(systemName: sessionTypeIcon)
                .font(.system(size: 80))
                .foregroundStyle(Theme.primary)
            
            VStack(spacing: 16) {
                Text("Ready to Record")
                    .font(Theme.Font.title)
                    .foregroundStyle(Theme.textPrimary)
                
                Text("You'll start with the preparation checklist")
                    .font(Theme.Font.body)
                    .foregroundStyle(.gray)
                    .multilineTextAlignment(.center)
            }
            
            STSCard {
                VStack(alignment: .leading, spacing: 12) {
                    sessionSummaryView
                }
            }
        }
        .alert("Calendar Event", isPresented: $showingCalendarResult) {
            Button("OK") {}
        } message: {
            Text(calendarMessage)
        }
    }
    
    @ViewBuilder
    private var sessionSummaryView: some View {
        HStack {
            Text("Type:")
                .font(Theme.Font.caption)
                .foregroundStyle(.secondary)
            Spacer()
            Text(selectedType.rawValue)
                .font(Theme.Font.body)
                .foregroundStyle(Theme.textPrimary)
        }
        
        if !roleName.isEmpty {
            HStack {
                Text("Role:")
                    .font(Theme.Font.caption)
                    .foregroundStyle(.secondary)
                Spacer()
                Text(roleName)
                    .font(Theme.Font.body)
                    .foregroundStyle(Theme.textPrimary)
            }
        }
        
        if !callbackNotes.isEmpty {
            VStack(alignment: .leading, spacing: 4) {
                Text("Callback Notes:")
                    .font(Theme.Font.caption)
                    .foregroundStyle(.secondary)
                Text(callbackNotes)
                    .font(Theme.Font.body)
                    .foregroundStyle(Theme.textPrimary)
            }
        }
        
        if !locationLabel.isEmpty {
            HStack {
                Text("Location:")
                    .font(Theme.Font.caption)
                    .foregroundStyle(.secondary)
                Spacer()
                Text(locationLabel)
                    .font(Theme.Font.body)
                    .foregroundStyle(Theme.textPrimary)
            }
        }
        
        if selectedType == .inPerson || selectedType == .chemistryRead {
            HStack {
                Text("Date:")
                    .font(Theme.Font.caption)
                    .foregroundStyle(.secondary)
                Spacer()
                Text(sessionDate.formatted(date: .abbreviated, time: .shortened))
                    .font(Theme.Font.body)
                    .foregroundStyle(Theme.textPrimary)
            }
        }
        
        if !parkingInfo.isEmpty {
            VStack(alignment: .leading, spacing: 4) {
                Text("Parking:")
                    .font(Theme.Font.caption)
                    .foregroundStyle(.secondary)
                Text(parkingInfo)
                    .font(Theme.Font.body)
                    .foregroundStyle(Theme.textPrimary)
            }
        }
    }
    
    private var sessionTypeIcon: String {
        switch selectedType {
        case .selfTape:
            return "video.fill"
        case .callback:
            return "arrow.triangle.2.circlepath"
        case .inPerson:
            return "building.2.fill"
        case .chemistryRead:
            return "person.3.fill"
        }
    }

    private var navigationButton: some View {
        VStack {
            if currentStep < totalSteps {
                BrandedPrimaryButton(
                    label: nextButtonTitle,
                    icon: nextButtonIcon
                ) {
                    withAnimation(.easeInOut(duration: 0.3)) {
                        currentStep += 1
                    }
                }
            } else {
                BrandedPrimaryButton(
                    label: "Create Session",
                    icon: "video.fill"
                ) {
                    saveSession()
                }
            }
        }
        .padding(.bottom, 34)
    }
    
    private var nextButtonTitle: String {
        switch currentStep {
        case 1:
            return "Add Details"
        case 2:
            return "Review Session"
        default:
            return "Continue"
        }
    }
    
    private var nextButtonIcon: String {
        switch currentStep {
        case 1:
            return "pencil"
        case 2:
            return "checkmark.circle.fill"
        default:
            return "chevron.right"
        }
    }
    
    private func saveSession() {
        let session = buildSession()
        repo.append(session: session, to: projectID)
        
        // Add calendar event for in-person sessions
        if selectedType == .inPerson || selectedType == .chemistryRead {
            addCalendarEvent(for: session)
        }
        
        // STREAMLINED: Store session and show ActorMustKnowsView directly
        createdSession = session
        showingActorMustKnows = true
        
        onComplete()
        dismiss()
    }
    
    private func buildSession() -> ProjectSession {
        var location: LocationInfo?
        if !locationLabel.isEmpty {
            location = LocationInfo(
                label: locationLabel,
                address: locationAddress.isEmpty ? nil : locationAddress
            )
        }
        
        var contact: Contact?
        if !contactName.isEmpty {
            contact = Contact(
                name: contactName,
                email: contactEmail.isEmpty ? nil : contactEmail
            )
        }
        
        return ProjectSession(
            type: selectedType,
            date: selectedType == .inPerson || selectedType == .chemistryRead ? sessionDate : Date(),
            location: location,
            contact: contact,
            notes: notes.isEmpty ? nil : notes,
            roleName: roleName.isEmpty ? nil : roleName,
            callbackNotes: callbackNotes.isEmpty ? nil : callbackNotes,
            parkingInfo: parkingInfo.isEmpty ? nil : parkingInfo
        )
    }
    
    private func addCalendarEvent(for session: ProjectSession) {
        // Get project title for calendar event
        guard let project = repo.project(by: projectID) else { return }
        
        CalendarHelper.addAuditionEvent(
            projectTitle: project.title,
            roleName: session.roleName ?? project.roles.first?.name,
            sessionType: session.type,
            date: session.date,
            location: session.location?.label,
            address: session.location?.address,
            parkingInfo: session.parkingInfo
        ) { success, message in
            calendarMessage = message ?? (success ? "Event added to calendar" : "Failed to add calendar event")
            showingCalendarResult = true
        }
    }
}

extension SessionType {
    var description: String {
        switch self {
        case .selfTape:
            return "Record audition at your location"
        case .callback:
            return "Follow-up audition with casting"
        case .inPerson:
            return "On-location audition or meeting"
        case .chemistryRead:
            return "Reading with other actors"
        }
    }
    
    var detailedDescription: String {
        switch self {
        case .selfTape:
            return "Recording a different role or additional take"
        case .callback:
            return "Follow-up session with casting director"
        case .inPerson:
            return "On-location audition appointment"
        case .chemistryRead:
            return "Reading with other actors at casting"
        }
    }
}
