import SwiftUI

// CRITICAL FIX: Add ProjectSessionData struct to eliminate @State capture bug

public struct NewProjectWizard: View {
    @Environment(\.dismiss) private var dismiss
    @State private var vm = NewProjectViewModel()
    @State private var repsVM = RepsViewModel()
    @State private var currentStep = 1
    private let totalSteps = 3
    
    // Additional fields from handoff
    @State private var projectType = "Feature"
    @State private var shootDate = Date()
    
    // File import state
    @State private var showFileImporter = false
    @State private var importType: ImportType = .breakdown
    @State private var importStatus: ImportStatus = .idle
    @State private var sidesFileName: String? = nil
    @State private var breakdownFileName: String? = nil
    
    // 🚨 CRITICAL FIX: Enhanced @FocusState management to eliminate keyboard lag and input session errors
    @FocusState private var focusedField: FocusableField?
    
    // FIXED: Use shared ProjectSessionData instead of separate @State variables to eliminate capture bug
    @State private var projectSessionData: ProjectSessionData?
    
    var onSave: (Project) -> Void
    
    public init(onSave: @escaping (Project) -> Void) {
        self.onSave = onSave
    }
    
    private enum ImportType {
        case sides
        case breakdown
    }
    
    private enum ImportStatus {
        case idle
        case importing
        case success(String)
        case error(String)
    }
    
    // CRITICAL FIX: Enhanced FocusableField enum for proper keyboard focus management
    private enum FocusableField: CaseIterable {
        case title, roleName, castingOffice, castingDirector
    }
    
    public var body: some View {
        NavigationStack {
            ZStack {
                BrandBackground()
                    .ignoresSafeArea()
                
                VStack(spacing: 0) {
                    // Progress Indicator
                    progressIndicator
                    
                    // Content with swipe navigation
                    TabView(selection: $currentStep) {
                        ForEach(1...totalSteps, id: \.self) { step in
                            ScrollView {
                                VStack(spacing: 16) {
                                    stepContent(for: step)
                                }
                                .padding(.horizontal, 24)
                                .padding(.vertical, 32)
                            }
                            .tag(step)
                        }
                    }
                    .tabViewStyle(PageTabViewStyle(indexDisplayMode: .never))
                    
                    // Navigation Button
                    navigationButton
                }
            }
            .navigationTitle("New Project")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    if currentStep > 1 {
                        Button {
                            // FIXED: Add haptic feedback and ensure smooth animation
                            let impactFeedback = UIImpactFeedbackGenerator(style: .light)
                            impactFeedback.impactOccurred()
                            
                            withAnimation(.easeInOut(duration: 0.3)) {
                                currentStep -= 1
                            }
                        } label: {
                            Image(systemName: "chevron.left")
                                .font(.title2)
                                .foregroundStyle(Theme.textPrimary)
                        }
                    }
                }
                
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("Cancel") {
                        // 🚨 CRITICAL FIX: Dismiss keyboard before closing to prevent constraint conflicts
                        focusedField = nil
                        dismiss()
                    }
                    .foregroundStyle(Theme.textPrimary)
                }
                
                // 🚨 ENHANCED: Safe keyboard toolbar to prevent width=0 constraint conflicts
                ToolbarItemGroup(placement: .keyboard) {
                    // CRITICAL FIX: Only show keyboard toolbar when focused field exists
                    // This prevents toolbar creation when container width = 0
                    if focusedField != nil {
                        HStack(spacing: 16) {
                            Button("Previous") {
                                focusPreviousField()
                            }
                            .disabled(!canFocusPrevious())
                            .foregroundColor(!canFocusPrevious() ? .gray : .blue)
                            
                            Spacer()
                            
                            Button("Next") {
                                focusNextField()
                            }
                            .disabled(!canFocusNext())
                            .foregroundColor(!canFocusNext() ? .gray : .blue)
                            
                            Spacer()
                            
                            Button("Done") {
                                // 🚨 FIX: Use animation to prevent abrupt keyboard dismissal
                                withAnimation(.easeInOut(duration: 0.2)) {
                                    focusedField = nil
                                }
                            }
                            .fontWeight(.medium)
                            .foregroundColor(.blue)
                        }
                        // 🚨 CONSTRAINT FIX: Ensure minimum width and safe frame to prevent 0-width constraint conflicts
                        .frame(minWidth: 200, minHeight: 44)
                        .background(Color.clear) // Ensure background exists for proper sizing
                    }
                }
            }
            // 🚨 CRITICAL FIX: Enhanced keyboard management for iOS 17+
            .ignoresSafeArea(.keyboard, edges: .bottom)
            // ENHANCED: Safer keyboard dismissal with constraint-friendly approach
            .onTapGesture {
                // 🚨 FIX: Move heavy work off main thread to prevent keyboard dismissal stall
                Task { @MainActor in
                    withAnimation(.easeInOut(duration: 0.2)) {
                        focusedField = nil
                    }
                }
            }
            // ENHANCED: Modern keyboard handling
            .scrollDismissesKeyboard(.interactively)
        }
        // FIXED: Use .sheet(item:) with shared ProjectSessionData to eliminate @State capture bug
        .sheet(item: $projectSessionData, onDismiss: {
            projectSessionData = nil
        }) { data in
            CameraCaptureView(
                project: data.project,
                session: data.session,
                onComplete: {
                    // Complete session - save project and dismiss
                    projectSessionData = nil
                    onSave(data.project)
                    dismiss()
                }
            )
            .interactiveDismissDisabled(true)
        }
    }
    
    private var progressIndicator: some View {
        HStack(spacing: 8) {
            ForEach(1...totalSteps, id: \.self) { stepNumber in
                Circle()
                    .fill(stepNumber <= currentStep ? Theme.primary : Theme.surface.opacity(0.3))
                    .frame(width: 12, height: 12)
            }
        }
        .padding(.vertical, 16)
    }
    
    @ViewBuilder
    private func stepContent(for step: Int) -> some View {
        switch step {
        case 1:
            projectDetailsStep
        case 2:
            representationAndScenesStep
        case 3:
            reviewProjectStep
        default:
            EmptyView()
        }
    }
    
    // MARK: - Step 1: Project Details - REDESIGNED WITH SAFER FOCUS HANDLING
    private var projectDetailsStep: some View {
        VStack(alignment: .leading, spacing: 24) {
            // REDESIGNED: Clean professional header (removed enterprise badge)
            VStack(alignment: .leading, spacing: 8) {
                Text("PRODUCTION DETAILS")
                    .font(.system(size: 11, weight: .bold, design: .monospaced))
                    .foregroundStyle(.orange)
                    .tracking(1)
                
                Text("Configure your project information")
                    .font(Theme.Font.body)
                    .foregroundStyle(.gray)
            }
            
            // REDESIGNED: Title and Role under Production Details header with enhanced focus management
            VStack(alignment: .leading, spacing: 16) {
                // Project Title - 🚨 FIRST FIELD: Enhanced to prevent focus hang
                VStack(alignment: .leading, spacing: 8) {
                    HStack {
                        Text("TITLE")
                            .font(.system(size: 10, weight: .bold, design: .monospaced))
                            .foregroundStyle(.orange)
                        
                        Spacer()
                        
                        if !vm.title.isEmpty {
                            Text("✓")
                                .font(.caption)
                                .foregroundStyle(.green)
                        }
                    }
                    
                    // 🚨 CRITICAL FIX: Enhanced first text field with safe focus handling
                    TextField("e.g. Silver Lake Pilot", text: $vm.title)
                        .font(.system(size: 16, weight: .semibold))
                        .foregroundColor(.white)
                        .textFieldStyle(PlainTextFieldStyle())
                        .padding(.vertical, 12)
                        .padding(.horizontal, 16)
                        .background(
                            RoundedRectangle(cornerRadius: 8)
                                .fill(Color.black.opacity(0.4))
                                .overlay(
                                    RoundedRectangle(cornerRadius: 8)
                                        .stroke(!vm.title.isEmpty ? .green.opacity(0.6) : .white.opacity(0.2), lineWidth: 1)
                                )
                        )
                        .focused($focusedField, equals: .title)
                        // 🚨 FIX: Move any "on focus" heavy work off main thread
                        .onChange(of: focusedField) { oldValue, newValue in
                            if newValue == .title && oldValue != .title {
                                // Any heavy work goes here in background
                                Task.detached(priority: .userInitiated) {
                                    // Example: Pre-fetch data without blocking UI
                                    // let data = await someHeavyOperation()
                                    // await MainActor.run { /* update UI */ }
                                }
                            }
                        }
                }
                
                // Role Name
                VStack(alignment: .leading, spacing: 8) {
                    HStack {
                        Text("ROLE")
                            .font(.system(size: 10, weight: .bold, design: .monospaced))
                            .foregroundStyle(.orange)
                        
                        Spacer()
                        
                        if !vm.roleName.isEmpty {
                            Text("✓")
                                .font(.caption)
                                .foregroundStyle(.green)
                        }
                    }
                    
                    TextField("Detective Ramos", text: $vm.roleName)
                        .font(.system(size: 16, weight: .semibold))
                        .foregroundColor(.white)
                        .textFieldStyle(PlainTextFieldStyle())
                        .padding(.vertical, 12)
                        .padding(.horizontal, 16)
                        .background(
                            RoundedRectangle(cornerRadius: 8)
                                .fill(Color.black.opacity(0.4))
                                .overlay(
                                    RoundedRectangle(cornerRadius: 8)
                                        .stroke(!vm.roleName.isEmpty ? .green.opacity(0.6) : .white.opacity(0.2), lineWidth: 1)
                                )
                        )
                        .focused($focusedField, equals: .roleName)
                }
            }
            
            // REDESIGNED: Fun Project Type with Icons + Schedule side by side with better spacing
            HStack(alignment: .top, spacing: 20) {
                // Project Type with Fun Icons
                VStack(alignment: .leading, spacing: 12) {
                    Text("TYPE")
                        .font(.system(size: 10, weight: .bold, design: .monospaced))
                        .foregroundStyle(.orange)
                    
                    // Fun icon-based project type selector
                    VStack(spacing: 8) {
                        ForEach(projectTypes, id: \.type) { projectTypeOption in
                            Button(action: {
                                vm.projectType = projectTypeOption.type
                            }) {
                                HStack(spacing: 10) {
                                    // Fun icon for each type
                                    Image(systemName: projectTypeOption.icon)
                                        .font(.system(size: 18))
                                        .foregroundStyle(vm.projectType == projectTypeOption.type ? .white : .gray)
                                        .frame(width: 24)
                                    
                                    Text(projectTypeOption.type)
                                        .font(.system(size: 13, weight: .medium))
                                        .foregroundStyle(vm.projectType == projectTypeOption.type ? .white : .gray)
                                    
                                    Spacer()
                                    
                                    if vm.projectType == projectTypeOption.type {
                                        Image(systemName: "checkmark.circle.fill")
                                            .font(.system(size: 14))
                                            .foregroundStyle(.green)
                                    }
                                }
                                .padding(.vertical, 8)
                                .padding(.horizontal, 10)
                                .background(
                                    RoundedRectangle(cornerRadius: 6)
                                        .fill(vm.projectType == projectTypeOption.type ? Color.blue.opacity(0.3) : Color.black.opacity(0.4))
                                        .overlay(
                                            RoundedRectangle(cornerRadius: 6)
                                                .stroke(vm.projectType == projectTypeOption.type ? .blue.opacity(0.8) : .white.opacity(0.2), lineWidth: 1)
                                        )
                                )
                            }
                            .buttonStyle(PlainButtonStyle())
                        }
                    }
                }
                .frame(maxWidth: .infinity)
                
                // Schedule Section - Improved Layout
                VStack(alignment: .leading, spacing: 10) {
                    Text("SCHEDULE")
                        .font(.system(size: 10, weight: .bold, design: .monospaced))
                        .foregroundStyle(.orange)
                    
                    VStack(spacing: 10) {
                        // Submission Due Date - Date and Time on separate lines
                        VStack(alignment: .leading, spacing: 6) {
                            HStack {
                                Text("SUBMISSION DUE")
                                    .font(.system(size: 8, weight: .bold, design: .monospaced))
                                    .foregroundStyle(vm.isAuditionDueSoon ? .red : .yellow)
                                
                                Spacer()
                                
                                if vm.isAuditionDueSoon {
                                    Text("URGENT")
                                        .font(.system(size: 6, weight: .bold, design: .monospaced))
                                        .foregroundStyle(.red)
                                        .padding(.horizontal, 4)
                                        .padding(.vertical, 1)
                                        .background(.red.opacity(0.2), in: Capsule())
                                }
                            }
                            
                            // Date picker - only date
                            DatePicker("", selection: $vm.auditionDueDate, displayedComponents: [.date])
                                .datePickerStyle(.compact)
                                .tint(vm.isAuditionDueSoon ? .red : .yellow)
                                .colorScheme(.dark)
                                .scaleEffect(0.85)
                            
                            // Time picker - separate row under date
                            DatePicker("", selection: $vm.auditionDueDate, displayedComponents: [.hourAndMinute])
                                .datePickerStyle(.compact)
                                .tint(vm.isAuditionDueSoon ? .red : .yellow)
                                .colorScheme(.dark)
                                .scaleEffect(0.85)
                        }
                        .padding(8)
                        .background(
                            RoundedRectangle(cornerRadius: 6)
                                .fill(vm.isAuditionDueSoon ? Color.red.opacity(0.1) : Color.yellow.opacity(0.1))
                                .overlay(
                                    RoundedRectangle(cornerRadius: 6)
                                        .stroke(vm.isAuditionDueSoon ? .red.opacity(0.4) : .yellow.opacity(0.4), lineWidth: 1)
                                )
                        )
                        
                        // Shoot Date - Date Only (no time)
                        VStack(alignment: .leading, spacing: 4) {
                            Text("SHOOT DATE")
                                .font(.system(size: 8, weight: .bold, design: .monospaced))
                                .foregroundStyle(.blue)
                            
                            // Date picker only (no time)
                            DatePicker("", selection: $vm.shootDate, displayedComponents: [.date])
                                .datePickerStyle(.compact)
                                .tint(.blue)
                                .colorScheme(.dark)
                                .scaleEffect(0.85)
                        }
                        .padding(8)
                        .background(
                            RoundedRectangle(cornerRadius: 6)
                                .fill(Color.blue.opacity(0.1))
                                .overlay(
                                    RoundedRectangle(cornerRadius: 6)
                                        .stroke(.blue.opacity(0.4), lineWidth: 1)
                                )
                        )
                    }
                }
                .frame(width: 140)
            }
            .padding(.vertical, 8)
            
            // MOVED: Breakdown upload and days left to bottom
            VStack(spacing: 16) {
                // Breakdown Upload
                VStack(alignment: .leading, spacing: 8) {
                    HStack {
                        Text("BREAKDOWN")
                            .font(.system(size: 10, weight: .bold, design: .monospaced))
                            .foregroundStyle(.orange)
                        
                        Spacer()
                        
                        if breakdownFileName != nil {
                            HStack(spacing: 4) {
                                Text("📎")
                                    .font(.caption)
                                Text("ATTACHED")
                                    .font(.system(size: 8, weight: .bold, design: .monospaced))
                                    .foregroundStyle(.green)
                            }
                        }
                    }
                    
                    Button(action: {
                        focusedField = nil
                        importType = .breakdown
                        showFileImporter = true
                    }) {
                        HStack(spacing: 12) {
                            Image(systemName: "doc.badge.plus")
                                .font(.system(size: 16))
                                .foregroundStyle(.blue)
                            
                            VStack(alignment: .leading, spacing: 2) {
                                Text(breakdownFileName ?? "Upload PDF or TXT")
                                    .font(.system(size: 14, weight: .medium))
                                    .foregroundStyle(breakdownFileName != nil ? .white : .gray)
                                
                                Text("Auto-fill project details")
                                    .font(.system(size: 12))
                                    .foregroundStyle(.gray)
                            }
                            
                            Spacer()
                            
                            Image(systemName: "chevron.right")
                                .font(.system(size: 12))
                                .foregroundStyle(.gray)
                        }
                        .padding(.vertical, 12)
                        .padding(.horizontal, 16)
                        .background(
                            RoundedRectangle(cornerRadius: 8)
                                .fill(Color.black.opacity(0.4))
                                .overlay(
                                    RoundedRectangle(cornerRadius: 8)
                                        .stroke(.white.opacity(0.2), lineWidth: 1)
                                )
                        )
                    }
                    .buttonStyle(PlainButtonStyle())
                }
                
                // Days until due countdown display
                if vm.daysUntilAuditionDue >= 0 {
                    VStack(alignment: .leading, spacing: 8) {
                        HStack {
                            Text("SUBMISSION DUE BY")
                                .font(.system(size: 10, weight: .bold, design: .monospaced))
                                .foregroundStyle(.orange)
                            
                            Spacer()
                            
                            if vm.isAuditionDueSoon {
                                Text("URGENT")
                                    .font(.system(size: 8, weight: .bold, design: .monospaced))
                                    .foregroundStyle(.red)
                                    .padding(.horizontal, 6)
                                    .padding(.vertical, 2)
                                    .background(.red.opacity(0.2), in: Capsule())
                            }
                        }
                        
                        VStack(spacing: 6) {
                            Text("\(vm.daysUntilAuditionDue)")
                                .font(.system(size: 32, weight: .bold, design: .monospaced))
                                .foregroundStyle(vm.isAuditionDueSoon ? .red : .white)
                            
                            Text(vm.daysUntilAuditionDue == 1 ? "DAY LEFT" : "DAYS LEFT")
                                .font(.system(size: 10, weight: .bold, design: .monospaced))
                                .foregroundStyle(.gray)
                        }
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 16)
                        .background(
                            RoundedRectangle(cornerRadius: 8)
                                .fill(Color.black.opacity(0.6))
                                .overlay(
                                    RoundedRectangle(cornerRadius: 8)
                                        .stroke(vm.isAuditionDueSoon ? .red.opacity(0.4) : .white.opacity(0.2), lineWidth: 1)
                                )
                        )
                    }
                }
            }

            // Import status message
            if case .success(let message) = importStatus {
                HStack {
                    Image(systemName: "checkmark.circle.fill")
                        .foregroundStyle(.green)
                    Text(message)
                        .font(.system(size: 12))
                        .foregroundStyle(.green)
                }
                .transition(.opacity.animation(.easeInOut))
            } else if case .error(let message) = importStatus {
                HStack {
                    Image(systemName: "exclamationmark.triangle.fill")
                        .foregroundStyle(.red)
                    Text(message)
                        .font(.system(size: 12))
                        .foregroundStyle(.red)
                }
                .transition(.opacity.animation(.easeInOut))
            }
        }
        .fileImporter(
            isPresented: $showFileImporter,
            allowedContentTypes: [.pdf, .plainText],
            allowsMultipleSelection: false
        ) { result in
            handleFileImport(result: result)
        }
    }

    // MARK: - Project Type Options with Fun Icons
    private var projectTypes: [(type: String, icon: String)] {
        [
            ("Feature", "film.fill"),                    // Film camera for feature film
            ("Short Film", "video.fill"),               // Video camera for short film
            ("Television", "tv.fill"),                  // TV for television
            ("Commercial", "megaphone.fill"),           // Megaphone for commercial
            ("Web Series", "globe"),                    // Globe for web series
            ("Theatre", "theatermasks.fill")            // Theater masks for theatre
        ]
    }
    
    // MARK: - Step 2: Representation and Scenes
    private var representationAndScenesStep: some View {
        VStack(alignment: .leading, spacing: 16) {
            // Header
            VStack(alignment: .leading, spacing: 8) {
                Text("Setup & Organization")
                    .font(Theme.Font.title)
                    .foregroundStyle(Theme.textPrimary)
                
                Text("Configure representation, sides, and scene organization")
                    .font(Theme.Font.body)
                    .foregroundStyle(.gray)
            }
            
            // ENHANCED: Prioritize scenes selection at the top with required indicator
            VStack(alignment: .leading, spacing: 8) {
                HStack {
                    Text("SCENES REQUIRED")
                        .font(.caption)
                        .fontWeight(.bold)
                        .foregroundStyle(.orange)
                    Spacer()
                }
                
                WizardNumberPickerRow(
                    title: "Number of Scenes",
                    subtitle: "How many scenes will you be recording?",
                    number: $vm.numberOfScenes,
                    range: 1...10
                )
            }
            
            // Divider for visual separation
            Rectangle()
                .frame(height: 1)
                .foregroundStyle(.white.opacity(0.2))
                .padding(.vertical, 8)
            
            // Representation row
            if !repsVM.reps.isEmpty {
                WizardPickerRow(
                    title: "Representation",
                    selection: $vm.selectedRepID,
                    options: [(UUID?.none, "No Rep Selected")] + repsVM.reps.map { (UUID?.some($0.id), "\($0.category): \($0.name)") }
                )
            }
            
            // Import sides row
            WizardFileImportRow(
                title: "Import Sides",
                subtitle: "Upload PDF or TXT file",
                fileName: sidesFileName
            ) {
                // CRITICAL FIX: Clear focus before showing file importer
                focusedField = nil
                importType = .sides
                showFileImporter = true
            }
            
            // Import status message
            if case .success(let message) = importStatus {
                Text("✅ \(message)")
                    .font(Theme.Font.caption)
                    .foregroundStyle(.green)
                    .padding(.horizontal)
            } else if case .error(let message) = importStatus {
                Text("❌ \(message)")
                    .font(Theme.Font.caption)
                    .foregroundStyle(.red)
                    .padding(.horizontal)
            }
            
            Spacer()
        }
        .fileImporter(
            isPresented: $showFileImporter,
            allowedContentTypes: [.pdf, .plainText],
            allowsMultipleSelection: false
        ) { result in
            handleFileImport(result: result)
        }
        .onChange(of: vm.selectedRepID) { _, newRepID in
            if let repID = newRepID,
               let selectedRep = repsVM.reps.first(where: { $0.id == repID }) {
                vm.applySelectedRep(selectedRep)
            }
        }
    }
    
    // MARK: - Step 3: Review Project
    private var reviewProjectStep: some View {
        VStack(alignment: .center, spacing: 24) {
            // Header
            VStack(spacing: 16) {
                Image(systemName: "checkmark.seal.fill")
                    .font(.system(size: 80))
                    .foregroundStyle(Theme.primary)
                
                Text("Review Project")
                    .font(Theme.Font.title)
                    .foregroundStyle(Theme.textPrimary)
                
                Text("Verify your production details before recording")
                    .font(Theme.Font.body)
                    .foregroundStyle(.gray)
                    .multilineTextAlignment(.center)
            }
            
            // ENHANCED: Production summary with callsheet styling
            VStack(spacing: 12) {
                WizardDisplayRow(
                    title: "Project Title",
                    value: vm.title.isEmpty ? "Not specified" : vm.title
                )
                
                WizardDisplayRow(
                    title: "Type",
                    value: vm.projectType
                )
                
                WizardDisplayRow(
                    title: "Role",
                    value: vm.roleName.isEmpty ? "Not specified" : vm.roleName
                )

                // ENHANCED: Show both dates with urgency indicators and time information
                WizardDisplayRow(
                    title: "Audition Due",
                    value: vm.auditionDueDate.formatted(date: .abbreviated, time: .shortened) + 
                           (vm.isAuditionDueSoon ? " ⚠️ URGENT" : " (\(vm.daysUntilAuditionDue) days)")
                )
                
                WizardDisplayRow(
                    title: "Shoot Date",
                    value: vm.shootDate.formatted(date: .abbreviated, time: .omitted)
                )
                
                WizardDisplayRow(
                    title: "Scenes",
                    value: vm.numberOfScenes == 1 ? "1 Scene" : "\(vm.numberOfScenes) Scenes"
                )
                
                if let repID = vm.selectedRepID,
                   let rep = repsVM.reps.first(where: { $0.id == repID }) {
                    WizardDisplayRow(title: "Representation", value: "\(rep.category): \(rep.name)")
                }
                
                // Show casting info if available (moved from old page 2)
                if !vm.castingOffice.isEmpty {
                    WizardDisplayRow(title: "Casting Office", value: vm.castingOffice)
                }
                
                if !vm.castingDirector.isEmpty {
                    WizardDisplayRow(title: "Casting Director", value: vm.castingDirector)
                }
                
                if let sidesFile = sidesFileName {
                    WizardDisplayRow(title: "Sides", value: sidesFile)
                }
                
                if let breakdownFile = breakdownFileName {
                    WizardDisplayRow(title: "Breakdown", value: breakdownFile)
                }
            }
            
            Spacer()
        }
    }
    
    // MARK: - Navigation
    private var navigationButton: some View {
        VStack(spacing: 8) {
            // Validation message for required fields
            if currentStep == 1 && !vm.canProceedFromStep1 {
                Text("Project title and role name are required")
                    .font(Theme.Font.caption)
                    .foregroundStyle(.red)
                    .multilineTextAlignment(.center)
            }
            
            if currentStep == 2 && !vm.canProceedFromStep2 {
                Text("Please select number of scenes (1-10)")
                    .font(Theme.Font.caption)
                    .foregroundStyle(.red)
                    .multilineTextAlignment(.center)
            }
            
            if currentStep == totalSteps && !vm.canProceedToRecording {
                Text("Please complete all required fields")
                    .font(Theme.Font.caption)
                    .foregroundStyle(.red)
                    .multilineTextAlignment(.center)
            }
            
            if currentStep < totalSteps {
                BrandedPrimaryButton(
                    label: nextButtonTitle,
                    icon: nextButtonIcon
                ) {
                    withAnimation(.easeInOut(duration: 0.3)) {
                        currentStep += 1
                    }
                }
                .disabled((currentStep == 1 && !vm.canProceedFromStep1) || (currentStep == 2 && !vm.canProceedFromStep2))
                .opacity((currentStep == 1 && !vm.canProceedFromStep1) || (currentStep == 2 && !vm.canProceedFromStep2) ? 0.6 : 1.0)
            } else {
                BrandedPrimaryButton(
                    label: "Begin Recording Session",
                    icon: "video.fill"
                ) {
                    // ENHANCED: Use comprehensive validation
                    guard vm.canProceedToRecording else {
                        print("❌ Cannot proceed - validation failed")
                        return
                    }
                    
                    // Build project and session in one step
                    let newProject = buildProject()
                    guard let firstSession = newProject.sessions.first else {
                        print("❌ No sessions found in created project")
                        return
                    }
                    
                    print("🎬 Created project: \(newProject.title) with \(newProject.sessions.count) sessions")
                    print("🎬 Project has \(newProject.sceneCount) scenes")
                    print("🎬 Using session: \(firstSession.id) of type \(firstSession.type.rawValue)")
                    
                    // FIXED: Set ProjectSessionData struct to eliminate capture bug
                    projectSessionData = ProjectSessionData(
                        project: newProject,
                        session: firstSession
                    )
                }
                .disabled(!vm.canProceedToRecording)
                .opacity(!vm.canProceedToRecording ? 0.6 : 1.0)
            }
        }
        .padding(.bottom, 34)
    }
    
    private var nextButtonTitle: String {
        switch currentStep {
        case 1:
            return "Setup Organization"
        case 2:
            return "Review Project"
        default:
            return "Continue"
        }
    }
    
    private var nextButtonIcon: String {
        switch currentStep {
        case 1:
            return "gearshape.fill"
        case 2:
            return "checkmark.circle.fill"
        default:
            return "chevron.right"
        }
    }
    
    // MARK: - Focus Management Helper Methods
    private func focusPreviousField() {
        guard let currentField = focusedField else { return }
        let fields = FocusableField.allCases
        if let currentIndex = fields.firstIndex(of: currentField),
           currentIndex > 0 {
            focusedField = fields[currentIndex - 1]
        }
    }
    
    private func focusNextField() {
        guard let currentField = focusedField else {
            focusedField = FocusableField.allCases.first
            return
        }
        let fields = FocusableField.allCases
        if let currentIndex = fields.firstIndex(of: currentField),
           currentIndex < fields.count - 1 {
            focusedField = fields[currentIndex + 1]
        }
    }
    
    private func canFocusPrevious() -> Bool {
        guard let currentField = focusedField else { return false }
        return FocusableField.allCases.first != currentField
    }
    
    private func canFocusNext() -> Bool {
        guard let currentField = focusedField else { return true }
        return FocusableField.allCases.last != currentField
    }
    
    // MARK: - File Import
    private func handleFileImport(result: Result<[URL], Error>) {
        importStatus = .importing
        
        DispatchQueue.global(qos: .userInitiated).async {
            switch result {
            case .success(let urls):
                guard let url = urls.first else {
                    DispatchQueue.main.async {
                        self.importStatus = .error("No file selected")
                    }
                    return
                }
                
                let fileName = url.lastPathComponent
                
                DispatchQueue.main.async {
                    switch self.importType {
                    case .sides:
                        self.sidesFileName = fileName
                        self.importStatus = .success("Sides imported: \(fileName)")
                        
                    case .breakdown:
                        self.breakdownFileName = fileName
                        
                        // Parse breakdown and apply fields
                        let fields = BreakdownParser.parse(from: url)
                        self.vm.applyBreakdownFields(fields)
                        
                        let fieldCount = [
                            fields.projectTitle,
                            fields.roleName,
                            fields.castingOffice,
                            fields.castingDirector
                        ].compactMap { $0 }.filter { !$0.isEmpty }.count
                        
                        if fieldCount > 0 {
                            self.importStatus = .success("Breakdown imported: \(fieldCount) field\(fieldCount == 1 ? "" : "s") filled")
                        } else {
                            self.importStatus = .success("Breakdown imported: \(fileName)")
                        }
                    }
                    
                    // Clear success message after 3 seconds
                    DispatchQueue.main.asyncAfter(deadline: .now() + 3.0) {
                        self.importStatus = .idle
                    }
                }
                
            case .failure(let error):
                DispatchQueue.main.async {
                    self.importStatus = .error("Import failed: \(error.localizedDescription)")
                    
                    // Clear error message after 5 seconds
                    DispatchQueue.main.asyncAfter(deadline: .now() + 5.0) {
                        self.importStatus = .idle
                    }
                }
            }
        }
    }
    
    // MARK: - Project Building
    private func buildProject() -> Project {
        var project = vm.buildProject()
        
        // Apply representation
        if let repID = vm.selectedRepID,
           let rep = repsVM.reps.first(where: { $0.id == repID }) {
            project.representation = Contact(
                name: rep.name,
                email: rep.email,
                phone: rep.phone
            )
        }
        
        return project
    }
}

#Preview {
    NewProjectWizard { project in
        print("Created project: \(project)")
    }
}
