import SwiftUI

struct TakeReviewPage: View {
    // FIXED: Make these mutable so we can reload data
    @State private var currentSession: ProjectSession
    @State private var currentProject: Project
    let repository: ProjectsRepository
    let onSessionAction: (SessionAction) -> Void
    let onTakeAction: (TakeAction, ProjectTake) -> Void

    // NEW: Callback to request video player from parent (centralized modal management) - ENHANCED: Context preservation
    let onVideoPlayerRequest: ([ProjectTake], Int, ViewType, Int?) -> Void

    @Environment(\.dismiss) private var dismiss
    @State private var exportManagerData: ExportManagerData?
    // @State private var actorMustKnowsData: ActorMustKnowsData?
    
    // FIXED: Direct camera launch for resume session
    @State private var showCameraForResume = false

    // FIXED: Centralized delete confirmation management
    @State private var showingDeleteConfirmation = false
    @State private var takeToDelete: ProjectTake?
    
    // FIXED: Centralized share sheet management
    @State private var showingShareSheet = false
    @State private var shareItems: [Any] = []

    // PHASE 1B FIX: Add horizontal tabs state for Scene/Slate/Keyframe selection
    @State private var selectedViewType: ViewType = .scenes
    @State private var selectedSceneNumber: Int = 1
    
    // NEW: Track if we have preserved state to avoid overriding it
    private let hasPreservedState: Bool
    
    // PHASE 2-4: Enhanced UI state management for 60fps animations
    @State private var isExporting = false
    @State private var showingBottomButtons = true
    
    // NEW: Submitted status tracking
    @State private var isSubmitted = false

    // PHASE 1B FIX: Define view types for horizontal tabs
    enum ViewType: CaseIterable {
        case scenes
        case slates
        case keyframes
        
        var displayName: String {
            switch self {
            case .scenes: return "Scenes"
            case .slates: return "Slates"
            case .keyframes: return "Photos"
            }
        }
        
        var icon: String {
            switch self {
            case .scenes: return "video.fill" // FIXED: Use valid SF Symbol
            case .slates: return "tv"
            case .keyframes: return "camera"
            }
        }
    }

    // FIXED: Add initializer to convert let parameters to @State - ENHANCED: Scene state preservation
    init(
        session: ProjectSession,
        project: Project,
        repository: ProjectsRepository,
        initialViewType: ViewType? = nil, // NEW: Optional initial view type
        initialSceneNumber: Int? = nil, // NEW: Optional initial scene number
        onSessionAction: @escaping (SessionAction) -> Void,
        onTakeAction: @escaping (TakeAction, ProjectTake) -> Void,
        onVideoPlayerRequest: @escaping ([ProjectTake], Int, ViewType, Int?) -> Void
    ) {
        self._currentSession = State(initialValue: session)
        self._currentProject = State(initialValue: project)
        self.repository = repository
        self.onSessionAction = onSessionAction
        self.onTakeAction = onTakeAction
        self.onVideoPlayerRequest = onVideoPlayerRequest
        
        // CRITICAL FIX: Initialize with preserved state or defaults and track if we have preserved state
        let viewType = initialViewType ?? .scenes
        let sceneNumber = initialSceneNumber ?? 1
        
        self._selectedViewType = State(initialValue: viewType)
        self._selectedSceneNumber = State(initialValue: sceneNumber)
        
        // CRITICAL FIX: Track if we received preserved state to avoid overriding it
        self.hasPreservedState = (initialViewType != nil || initialSceneNumber != nil)
    }

    var body: some View {
        NavigationView {
            ZStack {
                BrandBackground()
                    .ignoresSafeArea()

                // PHASE 2-4: Enhanced content layout with proper bottom button spacing
                VStack(spacing: 0) {
                    // Main scrollable content
                    ScrollView {
                        LazyVStack(spacing: Theme.Layout.cardSpacing) {
                            sessionInfoHeader
                            // ENHANCED: SmartFill status indicator for background processing feedback
                            SmartFillStatusIndicator(sessionID: currentSession.id)
                            
                            // PHASE 1B FIX: Add horizontal Scene/Slate/Keyframe tabs
                            horizontalTabs
                            
                            // PHASE 1B FIX: Show content based on selected tab
                            if selectedViewType == .scenes {
                                if !originalTakes.isEmpty {
                                    sceneBasedTakeSection
                                }
                            } else if selectedViewType == .slates {
                                if !slateTakes.isEmpty {
                                    takeSection(
                                        title: "Slates",
                                        takes: slateTakes,
                                        icon: "tv",
                                        color: .purple
                                    )
                                }
                            } else if selectedViewType == .keyframes {
                                if !keyframeTakes.isEmpty {
                                    takeSection(
                                        title: "Keyframe Photos",
                                        takes: keyframeTakes,
                                        icon: "camera",
                                        color: .orange
                                    )
                                }
                            }

                            // PHASE 1B FIX: Always show deliverables at bottom regardless of tab
                            if !mergedVideos.isEmpty || !exportedTakes.isEmpty {
                                takeSection(
                                    title: "Deliverables",
                                    takes: deliverables,
                                    icon: "doc.badge.plus",
                                    color: .blue
                                )
                            }
                            
                            // PHASE 2-4: Add bottom padding to prevent content from hiding behind fixed buttons
                            Color.clear
                                .frame(height: calculateBottomContentPadding())
                        }
                        .padding(.horizontal, Theme.Layout.screenPadding)
                        .padding(.top, Theme.Layout.padding)
                    }
                    
                    // PHASE 2-4: Enterprise-grade fixed bottom action bar
                    if showingBottomButtons {
                        enterpriseBottomActionBar
                            .transition(.move(edge: .bottom).combined(with: .opacity))
                    }
                }
            }
            .navigationTitle("\(currentSession.type.rawValue) Session")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    Button(action: {
                        withAnimation(Theme.Animation.modalDismiss) {
                            dismiss()
                        }
                    }) {
                        Image(systemName: "xmark")
                            .font(.system(size: 16, weight: .semibold))
                            .foregroundColor(Theme.textPrimary)
                    }
                }
            }
        }
        // SHEETS: Focused on this session with REMOVED ActorMustKnowsView navigation
        
        // NEW: Direct camera launch for resume session
        .sheet(isPresented: $showCameraForResume) {
            CameraCaptureView(
                project: currentProject,
                session: currentSession,
                onComplete: {
                    showCameraForResume = false
                    // Reload data after camera session
                    reloadSessionData()
                }
            )
            .interactiveDismissDisabled(true)
            // PHASE 1B FIX: Restore scene state when resuming session
            .onAppear {
                let lastActiveScene = getLastSceneWithTakes()
                SessionManager.shared.restoreSceneState(sceneNumber: lastActiveScene)
                print(" Resume session: Restored to scene \(lastActiveScene)")
            }
        }
        
        .sheet(item: $exportManagerData, onDismiss: {
            exportManagerData = nil
            // CRITICAL FIX: Reload fresh data immediately after export completion
            reloadSessionData()
        }) { data in
            ExportManagerView(
                takes: data.takes,
                project: data.project,
                session: data.session,
                repository: data.repository,
                onDismiss: {
                    exportManagerData = nil
                    // CRITICAL FIX: Reload fresh data immediately after export completion
                    reloadSessionData()
                }
            )
        }
        // FIXED: Centralized share sheet management
        .sheet(isPresented: $showingShareSheet) {
            ActivityViewController(activityItems: shareItems)
        }
        // FIXED: Centralized delete confirmation - replace confirmationDialog with alert
        .alert("Delete Take", isPresented: $showingDeleteConfirmation, presenting: takeToDelete) { take in
            Button("Delete", role: .destructive) {
                handleDeleteConfirmed(take)
            }
            Button("Cancel", role: .cancel) {
                takeToDelete = nil
            }
        } message: { take in
            Text("Are you sure you want to permanently delete this take? This action cannot be undone.")
        }
        // FIXED: Add share error alert
        .alert("Share Error", isPresented: $showingShareError) {
            Button("OK", role: .cancel) { }
        } message: {
            Text(shareErrorMessage)
        }
        // CRITICAL FIX: Listen for export completion notifications
        .onReceive(NotificationCenter.default.publisher(for: Notification.Name("STSExportCompleted"))) { notification in
            if let sessionIDFromNotification = notification.userInfo?["sessionID"] as?UUID,
               sessionIDFromNotification == currentSession.id {
                DispatchQueue.main.async {
                    reloadSessionData()
                }
                print(" Reloaded after export completion")
            }
        }
        // CRITICAL FIX: Listen for SmartFill completion notifications
        .onReceive(NotificationCenter.default.publisher(for: Notification.Name("STSSmartFillCompleted"))) { notification in
            if let sessionIDFromNotification = notification.userInfo?["sessionID"] as? UUID,
               sessionIDFromNotification == currentSession.id {
                DispatchQueue.main.async {
                    // CRITICAL FIX: Clear SmartFill cache for affected take
                    if let takeID = notification.userInfo?["takeID"] as? UUID {
                        ProjectTake.invalidateSmartFillCache(for: takeID)
                        print("🔄 TakeReviewPage: Invalidated SmartFill cache for take \(takeID)")
                    }
                    
                    reloadSessionData()
                    print("📱 TakeReviewPage: Reloaded session data after SmartFill completion")
                }
            }
        }
        // CRITICAL FIX: Listen for SmartFill Processing completion notifications
        .onReceive(NotificationCenter.default.publisher(for: Notification.Name("SmartFillProcessingDidComplete"))) { notification in
            if let sessionIDFromNotification = notification.userInfo?["sessionID"] as? UUID,
               sessionIDFromNotification == currentSession.id {
                DispatchQueue.main.async {
                    // CRITICAL FIX: Clear SmartFill cache for affected take
                    if let takeID = notification.userInfo?["takeID"] as? UUID {
                        ProjectTake.invalidateSmartFillCache(for: takeID)
                        print("🔄 TakeReviewPage: Invalidated SmartFill cache for take \(takeID)")
                    }
                    
                    reloadSessionData()
                    print("📱 TakeReviewPage: Reloaded session data after SmartFill processing")
                }
            }
        }
        // ENHANCED: Also listen for individual job status changes for real-time updates
        .onReceive(NotificationCenter.default.publisher(for: Notification.Name("SmartFillJobStatusDidChange"))) { notification in
            if let sessionIDFromNotification = notification.userInfo?["sessionID"] as? UUID,
               sessionIDFromNotification == currentSession.id,
               let status = notification.userInfo?["status"] as? String,
               status == "completed" {
                DispatchQueue.main.async {
                    reloadSessionData()
                }
                print(" Reloaded after SmartFill job completion")
            }
        }
        // ENHANCED: Listen for SessionManager SmartFill completion notifications
        .onReceive(NotificationCenter.default.publisher(for: Notification.Name("STSSmartFillCompleted"))) { notification in
            if let sessionIDFromNotification = notification.userInfo?["sessionID"] as? UUID,
               sessionIDFromNotification == currentSession.id {
                DispatchQueue.main.async {
                    reloadSessionData()
                }
                print(" Reloaded after SessionManager SmartFill update")
            }
        }
        .onReceive(NotificationCenter.default.publisher(for: Notification.Name("STSTakeRatingUpdated"))) { notification in
            if let sessionIDFromNotification = notification.userInfo?["sessionID"] as? UUID,
               sessionIDFromNotification == currentSession.id {
                DispatchQueue.main.async {
                    reloadSessionData()
                }
            }
        }
        // CRITICAL FIX: Reload data when view appears
        .onAppear {
            // CRITICAL FIX: Always reload fresh data when view appears
            reloadSessionData()
            
            // CRITICAL FIX: Only initialize scene selector if no preserved state was provided
            if !hasPreservedState {
                // Only set to last active scene if we're starting fresh (no preserved state)
                selectedSceneNumber = getLastSceneWithTakes()
                print(" No preserved state, initializing to last active scene \(selectedSceneNumber)")
            } else {
                print(" Using preserved state - ViewType: \(selectedViewType), Scene: \(selectedSceneNumber)")
            }
            
            // PHASE 2-4: Animate bottom buttons appearance
            withAnimation(Theme.Animation.comfortable.delay(0.3)) {
                showingBottomButtons = true
            }
        }
    }

    // PHASE 2-4: Calculate appropriate bottom padding to prevent content hiding
    private func calculateBottomContentPadding() -> CGFloat {
        // Account for bottom action bar height + safe area + breathing room
        let actionBarHeight: CGFloat = 140
        let safeAreaBottom = UIApplication.shared.connectedScenes
            .compactMap { $0 as? UIWindowScene }
            .first?.windows.first?.safeAreaInsets.bottom ?? 34
        
        return actionBarHeight + safeAreaBottom + Theme.Layout.padding
    }

    // PHASE 2-4: Enterprise-grade bottom action bar with sleek design
    @ViewBuilder
    private var enterpriseBottomActionBar: some View {
        VStack(spacing: 0) {
            // Subtle gradient overlay for content fade effect
            LinearGradient(
                gradient: Gradient(colors: [
                    Color.clear,
                    Color(red: 0.19, green: 0.05, blue: 0.25).opacity(0.3),
                    Color(red: 0.11, green: 0.11, blue: 0.27).opacity(0.8),
                    Color(red: 0.07, green: 0.08, blue: 0.17)
                ]),
                startPoint: .top,
                endPoint: .bottom
            )
            .frame(height: 20)
            
            // Main action bar content
            VStack(spacing: Theme.Layout.compactPadding) {
                // Professional action buttons with enterprise styling
                if currentSession.type == .selfTape {
                    HStack(spacing: Theme.Layout.compactPadding) {
                        // Resume Session - Always available for self-tapes
                        EnterpriseActionButton(
                            icon: "video.badge.plus",
                            label: "Resume",
                            style: .secondary,
                            isLoading: false
                        ) {
                            handleResumeSession()
                        }
                        
                        // Export & Share - Only if takes exist
                        if !currentSession.takes.isEmpty {
                            EnterpriseActionButton(
                                icon: "square.and.arrow.up.circle.fill",
                                label: "Export & Share",
                                style: .primary,
                                isLoading: isExporting
                            ) {
                                handleExportAndShare()
                            }
                        }
                    }
                }
            }
            .padding(.horizontal, Theme.Layout.screenPadding)
            .padding(.vertical, Theme.Layout.compactPadding)
            .background(
                // Professional glassmorphism background
                RoundedRectangle(cornerRadius: Theme.Layout.cardCornerRadius, style: .continuous)
                    .fill(.ultraThinMaterial)
                    .overlay(
                        RoundedRectangle(cornerRadius: Theme.Layout.cardCornerRadius, style: .continuous)
                            .stroke(Color.white.opacity(0.1), lineWidth: 1)
                    )
            )
            .padding(.horizontal, Theme.Layout.screenPadding)
            .shadow(
                color: Theme.Shadow.dramatic.color,
                radius: Theme.Shadow.dramatic.radius,
                x: Theme.Shadow.dramatic.x,
                y: Theme.Shadow.dramatic.y
            )
        }
        .background(
            // Full-width background to prevent content from showing through
            Rectangle()
                .fill(LinearGradient(
                    gradient: Gradient(colors: [
                        Color(red: 0.19, green: 0.05, blue: 0.25), // deep magenta-purple
                        Color(red: 0.11, green: 0.11, blue: 0.27), // navy blue
                        Color(red: 0.07, green: 0.08, blue: 0.17)  // almost-black
                    ]),
                    startPoint: .top,
                    endPoint: .bottom
                ))
                .ignoresSafeArea(.container, edges: .bottom)
        )
    }

    // CRITICAL FIX: Add method to reload fresh session data
    private func reloadSessionData() {
        // Reload project from repository
        if let freshProject = repository.project(by: currentProject.id) {
            currentProject = freshProject

            // Find the updated session within the fresh project
            if let freshSession = freshProject.sessions.first(where: { $0.id == currentSession.id }) {
                currentSession = freshSession
                print(" Reloaded session with \(freshSession.takes.count) takes")
            }
        }
    }

    // FIXED: Handle centralized delete confirmation with better state management
    private func handleDeleteConfirmed(_ take: ProjectTake) {
        onTakeAction(.deleteTake, take)
        takeToDelete = nil
        
        // CRITICAL FIX: Clear any share state related to the deleted take
        if !shareItems.isEmpty {
            let takeFileName = URL(fileURLWithPath: take.filePath).lastPathComponent
            if let sharedURL = shareItems.first as? URL,
               sharedURL.lastPathComponent == takeFileName {
                shareItems = []
                showingShareSheet = false
            }
        }
        
        // Reload after deletion with longer delay to ensure file system sync
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
            reloadSessionData()
        }
    }

    // FIXED: Handle centralized share action using the WORKING method from ExportResultsView
    private func handleShareAction(for take: ProjectTake) {
        do {
            // CRITICAL FIX: Use effectiveFilePath which prefers SmartFill version if available
            let fileName = URL(fileURLWithPath: take.effectiveFilePath).lastPathComponent
            let videoURL = try VideoFileManager.shared.getVideoURL(for: fileName)
            
            guard FileManager.default.fileExists(atPath: videoURL.path) else {
                print(" TakeReviewPage: Cannot share - video file not found at resolved path: \(videoURL.path)")
                self.showShareError(message: "Video file not found. It may have been deleted.")
                return
            }
            
            // CRITICAL FIX: Use the EXACT same method as ExportResultsView shareAllFiles()
            self.shareItems = [videoURL]
            self.showingShareSheet = true
            
            let versionInfo = take.hasSmartFilledVersion ? "(SmartFill version)" : "(original)"
            print(" TakeReviewPage: Sharing take \(take.takeType.displayName) \(versionInfo) - resolved from \(fileName) to \(videoURL.path)")
            
        } catch {
            print(" TakeReviewPage: VideoFileManager failed to resolve file for sharing: \(error)")
            self.showShareError(message: "Could not locate video file for sharing.")
        }
    }

    // FIXED: Add error handling for share failures
    @State private var showingShareError = false
    @State private var shareErrorMessage = ""
    
    private func showShareError(message: String) {
        shareErrorMessage = message
        showingShareError = true
    }

    @ViewBuilder
    private var sessionInfoHeader: some View {
        STSCard(elevation: .elevated) {
            VStack(alignment: .leading, spacing: Theme.Layout.compactPadding) {
                // Primary header: Project title and role
                VStack(alignment: .leading, spacing: 2) {
                    Text(currentProject.title)
                        .font(Theme.Font.cardTitle)
                        .foregroundStyle(Theme.textPrimary)
                    
                    if let roleName = getRoleName() {
                        Text(roleName)
                            .font(Theme.Font.cardSubtitle)
                            .foregroundStyle(Theme.Colors.secondaryText)
                    }
                    
                    // FIXED: Remove duplicate "Created on" display - keep only one
                    HStack(spacing: 8) {
                        Text(currentSession.type.rawValue)
                            .font(Theme.Font.cardSubtitle)
                            .foregroundStyle(Theme.primary)
                        
                        Text("•")
                            .font(Theme.Font.cardSubtitle)
                            .foregroundStyle(Theme.Colors.secondaryText)
                        
                        Text("Created on \(currentSession.date.formatted(date: .abbreviated, time: .shortened))")
                            .font(Theme.Font.cardSubtitle)
                            .foregroundStyle(Theme.Colors.secondaryText)
                    }
                    
                    // FIXED: Enhanced retake information with better detection and display
                    if hasRetakes {
                        HStack(spacing: 6) {
                            Image(systemName: "arrow.clockwise.circle.fill")
                                .font(.caption)
                                .foregroundStyle(.orange)
                            
                            Text("Retake created on \(latestTakeDate.formatted(date: .abbreviated, time: .shortened))")
                                .font(.caption)
                                .foregroundStyle(.orange)
                                .fontWeight(.medium)
                        }
                        .padding(.top, 2)
                    }
                    
                    // FIXED: Due date with corrected urgency logic and submitted toggle
                    if let auditionDue = currentProject.auditionDueDate {
                        let daysUntilDue = Calendar.current.dateComponents([.day], from: Date(), to: auditionDue).day ?? 0
                        let isUrgent = daysUntilDue == 0  // FIXED: Only urgent when due today (0 days)
                        
                        HStack(spacing: 6) {
                            Image(systemName: isUrgent ? "clock.fill" : "calendar")
                                .font(.caption)
                                .foregroundStyle(isUrgent ? .red : .yellow)
                            
                            Text("Due: \(auditionDue.formatted(date: .abbreviated, time: .shortened))")
                                .font(.caption)
                                .fontWeight(isUrgent ? .medium : .regular)
                                .foregroundStyle(isUrgent ? .red : .yellow)
                            
                            if isUrgent {
                                Text("URGENT")
                                    .font(.system(size: 8, weight: .bold, design: .monospaced))
                                    .foregroundStyle(.white)
                                    .padding(.horizontal, 4)
                                    .padding(.vertical, 1)
                                    .background(.red, in: Capsule())
                            } else if daysUntilDue > 0 {
                                Text("(\(daysUntilDue) day\(daysUntilDue == 1 ? "" : "s"))")
                                    .font(.caption2)
                                    .foregroundStyle(.yellow.opacity(0.8))
                            }
                            
                            // NEW: Submitted checkbox after export/share
                            if hasExportedOrShared {
                                Button(action: {
                                    toggleSubmittedStatus()
                                }) {
                                    HStack(spacing: 4) {
                                        Image(systemName: isSubmitted ? "checkmark.square.fill" : "square")
                                            .font(.caption)
                                        Text("Submitted")
                                            .font(.caption2)
                                            .foregroundStyle(isSubmitted ? .green : .gray)
                                    }
                                }
                                .buttonStyle(PlainButtonStyle())
                            }
                        }
                        .padding(.top, 2)
                    }
                }

                // ENHANCED: Main stats row with good takes counter included
                HStack(spacing: Theme.Layout.compactPadding) {
                    HStack {
                        Image(systemName: "video.fill")
                            .font(.caption)
                        Text("\(currentSession.takes.count) take\(currentSession.takes.count == 1 ? "" : "s")")
                            .font(Theme.Font.smallCaption)
                            .foregroundStyle(Theme.Colors.secondaryText)
                    }
                    
                    // NEW: Good takes counter in main stats row
                    let goodTakesCount = currentSession.takes.filter { $0.rating == .good }.count
                    if goodTakesCount > 0 {
                        HStack {
                            Image(systemName: "checkmark.circle.fill")
                                .font(.caption)
                                .foregroundStyle(.green)
                            Text("\(goodTakesCount) good")
                                .font(Theme.Font.smallCaption)
                                .foregroundStyle(Theme.Colors.secondaryText)
                        }
                    }
                    
                    // Scene count display
                    let sceneCount = getSceneCount()
                    if sceneCount > 1 {
                        HStack {
                            Image(systemName: "video.fill")
                                .font(.caption)
                                .foregroundStyle(.blue)
                            Text("\(sceneCount) scene\(sceneCount == 1 ? "" : "s")")
                                .font(Theme.Font.smallCaption)
                                .foregroundStyle(Theme.Colors.secondaryText)
                        }
                    }
                    
                    // Slate count display
                    let slateCount = getSlateCount()
                    if slateCount > 0 {
                        HStack {
                            Image(systemName: "tv")
                                .font(.caption)
                                .foregroundStyle(.purple)
                            Text("\(slateCount) slate\(slateCount == 1 ? "" : "s")")
                                .font(Theme.Font.smallCaption)
                                .foregroundStyle(Theme.Colors.secondaryText)
                        }
                    }
                    
                    // Keyframe photo count display
                    let photoCount = getKeyframePhotoCount()
                    if photoCount > 0 {
                        HStack {
                            Image(systemName: "camera")
                                .font(.caption)
                                .foregroundStyle(.orange)
                            Text("\(photoCount) photo\(photoCount == 1 ? "" : "s")")
                                .font(Theme.Font.smallCaption)
                                .foregroundStyle(Theme.Colors.secondaryText)
                        }
                    }
                }
            }
        }
    }
    
    // PHASE 1B FIX: Add horizontal tabs view
    @ViewBuilder
    private var horizontalTabs: some View {
        STSCard(elevation: .subtle) {
            VStack(spacing: Theme.Layout.compactPadding) {
                // Tab selector
                HStack(spacing: 0) {
                    ForEach(ViewType.allCases, id: \.self) { viewType in
                        Button(action: {
                            withAnimation(Theme.Animation.selection) {
                                selectedViewType = viewType
                                if viewType == .scenes {
                                    selectedSceneNumber = 1  // Reset to scene 1
                                }
                            }
                        }) {
                            HStack(spacing: Theme.Spacing.xs) {
                                Image(systemName: viewType.icon)
                                    .font(.caption)
                                Text(viewType.displayName)
                                    .font(.caption)
                                    .fontWeight(.medium)
                                
                                // Show counts
                                let count = getCountForViewType(viewType)
                                if count > 0 {
                                    Text("(\(count))")
                                        .font(.caption2)
                                        .foregroundStyle(.secondary)
                                }
                            }
                            .foregroundStyle(selectedViewType == viewType ? .white : Theme.Colors.secondaryText)
                            .padding(.horizontal, Theme.Layout.compactPadding)
                            .padding(.vertical, Theme.Layout.smallPadding)
                            .background(
                                RoundedRectangle(cornerRadius: Theme.Layout.smallCornerRadius)
                                    .fill(selectedViewType == viewType ? Theme.primary : Color.clear)
                            )
                        }
                        .buttonStyle(PlainButtonStyle())
                    }
                }
                
                // Scene selector (only show when scenes tab is selected)
                if selectedViewType == .scenes && getSceneCount() > 1 {
                    HStack(spacing: Theme.Layout.smallPadding) {
                        Text("Scene:")
                            .font(.caption)
                            .foregroundStyle(Theme.Colors.secondaryText)
                        
                        ForEach(1...getSceneCount(), id: \.self) { sceneNum in
                            Button(action: {
                                withAnimation(Theme.Animation.selection) {
                                    selectedSceneNumber = sceneNum
                                }
                            }) {
                                Text("\(sceneNum)")
                                    .font(.caption)
                                    .fontWeight(.medium)
                                    .foregroundStyle(selectedSceneNumber == sceneNum ? .white : Theme.Colors.secondaryText)
                                    .padding(.horizontal, 10)
                                    .padding(.vertical, 6)
                                    .background(
                                        RoundedRectangle(cornerRadius: 6)
                                            .fill(selectedSceneNumber == sceneNum ? Color.blue : Color.clear)
                                            .overlay(
                                                RoundedRectangle(cornerRadius: 6)
                                                    .stroke(Color.blue.opacity(0.3), lineWidth: 1)
                                            )
                                    )
                            }
                            .buttonStyle(PlainButtonStyle())
                        }
                        
                        Spacer()
                    }
                }
            }
        }
    }

    // PHASE 1B FIX: Scene-based take section
    @ViewBuilder
    private var sceneBasedTakeSection: some View {
        let sceneTakes = originalTakes.filter { $0.sceneNumber == selectedSceneNumber }
        
        if !sceneTakes.isEmpty {
            takeSection(
                title: "Scene \(selectedSceneNumber)",
                takes: sceneTakes,
                icon: "video.fill", // FIXED: Use valid SF Symbol
                color: .blue
            )
        } else {
            STSCard(elevation: .subtle) {
                VStack(spacing: Theme.Layout.compactPadding) {
                    Image(systemName: "tv.slash")
                        .font(.system(size: 32))
                        .foregroundStyle(.gray)
                    
                    Text("No takes for Scene \(selectedSceneNumber)")
                        .font(.headline)
                        .foregroundStyle(Theme.textPrimary)
                    
                    Text("Switch to a different scene or record some takes")
                        .font(.caption)
                        .foregroundStyle(Theme.Colors.secondaryText)
                        .multilineTextAlignment(.center)
                }
                .padding()
            }
        }
    }
    
    // PHASE 1B FIX: Helper method to get count for view type
    private func getCountForViewType(_ viewType: ViewType) -> Int {
        switch viewType {
        case .scenes:
            return originalTakes.count
        case .slates:
            return slateTakes.count
        case .keyframes:
            return keyframeTakes.count
        }
    }

    // MARK: - Helper methods for scene organization counts
    private func getSceneCount() -> Int {
        // CRITICAL FIX: Only count scenes with regular takes, not all takes
        let sceneNumbers = Set(currentSession.takes.filter { $0.takeType == .regular && $0.sceneNumber > 0 }.map { $0.sceneNumber })
        return sceneNumbers.count
    }
    
    private func getSlateCount() -> Int {
        return currentSession.takes.filter { $0.takeType == .slate }.count
    }
    
    private func getKeyframePhotoCount() -> Int {
        // This will need to be enhanced when we have photo support in ProjectTake
        // For now, estimate based on UnifiedTake integration
        return currentSession.takes.filter {
            $0.durationSeconds == 0.0 && (
                $0.filePath.lowercased().contains("photo") ||
                $0.filePath.lowercased().contains("keyframe") ||
                $0.takeNotes?.lowercased().contains("photo") == true ||
                $0.takeNotes?.lowercased().contains("keyframe") == true
            )
        }.count
    }

    @ViewBuilder
    private func takeSection(title: String, takes: [ProjectTake], icon: String, color: Color) -> some View {
        STSCard(elevation: .elevated) {
            VStack(alignment: .leading, spacing: Theme.Layout.compactPadding) {
                HStack {
                    Image(systemName: icon)
                        .font(.headline)
                        .foregroundStyle(color)

                    Text(title)
                        .font(Theme.Font.cardTitle)
                        .foregroundStyle(Theme.textPrimary)

                    Spacer()

                    Text("\(takes.count)")
                        .font(Theme.Font.smallCaption)
                        .foregroundStyle(Theme.Colors.secondaryText)
                }

                // ENHANCED: Scene organization display for raw footage
                if title == "Raw Footage" && takes.count > 1 {
                    let sceneGroups = groupTakesByScene(takes)
                    
                    ForEach(Array(sceneGroups.keys.sorted()), id: \.self) { sceneNumber in
                        let sceneTakes = sceneGroups[sceneNumber] ?? []
                        
                        VStack(alignment: .leading, spacing: Theme.Layout.smallPadding) {
                            // Scene header
                            HStack {
                                Image(systemName: "video.fill")
                                    .font(.caption)
                                Text("Scene \(sceneNumber)")
                                    .font(.caption)
                                    .fontWeight(.semibold)
                                    .foregroundStyle(.blue)
                                Spacer()
                                Text("\(sceneTakes.count) take\(sceneTakes.count == 1 ? "" : "s")")
                                    .font(.caption2)
                                    .foregroundStyle(Theme.Colors.secondaryText)
                            }
                            .padding(.horizontal, Theme.Layout.smallPadding)
                            .padding(.vertical, Theme.Layout.tinyPadding)
                            .background(Color.blue.opacity(0.1), in: RoundedRectangle(cornerRadius: 6))
                            
                            // Takes in this scene
                            LazyVStack(spacing: Theme.Layout.tinyPadding) {
                                ForEach(sceneTakes.indices, id: \.self) { index in
                                    let take = sceneTakes[index]
                                    TakeRowSimplified(
                                        take: take,
                                        takeNumber: index + 1,
                                        onAction: { action in
                                            handleTakeAction(action, for: take)
                                        },
                                        onDelete: {
                                            takeToDelete = take
                                            showingDeleteConfirmation = true
                                        },
                                        onShare: {
                                            handleShareAction(for: take)
                                        }
                                    )
                                }
                            }
                        }
                    }
                } else {
                    LazyVStack(spacing: Theme.Layout.tinyPadding) {
                        ForEach(takes.indices, id: \.self) { index in
                            let take = takes[index]
                            TakeRowSimplified(
                                take: take,
                                takeNumber: take.takeType == .merged ? 0 : (index + 1),
                                onAction: { action in
                                    handleTakeAction(action, for: take)
                                },
                                onDelete: {
                                    takeToDelete = take
                                    showingDeleteConfirmation = true
                                },
                                onShare: {
                                    handleShareAction(for: take)
                                }
                            )
                        }
                    }
                }
            }
        }
    }
    
    // NEW: Helper method to group takes by scene
    private func groupTakesByScene(_ takes: [ProjectTake]) -> [Int: [ProjectTake]] {
        return Dictionary(grouping: takes) { $0.sceneNumber }
    }

    // MARK: - Computed Properties - FIXED: Use currentSession
    private var mergedVideos: [ProjectTake] {
        currentSession.takes.filter { $0.takeType == .merged }
    }

    private var originalTakes: [ProjectTake] {
        currentSession.takes.filter { $0.takeType == .regular || $0.takeType == .slate }
    }

    private var exportedTakes: [ProjectTake] {
        currentSession.takes.filter { $0.takeType == .exported }
    }

    // NEW: Combined deliverables section
    private var deliverables: [ProjectTake] {
        // Merged videos first, then exported takes
        let merged = mergedVideos.sorted { $0.createdAt > $1.createdAt }
        let exported = exportedTakes.sorted { $0.createdAt > $1.createdAt }
        return merged + exported
    }
    
    // MARK: - Retake Detection Helpers
    // MARK: - Retake Detection Helpers - SIMPLIFIED to prevent performance issues
    
    // FIXED: Enhanced retake detection with better logic and debug logging
    private var hasRetakes: Bool {
        let sessionTime = currentSession.date.timeIntervalSince1970
        let fiveMinutesLater = sessionTime + 300
        
        let retakesFound = currentSession.takes.contains { take in
            let isRetake = take.createdAt.timeIntervalSince1970 > fiveMinutesLater
            if isRetake {
                print(" Retake detected: \(URL(fileURLWithPath: take.filePath).lastPathComponent) created at \(take.createdAt), session started at \(currentSession.date)")
            }
            return isRetake
        }
        
        if retakesFound {
            print(" Found retakes in session")
        } else {
            print(" No retakes found (session: \(currentSession.date), latest take: \(currentSession.takes.map { $0.createdAt }.max() ?? Date()))")
        }
        
        return retakesFound
    }
    
    // FIXED: Enhanced latest take date with debug logging
    private var latestTakeDate: Date {
        var latestDate = currentSession.date
        
        for take in currentSession.takes {
            if take.createdAt > latestDate {
                latestDate = take.createdAt
                print(" Latest take found: \(URL(fileURLWithPath: take.filePath).lastPathComponent) at \(latestDate)")
            }
        }
        
        print(" latestTakeDate: \(latestDate) (session started: \(currentSession.date))")
        return latestDate
    }

    // PHASE 1B FIX: Add slate and keyframe takes computed properties
    private var slateTakes: [ProjectTake] {
        currentSession.takes.filter { $0.takeType == .slate }.sorted { $0.createdAt < $1.createdAt }
    }
    
    private var keyframeTakes: [ProjectTake] {
        // For now, filter by duration and photo-related filename patterns
        // This will be enhanced when proper photo support is added to ProjectTake
        currentSession.takes.filter {
            $0.durationSeconds == 0.0 && (
                $0.filePath.lowercased().contains("photo") ||
                $0.filePath.lowercased().contains("keyframe") ||
                $0.takeNotes?.lowercased().contains("photo") == true ||
                $0.takeNotes?.lowercased().contains("keyframe") == true
            )
        }.sorted { $0.createdAt < $1.createdAt }
    }

    // MARK: - Action Handlers
    private func handleExportAndShare() {
        // PHASE 2-4: Set loading state with smooth animation
        withAnimation(Theme.Animation.smooth) {
            isExporting = true
        }
        
        let enhancedTakes = convertSessionToEnhancedTakes(currentSession)
        exportManagerData = ExportManagerData(
            project: currentProject,
            session: currentSession,
            takes: enhancedTakes,
            repository: repository
        )
        
        // Reset loading state after a delay
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
            withAnimation(Theme.Animation.smooth) {
                isExporting = false
            }
        }
    }

    private func handleResumeSession() {
        // PHASE 1B FIX: Store current scene state before resuming
        let lastSceneWithTakes = getLastSceneWithTakes()
        
        // CRITICAL FIX: Resume Session should go to camera with restored state
        SessionManager.shared.restoreSceneState(sceneNumber: lastSceneWithTakes)
        showCameraForResume = true
        
        print(" Resume session: Restored to scene \(lastSceneWithTakes) and launching camera")
    }
    
    // PHASE 1B FIX: Helper method to determine the last scene that had takes
    private func getLastSceneWithTakes() -> Int {
        let sceneNumbers = Set(currentSession.takes.filter { $0.takeType == .regular }.map { $0.sceneNumber })
        return sceneNumbers.max() ?? 1
    }

    private func handleTakeAction(_ action: TakeAction, for take: ProjectTake) {
        switch action {
        case .play:
            // CRITICAL FIX: Request video player from parent instead of presenting directly
            launchVideoPlayerViaParent(for: take)
        case .playOriginal:
            // ENHANCED: Play original version specifically (not SmartFill)
            launchVideoPlayerViaParent(for: take, forceOriginal: true)
        case .share:
            // FIXED: Handle share action centrally
            handleShareAction(for: take)
        case .deleteTake:
            // FIXED: Handle delete confirmation centrally
            takeToDelete = take
            showingDeleteConfirmation = true
        case .setRating(_):
             onTakeAction(action, take)
            // Reload after rating changes
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
                reloadSessionData()
            }
        default:
            // Handle other actions through parent callback
            onTakeAction(action, take)
        }
    }

    // CRITICAL FIX: Request video player from parent (centralized modal management)
    private func launchVideoPlayerViaParent(for selectedTake: ProjectTake, forceOriginal: Bool = false) {
        // CRITICAL FIX: Get takes that should be swipeable based on current viewing context
        let contextTakes = getContextualSwipeableTakes()

        // Find the initial index of the selected take within the contextual takes
        let initialIndex = contextTakes.firstIndex(where: { $0.id == selectedTake.id }) ?? 0

        // Request video player from parent with context-appropriate takes and current context
        onVideoPlayerRequest(
            contextTakes,
            initialIndex,
            selectedViewType, // NEW: Pass current view type for preservation
            selectedViewType == .scenes ? selectedSceneNumber : nil // NEW: Pass scene number if applicable
        )

        let versionInfo = forceOriginal ? "(original version)" :
                         selectedTake.hasSmartFilledVersion ? "(SmartFill version preferred)" : "(original)"
        print(" TakeReviewPage: Requesting context-aware video player with \(contextTakes.count) takes from \(getCurrentContextDescription()), starting at index \(initialIndex) \(versionInfo)")
    }

    // CRITICAL FIX: Get takes for current viewing context instead of all takes
    private func getContextualSwipeableTakes() -> [ProjectTake] {
        switch selectedViewType {
        case .scenes:
            // Only show takes for the currently selected scene
            let sceneTakes = originalTakes.filter { $0.sceneNumber == selectedSceneNumber }
            return sceneTakes
        case .slates:
            // Only show slate takes
            return slateTakes
        case .keyframes:
            // Only show keyframe photo takes
            return keyframeTakes
        }
    }
    
    // Helper method to describe current context for debugging
    private func getCurrentContextDescription() -> String {
        switch selectedViewType {
        case .scenes:
            return "Scene \(selectedSceneNumber)"
        case .slates:
            return "Slates"
        case .keyframes:
            return "Keyframe Photos"
        }
    }

    private func handleVideoPlayerAction(_ action: TakeAction, for take: ProjectTake) {
        switch action {
        case .setRating(let rating):
            // Update rating through repository and notify
            if let takeIndex = currentSession.takes.firstIndex(where: { $0.id == take.id }) {
                currentSession.takes[takeIndex].rating = rating

                // CRITICAL FIX: Use the correct repository method
                repository.setUnifiedTakeRating(
                    takeID: take.id,
                    sessionID: currentSession.id,
                    projectID: currentProject.id,
                    rating: rating
                )

                // Post notification for other views to update
                NotificationCenter.default.post(
                    name: Notification.Name("STSTakeRatingUpdated"),
                    object: nil,
                    userInfo: [
                        "takeID": take.id,
                        "sessionID": currentSession.id,
                        "projectID": currentProject.id,
                        "rating": rating.rawValue
                    ]
                )

                print(" TakeReviewPage: Updated rating for \(URL(fileURLWithPath: take.filePath).lastPathComponent) to \(rating.rawValue)")
            }
        case .share:
            // FIXED: Share is now handled at row level, this shouldn't be called
            print(" TakeReviewPage: Share action should be handled at row level")
        default:
            // Forward other actions to parent
            onTakeAction(action, take)
        }
    }

    private func convertSessionToEnhancedTakes(_ session: ProjectSession) -> [EnhancedTake] {
        return session.takes.enumerated().map { index, take in
            EnhancedTake(
                fileName: URL(fileURLWithPath: take.filePath).lastPathComponent,
                projectID: currentProject.id,
                sessionID: session.id,
                filePath: take.filePath,
                duration: take.durationSeconds,
                fileSize: estimateFileSize(for: take.filePath),
                cameraPosition: "back",
                sceneNumber: 1,
                takeNumber: index + 1,
                isSlate: take.filePath.lowercased().contains("slate"),
                createdAt: take.createdAt
            )
        }
    }

    private func estimateFileSize(for filePath: String) -> Int64 {
        if FileManager.default.fileExists(atPath: filePath) {
            do {
                let attributes = try FileManager.default.attributesOfItem(atPath: filePath)
                return attributes[.size] as? Int64 ?? 0
            } catch {
                print(" Could not get file size for \(filePath): \(error)")
            }
        }
        return 0
    }

    private func sessionTypeIcon(for type: SessionType) -> String {
        switch type {
        case .selfTape:
            return "video.fill"
        case .callback:
            return "arrow.triangle.2.circlepath"
        case .inPerson:
            return "building.2.fill"
        case .chemistryRead:
            return "person.3.fill"
        }
    }

    // MARK: - PHASE 2-4:
    // NEW: Helper method to get role name from session or project
    private func getRoleName() -> String? {
        // First try session's roleName
        if let sessionRole = currentSession.roleName, !sessionRole.isEmpty {
            return sessionRole
        }
        
        // If no session role, try to get the first role from the project
        if let firstRole = currentProject.roles.first {
            return firstRole.name
        }
        
        // Debug logging
        print(" Role debug - Session roleName: \(currentSession.roleName ?? "nil"), Project roles: \(currentProject.roles.map { $0.name })")
        
        return nil
    }
    
    private func toggleSubmittedStatus() {
        withAnimation(.easeInOut(duration: 0.2)) {
            isSubmitted.toggle()
        }
        
        // Could store this in UserDefaults or project model for persistence
        // For now, it's just local state
        print(" Project marked as \(isSubmitted ? "submitted" : "not submitted")")
    }
    
    var hasExportedOrShared: Bool {
        return !mergedVideos.isEmpty || !exportedTakes.isEmpty ||
               currentSession.takes.contains { !$0.exportedFromTakeIDs.isEmpty }
    }

    // MARK: - Supporting Views
    struct TakeRowSimplified: View {
        let take: ProjectTake
        let takeNumber: Int
        let onAction: (TakeAction) -> Void
        
        // FIXED: Add callback parameters for centralized delete/share handling
        let onDelete: () -> Void
        let onShare: () -> Void
        
        var body: some View {
            VStack(spacing: 0) {
                // ENHANCED: Main take row (parent)
                mainTakeRow
                
                // 🎯 ENTERPRISE FIX #275: SmartFill sub-item (child) - ALWAYS VISIBLE when exists
                if take.hasSmartFilledVersion {
                    smartFillSubItem
                }
            }
            .onAppear {
                // DEBUG: Print SmartFill status for debugging
            }
        }
        
        @ViewBuilder
        private var mainTakeRow: some View {
            HStack(spacing: Theme.Layout.compactPadding) {
                // ENHANCED: Video thumbnail with parent/child indicator
                videoThumbnail

                // Take info with enhanced scene organization
                takeInfo

                Spacer()

                takeRatingActions
            }
            .padding(Theme.Layout.compactPadding)
            .background(
                RoundedRectangle(cornerRadius: Theme.Layout.smallCornerRadius)
                    .fill(takeRowBackgroundColor)
            )
            .contentShape(Rectangle()) // Define the swipeable area to resolve gesture conflicts
            .swipeActions(edge: .trailing, allowsFullSwipe: false) {
                // ENHANCED: Context-aware share action
                if take.hasSmartFilledVersion {
                    // Share SmartFill version (preferred)
                    Button {
                        onShare()
                    } label: {
                        Label("Share SmartFill", systemImage: "square.and.arrow.up.fill")
                    }
                    .tint(.green)
                    
                    // Share original version
                    Button {
                        shareOriginalVersion()
                    } label: {
                        Label("Share Original", systemImage: "square.and.arrow.up")
                    }
                    .tint(.blue)
                } else {
                    // Standard share action
                    Button {
                        onShare()
                    } label: {
                        Label("Share", systemImage: "square.and.arrow.up.fill")
                    }
                    .tint(.blue)
                }

                // Delete action (red, destructive)
                Button(role: .destructive) {
                    // FIXED: Use callback to parent for centralized delete confirmation
                    onDelete()
                } label: {
                    Label("Delete", systemImage: "trash.fill")
                }
                .tint(.red)
            }
        }
        
        // 🎯 ENTERPRISE FIX #275: Enhanced SmartFill sub-item - ALWAYS VISIBLE with enterprise hierarchy
        @ViewBuilder
        private var smartFillSubItem: some View {
            VStack(spacing: 0) {
                // ENHANCED: Enterprise connecting line with better visual hierarchy
                HStack {
                    Rectangle()
                        .fill(LinearGradient(
                            gradient: Gradient(colors: [
                                Color.green.opacity(0.6),
                                Color.green.opacity(0.2)
                            ]),
                            startPoint: .top,
                            endPoint: .bottom
                        ))
                        .frame(width: 3) // Slightly thicker for enterprise look
                        .padding(.leading, 32)
                    Spacer()
                }
                .frame(height: 12) // More breathing room
                
                // ENHANCED: Enterprise SmartFill sub-row with professional styling
                HStack(spacing: Theme.Layout.compactPadding) {
                    // ENHANCED: Enterprise indent indicator with sophisticated design
                    HStack(spacing: 6) {
                        Rectangle()
                            .fill(LinearGradient(
                                gradient: Gradient(colors: [
                                    Color.green.opacity(0.6),
                                    Color.green.opacity(0.2)
                                ]),
                                startPoint: .leading,
                                endPoint: .trailing
                            ))
                            .frame(width: 3, height: 24) // Taller for enterprise look
                        
                        Rectangle()
                            .fill(LinearGradient(
                                gradient: Gradient(colors: [
                                    Color.green.opacity(0.6),
                                    Color.green.opacity(0.2)
                                ]),
                                startPoint: .leading,
                                endPoint: .trailing
                            ))
                            .frame(width: 16, height: 3) // Professional connector
                        
                        // ENHANCED: Enterprise child indicator
                        Image(systemName: "2.circle.fill")
                            .font(.caption)
                            .foregroundStyle(.green)
                            .background(
                                Circle()
                                    .fill(.white)
                                    .frame(width: 18, height: 18)
                            )
                            .shadow(color: .green.opacity(0.3), radius: 2)
                    }
                    .padding(.leading, 8)
                    
                    // ENHANCED: Enterprise SmartFill thumbnail with premium styling
                    smartFillVideoThumbnail
                    
                    // ENHANCED: Enterprise SmartFill info with professional hierarchy
                    VStack(alignment: .leading, spacing: 4) {
                        HStack(spacing: 8) {
                            Image(systemName: "rectangle.fill.badge.checkmark")
                                .font(.caption)
                                .foregroundStyle(.green)
                            Text("Smart Fill Enhanced")
                                .font(.caption)
                                .fontWeight(.semibold)
                                .foregroundStyle(.green)
                            
                            Spacer()
                            
                            // ENHANCED: Enterprise priority badge
                            Text("EXPORT READY")
                                .font(.caption2)
                                .fontWeight(.bold)
                                .foregroundStyle(.white)
                                .padding(.horizontal, 6)
                                .padding(.vertical, 2)
                                .background(
                                    Capsule()
                                        .fill(LinearGradient(
                                            gradient: Gradient(colors: [.green, .green.opacity(0.8)]),
                                            startPoint: .leading,
                                            endPoint: .trailing
                                        ))
                                )
                        }
                        
                        HStack(spacing: 12) {
                            Text(formattedDuration(take.durationSeconds))
                                .font(.caption2)
                                .foregroundStyle(Theme.Colors.secondaryText)
                            
                            Text("•")
                                .font(.caption2)
                                .foregroundStyle(Theme.Colors.secondaryText)
                            
                            Text("Landscape Optimized")
                                .font(.caption2)
                                .foregroundStyle(.green.opacity(0.8))
                            
                            Spacer()
                            
                            // ENHANCED: Processing status indicator
                            HStack(spacing: 4) {
                                Image(systemName: "checkmark.seal.fill")
                                    .font(.caption2)
                                    .foregroundStyle(.green)
                                Text("Processed")
                                    .font(.caption2)
                                    .foregroundStyle(.green)
                            }
                        }
                    }
                    
                    Spacer()
                    
                    // ENHANCED: Enterprise SmartFill specific actions with premium styling
                    VStack(spacing: 6) {
                        Button {
                            // Play SmartFill version
                            onAction(.play) // This will use effectiveFilePath (SmartFill version)
                        } label: {
                            ZStack {
                                Circle()
                                    .fill(LinearGradient(
                                        gradient: Gradient(colors: [.green, .green.opacity(0.8)]),
                                        startPoint: .topLeading,
                                        endPoint: .bottomTrailing
                                    ))
                                    .frame(width: 32, height: 32)
                                
                                Image(systemName: "play.fill")
                                    .font(.caption)
                                    .foregroundStyle(.white)
                            }
                        }
                        .buttonStyle(PlainButtonStyle())
                        
                        Text("Play")
                            .font(.caption2)
                            .fontWeight(.medium)
                            .foregroundStyle(.green)
                    }
                }
                .padding(Theme.Layout.compactPadding)
                .background(
                    RoundedRectangle(cornerRadius: Theme.Layout.smallCornerRadius)
                        .fill(
                            LinearGradient(
                                gradient: Gradient(colors: [
                                    Color.green.opacity(0.08),
                                    Color.green.opacity(0.03)
                                ]),
                                startPoint: .top,
                                endPoint: .bottom
                            )
                        )
                        .overlay(
                            RoundedRectangle(cornerRadius: Theme.Layout.smallCornerRadius)
                                .stroke(
                                    LinearGradient(
                                        gradient: Gradient(colors: [
                                            Color.green.opacity(0.3),
                                            Color.green.opacity(0.1)
                                        ]),
                                        startPoint: .topLeading,
                                        endPoint: .bottomTrailing
                                    ),
                                    lineWidth: 1.5
                                )
                        )
                        .shadow(color: .green.opacity(0.1), radius: 2, x: 0, y: 1)
                )
                .padding(.horizontal, Theme.Layout.compactPadding)
                .contentShape(Rectangle()) // Define the swipeable area to resolve gesture conflicts
                .onTapGesture {
                    // Play SmartFill version on tap
                    onAction(.play)
                }
                // ENHANCED: Enterprise swipe actions for child item
                .swipeActions(edge: .trailing, allowsFullSwipe: false) {
                    // Priority action: Share SmartFill version
                    Button {
                        onShare() // Shares the SmartFill version
                    } label: {
                        Label("Share Enhanced", systemImage: "square.and.arrow.up.fill")
                    }
                    .tint(.green)
                }
            }
        }

        @ViewBuilder
        private var videoThumbnail: some View {
            Button {
                // ENHANCED: Play original version for parent item
                playOriginalVersion()
            } label: {
                ZStack {
                    // ENHANCED: Always show original thumbnail for parent item with enterprise styling
                    ThumbnailPreviewView(unifiedTake: createUnifiedTakeForOriginalThumbnail())
                        .frame(width: 60, height: 36)
                        .clipShape(RoundedRectangle(cornerRadius: Theme.Layout.smallCornerRadius))
                    
                    // Play overlay for videos only (photos handled by ThumbnailPreviewView)
                    if !isPhotoTake {
                        Image(systemName: "play.fill")
                            .font(.caption)
                            .foregroundStyle(.white)
                            .background(
                                Circle()
                                    .fill(.black.opacity(0.6))
                                    .frame(width: 24, height: 24)
                            )
                    }
                    
                    // 🎯 ENTERPRISE: Enhanced parent indicator badge for SmartFill hierarchy
                    if take.hasSmartFilledVersion {
                        VStack {
                            HStack {
                                ZStack {
                                    Circle()
                                        .fill(.white)
                                        .frame(width: 20, height: 20)
                                    
                                    Image(systemName: "1.circle.fill")
                                        .font(.caption)
                                        .foregroundStyle(.orange)
                                }
                                .shadow(color: .orange.opacity(0.3), radius: 2)
                                
                                Spacer()
                            }
                            Spacer()
                        }
                        .padding(4)
                    }
                }
            }
            .buttonStyle(PlainButtonStyle())
        }

        @ViewBuilder
        private var takeInfo: some View {
            VStack(alignment: .leading, spacing: 2) {
                HStack {
                    if take.takeType == .merged {
                        HStack(spacing: 6) {
                            Image(systemName: "film.stack.fill")
                                .font(.caption)
                            Text(take.takeType.displayName)
                                .font(Theme.Font.cardSubtitle)
                                .fontWeight(.semibold)
                                .foregroundStyle(.green)
                        }
                    } else if take.takeType == .exported {
                        HStack(spacing: 6) {
                            Image(systemName: "square.and.arrow.up.fill")
                                .font(.caption)
                            Text(take.takeType.displayName)
                                .font(Theme.Font.cardSubtitle)
                                .fontWeight(.medium)
                                .foregroundStyle(.blue)
                        }
                    } else if take.takeType == .slate {
                        HStack(spacing: 6) {
                            Image(systemName: "tv")
                                .font(.caption)
                            Text("Slate")
                                .font(Theme.Font.cardSubtitle)
                                .foregroundStyle(Theme.textPrimary)
                            
                            // NEW: Show slate number if available
                            if let slateNumber = take.slateNumber {
                                Text("(\(slateNumber))")
                                    .font(.caption)
                                    .foregroundStyle(Theme.Colors.secondaryText)
                            }
                        }
                    } else {
                        HStack(spacing: 6) {
                            if take.sceneNumber > 1 {
                                Text("S\(take.sceneNumber)T\(takeNumber)")
                                    .font(Theme.Font.cardSubtitle)
                                    .foregroundStyle(Theme.textPrimary)
                            } else {
                                Text("Take \(takeNumber)")
                                    .font(Theme.Font.cardSubtitle)
                                    .foregroundStyle(Theme.textPrimary)
                            }
                            
                            // 🎯 ENTERPRISE: Parent indicator for SmartFill enabled takes
                            if take.hasSmartFilledVersion {
                                Text("(Original)")
                                    .font(.caption2)
                                    .foregroundStyle(.orange)
                                    .padding(.horizontal, 4)
                                    .padding(.vertical, 1)
                                    .background(.orange.opacity(0.15), in: Capsule())
                            }
                            
                            // NEW: Show slate ID if available
                            if let slateID = take.slateID {
                                Text("[\(slateID)]")
                                    .font(.caption)
                                    .foregroundStyle(.blue)
                            }
                        }
                    }

                    // Status indicators for regular takes
                    if take.takeType == .regular {
                        HStack(spacing: 4) {
                            if take.rating == .good {
                                Image(systemName: "checkmark.circle.fill")
                                    .font(.caption)
                                    .foregroundStyle(.green)
                            }
                            if take.rating == .favorite {
                                Image(systemName: "star.fill")
                                    .font(.caption)
                                    .foregroundStyle(.yellow)
                            }
                            if take.rating == .bad {
                                Image(systemName: "xmark.circle.fill")
                                    .font(.caption)
                                    .foregroundStyle(.red)
                            }
                        }
                    }
                }
                .font(Theme.Font.cardSubtitle)
                .foregroundColor(Theme.textPrimary)

                HStack {
                    Text(formattedDuration(take.durationSeconds))
                        .font(Theme.Font.smallCaption)
                        .foregroundStyle(Theme.Colors.secondaryText)
                    
                    // 🎯 ENTERPRISE: Enhanced SmartFill parent status with hierarchy indicator
                    if take.capturedOrientation == .portrait {
                        Text("•")
                            .font(Theme.Font.smallCaption)
                            .foregroundStyle(Theme.Colors.secondaryText)
                        
                        HStack(spacing: 2) {
                            Image(systemName: take.hasSmartFilledVersion ? "1.circle" : "rectangle.portrait")
                                .font(.caption2)
                                .foregroundStyle(take.hasSmartFilledVersion ? .orange : .orange)
                            Text(take.hasSmartFilledVersion ? "Parent + Enhanced Version" : "Portrait Only")
                                .font(.caption2)
                                .foregroundStyle(take.hasSmartFilledVersion ? .orange : .orange)
                        }
                    }
                    
                    // NEW: Show full scene display name if enhanced
                    if take.sceneNumber > 1 || take.slateNumber != nil {
                        Text("• \(take.sceneDisplayName)")
                            .font(.caption)
                            .foregroundStyle(.blue)
                    }
                }
            }
        }

        // CLEANED UP: Only rating buttons for regular takes, now includes bad take badge
        @ViewBuilder
        private var takeRatingActions: some View {
            if take.takeType == .regular || take.takeType == .slate {
                HStack(spacing: 8) {
                    Button {
                        let newRating: TakeRating = take.rating == .good ? .unrated : .good
                        onAction(.setRating(newRating))
                    } label: {
                        Image(systemName: take.rating == .good ? "checkmark.circle.fill" : "checkmark.circle")
                            .font(.caption)
                            .foregroundStyle(take.rating == .good ? .green : .gray)
                            .padding(6)
                    }

                    Button {
                        let newRating: TakeRating = take.rating == .favorite ? .unrated : .favorite
                        onAction(.setRating(newRating))
                    } label: {
                        Image(systemName: take.rating == .favorite ? "star.fill" : "star")
                            .font(.caption)
                            .foregroundStyle(take.rating == .favorite ? .yellow : .gray)
                            .padding(6)
                    }

                    // NEW: Bad take (x) rating button
                    Button {
                        let newRating: TakeRating = take.rating == .bad ? .unrated : .bad
                        onAction(.setRating(newRating))
                    } label: {
                        Image(systemName: take.rating == .bad ? "xmark.circle.fill" : "xmark.circle")
                            .font(.caption)
                            .foregroundStyle(take.rating == .bad ? .red : .gray)
                            .padding(6)
                    }
                }
                .buttonStyle(PlainButtonStyle())
            }
        }

        private var takeRowBackgroundColor: Color {
            switch take.takeType {
            case .merged:
                return Color.green.opacity(0.08)
            case .exported:
                return Color.blue.opacity(0.08)
            case .slate:
                return Color.blue.opacity(0.05)
            case .regular:
                return Color.white.opacity(0.03)
            }
        }
        
        // CRITICAL FIX: Helper to detect photo takes
        private var isPhotoTake: Bool {
            return take.durationSeconds == 0.0 && (
                take.filePath.lowercased().contains("photo") ||
                take.filePath.lowercased().contains("keyframe")
            )
        }

        @ViewBuilder
        private var smartFillVideoThumbnail: some View {
            Button {
                onAction(.play) // Play SmartFill version
            } label: {
                ZStack {
                    // ENHANCED: SmartFill thumbnail (using effectiveFilePath which points to SmartFill version)
                    ThumbnailPreviewView(unifiedTake: createUnifiedTakeForSmartFillThumbnail())
                        .frame(width: 40, height: 24)
                        .clipShape(RoundedRectangle(cornerRadius: 4))
                    
                    // SmartFill play overlay
                    Image(systemName: "play.fill")
                        .font(.caption2)
                        .foregroundStyle(.white)
                        .background(
                            Circle()
                                .fill(.green.opacity(0.8))
                                .frame(width: 16, height: 16)
                        )
                    
                    // SmartFill badge
                    VStack {
                        HStack {
                            Spacer()
                            Image(systemName: "rectangle.fill.badge.checkmark")
                                .font(.system(size: 8))
                                .foregroundStyle(.green)
                                .background(
                                    Circle()
                                        .fill(.black.opacity(0.7))
                                        .frame(width: 12, height: 12)
                                )
                        }
                        Spacer()
                    }
                    .padding(2)
                }
            }
            .buttonStyle(PlainButtonStyle())
        }
        
        // ENHANCED: Create UnifiedTake for original thumbnail (always uses original filePath)
        private func createUnifiedTakeForOriginalThumbnail() -> UnifiedTake {
            return UnifiedTake(
                from: take,
                projectID: UUID(),
                sessionID: UUID(),
                fileName: URL(fileURLWithPath: take.filePath).lastPathComponent, // Always original path
                takeNumber: takeNumber
            )
        }
        
        // ENHANCED: Create UnifiedTake for SmartFill thumbnail (uses SmartFill path)
        private func createUnifiedTakeForSmartFillThumbnail() -> UnifiedTake {
            return UnifiedTake(
                from: take,
                projectID: UUID(),
                sessionID: UUID(),
                fileName: URL(fileURLWithPath: take.effectiveFilePath).lastPathComponent, // SmartFill path
                takeNumber: takeNumber
            )
        }

        // CRITICAL FIX: Create UnifiedTake for thumbnail generation using effective file path
        private func createUnifiedTakeForThumbnail() -> UnifiedTake {
            return UnifiedTake(
                from: take,
                projectID: UUID(), // Placeholder - not used by thumbnail generation
                sessionID: UUID(), // Placeholder - not used by thumbnail generation
                fileName: URL(fileURLWithPath: take.effectiveFilePath).lastPathComponent, // Use effective path (SmartFill if available)
                takeNumber: takeNumber
            )
        }
        
        // ENHANCED: Play original version specifically
        private func playOriginalVersion() {
            // Create a temporary action to play original version
            // This would need to be handled by the parent view
            print(" Playing original version: \(take.filePath)")
            // For now, use the standard play action
            onAction(.play)
        }
        
        // ENHANCED: Share original version specifically
        private func shareOriginalVersion() {
            // This would need to be implemented to share the original file instead of SmartFill
            print(" Sharing original version: \(take.filePath)")
            // For now, use the standard share action
            onShare()
        }

        private func formattedDuration(_ duration: TimeInterval) -> String {
            let minutes = Int(duration) / 60
            let seconds = Int(duration) % 60
            return String(format: "%d:%02d", minutes, seconds)
        }
    }
    
    // MARK: - Enterprise Action Button Component
    struct EnterpriseActionButton: View {
        let icon: String
        let label: String
        let style: ButtonStyle
        let isLoading: Bool
        let action: () -> Void
        
        @State private var isPressed = false
        
        enum ButtonStyle {
            case primary
            case secondary
            
            var backgroundColor: AnyShapeStyle {
                switch self {
                case .primary:
                    return AnyShapeStyle(Theme.Colors.primaryGradient)
                case .secondary:
                    return AnyShapeStyle(Color.white.opacity(0.08))
                }
            }
            
            var foregroundColor: Color {
                switch self {
                case .primary:
                    return .white
                case .secondary:
                    return Theme.Colors.secondaryText
                }
            }
            
            var borderColor: Color {
                switch self {
                case .primary:
                    return Color.white.opacity(0.2)
                case .secondary:
                    return Color.white.opacity(0.15)
                }
            }
        }
        
        var body: some View {
            Button(action: {
                if !isLoading {
                    // Enterprise haptic feedback
                    let impactFeedback = UIImpactFeedbackGenerator(style: .medium)
                    impactFeedback.impactOccurred()
                    action()
                }
            }) {
                HStack(spacing: Theme.Spacing.xs) {
                    if isLoading {
                        ProgressView()
                            .scaleEffect(0.8)
                            .tint(style.foregroundColor)
                            .transition(.scale.combined(with: .opacity))
                    } else {
                        Image(systemName: icon)
                            .font(.system(size: 16, weight: .semibold))
                            .transition(.scale.combined(with: .opacity))
                    }
                    
                    Text(isLoading ? "Processing..." : label)
                        .font(Theme.Font.buttonLabel)
                        .fontWeight(.medium)
                }
                .padding(.vertical, Theme.Layout.compactPadding)
                .padding(.horizontal, Theme.Layout.comfortablePadding)
                .frame(maxWidth: .infinity)
                .background(
                    RoundedRectangle(cornerRadius: Theme.Layout.smallCornerRadius)
                        .fill(style.backgroundColor)
                )
                .foregroundColor(style.foregroundColor)
                .shadow(
                    color: style == .primary ? Theme.Shadow.elevated.color : Theme.Shadow.subtle.color,
                    radius: isPressed ?
                        (style == .primary ? Theme.Shadow.medium.radius : Theme.Shadow.subtle.radius) :
                        (style == .primary ? Theme.Shadow.elevated.radius : Theme.Shadow.small.radius),
                    x: 0,
                    y: Theme.Shadow.elevated.y
                )
                .shadow(
                    color: Theme.Shadow.small.color,
                    radius: Theme.Shadow.small.radius,
                    x: 0,
                    y: Theme.Shadow.small.y
                )
                .scaleEffect(isPressed ? Theme.InteractionState.buttonPressScale : 1.0)
                .animation(Theme.Animation.buttonPress, value: isPressed)
                .animation(Theme.Animation.smooth, value: isLoading)
            }
            .disabled(isLoading)
            .buttonStyle(PlainButtonStyle())
            .onLongPressGesture(minimumDuration: 0, maximumDistance: .infinity, pressing: { pressing in
                if !isLoading {
                    withAnimation(Theme.Animation.buttonPress) {
                        isPressed = pressing
                    }
                }
            }) {
                // Long press handled by main action
            }
        }
    }
}
