import SwiftUI

public struct ArchivesView: View {
    @State private var projectsVM: ProjectsViewModel
    private let repo: ProjectsRepository
    
    public init(repo: ProjectsRepository) {
        self.repo = repo
        _projectsVM = State(initialValue: ProjectsViewModel(repo: repo))
    }
    
    public var body: some View {
        NavigationStack {
            ZStack {
                BrandBackground()
                    .ignoresSafeArea()
                
                if projectsVM.archivedProjects.isEmpty {
                    EmptyStateView(
                        title: "No Archived Items", 
                        message: "Archived projects will appear here."
                    )
                } else {
                    List {
                        archivedProjectsSection
                    }
                    .listStyle(.plain)
                    .scrollContentBackground(.hidden)
                    .padding(.top)
                }
            }
            .navigationTitle("Archives")
            .navigationBarTitleDisplayMode(.large)
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("Clear All") {
                        // TODO: Implement clear all archives
                        print("Clear all archives tapped")
                    }
                    .foregroundStyle(.red)
                }
            }
            .onAppear {
                projectsVM.reload()
            }
        }
        .navigationDestination(for: UUID.self) { projectID in
            ProjectDetailView(projectID: projectID, repo: repo)
        }
    }
    
    @ViewBuilder
    private var archivedProjectsSection: some View {
        if !projectsVM.archivedProjects.isEmpty {
            Section("Archived Projects") {
                ForEach(projectsVM.archivedProjects) { project in
                    NavigationLink(value: project.id) {
                        ArchivedProjectRow(project: project)
                    }
                    .listRowSeparator(.hidden)
                    .listRowBackground(Color.clear)
                    // FIXED: Only restore action in archives - no delete
                    .swipeActions(edge: .leading, allowsFullSwipe: false) {
                        Button {
                            projectsVM.toggleArchive(project) // This will unarchive it
                        } label: {
                            Label("Restore", systemImage: "arrow.uturn.backward")
                        }
                        .tint(Theme.primary)
                    }
                }
            }
        }
    }
}

// MARK: - Supporting Views

struct ArchivedProjectRow: View {
    let project: Project
    
    var body: some View {
        STSCard {
            HStack {
                VStack(alignment: .leading, spacing: 8) {
                    Text(project.title)
                        .font(Theme.Font.headline)
                        .foregroundStyle(Theme.textPrimary)
                    
                    Text(project.createdAt.formatted(date: .abbreviated, time: .omitted))
                        .font(Theme.Font.caption)
                        .foregroundStyle(.secondary)
                }
                
                Spacer()
                
                VStack(alignment: .trailing, spacing: 4) {
                    HStack(spacing: 4) {
                        Image(systemName: "archivebox.fill")
                            .font(.caption)
                            .foregroundStyle(Theme.primary)
                        
                        if project.isFavorite {
                            Image(systemName: "star.fill")
                                .font(.caption)
                                .foregroundStyle(.yellow)
                        }
                        
                        if project.isCompleted {
                            Image(systemName: "checkmark.circle.fill")
                                .font(.caption)
                                .foregroundStyle(.green)
                        }
                    }
                    
                    let sessionCount = project.sessions.count
                    if sessionCount > 0 {
                        Text("\(sessionCount) session\(sessionCount > 1 ? "s" : "")")
                            .font(Theme.Font.caption)
                            .foregroundStyle(.secondary)
                    }
                }
            }
        }
    }
}

#Preview {
    ArchivesView(repo: InMemoryProjectsRepository())
}
