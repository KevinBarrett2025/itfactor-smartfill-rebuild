import SwiftUI
import AVFoundation  // PHASE 1: NEW - Import AVFoundation for editor integration

// CRITICAL FIX: Add missing VideoPlayerData struct
struct VideoPlayerData: Identifiable {
    let id = UUID()
    let take: ProjectTake
    let session: ProjectSession
}

// CRITICAL FIX: Add missing ActorMustKnowsData struct to fix empty sheet bug
struct ActorMustKnowsData: Identifiable {
    let id = UUID()
    let project: Project
    let session: ProjectSession
}

// STEP 1: Add ExportManagerData struct to fix sheet presentation bug
struct ExportManagerData: Identifiable {
    let id = UUID()
    let project: Project
    let session: ProjectSession
    let takes: [EnhancedTake]  // STEP 2B: Add takes to avoid recreating them
    let repository: ProjectsRepository  // CRITICAL FIX: Add repository parameter
}

// CRITICAL FIX: Add project-level archive data struct
struct ProjectArchiveData: Identifiable {
    let id = UUID()
    let project: Project
}

// CRITICAL FIX: Add TakeReviewData struct to fix blank sheet bug - ENHANCED: Scene state preservation
struct TakeReviewData: Identifiable {
    let id = UUID()
    let session: ProjectSession
    let project: Project
    let selectedViewType: TakeReviewPage.ViewType? // NEW: Preserve view type
    let selectedSceneNumber: Int? // NEW: Preserve scene number
}

// NEW: Swipeable Video Player Data for centralized modal management - ENHANCED: Context preservation
struct SwipeableVideoPlayerData: Identifiable {
    let id = UUID()
    let takes: [ProjectTake]
    let initialIndex: Int
    let session: ProjectSession
    let project: Project
    let contextViewType: TakeReviewPage.ViewType // NEW: Remember which context we came from
    let contextSceneNumber: Int? // NEW: Remember which scene we came from (if applicable)
}

// NEW: Centralized modal management to fix iOS sheet stacking issue
enum ProjectModalType {
    case none
    case takeReview(TakeReviewData)
    case videoPlayer(SwipeableVideoPlayerData)
    case actorMustKnows(ActorMustKnowsData)
    case exportManager(ExportManagerData)
    case projectArchive(ProjectArchiveData)
    case lightweightEditor(EditorData)  // PHASE 1: NEW - Editor modal
}

// PHASE 1: NEW - Editor data for modal presentation
struct EditorData: Identifiable {
    let id = UUID()
    let take: ProjectTake
    let session: ProjectSession
    let project: Project
}

// MARK: - Shared ActivityViewController with iPad Fix
struct ActivityViewController: UIViewControllerRepresentable {
    let activityItems: [Any]
    
    func makeUIViewController(context: Context) -> UIActivityViewController {
        let controller = UIActivityViewController(
            activityItems: activityItems,
            applicationActivities: nil
        )
        
        // Exclude some activities that don't make sense for video files
        controller.excludedActivityTypes = [
            .assignToContact,
            .addToReadingList,
            .postToVimeo
        ]
        
        // CRITICAL FIX: Configure popover for iPad to prevent blank share sheet
        if let popover = controller.popoverPresentationController {
            // Set source to center of screen since we don't have access to the specific button
            if let windowScene = UIApplication.shared.connectedScenes.first as? UIWindowScene,
               let window = windowScene.windows.first {
                popover.sourceView = window.rootViewController?.view
                popover.sourceRect = CGRect(
                    x: window.bounds.midX,
                    y: window.bounds.midY,
                    width: 0,
                    height: 0
                )
                popover.permittedArrowDirections = [] // No arrow when centered
            }
        }
        
        return controller
    }
    
    func updateUIViewController(_ uiViewController: UIActivityViewController, context: Context) {}
}

public struct ProjectDetailView: View {
    @State private var vm: ProjectDetailViewModel
    @State private var showNewSessionWizard = false
    @State private var showingBookedAlert = false
    @State private var fabScale: CGFloat = 1.0
    @State private var expandedSessions: Set<UUID> = []
    @State private var showDeleteProjectConfirmation = false
    
    // CRITICAL FIX: Centralized modal state management to prevent iOS sheet stacking conflicts
    @State private var activeModal: ProjectModalType = .none
    
    @State private var sessionToDelete: ProjectSession?
    
    // NEW: State for native iOS sharing
    @State private var showingShareSheet = false
    @State private var shareItems: [Any] = []

    @Environment(\.dismiss) private var dismiss

    public init(projectID: UUID, repo: ProjectsRepository) {
        _vm = State(initialValue: ProjectDetailViewModel(projectID: projectID, repo: repo))
    }

    public var body: some View {
        ZStack {
            BrandBackground()
                .ignoresSafeArea()
            
            if let project = vm.project {
                VStack(spacing: 0) {
                    projectContent(project)
                    bottomButton
                }
            } else {
                EmptyStateView(title: "Not Found", message: "This project could not be loaded.")
            }
            
            bookedItFAB
        }
        .navigationTitle(vm.project?.title ?? "Project")
        .navigationBarTitleDisplayMode(.inline)

        // CRITICAL FIX: Single centralized modal presentation system
        .fullScreenCover(isPresented: Binding<Bool>(
            get: {
                switch activeModal {
                case .none:
                    return false
                default:
                    return true
                }
            },
            set: { newValue in
                // CRITICAL FIX: Only auto-dismiss if we're not in a video player context
                // Let the onDismiss closures handle transitions properly
                if !newValue {
                    switch activeModal {
                    case .videoPlayer:
                        // Don't auto-dismiss, let the video player's onDismiss handle the transition
                        print("🎬 Video player dismissed via gesture, letting onDismiss handle transition")
                        return
                    default:
                        // For other modals, allow normal dismissal
                        activeModal = .none
                    }
                }
            }
        )) {
            modalContent
        }
        .sheet(isPresented: $showNewSessionWizard) {
            NewSessionWizard(projectID: vm.projectID, repo: vm.repo) {
                vm.reload()
            }
        }
        // NEW: Native iOS sharing sheet
        .sheet(isPresented: $showingShareSheet) {
            ActivityViewController(activityItems: shareItems)
        }
        .alert("Delete Project?", isPresented: $showDeleteProjectConfirmation) {
            Button("Cancel", role: .cancel) {}
            Button("Delete Forever", role: .destructive) {
                if let project = vm.project {
                    vm.repo.delete(project: project)
                    // CRITICAL FIX: Notify parent to reload immediately
                    NotificationCenter.default.post(name: Notification.Name("STSProjectsListShouldReload"), object: nil)
                    dismiss()
                }
            }
        } message: {
            if let project = vm.project {
                Text("This will permanently delete \"\(project.title)\" and all \(project.sessions.count) session\(project.sessions.count == 1 ? "" : "s"). This action cannot be undone.")
            }
        }
        .alert("Delete Session?", isPresented: Binding(get: { sessionToDelete != nil }, set: { _ in sessionToDelete = nil })) {
            Button("Cancel", role: .cancel) {}
            Button("Delete Session", role: .destructive) {
                if let session = sessionToDelete {
                    vm.deleteSession(session)
                    sessionToDelete = nil
                }
            }
        } message: {
            if let session = sessionToDelete {
                Text("This will permanently delete this \(session.type.rawValue) session and all \(session.takes.count) take\(session.takes.count == 1 ? "" : "s").")
            }
        }
        .onReceive(NotificationCenter.default.publisher(for: Notification.Name("STSTakeRatingUpdated"))) { notification in
            // CRITICAL FIX: Force immediate reload when any take rating is updated
            if let projectIDFromNotification = notification.userInfo?["projectID"] as? UUID,
               projectIDFromNotification == vm.projectID {
                DispatchQueue.main.async {
                    vm.reload()
                }
                print("🔄 ProjectDetailView: Force reloaded due to rating update")
            }
        }
        .onReceive(NotificationCenter.default.publisher(for: Notification.Name("STSProjectsListShouldReload"))) { _ in
            // Also reload on general project updates
            DispatchQueue.main.async {
                vm.reload()
            }
        }
        .onAppear {
            // CRITICAL FIX: Always reload fresh data when view appears
            vm.reload()
            // KEVIN'S FIX: Expand all sessions by default when entering project
            if let project = vm.project {
                expandedSessions = Set(project.sessions.map { $0.id })
            }
        }
    }
    
    // CRITICAL FIX: Centralized modal content resolver
    @ViewBuilder
    private var modalContent: some View {
        switch activeModal {
        case .none:
            EmptyView()
            
        case .takeReview(let reviewData):
            TakeReviewPage(
                session: reviewData.session,
                project: reviewData.project,
                repository: vm.repo,
                initialViewType: reviewData.selectedViewType, // NEW: Pass preserved view type
                initialSceneNumber: reviewData.selectedSceneNumber, // NEW: Pass preserved scene number
                onSessionAction: { action in
                    handleSessionAction(action, for: reviewData.session)
                },
                onTakeAction: { action, take in
                    handleTakeAction(action, for: take, in: reviewData.session)
                },
                onVideoPlayerRequest: { takes, initialIndex, viewType, sceneNumber in
                    // CRITICAL FIX: Handle video player request from TakeReviewPage with context preservation
                    let videoPlayerData = SwipeableVideoPlayerData(
                        takes: takes,
                        initialIndex: initialIndex,
                        session: reviewData.session,
                        project: reviewData.project,
                        contextViewType: viewType, // NEW: Preserve context
                        contextSceneNumber: sceneNumber // NEW: Preserve scene
                    )
                    activeModal = .videoPlayer(videoPlayerData)
                }
            )
            
        case .videoPlayer(let playerData):
            SwipeableVideoPlayerView(
                takes: playerData.takes,
                session: playerData.session,
                project: playerData.project,
                initialIndex: playerData.initialIndex,
                onDismiss: {
                    // CRITICAL FIX: Return to TakeReviewPage with preserved scene state
                    print("🎬 Video player dismissed, returning to TakeReviewPage with context: \(playerData.contextViewType)")
                    activeModal = .takeReview(TakeReviewData(
                        session: playerData.session,
                        project: playerData.project,
                        selectedViewType: playerData.contextViewType, // NEW: Restore view type
                        selectedSceneNumber: playerData.contextSceneNumber // NEW: Restore scene number
                    ))
                },
                onTakeAction: { action, take in
                    handleTakeAction(action, for: take, in: playerData.session)
                },
                onEditorRequest: { take in  // PHASE 1: NEW - Handle editor request from video player
                    handleEditorRequest(
                        take: take,
                        session: playerData.session,
                        project: playerData.project
                    )
                }
            )
            
        case .actorMustKnows(let data):
            ActorMustKnowsView(
                project: data.project,
                session: data.session,
                onComplete: {
                    activeModal = .none
                    vm.reload()
                }
            )
            
        case .exportManager(let data):
            ExportManagerView(
                takes: data.takes,
                project: data.project,
                session: data.session,
                repository: data.repository,
                onDismiss: {
                    vm.reload()
                    NotificationCenter.default.post(
                        name: Notification.Name("STSExportCompleted"),
                        object: nil,
                        userInfo: ["sessionID": data.session.id]
                    )
                    activeModal = .none
                }
            )
            
        case .projectArchive(let archiveData):
            ProjectArchiveModal(
                project: archiveData.project,
                onDismiss: {
                    activeModal = .none
                },
                onDelete: {
                    activeModal = .none
                    vm.repo.delete(project: archiveData.project)
                    NotificationCenter.default.post(name: Notification.Name("STSProjectsListShouldReload"), object: nil)
                    dismiss()
                },
                onArchive: { archiveOptions in
                    activeModal = .none
                    vm.repo.toggleArchive(project: archiveData.project)
                    NotificationCenter.default.post(name: Notification.Name("STSProjectsListShouldReload"), object: nil)
                    dismiss()
                }
            )
            
        // PHASE 1: NEW - Lightweight Editor modal
        case .lightweightEditor(let editorData):
            NavigationView {
                LightweightEditorView(
                    asset: AVURLAsset(url: URL(fileURLWithPath: editorData.take.filePath)),
                    onSave: { asset, trimRange, cropRect in
                        handleEditorSave(
                            asset: asset,
                            trimRange: trimRange,
                            cropRect: cropRect,
                            originalTake: editorData.take,
                            session: editorData.session
                        )
                    },
                    onCancel: {
                        handleEditorCancel(
                            take: editorData.take,
                            session: editorData.session,
                            project: editorData.project
                        )
                    },
                    // PHASE 3: Pass processing context for SmartFill integration
                    takeID: editorData.take.id,
                    sessionID: editorData.session.id,
                    projectID: editorData.project.id,
                    originalVideoPath: editorData.take.filePath,
                    capturedOrientation: editorData.take.capturedOrientation
                )
                .navigationTitle("Edit Video")
                .navigationBarTitleDisplayMode(.inline)
            }
        }
    }
    
    @ViewBuilder
    private func projectContent(_ project: Project) -> some View {
        List {
            projectInfoSection(project)
            sessionsSections
        }
        .listStyle(.plain)
        .scrollContentBackground(.hidden)
        .padding(.bottom, 120)
    }
    
    @ViewBuilder
    private func projectInfoSection(_ project: Project) -> some View {
        Section {
            STSCard {
                VStack(alignment: .leading, spacing: 12) {
                    Text(project.title)
                        .font(Theme.Font.title)
                        .foregroundStyle(Theme.textPrimary)
                    
                    if let cd = project.castingDirector {
                        InfoRow(label: "Casting Director:", value: cd.name)
                    }
                    
                    if let office = project.castingOffice {
                        InfoRow(label: "Office:", value: office)
                    }
                    
                    if let rep = project.representation {
                        InfoRow(label: "Representation:", value: rep.name)
                    }
                    
                    // CRITICAL FIX: Add project-level archive and delete buttons
                    Divider()
                        .padding(.vertical, 8)
                    
                    HStack(spacing: 12) {
                        // Archive Project
                        Button(action: {
                            activeModal = .projectArchive(ProjectArchiveData(project: project))
                        }) {
                            HStack(spacing: 6) {
                                Image(systemName: "archivebox.fill")
                                    .font(.caption)
                                Text("Archive Project")
                                    .font(.caption)
                                    .fontWeight(.medium)
                            }
                            .foregroundStyle(.blue)
                            .padding(.horizontal, 12)
                            .padding(.vertical, 8)
                            .background(
                                RoundedRectangle(cornerRadius: 8)
                                    .fill(Color.blue.opacity(0.1))
                                    .overlay(
                                        RoundedRectangle(cornerRadius: 8)
                                            .stroke(Color.blue.opacity(0.3), lineWidth: 1)
                                    )
                            )
                        }
                        .buttonStyle(PlainButtonStyle())
                        
                        // Delete Project
                        Button(action: {
                            showDeleteProjectConfirmation = true
                        }) {
                            HStack(spacing: 6) {
                                Image(systemName: "trash.fill")
                                    .font(.caption)
                                Text("Delete Project")
                                    .font(.caption)
                                    .fontWeight(.medium)
                            }
                            .foregroundStyle(.red)
                            .padding(.horizontal, 12)
                            .padding(.vertical, 8)
                            .background(
                                RoundedRectangle(cornerRadius: 8)
                                    .fill(Color.red.opacity(0.1))
                                    .overlay(
                                        RoundedRectangle(cornerRadius: 8)
                                            .stroke(Color.red.opacity(0.3), lineWidth: 1)
                                    )
                            )
                        }
                        .buttonStyle(PlainButtonStyle())
                        
                        Spacer()
                    }
                }
            }
        }
        .listRowSeparator(.hidden)
        .listRowBackground(Color.clear)
    }
    
    @ViewBuilder
    private var sessionsSections: some View {
        ForEach(vm.groupedSessions, id: \.0) { group in
            Section {
                ForEach(group.1) { session in
                    SessionNavigationCard(
                        session: session,
                        onNavigate: {
                            // FIXED: Use centralized modal management for TakeReviewPage
                            if let project = vm.project {
                                activeModal = .takeReview(TakeReviewData(
                                    session: session,
                                    project: project,
                                    selectedViewType: nil, // NEW: Use defaults for initial navigation
                                    selectedSceneNumber: nil // NEW: Use defaults for initial navigation
                                ))
                            }
                        },
                        onDelete: {
                            handleSessionAction(.deleteSession, for: session)
                        },
                        onArchive: {
                            // FIXED: Use centralized modal management
                            if let project = vm.project {
                                activeModal = .projectArchive(ProjectArchiveData(project: project))
                            }
                        }
                    )
                    .listRowSeparator(.hidden)
                    .listRowBackground(Color.clear)
                }
            } header: {
                Text(group.0.rawValue)
                    .font(Theme.Font.headline)
                    .foregroundStyle(Theme.textPrimary)
            }
        }
    }
    
    @ViewBuilder
    private var bottomButton: some View {
        VStack {
            BrandedPrimaryButton(
                label: "Start New Session",
                icon: "plus.circle.fill"
            ) {
                showNewSessionWizard = true
            }
            .padding(.bottom, 34)
        }
    }
    
    @ViewBuilder
    private var bookedItFAB: some View {
        VStack {
            Spacer()
            HStack {
                Spacer()
                Circle()
                    .fill(Color.green.gradient)
                    .frame(width: 48, height: 48)
                    .overlay(
                        Image(systemName: "party.popper.fill")
                            .font(.title3)
                            .foregroundStyle(.white)
                    )
                    .scaleEffect(fabScale)
                    .onTapGesture {
                        withAnimation(.spring(response: 0.25, dampingFraction: 0.6)) {
                            fabScale = 1.12
                        }
                        DispatchQueue.main.asyncAfter(deadline: .now() + 0.2) {
                            withAnimation(.spring) {
                                fabScale = 1.0
                            }
                        }
                        showingBookedAlert = true
                    }
                    .padding(.trailing, 20)
                    .padding(.bottom, 96)
            }
        }
    }
    
    private func toggleSession(_ sessionID: UUID) {
        withAnimation(.easeInOut(duration: 0.3)) {
            if expandedSessions.contains(sessionID) {
                expandedSessions.remove(sessionID)
            } else {
                expandedSessions.insert(sessionID)
            }
        }
    }
    
    private func handleSessionAction(_ action: SessionAction, for session: ProjectSession) {
        switch action {
        case .resume:
            // CRITICAL FIX: Resume should go to TakeReviewPage (SessionReviewModal) NOT camera
            if let project = vm.project {
                // Restore scene state for when camera IS eventually launched
                let sessionManager = SessionManager.shared
                let lastScene = getLastSceneWithTakes(for: session)
                sessionManager.restoreSceneState(sceneNumber: lastScene)
                
                // Go directly to SessionReviewModal (TakeReviewPage) - restore to last scene
                activeModal = .takeReview(TakeReviewData(
                    session: session,
                    project: project,
                    selectedViewType: .scenes, // NEW: Start with scenes view
                    selectedSceneNumber: lastScene // NEW: Start with last active scene
                ))
                print("🎬 Resume: Opening SessionReviewModal for session with \(session.takes.count) takes, scene \(lastScene)")
            }
        case .exportAndShare:
            // STEP 2B: Create enhanced takes and pass all data to ExportManagerView
            if let project = vm.project {
                let enhancedTakes = convertSessionToEnhancedTakes(session)
                activeModal = .exportManager(ExportManagerData(
                    project: project,
                    session: session,
                    takes: enhancedTakes,
                    repository: vm.repo
                ))
                print("🚀 Launching ExportManager with \(enhancedTakes.count) takes for session with \(session.takes.count) project takes")
            }
        case .favorite:
            vm.toggleSessionFavorite(session)
        case .duplicate:
            vm.duplicateSession(session)
        case .export:
            vm.exportSession(session)
        case .delete:
            vm.deleteSession(session)
        case .deleteSession:
            sessionToDelete = session
        }
    }
    
    private func handleTakeAction(_ action: TakeAction, for take: ProjectTake, in session: ProjectSession) {
        switch action {
        case .play:
            // This action is now handled by TakeReviewPage calling onVideoPlayerRequest
            break
        case .playOriginal:
            // ENHANCED: Play original version specifically (not SmartFill)
            // This action is now handled by TakeReviewPage calling onVideoPlayerRequest with forceOriginal
            break
        case .markBest:
            vm.markTakeAsBest(take, in: session)
        case .favorite:
            vm.toggleTakeFavorite(take)
        case .addNote:
            vm.showTakeNoteEditor(for: take)
        case .export:
            vm.exportTake(take)
        case .delete:
            vm.deleteTake(take, from: session)
        case .setRating(let rating):
            // UNIFIED: Use the unified rating system through ViewModel
            vm.setUnifiedTakeRating(take, in: session, to: rating)
        // NEW: Handle swipe actions
        case .share:
            shareTake(take)
        case .deleteTake:
            deleteTakeWithConfirmation(take, from: session)
        }
    }
    
    // NEW: Share take functionality using native iOS sharing
    private func shareTake(_ take: ProjectTake) {
        let videoURL = URL(fileURLWithPath: take.filePath)
        
        // Verify file exists before sharing
        guard FileManager.default.fileExists(atPath: take.filePath) else {
            print("❌ ProjectDetailView: Cannot share - video file not found at: \(take.filePath)")
            // TODO: Show user-friendly error message
            return
        }
        
        // Prepare share items
        shareItems = [videoURL]
        
        // Show native iOS share sheet
        showingShareSheet = true
        
        print("📤 ProjectDetailView: Sharing \(take.takeType.displayName) - \(videoURL.lastPathComponent)")
    }
    
    // NEW: Delete take with proper cleanup and refresh
    private func deleteTakeWithConfirmation(_ take: ProjectTake, from session: ProjectSession) {
        // Delete the take using existing ViewModel method
        vm.deleteTake(take, from: session)
        
        // Force refresh to update UI immediately
        vm.reload()
        
        print("🗑️ ProjectDetailView: Deleted \(take.takeType.displayName) - \(URL(fileURLWithPath: take.filePath).lastPathComponent)")
    }
    
    // PHASE 1: NEW - Handle editor request from video player
    private func handleEditorRequest(take: ProjectTake, session: ProjectSession, project: Project) {
        print("✨ Opening Lightweight Editor for: \(URL(fileURLWithPath: take.filePath).lastPathComponent)")
        
        // Present editor modal
        activeModal = .lightweightEditor(EditorData(
            take: take,
            session: session,
            project: project
        ))
    }
    
    // PHASE 1: NEW - Handle editor save (placeholder for now)
    private func handleEditorSave(
        asset: AVAsset,
        trimRange: CMTimeRange?,
        cropRect: CGRect?,
        originalTake: ProjectTake,
        session: ProjectSession
    ) {
        print("💾 Editor save requested for: \(URL(fileURLWithPath: originalTake.filePath).lastPathComponent)")
        
        if let trimRange = trimRange {
            print("   Trim range: \(trimRange.start.seconds) - \(trimRange.end.seconds)")
        } else {
            print("   Trim range: none")
        }
        
        if let cropRect = cropRect {
            print("   Crop rect: \(cropRect)")
        } else {
            print("   Crop rect: none")
        }
        
        // TODO: Phase 2-3 will implement actual video processing here
        // For now, just return to video player
        activeModal = .videoPlayer(SwipeableVideoPlayerData(
            takes: [originalTake], // Show just the current take for now
            initialIndex: 0,
            session: session,
            project: vm.project!,
            contextViewType: .scenes,
            contextSceneNumber: originalTake.sceneNumber
        ))
    }
    
    // PHASE 1: NEW - Handle editor cancel
    private func handleEditorCancel(take: ProjectTake, session: ProjectSession, project: Project) {
        print("❌ Editor cancelled for: \(URL(fileURLWithPath: take.filePath).lastPathComponent)")
        
        // Return to video player
        activeModal = .videoPlayer(SwipeableVideoPlayerData(
            takes: [take], // Show just the current take for now
            initialIndex: 0,
            session: session,
            project: project,
            contextViewType: .scenes,
            contextSceneNumber: take.sceneNumber
        ))
    }
    
    // STEP 1: Add helper method to convert ProjectSession to EnhancedTakes
    private func convertSessionToEnhancedTakes(_ session: ProjectSession) -> [EnhancedTake] {
        return session.takes.enumerated().map { index, take in
            EnhancedTake(
                fileName: URL(fileURLWithPath: take.filePath).lastPathComponent,
                projectID: vm.project?.id ?? UUID(),
                sessionID: session.id,
                filePath: take.filePath,
                duration: take.durationSeconds,
                fileSize: estimateFileSize(for: take.filePath),
                cameraPosition: "back", // Default - could be enhanced later
                sceneNumber: 1,
                takeNumber: index + 1,
                isSlate: take.filePath.lowercased().contains("slate"),
                createdAt: take.createdAt
            )
        }
    }
    
    // STEP 1: Helper to estimate file size
    private func estimateFileSize(for filePath: String) -> Int64 {
        if FileManager.default.fileExists(atPath: filePath) {
            do {
                let attributes = try FileManager.default.attributesOfItem(atPath: filePath)
                return attributes[.size] as? Int64 ?? 0
            } catch {
                print("❌ Could not get file size for \(filePath): \(error)")
            }
        }
        return 0
    }
}

// MARK: - Helper Views
struct InfoRow: View {
    let label: String
    let value: String
    
    var body: some View {
        HStack {
            Text(label)
                .font(Theme.Font.caption)
                .foregroundStyle(.secondary)
            Spacer()
            Text(value)
                .font(Theme.Font.body)
                .foregroundStyle(Theme.textPrimary)
        }
    }
}

// MARK: - Expandable Session Card
struct ExpandableSessionCard: View {
    let session: ProjectSession
    let isExpanded: Bool
    let onToggle: () -> Void
    let onSessionAction: (SessionAction) -> Void
    let onTakeAction: (TakeAction, ProjectTake) -> Void
    
    var body: some View {
        VStack(spacing: 0) {
            sessionHeader
            
            if isExpanded {
                expandedContent
            }
        }
    }
    
    @ViewBuilder
    private var sessionHeader: some View {
        Button(action: onToggle) {
            HStack {
                VStack(alignment: .leading, spacing: 4) {
                    HStack(spacing: 8) {
                        Image(systemName: sessionTypeIcon(for: session.type))
                            .font(.headline)
                            .foregroundStyle(Theme.primary)
                        
                        Text(session.type.rawValue)
                            .font(Theme.Font.headline)
                            .foregroundStyle(Theme.textPrimary)
                        
                        if session.isFavorite {
                            Image(systemName: "star.fill")
                                .font(.caption)
                            .foregroundStyle(.yellow)
                        }
                    }
                    
                    Text(session.date.formatted(date: .abbreviated, time: .shortened))
                        .font(Theme.Font.caption)
                        .foregroundStyle(.secondary)
                    
                    if let roleName = session.roleName {
                        Text("Role: \(roleName)")
                            .font(Theme.Font.caption)
                            .foregroundStyle(.secondary)
                    }
                }
                
                Spacer()
                
                VStack(alignment: .trailing, spacing: 4) {
                    if !session.takes.isEmpty {
                        HStack(spacing: 4) {
                            Image(systemName: "video.fill")
                                .font(.caption)
                                .foregroundStyle(Theme.primary)
                            Text("\(session.takes.count) take\(session.takes.count == 1 ? "" : "s")")
                                .font(.caption)
                                .foregroundStyle(.secondary)
                        }
                    }
                    
                    Image(systemName: isExpanded ? "chevron.up" : "chevron.down")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                        .animation(.easeInOut(duration: 0.2), value: isExpanded)
                }
            }
        }
        .buttonStyle(PlainButtonStyle())
        .padding()
        .background(
            RoundedRectangle(cornerRadius: 12, style: .continuous)
                .fill(Color(.systemIndigo).opacity(0.15))
                .overlay(
                    RoundedRectangle(cornerRadius: 12, style: .continuous)
                        .stroke(Color.white.opacity(0.1), lineWidth: 1)
                )
        )
    }
    
    @ViewBuilder
    private var expandedContent: some View {
        VStack(spacing: 12) {
            sessionActions
            takesList
        }
        .padding(.top, 12)
        .background(
            RoundedRectangle(cornerRadius: 12, style: .continuous)
                .fill(Color.black.opacity(0.1))
        )
        .transition(.opacity.combined(with: .move(edge: .top)))
    }
    
    @ViewBuilder
    private var sessionActions: some View {
        HStack(spacing: 12) {
            // SIMPLIFIED: Only Resume, Export & Share, and Delete Session
            if session.type == .selfTape {
                if !session.takes.isEmpty {
                    // STEP 1: Update button text from "Review and export" to "Export & Share"
                    SessionActionButton(
                        icon: "square.and.arrow.up.circle.fill",
                        label: "Export & Share",
                        color: .blue
                    ) {
                        onSessionAction(.exportAndShare)
                    }
                }
                
                // Always show Resume button for self-tape sessions
                SessionActionButton(
                    icon: "video.badge.plus",
                    label: "Resume Session",
                    color: .green
                ) {
                    onSessionAction(.resume)
                }
                
                // FIXED: Only Delete Session button (no archive for sessions)
                SessionActionButton(
                    icon: "trash.circle.fill",
                    label: "Delete Session",
                    color: .red
                ) {
                    onSessionAction(.deleteSession)
                }
            }
        }
    }
    
    @ViewBuilder
    private var takesList: some View {
        if !session.takes.isEmpty {
            VStack(spacing: 8) {
                HStack {
                    Text("Takes")
                        .font(Theme.Font.subheadline)
                        .foregroundStyle(Theme.textPrimary)
                    Spacer()
                }
                .padding(.horizontal)
                
                // NEW: Use takesSortedForDisplay to show merged videos at top
                ForEach(Array(session.takesSortedForDisplay.enumerated()), id: \.element.id) { index, take in
                    TakeRow(
                        take: take,
                        takeNumber: take.takeType == .merged ? 0 : (index + 1), // Merged videos show as "Merged" not numbered
                        onAction: { action in
                            onTakeAction(action, take)
                        }
                    )
                }
            }
        } else {
            Text("No takes recorded yet")
                .font(Theme.Font.caption)
                .foregroundStyle(.secondary)
                .padding()
        }
    }
    
    private func sessionTypeIcon(for type: SessionType) -> String {
        switch type {
        case .selfTape:
            return "video.fill"
        case .callback:
            return "arrow.triangle.2.circlepath"
        case .inPerson:
            return "building.2.fill"
        case .chemistryRead:
            return "person.3.fill"
        }
    }
}

// MARK: - Session Action Button
struct SessionActionButton: View {
    let icon: String
    let label: String
    let color: Color
    let action: () -> Void
    
    var body: some View {
        Button(action: action) {
            VStack(spacing: 4) {
                Image(systemName: icon)
                    .font(.caption)
                    .foregroundStyle(color)
                
                Text(label)
                    .font(.system(size: 10))
                    .foregroundStyle(.secondary)
            }
            .padding(.vertical, 8)
            .padding(.horizontal, 6)
            .background(
                RoundedRectangle(cornerRadius: 8)
                    .fill(color.opacity(0.1))
            )
        }
        .buttonStyle(PlainButtonStyle())
    }
}

// MARK: - Take Row
struct TakeRow: View {
    let take: ProjectTake
    let takeNumber: Int
    let onAction: (TakeAction) -> Void

    @State private var showDeleteConfirmation = false
    
    var body: some View {
        mainRowContent
            .swipeActions(edge: .trailing, allowsFullSwipe: false) {
                // Share action (blue)
                Button {
                    onAction(.share)
                } label: {
                    Label("Share", systemImage: "square.and.arrow.up.fill")
                }
                .tint(.blue)
                
                // Delete action (red, destructive)
                Button(role: .destructive) {
                    showDeleteConfirmation = true
                } label: {
                    Label("Delete", systemImage: "trash.fill")
                }
            }
            .alert("Delete Video?", isPresented: $showDeleteConfirmation) {
                Button("Cancel", role: .cancel) { }
                Button("Delete Forever", role: .destructive) {
                    onAction(.deleteTake)
                }
            } message: {
                Text(deleteConfirmationMessage)
            }
    }
    
    // FIXED: Clean main row content without custom drag gestures
    @ViewBuilder
    private var mainRowContent: some View {
        HStack(spacing: 12) {
            videoThumbnail
            takeInfo
            Spacer()
            if take.takeType == .merged {
                exportInfo
            } else if take.takeType == .exported {
                exportedTakeInfo
            } else {
                takeActions
            }
        }
        .padding(.horizontal)
        .padding(.vertical, 8)
        .background(
            RoundedRectangle(cornerRadius: 8)
                .fill(takeRowBackgroundColor)
                .overlay(
                    RoundedRectangle(cornerRadius: 8)
                        .stroke(takeRowBorderColor, lineWidth: take.takeType == .merged ? 2 : 0)
                )
        )
    }

    // NEW: Dynamic delete confirmation message based on take type
    private var deleteConfirmationMessage: String {
        switch take.takeType {
        case .merged:
            return "This will permanently delete the merged video. The original takes will remain available."
        case .exported:
            return "This will permanently delete the exported video file. The original take will remain available."
        case .slate:
            return "This will permanently delete the slate video."
        case .regular:
            return "This will permanently delete this take. This action cannot be undone."
        }
    }

    // NEW: Dynamic background color based on take type
    private var takeRowBackgroundColor: Color {
        switch take.takeType {
        case .merged:
            return Color.green.opacity(0.15)
        case .exported:
            return Color.blue.opacity(0.12)
        case .slate:
            return Color.blue.opacity(0.08)
        case .regular:
            if take.isExported {
                return Color.yellow.opacity(0.08)
            } else {
                return Color.white.opacity(0.05)
            }
        }
    }
    
    // NEW: Dynamic border color for special take types
    private var takeRowBorderColor: Color {
        switch take.takeType {
        case .merged:
            return Color.green.opacity(0.6)
        case .exported:
            return Color.blue.opacity(0.5)
        case .slate:
            return Color.blue.opacity(0.3)
        case .regular:
            if take.isExported {
                return Color.yellow.opacity(0.4)
            } else {
                return Color.clear
            }
        }
    }
    
    @ViewBuilder
    private var videoThumbnail: some View {
        Button {
            onAction(.play)
        } label: {
            ZStack {
                // CRITICAL FIX: Replace AsyncImage with working ThumbnailPreviewView
                ThumbnailPreviewView(unifiedTake: createUnifiedTakeForThumbnail())
                    .frame(width: 60, height: 36)
                    .clipShape(RoundedRectangle(cornerRadius: 8))
                
                // Play overlay for videos only (photos handled by ThumbnailPreviewView)
                if take.takeType != .regular || take.durationSeconds > 0.0 {
                    Image(systemName: "play.fill")
                        .font(.caption)
                        .foregroundStyle(take.takeType == .merged ? .green : Theme.primary)
                        .background(
                            Circle()
                                .fill(.black.opacity(0.6))
                                .frame(width: 24, height: 24)
                        )
                }
            }
        }
        .buttonStyle(PlainButtonStyle())
    }
    
    // CRITICAL FIX: Create UnifiedTake for thumbnail generation
    private func createUnifiedTakeForThumbnail() -> UnifiedTake {
        return UnifiedTake(
            from: take,
            projectID: UUID(), // Placeholder - not used by thumbnail generation
            sessionID: UUID(), // Placeholder - not used by thumbnail generation
            fileName: URL(fileURLWithPath: take.filePath).lastPathComponent,
            takeNumber: takeNumber
        )
    }
    
    @ViewBuilder
    private var takeInfo: some View {
        VStack(alignment: .leading, spacing: 2) {
            HStack(spacing: 8) {
                // NEW: Display based on take type
                if take.takeType == .merged {
                    HStack(spacing: 6) {
                        Image(systemName: "film.stack.fill")
                            .font(.caption)
                            .foregroundStyle(.green)
                        
                        Text(take.takeType.displayName)
                            .font(Theme.Font.body)
                            .fontWeight(.semibold)
                            .foregroundStyle(.green)
                    }
                } else if take.takeType == .exported {
                    HStack(spacing: 6) {
                        Image(systemName: "square.and.arrow.up.fill")
                            .font(.caption)
                            .foregroundStyle(.blue)
                        
                        Text(take.takeType.displayName)
                            .font(Theme.Font.body)
                            .fontWeight(.medium)
                            .foregroundStyle(.blue)
                    }
                } else if take.takeType == .slate {
                    HStack(spacing: 6) {
                        Image(systemName: "person.crop.rectangle.fill")
                            .font(.caption)
                            .foregroundStyle(.blue)
                        
                        Text("Slate")
                            .font(Theme.Font.body)
                            .foregroundStyle(Theme.textPrimary)
                    }
                } else {
                    Text("Take \(takeNumber)")
                        .font(Theme.Font.body)
                        .foregroundStyle(Theme.textPrimary)
                }
                
                // NEW: Export status indicator for regular takes (not needed for .exported type since it's already marked as exported)
                if take.takeType == .regular && take.isExported {
                    Image(systemName: "square.and.arrow.up.fill")
                        .font(.caption2)
                        .foregroundStyle(.yellow)
                }
                
                // Status indicators - CLEANED: Use TakeRating directly (only for regular takes)
                if take.takeType == .regular {
                    HStack(spacing: 4) {
                        if take.rating == .good {
                            Image(systemName: "checkmark.circle.fill")
                                .font(.caption)
                                .foregroundStyle(.green)
                        }
                        
                        if take.rating == .favorite {
                            Image(systemName: "star.fill")
                                .font(.caption)
                                .foregroundStyle(.yellow)
                        }
                        
                        if take.rating == .bad {
                            Image(systemName: "xmark.circle.fill")
                                .font(.caption)
                                .foregroundStyle(.red)
                        }
                    }
                }
            }
            
            HStack(spacing: 8) {
                Text(formattedDuration(take.durationSeconds))
                    .font(Theme.Font.caption)
                    .foregroundStyle(.secondary)
                
                // NEW: Export status display
                if !take.exportStatusDisplay.isEmpty {
                    Text("• \(take.exportStatusDisplay)")
                        .font(.caption2)
                        .foregroundStyle(.gray)
                }
            }
        }
    }
    
    // NEW: Export info view for merged videos
    @ViewBuilder
    private var exportInfo: some View {
        VStack(alignment: .trailing, spacing: 4) {
            if let metadata = take.exportMetadata {
                Text("\(metadata.originalTakeIDs.count) takes")
                    .font(.caption)
                    .foregroundStyle(.green)
                    .fontWeight(.medium)
                
                Text(metadata.exportDate.formatted(date: .omitted, time: .shortened))
                    .font(.caption2)
                    .foregroundStyle(.gray)
            } else {
                Text("Merged")
                    .font(.caption)
                    .foregroundStyle(.green)
                    .fontWeight(.medium)
            }
        }
    }
    
    // NEW: Export info view for exported individual files
    @ViewBuilder
    private var exportedTakeInfo: some View {
        VStack(alignment: .trailing, spacing: 4) {
            if let metadata = take.exportMetadata {
                Text(metadata.exportType.displayName)
                    .font(.caption)
                    .foregroundStyle(.blue)
                    .fontWeight(.medium)
                
                Text(metadata.exportDate.formatted(date: .omitted, time: .shortened))
                    .font(.caption2)
                    .foregroundStyle(.gray)
            } else {
                Text("Exported")
                    .font(.caption)
                    .foregroundStyle(.blue)
                    .fontWeight(.medium)
            }
        }
    }
    
    @ViewBuilder
    private var takeActions: some View {
        HStack(spacing: 8) {
            // CLEANED: Use TakeRating system directly - no more boolean mess!
            // Only show rating controls for regular takes
            if take.takeType == .regular {
                Button {
                    onAction(.setRating(.good))
                } label: {
                    Image(systemName: take.rating == .good ? "checkmark.circle.fill" : "checkmark.circle")
                        .font(.caption)
                        .foregroundStyle(take.rating == .good ? .green : .gray)
                }
                Button {
                    onAction(.setRating(.favorite))
                } label: {
                    Image(systemName: take.rating == .favorite ? "star.fill" : "star")
                        .font(.caption)
                        .foregroundStyle(take.rating == .favorite ? .yellow : .gray)
                }
                Button {
                    onAction(.setRating(.bad))
                } label: {
                    Image(systemName: take.rating == .bad ? "xmark.circle.fill" : "xmark.circle")
                        .font(.caption)
                        .foregroundStyle(take.rating == .bad ? .red : .gray)
                }
            }
        }
        .buttonStyle(PlainButtonStyle())
    }
    
    private func formattedDuration(_ duration: TimeInterval) -> String {
        let minutes = Int(duration) / 60
        let seconds = Int(duration) % 60
        return String(format: "%d:%02d", minutes, seconds)
    }
}

// MARK: - Action Enums
enum SessionAction {
    case favorite, duplicate, export, delete, resume, exportAndShare, deleteSession
}

enum TakeAction {
    case play
    case playOriginal  // ENHANCED: Play original version specifically (not SmartFill)
    case markBest
    case favorite
    case addNote
    case export
    case delete
    // NEW (for all-your-rating-unification)
    case setRating(TakeRating)
    // NEW: Swipe actions for all video rows
    case share
    case deleteTake
}

// MARK: - Session Navigation Card with Swipe-to-Delete
// MARK: - Session Navigation Card - FIXED: Native SwiftUI swipeActions without NavigationLink
struct SessionNavigationCard: View {
    let session: ProjectSession
    let onNavigate: () -> Void
    let onDelete: () -> Void
    let onArchive: () -> Void
    
    @State private var showDeleteConfirmation = false
    
    var body: some View {
        Button(action: onNavigate) {
            sessionCardContent
        }
        .buttonStyle(PlainButtonStyle())
        .swipeActions(edge: .trailing, allowsFullSwipe: false) {
            Button("Archive") {
                onArchive()
            }
            .tint(.orange)
            
            Button(role: .destructive) {
                showDeleteConfirmation = true
            } label: {
                Label("Delete", systemImage: "trash.fill")
            }
        }
        .alert("Delete Session?", isPresented: $showDeleteConfirmation) {
            Button("Cancel", role: .cancel) { }
            Button("Delete Forever", role: .destructive) {
                onDelete()
            }
        } message: {
            Text("This will permanently delete this \(session.type.rawValue) session and all \(session.takes.count) take\(session.takes.count == 1 ? "" : "s").")
        }
    }
    
    @ViewBuilder
    private var sessionCardContent: some View {
        HStack(spacing: 12) {
            VStack(alignment: .leading, spacing: 4) {
                HStack(spacing: 8) {
                    Image(systemName: sessionTypeIcon(for: session.type))
                        .font(.headline)
                        .foregroundStyle(Theme.primary)
                    
                    Text(session.type.rawValue)
                        .font(Theme.Font.headline)
                        .foregroundStyle(Theme.textPrimary)
                    
                    if session.isFavorite {
                        Image(systemName: "star.fill")
                            .font(.caption)
                            .foregroundStyle(.yellow)
                    }
                }
                
                Text(session.date.formatted(date: .abbreviated, time: .shortened))
                    .font(Theme.Font.caption)
                    .foregroundStyle(.secondary)
                
                if let roleName = session.roleName {
                    Text("Role: \(roleName)")
                        .font(Theme.Font.caption)
                        .foregroundStyle(.secondary)
                }
            }
            
            Spacer()
            
            // Sheet presentations (modals) don't need navigation indicators
        }
        .padding()
        .background(
            RoundedRectangle(cornerRadius: 12, style: .continuous)
                .fill(Color(.systemIndigo).opacity(0.15))
                .overlay(
                    RoundedRectangle(cornerRadius: 12, style: .continuous)
                        .stroke(Color.white.opacity(0.1), lineWidth: 1)
                )
        )
    }
    
    private func sessionTypeIcon(for type: SessionType) -> String {
        switch type {
        case .selfTape:
            return "video.fill"
        case .callback:
            return "arrow.triangle.2.circlepath"
        case .inPerson:
            return "building.2.fill"
        case .chemistryRead:
            return "person.3.fill"
        }
    }
}

// NEW: Helper method to get last scene with takes for a specific session
private func getLastSceneWithTakes(for session: ProjectSession) -> Int {
    let sceneNumbers = Set(session.takes.filter { $0.takeType == .regular && $0.sceneNumber > 0 }.map { $0.sceneNumber })
    return sceneNumbers.max() ?? 1
}
