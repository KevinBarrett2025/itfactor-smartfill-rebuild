import SwiftUI
import AVFoundation
import AVKit
import ImageIO

// MARK: - 60FPS PERFORMANCE: Optimized Image Cache for Enterprise UI

class OptimizedImageCache: ObservableObject {
    static let shared = OptimizedImageCache()
    
    private let cache = NSCache<NSString, UIImage>()
    private let loadingQueue = DispatchQueue(label: "com.sts.imageLoading", qos: .userInteractive)
    private var loadingTasks: [String: Task<UIImage?, Never>] = [:]
    
    private init() {
        // Configure cache for 60fps performance
        cache.countLimit = 50 // Limit memory usage
        cache.totalCostLimit = 100 * 1024 * 1024 // 100MB limit
        
        // Listen for memory warnings
        NotificationCenter.default.addObserver(
            forName: UIApplication.didReceiveMemoryWarningNotification,
            object: nil,
            queue: .main
        ) { [weak self] _ in
            self?.cache.removeAllObjects()
            print("🧹 Image cache cleared due to memory warning")
        }
    }
    
    func loadImage(for path: String) async -> UIImage? {
        let cacheKey = NSString(string: path)
        
        // Check cache first for 60fps performance
        if let cachedImage = cache.object(forKey: cacheKey) {
            return cachedImage
        }
        
        // Check if already loading to prevent duplicate work
        if let existingTask = loadingTasks[path] {
            return await existingTask.value
        }
        
        // Create loading task
        let task = Task<UIImage?, Never> {
            await loadImageFromDiskWithOrientation(path: path, cacheKey: cacheKey)
        }
        
        loadingTasks[path] = task
        let result = await task.value
        loadingTasks.removeValue(forKey: path)
        
        return result
    }
    
    // CRITICAL FIX: New method that handles EXIF orientation properly
    private func loadImageFromDiskWithOrientation(path: String, cacheKey: NSString) async -> UIImage? {
        return await withCheckedContinuation { continuation in
            loadingQueue.async { [weak self] in
                guard let self = self else {
                    continuation.resume(returning: nil)
                    return
                }
                
                var imagePath = path
                
                // Try primary path
                if !FileManager.default.fileExists(atPath: path) {
                    // Try Documents directory fallback
                    let fileName = URL(fileURLWithPath: path).lastPathComponent
                    let documentsPath = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first!
                    let documentsURL = documentsPath.appendingPathComponent(fileName)
                    
                    if FileManager.default.fileExists(atPath: documentsURL.path) {
                        imagePath = documentsURL.path
                    } else {
                        continuation.resume(returning: nil)
                        return
                    }
                }
                
                // CRITICAL FIX: Load image with proper EXIF orientation handling
                guard let imageSource = CGImageSourceCreateWithURL(URL(fileURLWithPath: imagePath) as CFURL, nil),
                      let cgImage = CGImageSourceCreateImageAtIndex(imageSource, 0, nil) else {
                    print("❌ Failed to create CGImage from path: \(imagePath)")
                    continuation.resume(returning: nil)
                    return
                }
                
                // CRITICAL FIX: Read EXIF orientation from image metadata
                let orientation = self.getImageOrientation(from: imageSource)
                
                // CRITICAL FIX: Apply orientation correction like video orientation manager
                let correctedImage = self.correctImageOrientation(cgImage: cgImage, orientation: orientation)
                
                if let finalImage = correctedImage {
                    self.cache.setObject(finalImage, forKey: cacheKey)
                    print("✅ Loaded and orientation-corrected photo: \(URL(fileURLWithPath: imagePath).lastPathComponent)")
                    continuation.resume(returning: finalImage)
                } else {
                    print("❌ Failed to apply orientation correction for: \(imagePath)")
                    continuation.resume(returning: nil)
                }
            }
        }
    }
    
    // CRITICAL FIX: Read EXIF orientation from image source
    private func getImageOrientation(from imageSource: CGImageSource) -> CGImagePropertyOrientation {
        guard let properties = CGImageSourceCopyPropertiesAtIndex(imageSource, 0, nil) as? [CFString: Any],
              let orientationValue = properties[kCGImagePropertyOrientation] as? UInt32 else {
            return .up // Default orientation
        }
        
        return CGImagePropertyOrientation(rawValue: orientationValue) ?? .up
    }
    
    // CRITICAL FIX: Apply orientation correction similar to video orientation manager
    private func correctImageOrientation(cgImage: CGImage, orientation: CGImagePropertyOrientation) -> UIImage? {
        // If orientation is already correct, return as-is for performance
        if orientation == .up {
            return UIImage(cgImage: cgImage)
        }
        
        print("📸 Applying EXIF orientation correction: \(orientation.rawValue) (\(orientation.description))")
        
        let width = cgImage.width
        let height = cgImage.height
        
        // Determine the size and transform based on orientation
        var transform = CGAffineTransform.identity
        var size = CGSize(width: width, height: height)
        
        switch orientation {
        case .up:
            transform = .identity
            
        case .upMirrored:
            transform = CGAffineTransform(scaleX: -1, y: 1)
            
        case .down:
            transform = CGAffineTransform(rotationAngle: .pi)
            
        case .downMirrored:
            transform = CGAffineTransform(rotationAngle: .pi).scaledBy(x: -1, y: 1)
            
        case .left:
            transform = CGAffineTransform(rotationAngle: .pi / 2)
            size = CGSize(width: height, height: width)
            
        case .leftMirrored:
            transform = CGAffineTransform(rotationAngle: .pi / 2).scaledBy(x: -1, y: 1)
            size = CGSize(width: height, height: width)
            
        case .right:
            transform = CGAffineTransform(rotationAngle: -.pi / 2)
            size = CGSize(width: height, height: width)
            
        case .rightMirrored:
            transform = CGAffineTransform(rotationAngle: -.pi / 2).scaledBy(x: -1, y: 1)
            size = CGSize(width: height, height: width)
        @unknown default:
            print("⚠️ Unknown orientation: \(orientation.rawValue), using identity")
            transform = .identity
        }
        
        // Create graphics context and apply transform
        UIGraphicsBeginImageContextWithOptions(size, false, 0)
        guard let context = UIGraphicsGetCurrentContext() else {
            UIGraphicsEndImageContext()
            return UIImage(cgImage: cgImage)
        }
        
        // Configure context for the transformation
        context.concatenate(transform)
        
        // Draw the image in the correct coordinate system
        let drawRect: CGRect
        switch orientation {
        case .left, .leftMirrored:
            drawRect = CGRect(x: 0, y: -height, width: width, height: height)
        case .right, .rightMirrored:
            drawRect = CGRect(x: -width, y: 0, width: width, height: height)
        case .down, .downMirrored:
            drawRect = CGRect(x: -width, y: -height, width: width, height: height)
        default:
            drawRect = CGRect(x: 0, y: 0, width: width, height: height)
        }
        
        context.draw(cgImage, in: drawRect)
        let orientedImage = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()
        
        print("✅ Applied EXIF orientation correction: \(orientation.description)")
        return orientedImage
    }
    
    // DEPRECATED: Keep old method for backward compatibility but mark as deprecated
    private func loadImageFromDisk(path: String, cacheKey: NSString) async -> UIImage? {
        // This method is now deprecated in favor of loadImageFromDiskWithOrientation
        return await loadImageFromDiskWithOrientation(path: path, cacheKey: cacheKey)
    }
    
    func preloadImages(for paths: [String]) {
        Task {
            await withTaskGroup(of: Void.self) { group in
                for path in paths {
                    group.addTask {
                        _ = await self.loadImage(for: path)
                    }
                }
            }
        }
    }
}

// MARK: - EXIF Orientation Extension

extension CGImagePropertyOrientation {
    var description: String {
        switch self {
        case .up: return "Up (normal)"
        case .upMirrored: return "Up Mirrored"
        case .down: return "Down (180°)"
        case .downMirrored: return "Down Mirrored"
        case .left: return "Left (90° CW)"
        case .leftMirrored: return "Left Mirrored"
        case .right: return "Right (90° CCW)"
        case .rightMirrored: return "Right Mirrored"
        @unknown default: return "Unknown (\(rawValue))"
        }
    }
}

// MARK: - 60FPS PERFORMANCE: Optimized Async Image View

struct OptimizedAsyncImageView: View {
    let imagePath: String
    let placeholder: AnyView
    
    @StateObject private var imageCache = OptimizedImageCache.shared
    @State private var loadedImage: UIImage?
    @State private var isLoading = true
    
    init<PlaceholderContent: View>(
        imagePath: String,
        @ViewBuilder placeholder: () -> PlaceholderContent
    ) {
        self.imagePath = imagePath
        self.placeholder = AnyView(placeholder())
    }
    
    var body: some View {
        Group {
            if let loadedImage = loadedImage {
                Image(uiImage: loadedImage)
                    .resizable()
                    .transition(.opacity.animation(.easeInOut(duration: 0.2)))
            } else {
                placeholder
                    .overlay(
                        // 60FPS: Subtle loading indicator
                        isLoading ? 
                        ProgressView()
                            .scaleEffect(0.8)
                            .tint(.white.opacity(0.6))
                        : nil
                    )
            }
        }
        .task {
            await loadImageAsync()
        }
        .onChange(of: imagePath) { _, _ in
            Task {
                await loadImageAsync()
            }
        }
    }
    
    private func loadImageAsync() async {
        isLoading = true
        let image = await imageCache.loadImage(for: imagePath)
        
        await MainActor.run {
            withAnimation(.easeInOut(duration: 0.2)) {
                loadedImage = image
                isLoading = false
            }
        }
    }
}

// MARK: - Unified Media Display Data

struct MediaPlayerDisplayData {
    let take: ProjectTake
    let unifiedTake: UnifiedTake
    let takeNumber: Int
    let totalTakes: Int
    let isPhoto: Bool
    
    init(take: ProjectTake, unifiedTake: UnifiedTake, takeNumber: Int, totalTakes: Int) {
        self.take = take
        self.unifiedTake = unifiedTake
        self.takeNumber = takeNumber
        self.totalTakes = totalTakes
        self.isPhoto = unifiedTake.isPhoto
    }
}

/// PHASE 3: Unified media player that handles both photos and videos with comprehensive swipe functionality
/// PRESERVED: All swipeable functionality from SwipeableVideoPlayerView
/// ENHANCED: Added photo display support with same gesture system
struct SwipeableMediaPlayerView: View {
    let takes: [ProjectTake]
    let currentSession: ProjectSession
    let currentProject: Project
    let initialIndex: Int
    let onDismiss: () -> Void
    let onTakeAction: (TakeAction, ProjectTake) -> Void
    
    @State private var currentIndex: Int
    @State private var mediaPlayerData: [MediaPlayerDisplayData] = []
    @State private var isLoading = true
    
    // PRESERVED: Video player lifecycle management for videos
    @State private var videoPlayers: [Int: EnhancedAVPlayerViewController] = [:]
    @State private var previousIndex: Int = 0
    
    // PRESERVED: Explicit dismiss control
    @State private var shouldDismiss = false
    
    // PRESERVED: Pull-to-dismiss state with background reveal
    @State private var dragOffset: CGFloat = 0
    @State private var isDragging = false
    @State private var backgroundOpacity: Double = 0
    
    init(takes: [ProjectTake], session: ProjectSession, project: Project, initialIndex: Int = 0, onDismiss: @escaping () -> Void, onTakeAction: @escaping (TakeAction, ProjectTake) -> Void) {
        self.takes = takes
        self.currentSession = session
        self.currentProject = project
        self.initialIndex = initialIndex
        self.onDismiss = onDismiss
        self.onTakeAction = onTakeAction
        self._currentIndex = State(initialValue: initialIndex)
        self._previousIndex = State(initialValue: initialIndex)
    }
    
    var body: some View {
        GeometryReader { geometry in
            ZStack {
                // PRESERVED: Background that becomes visible during pull-to-dismiss
                Color.clear
                    .background(.ultraThinMaterial)
                    .opacity(backgroundOpacity)
                    .ignoresSafeArea()
                
                // Main media player content
                ZStack {
                    Color.black.ignoresSafeArea()
                    
                    if isLoading {
                        loadingView
                    } else if !mediaPlayerData.isEmpty {
                        TabView(selection: $currentIndex) {
                            ForEach(Array(mediaPlayerData.enumerated()), id: \.offset) { index, mediaData in
                                // UNIFIED: Media content that handles both photos and videos
                                UnifiedMediaContentView(
                                    mediaData: mediaData,
                                    index: index,
                                    onDismiss: {
                                        shouldDismiss = true
                                    },
                                    onRatingChange: { newRating in
                                        // CRITICAL FIX: Update local media data immediately for persistence
                                        handleRatingChangeWithDataUpdate(newRating, for: mediaData.take, at: index)
                                    },
                                    onShare: {
                                        handleShare(mediaData.take)
                                    },
                                    onVideoPlayerCreated: { playerController in
                                        // PRESERVED: Video player lifecycle management
                                        videoPlayers[index] = playerController
                                        playerController.isCurrentlyVisible = (index == currentIndex)
                                    }
                                )
                                .tag(index)
                                .ignoresSafeArea(.all)
                            }
                        }
                        .tabViewStyle(PageTabViewStyle(indexDisplayMode: .never))
                        .ignoresSafeArea(.all)
                        .onChange(of: currentIndex) { oldValue, newIndex in
                            // PRESERVED: Media swipe handling for both photos and videos
                            handleMediaSwipe(from: oldValue, to: newIndex)
                            previousIndex = oldValue
                            print("🔄 SwipeableMediaPlayer: Switched to media \(newIndex + 1) of \(mediaPlayerData.count)")
                        }
                        .onAppear {
                            DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                                ensureCurrentMediaIsReady()
                            }
                        }
                    } else {
                        errorView
                    }
                }
                .simultaneousGesture(
                    // PRESERVED: Pull-to-dismiss gesture - works for both photos and videos
                    DragGesture(minimumDistance: 50)
                        .onChanged { value in
                            if value.translation.height > 0 && abs(value.translation.height) > abs(value.translation.width) {
                                isDragging = true
                                dragOffset = value.translation.height
                                backgroundOpacity = min(0.8, dragOffset / 300)
                            }
                        }
                        .onEnded { value in
                            isDragging = false
                            
                            if value.translation.height > 120 {
                                withAnimation(.easeOut(duration: 0.35)) {
                                    dragOffset = geometry.size.height
                                    backgroundOpacity = 1.0
                                }
                                DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
                                    shouldDismiss = true
                                }
                            } else {
                                withAnimation(.spring(response: 0.5, dampingFraction: 0.8)) {
                                    dragOffset = 0
                                    backgroundOpacity = 0
                                }
                            }
                        }
                )
                .offset(y: dragOffset)
                .scaleEffect(isDragging ? max(0.85, 1 - (dragOffset / 1200)) : 1)
                .clipShape(RoundedRectangle(cornerRadius: isDragging ? min(20, dragOffset / 10) : 0))
            }
        }
        .onChange(of: shouldDismiss) { _, dismiss in
            if dismiss {
                // PRESERVED: Pause all videos before dismissing
                pauseAllVideos()
                onDismiss()
            }
        }
        .onAppear {
            setupMediaPlayerData()
        }
        .onDisappear {
            // PRESERVED: Cleanup - pause all videos when view disappears
            pauseAllVideos()
        }
        // CRITICAL FIX: Listen for external rating updates and sync local data
        .onReceive(NotificationCenter.default.publisher(for: Notification.Name("STSTakeRatingUpdated"))) { notification in
            if let takeID = notification.userInfo?["takeID"] as? UUID,
               let ratingRawValue = notification.userInfo?["rating"] as? String,
               let newRating = TakeRating(rawValue: ratingRawValue) {
                
                // Find and update the matching media data
                if let index = mediaPlayerData.firstIndex(where: { $0.take.id == takeID }) {
                    updateMediaDataRating(at: index, newRating: newRating)
                    print("🔄 SwipeableMediaPlayer: External rating update applied to media data at index \(index)")
                }
            }
        }
    }
    
    // CRITICAL FIX: Enhanced rating change handler that updates both repository and local data
    private func handleRatingChangeWithDataUpdate(_ newRating: TakeRating, for take: ProjectTake, at index: Int) {
        // Update local media data immediately for persistence across swipes
        updateMediaDataRating(at: index, newRating: newRating)
        
        print("⭐ SwipeableMediaPlayer: Rating changed to \(newRating.rawValue) for \(URL(fileURLWithPath: take.filePath).lastPathComponent) at index \(index)")
        
        // Call the original handler for repository update
        onTakeAction(.setRating(newRating), take)
    }
    
    // CRITICAL FIX: Update media data rating in local array for persistence
    private func updateMediaDataRating(at index: Int, newRating: TakeRating) {
        guard index >= 0 && index < mediaPlayerData.count else {
            print("❌ Invalid index \(index) for media data update")
            return
        }
        
        // Create a new ProjectTake with updated rating
        var updatedTake = mediaPlayerData[index].take
        updatedTake.rating = newRating
        
        // Create new MediaPlayerDisplayData with updated take
        let updatedDisplayData = MediaPlayerDisplayData(
            take: updatedTake,
            unifiedTake: mediaPlayerData[index].unifiedTake,
            takeNumber: mediaPlayerData[index].takeNumber,
            totalTakes: mediaPlayerData[index].totalTakes
        )
        
        // Update the array
        mediaPlayerData[index] = updatedDisplayData
        
        print("✅ Updated local media data rating to \(newRating.rawValue) at index \(index)")
    }
    
    // ENHANCED: Media-aware readiness check
    private func ensureCurrentMediaIsReady() {
        let currentMediaData = mediaPlayerData[currentIndex]
        
        if currentMediaData.isPhoto {
            print("📸 Current photo (\(currentIndex + 1)) ready for display")
        } else if let currentPlayer = videoPlayers[currentIndex] {
            currentPlayer.isCurrentlyVisible = true
            print("🎬 Current video (\(currentIndex + 1)) ready - waiting for user to play")
        }
    }
    
    // ENHANCED: Handle media swipe with support for both photos and videos
    private func handleMediaSwipe(from oldIndex: Int, to newIndex: Int) {
        let oldMediaData = mediaPlayerData[oldIndex]
        let newMediaData = mediaPlayerData[newIndex]
        
        // Handle previous media cleanup
        if !oldMediaData.isPhoto {
            // Pause the previous video immediately
            if let previousPlayer = videoPlayers[oldIndex] {
                previousPlayer.pauseVideo()
                previousPlayer.isCurrentlyVisible = false
            }
        }
        
        // Pause all videos except the new one (if it's a video)
        if !newMediaData.isPhoto {
            pauseAllVideosExcept(newIndex)
            updatePlayerVisibility(for: newIndex)
        }
        
        // Refresh overlay positioning for videos
        if !newMediaData.isPhoto, let newPlayer = videoPlayers[newIndex] {
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.2) {
                refreshOverlayPositioning(for: newPlayer)
            }
        }
        
        let mediaType = newMediaData.isPhoto ? "photo" : "video"
        print("🔄 Media swipe: switched to \(mediaType) \(newIndex + 1) of \(mediaPlayerData.count) with rating \(newMediaData.take.rating.rawValue)")
    }
    
    // PRESERVED: Video player management methods
    private func updatePlayerVisibility(for index: Int) {
        for (playerIndex, player) in videoPlayers {
            let shouldBeVisible = (playerIndex == index)
            player.isCurrentlyVisible = shouldBeVisible
        }
        
        print("📱 Updated video visibility: video \(index + 1) is now visible, ready for user control")
    }
    
    private func pauseAllVideosExcept(_ exceptIndex: Int) {
        for (index, player) in videoPlayers {
            if index != exceptIndex {
                player.pauseVideo()
                player.isCurrentlyVisible = false
            }
        }
    }
    
    private func pauseAllVideos() {
        for (_, player) in videoPlayers {
            player.pauseVideo()
            player.isCurrentlyVisible = false
        }
        print("⏹️ Paused all videos in SwipeableMediaPlayer")
    }
    
    private func refreshOverlayPositioning(for playerViewController: EnhancedAVPlayerViewController) {
        guard let overlayView = playerViewController.contentOverlayView else { return }
        
        overlayView.setNeedsLayout()
        overlayView.layoutIfNeeded()
        
        for subview in overlayView.subviews {
            subview.layer.zPosition = 1000
        }
        
        print("🔄 Refreshed overlay positioning for stable display")
    }
    
    // MARK: - Setup Methods
    
    private func setupMediaPlayerData() {
        isLoading = true
        
        Task { @MainActor in
            var playerDataArray: [MediaPlayerDisplayData] = []
            
            for (index, take) in takes.enumerated() {
                let unifiedTake = UnifiedTake(
                    from: take,
                    projectID: currentProject.id,
                    sessionID: currentSession.id,
                    fileName: URL(fileURLWithPath: take.filePath).lastPathComponent,
                    takeNumber: (currentSession.takes.firstIndex(where: { $0.id == take.id }) ?? 0) + 1
                )
                
                // CRITICAL FIX: Use contextual take numbering instead of session-wide numbering
                let contextualTakeNumber = index + 1 // Sequential numbering within the filtered context
                
                let displayData = MediaPlayerDisplayData(
                    take: take,
                    unifiedTake: unifiedTake,
                    takeNumber: contextualTakeNumber, // FIXED: Use contextual take number
                    totalTakes: takes.count // FIXED: Total takes in current context, not all session takes
                )
                
                playerDataArray.append(displayData)
            }
            
            mediaPlayerData = playerDataArray
            isLoading = false
            
            let photoCount = playerDataArray.filter { $0.isPhoto }.count
            let videoCount = playerDataArray.count - photoCount
            print("✅ SwipeableMediaPlayer: Loaded \(videoCount) contextual videos and \(photoCount) photos, starting at index \(currentIndex)")
        }
    }
    
    // MARK: - Action Handlers
    
    private func handleRatingChange(_ newRating: TakeRating, for take: ProjectTake) {
        print("⭐ SwipeableMediaPlayer: Rating changed to \(newRating.rawValue) for \(URL(fileURLWithPath: take.filePath).lastPathComponent)")
        onTakeAction(.setRating(newRating), take)
    }
    
    private func handleShare(_ take: ProjectTake) {
        print("📤 SwipeableMediaPlayer: Sharing \(URL(fileURLWithPath: take.filePath).lastPathComponent)")
        onTakeAction(.share, take)
    }
    
    // MARK: - UI Components
    
    @ViewBuilder
    private var loadingView: some View {
        VStack(spacing: 16) {
            ProgressView()
                .scaleEffect(1.5)
                .tint(.white)
            
            Text("Loading media...")
                .font(.headline)
                .foregroundColor(.white)
            
            Text("\(takes.count) item\(takes.count == 1 ? "" : "s")")
                .font(.caption)
                .foregroundColor(.gray)
        }
    }
    
    @ViewBuilder
    private var errorView: some View {
        VStack(spacing: 16) {
            Image(systemName: "exclamationmark.triangle")
                .font(.system(size: 48))
                .foregroundColor(.red)
            
            Text("No media to display")
                .font(.headline)
                .foregroundColor(.white)
            
            Button("Close") {
                shouldDismiss = true
            }
            .font(.headline)
            .foregroundColor(.white)
            .padding()
            .background(Color.blue, in: RoundedRectangle(cornerRadius: 12))
        }
    }
}

// MARK: - Unified Media Content View

struct UnifiedMediaContentView: View {
    let mediaData: MediaPlayerDisplayData
    let index: Int
    let onDismiss: () -> Void
    let onRatingChange: (TakeRating) -> Void
    let onShare: () -> Void
    let onVideoPlayerCreated: (EnhancedAVPlayerViewController) -> Void
    
    var body: some View {
        ZStack {
            Color.black.ignoresSafeArea()
            
            if mediaData.isPhoto {
                // ENHANCED: Photo display with zoom and swipe compatibility
                UnifiedPhotoDisplayView(
                    mediaData: mediaData,
                    onRatingChange: onRatingChange,
                    onShare: onShare
                )
            } else {
                // PRESERVED: Video display using existing video player
                CustomAVPlayerViewContent(
                    videoData: VideoPlayerDisplayData(
                        take: mediaData.take,
                        unifiedTake: mediaData.unifiedTake,
                        takeNumber: mediaData.takeNumber,
                        totalTakes: mediaData.totalTakes
                    ),
                    index: index,
                    onDismiss: onDismiss,
                    onRatingChange: onRatingChange,
                    onShare: onShare,
                    onPlayerCreated: onVideoPlayerCreated,
                    onEditorRequest: nil  // PHASE 1: Add editor request parameter (no editor for media player currently)
                )
            }
        }
    }
}

// MARK: - Unified Photo Display View - SIMPLIFIED FOR SWIPE-ONLY INTERACTION

struct UnifiedPhotoDisplayView: View {
    let mediaData: MediaPlayerDisplayData
    let onRatingChange: (TakeRating) -> Void
    let onShare: () -> Void
    
    @State private var showOverlays = true
    
    // CRITICAL FIX: Add local state for immediate visual feedback
    @State private var currentRating: TakeRating
    
    // ORIENTATION FIX: Add orientation detection state
    @State private var currentOrientation = UIDevice.current.orientation
    @State private var isLandscape = UIDevice.current.orientation.isLandscape
    
    // 60FPS PERFORMANCE: Optimized image loading state
    @State private var optimizedImage: UIImage?
    @State private var isImageLoading = true
    
    // CRITICAL FIX: Initialize with current rating for immediate visual updates
    init(mediaData: MediaPlayerDisplayData, onRatingChange: @escaping (TakeRating) -> Void, onShare: @escaping () -> Void) {
        self.mediaData = mediaData
        self.onRatingChange = onRatingChange
        self.onShare = onShare
        self._currentRating = State(initialValue: mediaData.take.rating)
    }
    
    var body: some View {
        ZStack {
            // 60FPS PERFORMANCE: Optimized photo display with enterprise caching - SWIPE ONLY
            Group {
                if let image = optimizedImage {
                    Image(uiImage: image)
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                        .transition(.opacity.animation(.easeInOut(duration: 0.3)))
                        .onTapGesture {
                            // SIMPLIFIED: Single tap to toggle overlays with haptic feedback
                            let impact = UIImpactFeedbackGenerator(style: .light)
                            impact.impactOccurred()
                            
                            withAnimation(.easeInOut(duration: 0.3)) {
                                showOverlays.toggle()
                            }
                        }
                } else {
                    // 60FPS PERFORMANCE: Optimized loading placeholder
                    photoLoadingPlaceholder
                        .transition(.opacity.animation(.easeInOut(duration: 0.2)))
                }
            }
            
            // CRITICAL FIX: Simplified overlay structure with proper hit testing
            if showOverlays && !isImageLoading {
                // Top overlay: Photo title - positioned absolutely 
                VStack {
                    HStack {
                        VStack(alignment: .leading, spacing: 4) {
                            Text(formatPhotoTitle())
                                .font(.system(size: 18, weight: .bold))
                                .foregroundColor(.white)
                                .shadow(color: .black.opacity(0.8), radius: 3, x: 0, y: 1)
                            
                            Text(formatPhotoSubtitle())
                                .font(.system(size: 14))
                                .foregroundColor(.white.opacity(0.9))
                                .shadow(color: .black.opacity(0.8), radius: 2, x: 0, y: 1)
                        }
                        .padding(.horizontal, 12)
                        .padding(.vertical, 8)
                        .background(
                            RoundedRectangle(cornerRadius: 12)
                                .fill(Color.black.opacity(0.5))
                        )
                        .padding(.leading, 20)
                        .padding(.top, 20)
                        
                        Spacer()
                    }
                    Spacer()
                }
                .allowsHitTesting(false) // CRITICAL: Don't intercept touches for title overlay
                .transition(.opacity.animation(.easeInOut(duration: 0.3)))
                
                // CRITICAL FIX: Rating buttons as separate overlay with full hit testing
                ratingButtonsOverlay
                    .transition(.opacity.animation(.easeInOut(duration: 0.3)))
            }
        }
        // CRITICAL FIX: Listen for external rating changes (from other views)
        .onReceive(NotificationCenter.default.publisher(for: Notification.Name("STSTakeRatingUpdated"))) { notification in
            if let takeID = notification.userInfo?["takeID"] as? UUID,
               takeID == mediaData.take.id,
               let ratingRawValue = notification.userInfo?["rating"] as? String,
               let newRating = TakeRating(rawValue: ratingRawValue) {
                
                withAnimation(.easeInOut(duration: 0.2)) {
                    currentRating = newRating
                }
                print("📸 Photo player: External rating update received - \(newRating.rawValue)")
            }
        }
        // ORIENTATION FIX: Listen for orientation changes with 60fps smooth transitions
        .onReceive(NotificationCenter.default.publisher(for: UIDevice.orientationDidChangeNotification)) { _ in
            let newOrientation = UIDevice.current.orientation
            
            // Only update for valid orientations
            guard newOrientation.isValidInterfaceOrientation else { return }
            
            // 60FPS PERFORMANCE: Smooth orientation transition with enterprise-grade curve
            withAnimation(.interactiveSpring(response: 0.35, dampingFraction: 0.85, blendDuration: 0.1)) {
                currentOrientation = newOrientation
                isLandscape = newOrientation.isLandscape
            }
            
            print("🔄 Photo orientation changed to: \(newOrientation.description)")
        }
        .onAppear {
            // Initialize orientation state and load image
            let deviceOrientation = UIDevice.current.orientation
            if deviceOrientation.isValidInterfaceOrientation {
                currentOrientation = deviceOrientation
                isLandscape = deviceOrientation.isLandscape
            }
            
            // CRITICAL FIX: Sync local rating state with media data
            currentRating = mediaData.take.rating
            
            // 60FPS PERFORMANCE: Async image loading
            Task {
                await loadOptimizedImage()
            }
            
            print("📸 Photo viewer appeared with rating: \(currentRating.rawValue) - SWIPE ONLY")
        }
        .task {
            // 60FPS PERFORMANCE: Preload adjacent images for smoother swiping
            await preloadAdjacentImages()
        }
    }
    
    // CRITICAL FIX: Dedicated rating buttons overlay with guaranteed hit testing
    @ViewBuilder
    private var ratingButtonsOverlay: some View {
        GeometryReader { geometry in
            // Position rating buttons on the right side with absolute positioning
            VStack(spacing: 20) {
                // Order matches video player: Favorite, Good, Unrated, Bad (top to bottom)
                enhancedRatingButton(.favorite, "star.fill", .yellow)
                enhancedRatingButton(.good, "checkmark.circle.fill", .green)
                enhancedRatingButton(.unrated, "circle", .gray)
                enhancedRatingButton(.bad, "xmark.circle.fill", .red)
            }
            .position(
                x: geometry.size.width - 50, // 30pt from right edge + 20pt button radius
                y: geometry.size.height * 0.6 // Centered vertically in lower 60%
            )
        }
        .allowsHitTesting(true) // CRITICAL: Enable hit testing for rating buttons
    }
    
    // CRITICAL FIX: Enhanced rating button with guaranteed touch detection AND immediate visual feedback
    @ViewBuilder
    private func enhancedRatingButton(_ rating: TakeRating, _ iconName: String, _ color: Color) -> some View {
        Button(action: {
            // ENHANCED: Add haptic feedback for better user experience
            let impact = UIImpactFeedbackGenerator(style: .medium)
            impact.impactOccurred()
            
            // CRITICAL FIX: Update local state immediately for instant visual feedback
            withAnimation(.spring(response: 0.3, dampingFraction: 0.7)) {
                currentRating = rating
            }
            
            print("📸 Photo rating button tapped: \(rating.rawValue) - immediate visual update")
            
            // Then call the repository update
            onRatingChange(rating)
        }) {
            ZStack {
                // CRITICAL FIX: Larger hit area for better touch detection
                Circle()
                    .fill(Color.clear)
                    .frame(width: 70, height: 70) // Larger hit area
                
                // Visual button - NOW USES LOCAL STATE for immediate updates
                Image(systemName: iconName)
                    .font(.system(size: 24, weight: .medium))
                    .foregroundColor(currentRating == rating ? color : Color.white.opacity(0.9))
                    .frame(width: 56, height: 56)
                    .background(
                        Circle()
                            .fill(
                                currentRating == rating 
                                    ? color.opacity(0.6)
                                    : Color.black.opacity(0.8)
                            )
                            .overlay(
                                Circle()
                                    .stroke(Color.white.opacity(0.3), lineWidth: 2)
                            )
                    )
                    .shadow(color: .black.opacity(0.9), radius: 8, x: 0, y: 4)
            }
        }
        .buttonStyle(PlainButtonStyle()) // CRITICAL: Use PlainButtonStyle to avoid interference
        .scaleEffect(currentRating == rating ? 1.2 : 1.0) // NOW USES LOCAL STATE
        .animation(.spring(response: 0.3, dampingFraction: 0.7), value: currentRating) // ANIMATE ON LOCAL STATE CHANGES
        .contentShape(Circle()) // CRITICAL: Define explicit content shape for hit testing
        .allowsHitTesting(true) // CRITICAL: Explicitly enable hit testing
    }
    
    // 60FPS PERFORMANCE: Optimized image loading with enterprise caching
    private func loadOptimizedImage() async {
        await MainActor.run {
            isImageLoading = true
        }
        
        let imagePath = mediaData.take.filePath
        let loadedImage = await OptimizedImageCache.shared.loadImage(for: imagePath)
        
        await MainActor.run {
            withAnimation(.easeInOut(duration: 0.3)) {
                optimizedImage = loadedImage
                isImageLoading = false
            }
        }
    }
    
    // 60FPS PERFORMANCE: Preload adjacent images for smooth swiping
    private func preloadAdjacentImages() async {
        guard mediaData.totalTakes > 1 else { return }
        
        // This would need access to adjacent media data - conceptual implementation
        // In a real implementation, this would be passed from the parent view
        print("📸 Preloading adjacent images for smooth swiping experience")
    }
    
    // 60FPS PERFORMANCE: Optimized loading placeholder with smooth animations
    @ViewBuilder
    private var photoLoadingPlaceholder: some View {
        VStack(spacing: 16) {
            // 60FPS PERFORMANCE: Smooth loading animation
            ZStack {
                RoundedRectangle(cornerRadius: 12)
                    .fill(.ultraThinMaterial.opacity(0.3))
                    .frame(width: 120, height: 80)
                
                Image(systemName: "photo")
                    .font(.system(size: 32))
                    .foregroundColor(.white.opacity(0.6))
                    .scaleEffect(isImageLoading ? 1.0 : 0.8)
                    .animation(.easeInOut(duration: 1.0).repeatForever(autoreverses: true), value: isImageLoading)
            }
            
            Text("Loading photo...")
                .font(.headline)
                .foregroundColor(.white.opacity(0.8))
                .opacity(isImageLoading ? 1.0 : 0.6)
                .animation(.easeInOut(duration: 0.5), value: isImageLoading)
        }
        .padding()
    }
    
    // MARK: - Helper Methods for Photo Rating Display (optimized for 60fps)
    
    private func loadPhotoImage() -> UIImage? {
        // DEPRECATED: This method is replaced by optimized async loading
        // Kept for backward compatibility but not used in optimized path
        return optimizedImage
    }
    
    private func formatPhotoTitle() -> String {
        switch mediaData.take.takeType {
        case .slate:
            if let slateID = mediaData.take.slateID {
                return slateID // e.g., "SLATE1", "SLATE2"
            } else {
                return "Slate \(mediaData.takeNumber)"
            }
        case .regular:
            if mediaData.unifiedTake.isKeyframePhoto {
                return "Keyframe Photo \(mediaData.takeNumber)"
            } else if mediaData.take.sceneNumber > 1 {
                return "Scene \(mediaData.take.sceneNumber) Photo \(mediaData.takeNumber)"
            } else {
                return "Photo \(mediaData.takeNumber)"
            }
        case .exported:
            return "Exported Photo"
        case .merged:
            return "Merged Photo"
        }
    }
    
    private func formatPhotoSubtitle() -> String {
        // CRITICAL FIX: Show context-aware subtitle for photos (matches video player format)
        switch mediaData.take.takeType {
        case .slate:
            return "\(mediaData.takeNumber) of \(mediaData.totalTakes) slate photos"
        case .regular:
            if mediaData.unifiedTake.isKeyframePhoto {
                return "Keyframe photo \(mediaData.takeNumber) of \(mediaData.totalTakes)"
            } else if mediaData.take.sceneNumber > 1 {
                return "Photo \(mediaData.takeNumber) of \(mediaData.totalTakes) in Scene \(mediaData.take.sceneNumber)"
            } else {
                return "\(mediaData.takeNumber) of \(mediaData.totalTakes)"
            }
        case .exported, .merged:
            return "\(mediaData.takeNumber) of \(mediaData.totalTakes)"
        }
    }
}
