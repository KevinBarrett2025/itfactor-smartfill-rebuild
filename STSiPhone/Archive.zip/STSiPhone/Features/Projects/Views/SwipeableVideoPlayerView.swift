import SwiftUI
import AVFoundation
import AVKit
import CoreGraphics

// MARK: - Video Player Display Data

struct VideoPlayerDisplayData {
    let take: ProjectTake
    let unifiedTake: UnifiedTake
    let takeNumber: Int
    let totalTakes: Int
}

/// Enhanced video player that allows swiping between multiple takes with pull-to-dismiss
struct SwipeableVideoPlayerView: View {
    let takes: [ProjectTake]
    let currentSession: ProjectSession
    let currentProject: Project
    let initialIndex: Int
    let onDismiss: () -> Void
    let onTakeAction: (TakeAction, ProjectTake) -> Void
    
    // PHASE 1: NEW - Editor request callback for sparkles.2 button
    let onEditorRequest: ((ProjectTake) -> Void)?
    
    @State private var currentIndex: Int
    @State private var videoPlayerData: [VideoPlayerDisplayData] = []
    @State private var isLoading = true
    
    // CRITICAL FIX: Track video players for lifecycle management
    @State private var videoPlayers: [Int: EnhancedAVPlayerViewController] = [:]
    @State private var previousIndex: Int = 0
    
    // CRITICAL FIX: Use explicit dismiss control instead of @Environment
    @State private var shouldDismiss = false
    
    // ENHANCED: Pull-to-dismiss state with background reveal
    @State private var dragOffset: CGFloat = 0
    @State private var isDragging = false
    @State private var backgroundOpacity: Double = 0
    
    // PHASE 1: UPDATED initializer with editor callback
    init(
        takes: [ProjectTake],
        session: ProjectSession,
        project: Project,
        initialIndex: Int = 0,
        onDismiss: @escaping () -> Void,
        onTakeAction: @escaping (TakeAction, ProjectTake) -> Void,
        onEditorRequest: ((ProjectTake) -> Void)? = nil  // PHASE 1: NEW - Optional editor callback
    ) {
        self.takes = takes
        self.currentSession = session
        self.currentProject = project
        self.initialIndex = initialIndex
        self.onDismiss = onDismiss
        self.onTakeAction = onTakeAction
        self.onEditorRequest = onEditorRequest  // PHASE 1: NEW - Store editor callback
        self._currentIndex = State(initialValue: initialIndex)
        self._previousIndex = State(initialValue: initialIndex)
    }
    
    var body: some View {
        GeometryReader { geometry in
            ZStack {
                // ENHANCED: Background that becomes visible during pull-to-dismiss
                Color.clear
                    .background(.ultraThinMaterial)
                    .opacity(backgroundOpacity)
                    .ignoresSafeArea()
                
                // Main video player content
                ZStack {
                    Color.black.ignoresSafeArea()
                    
                    if isLoading {
                        loadingView
                    } else if !videoPlayerData.isEmpty {
                        TabView(selection: $currentIndex) {
                            ForEach(Array(videoPlayerData.enumerated()), id: \.offset) { index, videoData in
                                CustomAVPlayerViewContent(
                                    videoData: videoData,
                                    index: index,
                                    onDismiss: {
                                        shouldDismiss = true
                                    },
                                    onRatingChange: { newRating in
                                        handleRatingChange(newRating, for: videoData.take)
                                    },
                                    onShare: {
                                        handleShare(videoData.take)
                                    },
                                    onPlayerCreated: { playerController in
                                        // CRITICAL FIX: Track video players for lifecycle management
                                        videoPlayers[index] = playerController
                                        // CRITICAL FIX: Set initial visibility correctly
                                        playerController.isCurrentlyVisible = (index == currentIndex)
                                    },
                                    onEditorRequest: onEditorRequest  // PHASE 1: NEW - Pass editor callback through
                                )
                                .tag(index)
                                .ignoresSafeArea(.all)
                            }
                        }
                        .tabViewStyle(PageTabViewStyle(indexDisplayMode: .never))
                        .ignoresSafeArea(.all)
                        .onChange(of: currentIndex) { oldValue, newIndex in
                            // CRITICAL FIX: Pause previous video and manage playback
                            handleVideoSwipe(from: oldValue, to: newIndex)
                            previousIndex = oldValue
                            print("🔄 SwipeableVideoPlayer: Switched to video \(newIndex + 1) of \(videoPlayerData.count)")
                        }
                        // CRITICAL FIX: Ensure initial video starts playing when TabView appears
                        .onAppear {
                            DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                                ensureCurrentVideoIsPlaying()
                            }
                        }
                    } else {
                        errorView
                    }
                }
                .simultaneousGesture(
                    DragGesture(minimumDistance: 50)
                        .onChanged { value in
                            if value.translation.height > 0 && abs(value.translation.height) > abs(value.translation.width) {
                                isDragging = true
                                dragOffset = value.translation.height
                                backgroundOpacity = min(0.8, dragOffset / 300)
                            }
                        }
                        .onEnded { value in
                            isDragging = false
                            
                            if value.translation.height > 120 {
                                withAnimation(.easeOut(duration: 0.35)) {
                                    dragOffset = geometry.size.height
                                    backgroundOpacity = 1.0
                                }
                                DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
                                    shouldDismiss = true
                                }
                            } else {
                                withAnimation(.spring(response: 0.5, dampingFraction: 0.8)) {
                                    dragOffset = 0
                                    backgroundOpacity = 0
                                }
                            }
                        }
                )
                .offset(y: dragOffset)
                .scaleEffect(isDragging ? max(0.85, 1 - (dragOffset / 1200)) : 1)
                .clipShape(RoundedRectangle(cornerRadius: isDragging ? min(20, dragOffset / 10) : 0))
            }
        }
        .onChange(of: shouldDismiss) { _, dismiss in
            if dismiss {
                // CRITICAL FIX: Pause all videos before dismissing
                pauseAllVideos()
                onDismiss()
            }
        }
        .onAppear {
            setupVideoPlayerData()
        }
        .onDisappear {
            // CRITICAL FIX: Cleanup - pause all videos when view disappears
            pauseAllVideos()
        }
    }
    
    // CRITICAL FIX: Ensure current video is playing (fallback for initial load) - UPDATED: Don't auto-play
    private func ensureCurrentVideoIsPlaying() {
        if let currentPlayer = videoPlayers[currentIndex] {
            currentPlayer.isCurrentlyVisible = true
            print("🎬 Current video (\(currentIndex + 1)) ready - waiting for user to play")
        }
    }
    
    // CRITICAL FIX: Handle video swipe with proper playback management AND overlay stability
    private func handleVideoSwipe(from oldIndex: Int, to newIndex: Int) {
        // Pause the previous video immediately
        if let previousPlayer = videoPlayers[oldIndex] {
            previousPlayer.pauseVideo()
            previousPlayer.isCurrentlyVisible = false
        }
        
        // Pause all other videos to ensure clean state
        pauseAllVideosExcept(newIndex)
        
        // Update visibility for the new video
        updatePlayerVisibility(for: newIndex)
        
        // CRITICAL FIX: Ensure overlay positioning remains stable after swipe
        if let newPlayer = videoPlayers[newIndex] {
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.2) {
                // Force layout update to ensure overlays stay in correct position
                if let overlayView = newPlayer.contentOverlayView {
                    overlayView.setNeedsLayout()
                    overlayView.layoutIfNeeded()
                    
                    // Ensure z-position is maintained
                    for subview in overlayView.subviews {
                        subview.layer.zPosition = 1000
                    }
                    print("🔄 Refreshed overlay positioning after video swipe")
                }
            }
        }
        
        print("🎬 Video swipe: paused video \(oldIndex + 1), now showing video \(newIndex + 1)")
    }
    
    // CRITICAL FIX: Update player visibility state - UPDATED: Don't auto-play
    private func updatePlayerVisibility(for index: Int) {
        for (playerIndex, player) in videoPlayers {
            let shouldBeVisible = (playerIndex == index)
            player.isCurrentlyVisible = shouldBeVisible
        }
        
        print("📱 Updated visibility: video \(index + 1) is now visible, ready for user control")
    }
    
    // CRITICAL FIX: Pause all videos except the specified index
    private func pauseAllVideosExcept(_ exceptIndex: Int) {
        for (index, player) in videoPlayers {
            if index != exceptIndex {
                player.pauseVideo()
                player.isCurrentlyVisible = false
            }
        }
    }
    
    // CRITICAL FIX: Pause all videos (for cleanup)
    private func pauseAllVideos() {
        for (_, player) in videoPlayers {
            player.pauseVideo()
            player.isCurrentlyVisible = false
        }
        print("⏹️ Paused all videos in SwipeableVideoPlayer")
    }
    
    // 🚨 CRITICAL FIX: Safe cleanup before opening editor to prevent AVPlayerItem reuse
    private func prepareForEditorTransition() {
        print("🧹 SwipeableVideoPlayer: Preparing for editor transition")
        
        // Pause all videos first
        pauseAllVideos()
        
        // Detach all player items to prevent reuse
        for (_, playerVC) in videoPlayers {
            if let player = playerVC.player {
                PlayerItemFactory.detachItem(from: player)
            }
        }
        
        print("✅ SwipeableVideoPlayer: All player items safely detached for editor transition")
    }
    
    // MARK: - Setup Methods
    
    private func setupVideoPlayerData() {
        isLoading = true
        
        Task { @MainActor in
            var playerDataArray: [VideoPlayerDisplayData] = []
            
            for (index, take) in takes.enumerated() {
                let unifiedTake = UnifiedTake(
                    from: take,
                    projectID: currentProject.id,
                    sessionID: currentSession.id,
                    fileName: URL(fileURLWithPath: take.filePath).lastPathComponent,
                    takeNumber: (currentSession.takes.firstIndex(where: { $0.id == take.id }) ?? 0) + 1
                )
                
                // CRITICAL FIX: Use contextual take numbering instead of session-wide numbering
                let contextualTakeNumber = index + 1 // Sequential numbering within the filtered context
                
                let displayData = VideoPlayerDisplayData(
                    take: take,
                    unifiedTake: unifiedTake,
                    takeNumber: contextualTakeNumber, // FIXED: Use contextual take number
                    totalTakes: takes.count // FIXED: Total takes in current context, not all session takes
                )
                
                playerDataArray.append(displayData)
            }
            
            videoPlayerData = playerDataArray
            isLoading = false
            
            print("✅ SwipeableVideoPlayer: Loaded \(playerDataArray.count) contextual videos, starting at index \(currentIndex)")
        }
    }
    
    // MARK: - Action Handlers
    
    private func handleRatingChange(_ newRating: TakeRating, for take: ProjectTake) {
        print("⭐ SwipeableVideoPlayer: Rating changed to \(newRating.rawValue) for \(URL(fileURLWithPath: take.filePath).lastPathComponent)")
        onTakeAction(.setRating(newRating), take)
    }
    
    private func handleShare(_ take: ProjectTake) {
        print("📤 SwipeableVideoPlayer: Sharing \(URL(fileURLWithPath: take.filePath).lastPathComponent)")
        onTakeAction(.share, take)
    }
    
    // MARK: - UI Components
    
    @ViewBuilder
    private var loadingView: some View {
        VStack(spacing: 16) {
            ProgressView()
                .scaleEffect(1.5)
                .tint(.white)
            
            Text("Loading videos...")
                .font(.headline)
                .foregroundColor(.white)
            
            Text("\(takes.count) take\(takes.count == 1 ? "" : "s")")
                .font(.caption)
                .foregroundColor(.gray)
        }
    }
    
    @ViewBuilder
    private var errorView: some View {
        VStack(spacing: 16) {
            Image(systemName: "exclamationmark.triangle")
                .font(.system(size: 48))
                .foregroundColor(.red)
            
            Text("No videos to display")
                .font(.headline)
                .foregroundColor(.white)
            
            Button("Close") {
                shouldDismiss = true
            }
            .font(.headline)
            .foregroundColor(.white)
            .padding()
            .background(Color.blue, in: RoundedRectangle(cornerRadius: 12))
        }
    }
}

// MARK: - Custom AVPlayer View Content

struct CustomAVPlayerViewContent: View {
    let videoData: VideoPlayerDisplayData
    let index: Int
    let onDismiss: () -> Void
    let onRatingChange: (TakeRating) -> Void
    let onShare: () -> Void
    let onPlayerCreated: (EnhancedAVPlayerViewController) -> Void
    
    // PHASE 1: NEW - Editor request callback
    let onEditorRequest: ((ProjectTake) -> Void)?
    
    var body: some View {
        CustomAVPlayerViewController(
            videoData: videoData,
            index: index,
            onRatingChange: onRatingChange,
            onShare: onShare,
            onPlayerCreated: onPlayerCreated,
            onEditorRequest: onEditorRequest  // PHASE 1: NEW - Pass editor callback through
        )
        .ignoresSafeArea(.all)
    }
}

// MARK: - Custom AVPlayerViewController with Overlay Management

struct CustomAVPlayerViewController: UIViewControllerRepresentable {
    let videoData: VideoPlayerDisplayData
    let index: Int
    let onRatingChange: (TakeRating) -> Void
    let onShare: () -> Void
    let onPlayerCreated: (EnhancedAVPlayerViewController) -> Void
    
    // PHASE 1: NEW - Editor request callback
    let onEditorRequest: ((ProjectTake) -> Void)?
    
    // NEW: Track overlay visibility state
    @State private var showOverlays = true
    
    func makeUIViewController(context: Context) -> EnhancedAVPlayerViewController {
        let playerVC = EnhancedAVPlayerViewController()
        
        // RESTORED: Proper video configuration with natural aspect ratios
        playerVC.videoGravity = AVLayerVideoGravity.resizeAspect // FIXED: Use full type name
        playerVC.showsPlaybackControls = true
        playerVC.allowsPictureInPicturePlayback = false
        playerVC.modalPresentationStyle = UIModalPresentationStyle.fullScreen // FIXED: Use full type name
        playerVC.entersFullScreenWhenPlaybackBegins = false
        playerVC.exitsFullScreenWhenPlaybackEnds = false
        
        // CRITICAL FIX: Mark as part of swipeable collection to enable lifecycle management
        playerVC.isPartOfSwipeableCollection = true
        
        // NEW: Setup control visibility monitoring for overlay synchronization
        playerVC.onControlVisibilityChanged = { controlsVisible in
            DispatchQueue.main.async {
                context.coordinator.updateOverlayVisibility(controlsVisible: controlsVisible, playerVC: playerVC)
            }
        }
        
        // Store coordinator and setup video
        playerVC.coordinator = context.coordinator
        setupVideo(for: playerVC)
        setupOverlay(for: playerVC, coordinator: context.coordinator)
        
        // NEW: Setup control visibility monitoring
        playerVC.setupControlVisibilityMonitoring()
        
        // CRITICAL FIX: Notify parent about player creation for lifecycle management
        onPlayerCreated(playerVC)
        
        return playerVC
    }
    
    func updateUIViewController(_ uiViewController: EnhancedAVPlayerViewController, context: Context) {
        // Minimal updates to avoid interference
    }
    
    // CRITICAL FIX: New method to setup video naturally without forcing composition
    private func setupVideoNaturally(for playerVC: EnhancedAVPlayerViewController, videoURL: URL) {
        // RESEARCH-BASED FIX: Simply create AVPlayer with URL - let AVPlayerViewController handle orientation naturally
        let player = AVPlayer(url: videoURL)
        playerVC.player = player
        
        print("✅ SwipeableVideoPlayer: Set up video naturally - letting AVPlayerViewController handle orientation automatically")
        print("   💡 Research finding: AVPlayerViewController respects video rotation metadata without composition")
    }
    
    private func setupVideo(for playerVC: EnhancedAVPlayerViewController) {
        guard let videoURL = getVideoURL() else {
            print("❌ Could not get video URL for \(videoData.unifiedTake.fileName)")
            return
        }
        
        playerVC.videoData = videoData
        
        // CRITICAL FIX: Always use orientation fix, never SmartFillPreview
        // The SmartFill processing already created the processed file, just play it normally
        setupVideoWithOrientationFix(for: playerVC, videoURL: videoURL)
        
        let smartFillIndicator = videoData.take.hasSmartFilledVersion ? " (SmartFill processed)" : " (original)"
        print("✅ Set up video for playback: \(videoData.unifiedTake.fileName)\(smartFillIndicator)")
    }
    
    // Remove the SmartFill preview setup - not needed for modern system
    private func setupVideoWithSmartFill(for playerVC: EnhancedAVPlayerViewController, videoURL: URL) {
        // Now just use regular video setup since SmartFill processing is handled separately
        setupVideoWithOrientationFix(for: playerVC, videoURL: videoURL)
    }
    
    // NEW: Method to determine if Smart Fill should be applied - ONLY for videos with actual SmartFill versions
    private func shouldApplySmartFill(for take: ProjectTake) -> Bool {
        // FIXED: Never use SmartFillPreview for videos that have been processed - play the actual processed file
        // SmartFillPreview is only for live preview, not for playing processed videos
        return false  // Always play the actual video file (original or processed)
    }
    
    private func setupVideoWithOrientationFix(for playerVC: EnhancedAVPlayerViewController, videoURL: URL) {
        // 🚨 CRITICAL FIX: Use PlayerItemFactory to create fresh item and avoid reuse crashes
        let asset = AVURLAsset(url: videoURL)
        
        // Create a fresh player item using the factory (never reuses existing items)
        let playerItem = PlayerItemFactory.makeItem(asset: asset)
        let player = AVPlayer(playerItem: playerItem)
        playerVC.player = player
        
        print("✅ SwipeableVideoPlayer: Created fresh player with PlayerItemFactory")
        
        // Then apply the working transform logic with KVO observation for reliable timing
        Task { @MainActor in
            do {
                guard let videoTrack = try await asset.loadTracks(withMediaType: .video).first else {
                    print("⚠️ Could not load video track")
                    return
                }
                
                let preferredTransform = try await videoTrack.load(.preferredTransform)
                let naturalSize = try await videoTrack.load(.naturalSize)
                
                print("🔄 SwipeableVideo Orientation Fix:")
                print("   📐 Preferred Transform: \(preferredTransform)")
                print("   📏 Natural Size: \(naturalSize)")
                print("   🔧 Transform Analysis: \(analyzeTransform(preferredTransform))")
                
                // Apply the working transform logic that made landscape correct
                let correctTransform = getCorrectTransform(for: preferredTransform)
                
                // CRITICAL FIX: Use KVO-based approach instead of unreliable timer retry
                await applyTransformWithKVOObservation(
                    playerViewController: playerVC,
                    transform: correctTransform
                )
                
            } catch {
                print("❌ Failed to apply orientation fix: \(error)")
            }
        }
    }
    
    // NEW: KVO-based transform application for reliable AVPlayerLayer access
    @MainActor
    private func applyTransformWithKVOObservation(
        playerViewController: EnhancedAVPlayerViewController,
        transform: CGAffineTransform
    ) async {
        print("🔄 Applying transform with KVO observation for reliable timing")
        
        // Wait for the player layer to be available with KVO observation
        let playerLayer = await waitForPlayerLayerWithKVO(playerViewController: playerViewController)
        
        guard let layer = playerLayer else {
            print("❌ Failed to access AVPlayerLayer after KVO observation - falling back to natural handling")
            // FALLBACK: Let AVPlayerViewController handle orientation naturally
            return
        }
        
        // Apply transform to the ready player layer
        if !transform.isIdentity {
            layer.setAffineTransform(transform)
            print("   ✅ Applied Transform with KVO approach: \(analyzeTransform(transform))")
        } else {
            print("   ✅ Using identity transform (no rotation needed)")
        }
    }
    
    // NEW: Reliable KVO-based player layer detection
    private func waitForPlayerLayerWithKVO(playerViewController: EnhancedAVPlayerViewController) async -> AVPlayerLayer? {
        return await withCheckedContinuation { continuation in
            var observer: NSKeyValueObservation?
            var hasResumed = false
            
            func checkAndReturnLayer() {
                guard !hasResumed else { return }
                
                if let playerLayer = getPlayerLayer(from: playerViewController) {
                    hasResumed = true
                    observer?.invalidate()
                    continuation.resume(returning: playerLayer)
                    print("✅ KVO: Found player layer successfully")
                }
            }
            
            // Check if layer is already available
            checkAndReturnLayer()
            
            guard !hasResumed else { return }
            
            // ENHANCED: Observe player readiness state changes
            if let player = playerViewController.player {
                observer = player.observe(\.currentItem?.status, options: [.new]) { _, _ in
                    DispatchQueue.main.async {
                        checkAndReturnLayer()
                    }
                }
            }
            
            // Also observe view layout changes as backup
            let layoutObserver = NotificationCenter.default.addObserver(
                forName: UIDevice.orientationDidChangeNotification,
                object: nil,
                queue: .main
            ) { _ in
                checkAndReturnLayer()
            }
            
            // Safety timeout after 5 seconds
            DispatchQueue.main.asyncAfter(deadline: .now() + 5.0) {
                guard !hasResumed else { return }
                hasResumed = true
                observer?.invalidate()
                NotificationCenter.default.removeObserver(layoutObserver)
                
                print("⏰ KVO observation timeout - attempting final layer check")
                let finalLayer = self.getPlayerLayer(from: playerViewController)
                continuation.resume(returning: finalLayer)
            }
        }
    }
    
    private func getCorrectTransform(for preferredTransform: CGAffineTransform) -> CGAffineTransform {
        let t = preferredTransform
        
        // CRITICAL FIX: Skip orientation fixes for exported and merged videos - they're already correctly oriented
        if videoData.take.takeType == .exported || videoData.take.takeType == .merged {
            print("🎬 Skipping orientation transform for \(videoData.take.takeType.displayName) - already correctly oriented")
            return .identity
        }
        
        if t.isIdentity {
            // SURGICAL FIX: Add 180° rotation to fix upside-down display (ONLY for regular takes)
            return CGAffineTransform(rotationAngle: CGFloat.pi)
        } else if t.a == 0 && t.b == 1 && t.c == -1 && t.d == 0 {
            // Portrait (90° clockwise) + 180° fix = 270° total
            return CGAffineTransform(rotationAngle: CGFloat.pi + CGFloat.pi / 2)
            
        } else if t.a == -1 && t.b == 0 && t.c == 0 && t.d == -1 {
            // Landscape Left (180° rotation) + 180° fix = 360° = 0°
            return .identity
            
        } else if t.a == 0 && t.b == -1 && t.c == 1 && t.d == 0 {
            // Portrait Upside Down (-90°) + 180° fix = 90° total
            return CGAffineTransform(rotationAngle: CGFloat.pi + (-CGFloat.pi / 2))
            
        } else {
            // Custom transform - invert and add 180°
            return preferredTransform.inverted().concatenating(CGAffineTransform(rotationAngle: CGFloat.pi))
        }
    }
    
    // CRITICAL FIX: Add missing helper methods from UnifiedVideoPlayerView
    private func analyzeTransform(_ transform: CGAffineTransform) -> String {
        if transform.isIdentity {
            return "Identity (no rotation)"
        } else if transform.a == 0 && transform.b == 1 && transform.c == -1 && transform.d == 0 {
            return "90° clockwise rotation"
        } else if transform.a == -1 && transform.b == 0 && transform.c == 0 && transform.d == -1 {
            return "180° rotation"
        } else if transform.a == 0 && transform.b == -1 && transform.c == 1 && transform.d == 0 {
            return "90° counter-clockwise rotation"
        } else {
            return "Custom transform: a=\(transform.a), b=\(transform.b), c=\(transform.c), d=\(transform.d)"
        }
    }
    
    private func getPlayerLayer(from playerViewController: EnhancedAVPlayerViewController) -> AVPlayerLayer? {
        return findPlayerLayer(in: playerViewController.view.layer)
    }
    
    private func findPlayerLayer(in layer: CALayer) -> AVPlayerLayer? {
        if let playerLayer = layer as? AVPlayerLayer {
            return playerLayer
        }
        
        if let sublayers = layer.sublayers {
            for sublayer in sublayers {
                if let playerLayer = sublayer as? AVPlayerLayer {
                    return playerLayer
                }
            }
        }
        
        return nil
    }
    
    // CRITICAL FIX: Add method to refresh overlay positioning (move to class level)
    private func refreshOverlayPositioning(for playerViewController: EnhancedAVPlayerViewController) {
        guard let overlayView = playerViewController.contentOverlayView else { return }
        
        // Force layout update to ensure overlays stay in correct position
        overlayView.setNeedsLayout()
        overlayView.layoutIfNeeded()
        
        // Ensure z-position is maintained
        for subview in overlayView.subviews {
            subview.layer.zPosition = 1000
        }
        
        print("🔄 Refreshed overlay positioning for stable display")
    }
    
    
    
    

    private func setupOverlay(for playerVC: EnhancedAVPlayerViewController, coordinator: Coordinator) {
        guard let overlayView = playerVC.contentOverlayView else {
            print("❌ Could not access contentOverlayView")
            return
        }
        
        overlayView.subviews.forEach { $0.removeFromSuperview() }
        
        // PHASE 4: UPDATED - Enable sparkles.2 editor button for both regular takes AND slate videos
        if (videoData.take.takeType == .regular || videoData.take.takeType == .slate),
           onEditorRequest != nil {
            let editorButtonView = createEditorButtonOverlay(coordinator: coordinator)
            overlayView.addSubview(editorButtonView)
            
            editorButtonView.translatesAutoresizingMaskIntoConstraints = false
            // PHASE 2: Lower left safe area positioning as requested
            let leadingConstraint = editorButtonView.leadingAnchor.constraint(equalTo: overlayView.safeAreaLayoutGuide.leadingAnchor, constant: 20)
            let bottomConstraint = editorButtonView.bottomAnchor.constraint(equalTo: overlayView.safeAreaLayoutGuide.bottomAnchor, constant: -80) // Position in lower area, above controls
            let widthConstraint = editorButtonView.widthAnchor.constraint(equalToConstant: 60)
            let heightConstraint = editorButtonView.heightAnchor.constraint(equalToConstant: 60)
            
            // Set higher priority for stable positioning
            leadingConstraint.priority = UILayoutPriority(999)
            bottomConstraint.priority = UILayoutPriority(999)
            widthConstraint.priority = UILayoutPriority(1000)
            heightConstraint.priority = UILayoutPriority(1000)
            
            NSLayoutConstraint.activate([leadingConstraint, bottomConstraint, widthConstraint, heightConstraint])
            
            // Ensure editor button stays positioned correctly
            editorButtonView.layer.zPosition = 1000
        }
        
        // Add rating buttons for regular takes AND slates with SAFE AREA positioning
        if videoData.take.takeType == .regular || videoData.take.takeType == .slate {
            let ratingButtonsView = createRatingButtonsOverlay(coordinator: coordinator)
            overlayView.addSubview(ratingButtonsView)
            
            ratingButtonsView.translatesAutoresizingMaskIntoConstraints = false
            // CRITICAL FIX: Use safe area but with priority adjustments for stability
            let trailingConstraint = ratingButtonsView.trailingAnchor.constraint(equalTo: overlayView.safeAreaLayoutGuide.trailingAnchor, constant: -20)
            let centerYConstraint = ratingButtonsView.centerYAnchor.constraint(equalTo: overlayView.safeAreaLayoutGuide.centerYAnchor)
            let widthConstraint = ratingButtonsView.widthAnchor.constraint(equalToConstant: 60)
            let heightConstraint = ratingButtonsView.heightAnchor.constraint(equalToConstant: 280)
            
            // CRITICAL FIX: Set higher priority for these constraints to prevent breaking
            trailingConstraint.priority = UILayoutPriority(999)
            centerYConstraint.priority = UILayoutPriority(999)
            widthConstraint.priority = UILayoutPriority(1000)
            heightConstraint.priority = UILayoutPriority(1000)
            
            NSLayoutConstraint.activate([trailingConstraint, centerYConstraint, widthConstraint, heightConstraint])
            
            // CRITICAL FIX: Ensure overlay stays positioned correctly during orientation changes
            ratingButtonsView.layer.zPosition = 1000
        }
        
        // Add video title with SAFE AREA positioning
        let titleView = createTitleOverlay()
        overlayView.addSubview(titleView)
        
        titleView.translatesAutoresizingMaskIntoConstraints = false
        // CRITICAL FIX: Use safe area with priority adjustments
        let centerXConstraint = titleView.centerXAnchor.constraint(equalTo: overlayView.safeAreaLayoutGuide.centerXAnchor)
        let topConstraint = titleView.topAnchor.constraint(equalTo: overlayView.safeAreaLayoutGuide.topAnchor, constant: 20)
        
        // CRITICAL FIX: Set higher priority for these constraints
        centerXConstraint.priority = UILayoutPriority(999)
        topConstraint.priority = UILayoutPriority(999)
        
        NSLayoutConstraint.activate([centerXConstraint, topConstraint])
        
        // CRITICAL FIX: Ensure title stays positioned correctly
        titleView.layer.zPosition = 1000
        
        print("✅ Added overlay controls with safe area positioning and stability priorities")
    }
    
    // PHASE 2: UPDATED - Enhanced sparkles.2 editor button styling to match rating buttons
    private func createEditorButtonOverlay(coordinator: Coordinator) -> UIView {
        let containerView = UIView()
        containerView.backgroundColor = UIColor.clear
        
        let buttonSize: CGFloat = 50
        
        let button = UIButton(type: .system)
        button.frame = CGRect(
            x: (60 - buttonSize) / 2,
            y: (60 - buttonSize) / 2,
            width: buttonSize,
            height: buttonSize
        )
        
        // PHASE 2: Enhanced styling to match rating buttons exactly
        let configuration = UIImage.SymbolConfiguration(pointSize: 22, weight: .medium)
        button.setImage(UIImage(systemName: "sparkles.2", withConfiguration: configuration), for: .normal)
        button.tintColor = UIColor.white.withAlphaComponent(0.9)
        button.backgroundColor = UIColor.systemPurple.withAlphaComponent(0.6)  // Consistent with rating button opacity
        button.layer.cornerRadius = buttonSize / 2
        
        // PHASE 2: Match rating button shadow styling exactly
        button.layer.shadowColor = UIColor.black.cgColor
        button.layer.shadowOffset = CGSize(width: 0, height: 2)
        button.layer.shadowRadius = 4
        button.layer.shadowOpacity = 0.7
        
        button.addTarget(coordinator, action: #selector(Coordinator.editorButtonTapped), for: .touchUpInside)
        
        containerView.addSubview(button)
        
        return containerView
    }
    
    private func createRatingButtonsOverlay(coordinator: Coordinator) -> UIView {
        let containerView = UIView()
        containerView.backgroundColor = UIColor.clear
        
        let buttonSize: CGFloat = 50
        let spacing: CGFloat = 16
        
        let ratings: [(TakeRating, String, UIColor)] = [
            (.favorite, "star.fill", .systemYellow),
            (.good, "checkmark.circle.fill", .systemGreen),
            (.unrated, "circle", .systemGray),
            (.bad, "xmark.circle.fill", .systemRed)
        ]
        
        for (index, (rating, iconName, color)) in ratings.enumerated() {
            let button = UIButton(type: .system)
            button.frame = CGRect(
                x: (60 - buttonSize) / 2,
                y: CGFloat(index) * (buttonSize + spacing),
                width: buttonSize,
                height: buttonSize
            )
            
            let configuration = UIImage.SymbolConfiguration(pointSize: 22, weight: .medium)
            button.setImage(UIImage(systemName: iconName, withConfiguration: configuration), for: .normal)
            button.tintColor = videoData.take.rating == rating ? color : UIColor.white.withAlphaComponent(0.9)
            button.backgroundColor = videoData.take.rating == rating ? color.withAlphaComponent(0.4) : UIColor.black.withAlphaComponent(0.6)
            button.layer.cornerRadius = buttonSize / 2
            
            button.layer.shadowColor = UIColor.black.cgColor
            button.layer.shadowOffset = CGSize(width: 0, height: 2)
            button.layer.shadowRadius = 4
            button.layer.shadowOpacity = 0.7
            
            button.tag = index
            button.addTarget(coordinator, action: #selector(Coordinator.ratingButtonTapped(_:)), for: .touchUpInside)
            
            containerView.addSubview(button)
        }
        
        return containerView
    }
    
    private func createTitleOverlay() -> UIView {
        let containerView = UIView()
        containerView.backgroundColor = UIColor.black.withAlphaComponent(0.5)
        containerView.layer.cornerRadius = 12
        
        let stackView = UIStackView()
        stackView.axis = .vertical
        stackView.alignment = .center
        stackView.spacing = 4
        
        let titleLabel = UILabel()
        titleLabel.text = formatVideoTitle()
        titleLabel.textColor = .white
        titleLabel.font = UIFont.boldSystemFont(ofSize: 18)
        titleLabel.textAlignment = .center
        
        let subtitleLabel = UILabel()
        subtitleLabel.text = formatVideoSubtitle()
        subtitleLabel.textColor = UIColor.white.withAlphaComponent(0.9)
        subtitleLabel.font = UIFont.systemFont(ofSize: 14)
        subtitleLabel.textAlignment = .center
        
        stackView.addArrangedSubview(titleLabel)
        stackView.addArrangedSubview(subtitleLabel)
        
        containerView.addSubview(stackView)
        stackView.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([
            stackView.leadingAnchor.constraint(equalTo: containerView.leadingAnchor, constant: 12),
            stackView.trailingAnchor.constraint(equalTo: containerView.trailingAnchor, constant: -12),
            stackView.topAnchor.constraint(equalTo: containerView.topAnchor, constant: 8),
            stackView.bottomAnchor.constraint(equalTo: containerView.bottomAnchor, constant: -8)
        ])
        
        return containerView
    }
    
    // MARK: - Coordinator
    
    func makeCoordinator() -> Coordinator {
        Coordinator(self)
    }
    
    class Coordinator: NSObject {
        let parent: CustomAVPlayerViewController
        
        init(_ parent: CustomAVPlayerViewController) {
            self.parent = parent
        }
        
        // 🚨 CRITICAL FIX: Handle editor button tap with proper cleanup
        @objc func editorButtonTapped() {
            print("✨ Editor Button Tapped for: \(parent.videoData.unifiedTake.fileName)")
            
            // Note: Proper cleanup should be handled by the parent SwipeableVideoPlayerView
            // when it receives the editor request callback
            parent.onEditorRequest?(parent.videoData.take)
        }
        
        // UPDATED: Update overlay visibility based on control visibility instead of playback state
        func updateOverlayVisibility(controlsVisible: Bool, playerVC: EnhancedAVPlayerViewController?) {
            guard let playerVC = playerVC,
                  let overlayView = playerVC.contentOverlayView else { return }
            
            let targetAlpha: CGFloat = controlsVisible ? 1.0 : 0.0
            let animationDuration: TimeInterval = 0.3
            
            UIView.animate(withDuration: animationDuration, delay: 0, options: .curveEaseInOut) {
                for subview in overlayView.subviews {
                    subview.alpha = targetAlpha
                }
            }
            
            print("🎮 \(controlsVisible ? "Showing" : "Hiding") overlays with player controls")
        }
        
        @objc func ratingButtonTapped(_ sender: UIButton) {
            let ratings: [TakeRating] = [.favorite, .good, .unrated, .bad]
            guard sender.tag < ratings.count else { return }
            
            let selectedRating = ratings[sender.tag]
            print("🎯 Rating Button Tapped: \(selectedRating.rawValue)")
            
            parent.onRatingChange(selectedRating)
            updateButtonAppearances(selectedRating: selectedRating, sender: sender)
        }
        
        private func updateButtonAppearances(selectedRating: TakeRating, sender: UIButton) {
            guard let containerView = sender.superview else { return }
            
            let colors: [UIColor] = [.systemYellow, .systemGreen, .systemGray, .systemRed]
            let ratings: [TakeRating] = [.favorite, .good, .unrated, .bad]
            
            for (index, subview) in containerView.subviews.enumerated() {
                guard let button = subview as? UIButton, index < colors.count else { continue }
                
                let rating = ratings[index]
                let color = colors[index]
                
                button.tintColor = selectedRating == rating ? color : UIColor.white.withAlphaComponent(0.9)
                button.backgroundColor = selectedRating == rating ? color.withAlphaComponent(0.4) : UIColor.black.withAlphaComponent(0.6)
            }
        }
    }
    
    // MARK: - Helper Methods
    
    private func getVideoURL() -> URL? {
        do {
            // CRITICAL FIX: Use effectiveFilePath which prefers SmartFill version if available
            let effectiveFileName = URL(fileURLWithPath: videoData.take.effectiveFilePath).lastPathComponent
            
            print("🎬 SwipeableVideoPlayer: Loading video - \(effectiveFileName)")
            
            // 🚨 ENHANCED: Better SmartFill status reporting
            let smartFillIndicator = videoData.take.hasSmartFilledVersion ? " (SmartFill)" : ""
            
            // 🚨 ENHANCED: Additional validation before loading
            let effectiveFilePath = videoData.take.effectiveFilePath
            let effectiveURL = URL(fileURLWithPath: effectiveFilePath)
            
            guard FileManager.default.fileExists(atPath: effectiveFilePath) else {
                print("❌ SwipeableVideoPlayer: Video file doesn't exist - \(effectiveFileName)")
                // FALLBACK: Try original file path as last resort
                let originalURL = URL(fileURLWithPath: videoData.take.filePath)
                if FileManager.default.fileExists(atPath: videoData.take.filePath) {
                    print("🔄 SwipeableVideoPlayer: Falling back to original file - \(originalURL.lastPathComponent)")
                    return originalURL
                } else {
                    print("❌ SwipeableVideoPlayer: Neither effective nor original file exists!")
                    return nil
                }
            }
            
            print("🎬 SwipeableVideoPlayer: Setting up player for \(effectiveFileName)\(smartFillIndicator)")
            
            let videoURL = try VideoFileManager.shared.getVideoURL(for: effectiveFileName)
            
            print("✅ Set up video for playback: \(effectiveFileName) (original)")
            
            return videoURL
            
        } catch {
            print("⚠️ VideoFileManager couldn't locate file: \(error)")
        }
        
        // Fallback to direct file path (try SmartFill version first if available)
        let effectiveFilePath = videoData.take.effectiveFilePath
        let effectiveURL = URL(fileURLWithPath: effectiveFilePath)
        
        if FileManager.default.fileExists(atPath: effectiveURL.path) {
            let smartFillIndicator = videoData.take.hasSmartFilledVersion ? " (SmartFill)" : ""
            print("🎬 SwipeableVideoPlayer: Using direct path\(smartFillIndicator) - \(effectiveURL.lastPathComponent)")
            return effectiveURL
        }
        
        // Final fallback to original file path
        if !videoData.take.filePath.isEmpty {
            let originalURL = URL(fileURLWithPath: videoData.take.filePath)
            if FileManager.default.fileExists(atPath: originalURL.path) {
                print("🎬 SwipeableVideoPlayer: Falling back to original file - \(originalURL.lastPathComponent)")
                return originalURL
            }
        }
        
        return nil
    }
    
    private func formatVideoTitle() -> String {
        switch videoData.take.takeType {
        case .merged:
            return "Merged Video"
        case .exported:
            return "Exported Take"
        case .slate:
            // ENHANCED: Show slate with session-wide numbering
            if let slateID = videoData.take.slateID {
                return slateID // e.g., "SLATE1", "SLATE2"
            } else {
                return "Slate \(videoData.takeNumber)"
            }
        case .regular:
            // CRITICAL FIX: Show proper scene-aware numbering with SmartFill indicator
            let baseTitle = if videoData.take.sceneNumber > 1 {
                "Scene \(videoData.take.sceneNumber) Take \(videoData.takeNumber)"
            } else {
                "Take \(videoData.takeNumber)"
            }
            
            // Add SmartFill indicator if available
            if videoData.take.hasSmartFilledVersion {
                return "\(baseTitle) (Smart Fill)"
            }
            
            return baseTitle
        }
    }
    
    private func formatVideoSubtitle() -> String {
        let duration = formattedDuration(videoData.take.durationSeconds)
        
        // Build base subtitle
        let baseSubtitle = switch videoData.take.takeType {
        case .slate:
            "\(duration) • \(videoData.takeNumber) of \(videoData.totalTakes) slates"
        case .regular:
            if videoData.take.sceneNumber > 1 {
                "\(duration) • Take \(videoData.takeNumber) of \(videoData.totalTakes) in Scene \(videoData.take.sceneNumber)"
            } else {
                "\(duration) • \(videoData.takeNumber) of \(videoData.totalTakes)"
            }
        case .merged, .exported:
            "\(duration) • \(videoData.takeNumber) of \(videoData.totalTakes)"
        }
        
        // Add SmartFill status info for portrait takes
        if let capturedOrientation = videoData.take.capturedOrientation, capturedOrientation == .portrait {
            let smartFillStatus = videoData.take.hasSmartFilledVersion ? "Smart Fill Applied" : "Portrait Original"
            return "\(baseSubtitle) • \(smartFillStatus)"
        }
        
        return baseSubtitle
    }
    
    private func formattedDuration(_ duration: TimeInterval) -> String {
        let minutes = Int(duration) / 60
        let seconds = Int(duration) % 60
        return String(format: "%d:%02d", minutes, seconds)
    }
}
