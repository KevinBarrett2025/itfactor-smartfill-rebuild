import SwiftUI

public struct HomeScreenView: View {
    let repo: ProjectsRepository
    @State private var vm: ProjectsViewModel
    @State private var showingNewProjectWizard = false
    
    public init(repo: ProjectsRepository) {
        self.repo = repo
        _vm = State(initialValue: ProjectsViewModel(repo: repo))
    }
    
    public var body: some View {
        NavigationStack {
            ZStack {
                // Background gradient matching our brand
                BrandBackground()
                    .ignoresSafeArea()
                
                VStack(spacing: 0) {
                    // Top bar with archive (left) and settings gear (right)
                    HStack {
                        // Archive icon with badge (LEFT)
                        NavigationLink(destination: ArchivesView(repo: repo)) {
                            ZStack(alignment: .topTrailing) {
                                Circle()
                                    .fill(Color.white.opacity(0.11))
                                    .frame(width: 44, height: 44)
                                    .shadow(radius: 2)
                                Image(systemName: "archivebox.fill")
                                    .resizable()
                                    .scaledToFit()
                                    .frame(width: 26, height: 26)
                                    .foregroundColor(Color.blue)
                                
                                // Archive count badge
                                if vm.archivedProjects.count > 0 {
                                    Text("\(vm.archivedProjects.count)")
                                        .font(.caption2)
                                        .fontWeight(.bold)
                                        .foregroundColor(.white)
                                        .frame(width: 18, height: 18)
                                        .background(Circle().fill(Color.blue))
                                        .offset(x: 14, y: -12)
                                }
                            }
                            .padding(.leading, 12)
                            .padding(.top, 10)
                            .accessibilityLabel("View Archives")
                        }
                        
                        Spacer()
                        
                        // Settings gear (RIGHT)
                        NavigationLink(destination: SettingsView()) {
                            Image(systemName: "gearshape.fill")
                                .foregroundStyle(.white)
                                .font(.title2)
                        }
                        .padding(.trailing, 12)
                    }
                    .padding(.horizontal, 4)
                    .padding(.top, 16)
                    
                    // Enterprise app logo (non-interactive)
                    Image("AppLogo")
                        .resizable()
                        .scaledToFit()
                        .frame(width: 220, height: 220)
                        .padding(.vertical, 8)
                    
                    // Project cards
                    if vm.projects.isEmpty {
                        VStack(spacing: 24) {
                            Spacer()
                            Image(systemName: "square.stack.3d.up.slash")
                                .font(.system(size: 64))
                                .foregroundStyle(.white.opacity(0.6))
                            VStack(spacing: 8) {
                                Text("No Projects Yet")
                                    .font(.title2.bold())
                                    .foregroundStyle(.white)
                                Text("Start your first project by tapping the button below")
                                    .font(.body)
                                    .foregroundStyle(.white.opacity(0.7))
                                    .multilineTextAlignment(.center)
                                    .padding(.horizontal, 40)
                            }
                            Spacer()
                        }
                    } else {
                        // Project list using non-interactive branded cards inside NavigationLink
                        ScrollView {
                            LazyVStack(spacing: 8) { // RESTORED: Professional spacing now that duplicate IDs are fixed
                                // 🚨 ENHANCED: Use stable IDs and prevent ForEach crashes
                                ForEach(vm.projects.indices, id: \.self) { index in
                                    if index < vm.projects.count {
                                        let project = vm.projects[index]
                                        NavigationLink {
                                            ProjectDetailView(projectID: project.id, repo: repo)
                                        } label: {
                                            BrandedRowCard(
                                                title: project.title,
                                                subtitle: project.castingOffice ?? "",
                                                roles: project.roles.map { $0.name }.joined(separator: ", "),
                                                sessionsCount: project.sessions.filter { !$0.isArchived }.count, // Only show active sessions count
                                                isInteractive: false
                                            )
                                        }
                                        .buttonStyle(PlainButtonStyle())
                                        // 🚨 ADDITIONAL SAFETY: Force stable ID based on both index and project ID
                                        .id("\(index)-\(project.id)")
                                    }
                                }
                            }
                            .padding(.horizontal, 16)
                            .padding(.top, 8)
                            .padding(.bottom, 120) // SURGICAL FIX: Increased from 100 to 120 to prevent button overlap
                        }
                    }
                }
                
                // New branded primary button
                VStack {
                    Spacer()
                    BrandedPrimaryButton(
                        label: "Start New Session",
                        icon: "plus"
                    ) {
                        showingNewProjectWizard = true
                    }
                    .padding(.bottom, 34)
                }
            }
            .navigationBarHidden(true)
            .navigationDestination(for: UUID.self) { id in
                ProjectDetailView(projectID: id, repo: repo)
            }
        }
        .sheet(isPresented: $showingNewProjectWizard) {
            NewProjectWizard { newProject in
                repo.insert(project: newProject)
                vm.reload()
            }
        }
        .onAppear {
            vm.reload()
        }
        .onReceive(NotificationCenter.default.publisher(for: Notification.Name("STSProjectsListShouldReload"))) { _ in
            // 🚨 ENHANCED: Prevent main thread blocking during reload
            Task { @MainActor in
                vm.reload()
            }
        }
        .onReceive(NotificationCenter.default.publisher(for: Notification.Name("STSTakeRatingUpdated"))) { _ in
            // 🚨 ENHANCED: Prevent main thread blocking during reload
            Task { @MainActor in
                vm.reload()
            }
        }
    }
}
