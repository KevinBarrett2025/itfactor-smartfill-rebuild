import SwiftUI
import CoreMotion

// MARK: - Level Indicator View
struct LevelIndicatorView: View {
    @StateObject private var motionManager = DeviceMotionManager()
    @State private var showIndicator = false
    @State private var isLevel = false
    @State private var hideIndicatorTask: Task<Void, Never>?
    
    let showInPortrait: Bool
    let showInLandscape: Bool
    let customBottomPadding: CGFloat? // NEW: Accept custom positioning from parent
    
    init(showInPortrait: Bool = true, showInLandscape: Bool = true, customBottomPadding: CGFloat? = nil) {
        self.showInPortrait = showInPortrait
        self.showInLandscape = showInLandscape
        self.customBottomPadding = customBottomPadding
    }
    
    var body: some View {
        GeometryReader { geometry in
            ZStack {
                if showIndicator && shouldShowForOrientation {
                    levelIndicatorContent
                        .transition(.opacity.combined(with: .scale))
                        .animation(.spring(response: 0.5, dampingFraction: 0.8), value: showIndicator)
                        .animation(.easeInOut(duration: 0.3), value: isLevel)
                }
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity)
        }
        .onReceive(motionManager.$tiltAngle) { angle in
            updateLevelIndicator(angle: angle)
        }
        .onReceive(motionManager.$isPortrait) { _ in
            // Re-evaluate visibility when orientation changes
            if motionManager.isSignificantlyTilted && shouldShowForOrientation {
                showIndicator = true
            }
        }
        .onAppear {
            motionManager.startUpdates()
        }
        .onDisappear {
            motionManager.stopUpdates()
            hideIndicatorTask?.cancel()
        }
    }
    
    private var shouldShowForOrientation: Bool {
        if motionManager.isPortrait {
            return showInPortrait
        } else {
            return showInLandscape
        }
    }
    
    @ViewBuilder
    private var levelIndicatorContent: some View {
        if motionManager.isPortrait {
            portraitLevelIndicator
        } else {
            landscapeLevelIndicator
        }
    }
    
    // MARK: - Portrait Level Indicator (UPDATED: Uses calculated positioning)
    
    private var portraitLevelIndicator: some View {
        VStack {
            Spacer()
            
            // Center the horizontal level indicator above record button
            VStack(spacing: 12) {
                // Horizontal level bubble (same as landscape but repositioned)
                ZStack {
                    // Background track
                    RoundedRectangle(cornerRadius: 8)
                        .fill(Color.black.opacity(0.7))
                        .frame(width: 120, height: 16)
                        .overlay(
                            RoundedRectangle(cornerRadius: 8)
                                .stroke(Color.white.opacity(0.3), lineWidth: 1)
                        )
                    
                    // Center reference line
                    Rectangle()
                        .fill(Color.white.opacity(0.5))
                        .frame(width: 2, height: 16)
                    
                    // Level bubble
                    Circle()
                        .fill(isLevel ? .green : .white)
                        .frame(width: 12, height: 12)
                        .offset(x: min(max(motionManager.tiltAngle * 200, -54), 54)) // Constrain to track
                        .shadow(color: isLevel ? .green.opacity(0.5) : .clear, radius: isLevel ? 8 : 0)
                    
                    // Level indicator marks
                    HStack {
                        ForEach(-2...2, id: \.self) { mark in
                            Rectangle()
                                .fill(Color.white.opacity(mark == 0 ? 0.8 : 0.4))
                                .frame(width: 1, height: mark == 0 ? 20 : 12)
                                .offset(x: Double(mark) * 24)
                        }
                    }
                }
                
                // Status and angle (centered below level indicator)
                HStack(spacing: 12) {
                    if isLevel {
                        HStack(spacing: 4) {
                            Image(systemName: "checkmark.circle.fill")
                                .font(.caption2)
                                .foregroundColor(.green)
                            
                            Text("LEVEL")
                                .font(.caption2)
                                .fontWeight(.bold)
                                .foregroundColor(.green)
                        }
                        .padding(.horizontal, 8)
                        .padding(.vertical, 4)
                        .background(
                            RoundedRectangle(cornerRadius: 12)
                                .fill(Color.green.opacity(0.2))
                                .overlay(
                                    RoundedRectangle(cornerRadius: 12)
                                        .stroke(Color.green.opacity(0.5), lineWidth: 1)
                                )
                        )
                    }
                    
                    Text("\(abs(motionManager.tiltAngle * 180 / .pi), specifier: "%.1f")°")
                        .font(.caption2)
                        .fontWeight(.medium)
                        .foregroundColor(isLevel ? .green : .white)
                        .monospacedDigit()
                        .padding(.horizontal, 8)
                        .padding(.vertical, 4)
                        .background(
                            RoundedRectangle(cornerRadius: 6)
                                .fill(Color.black.opacity(0.7))
                                .overlay(
                                    RoundedRectangle(cornerRadius: 6)
                                        .stroke(isLevel ? Color.green.opacity(0.5) : Color.white.opacity(0.3), lineWidth: 1)
                                )
                        )
                }
            }
            // CHOREOGRAPHED: Use calculated positioning from parent
            .padding(.bottom, customBottomPadding ?? 150)
            .animation(.easeInOut(duration: 0.3), value: customBottomPadding)
        }
    }
    
    // MARK: - Landscape Level Indicator (UPDATED: Uses calculated positioning)
    
    private var landscapeLevelIndicator: some View {
        VStack {
            Spacer()
            
            VStack(spacing: 12) {
                // Horizontal level bubble
                ZStack {
                    // Background track
                    RoundedRectangle(cornerRadius: 8)
                        .fill(Color.black.opacity(0.7))
                        .frame(width: 120, height: 16)
                        .overlay(
                            RoundedRectangle(cornerRadius: 8)
                                .stroke(Color.white.opacity(0.3), lineWidth: 1)
                        )
                    
                    // Center reference line
                    Rectangle()
                        .fill(Color.white.opacity(0.5))
                        .frame(width: 2, height: 16)
                    
                    // Level bubble
                    Circle()
                        .fill(isLevel ? .green : .white)
                        .frame(width: 12, height: 12)
                        .offset(x: min(max(motionManager.tiltAngle * 200, -54), 54)) // Constrain to track
                        .shadow(color: isLevel ? .green.opacity(0.5) : .clear, radius: isLevel ? 8 : 0)
                    
                    // Level indicator marks
                    HStack {
                        ForEach(-2...2, id: \.self) { mark in
                            Rectangle()
                                .fill(Color.white.opacity(mark == 0 ? 0.8 : 0.4))
                                .frame(width: 1, height: mark == 0 ? 20 : 12)
                                .offset(x: Double(mark) * 24)
                        }
                    }
                }
                
                // Status and angle
                HStack(spacing: 12) {
                    if isLevel {
                        HStack(spacing: 4) {
                            Image(systemName: "checkmark.circle.fill")
                                .font(.caption2)
                                .foregroundColor(.green)
                            
                            Text("LEVEL")
                                .font(.caption2)
                                .fontWeight(.bold)
                                .foregroundColor(.green)
                        }
                        .padding(.horizontal, 8)
                        .padding(.vertical, 4)
                        .background(
                            RoundedRectangle(cornerRadius: 12)
                                .fill(Color.green.opacity(0.2))
                                .overlay(
                                    RoundedRectangle(cornerRadius: 12)
                                        .stroke(Color.green.opacity(0.5), lineWidth: 1)
                                )
                        )
                    }
                    
                    Text("\(abs(motionManager.tiltAngle * 180 / .pi), specifier: "%.1f")°")
                        .font(.caption2)
                        .fontWeight(.medium)
                        .foregroundColor(isLevel ? .green : .white)
                        .monospacedDigit()
                        .padding(.horizontal, 8)
                        .padding(.vertical, 4)
                        .background(
                            RoundedRectangle(cornerRadius: 6)
                                .fill(Color.black.opacity(0.7))
                                .overlay(
                                    RoundedRectangle(cornerRadius: 6)
                                        .stroke(isLevel ? Color.green.opacity(0.5) : Color.white.opacity(0.3), lineWidth: 1)
                                )
                        )
                }
            }
            // CHOREOGRAPHED: Use calculated positioning from parent  
            .padding(.bottom, customBottomPadding ?? 60)
            .animation(.easeInOut(duration: 0.3), value: customBottomPadding)
        }
    }
    
    // MARK: - Level Updates
    
    private func updateLevelIndicator(angle: Double) {
        let wasLevel = isLevel
        isLevel = abs(angle) < 0.05 // ~3 degrees tolerance
        
        // Show indicator when device is significantly tilted
        if motionManager.isSignificantlyTilted && shouldShowForOrientation {
            showIndicator = true
            hideIndicatorTask?.cancel()
        }
        
        // When device becomes level, show green for a moment then fade out
        if isLevel && !wasLevel {
            scheduleIndicatorHide(delay: 2.0) // Show green level indicator for 2 seconds
        } else if !isLevel {
            hideIndicatorTask?.cancel() // Keep showing while not level
        }
    }
    
    private func scheduleIndicatorHide(delay: TimeInterval = 3.0) {
        hideIndicatorTask?.cancel()
        hideIndicatorTask = Task {
            try? await Task.sleep(nanoseconds: UInt64(delay * 1_000_000_000))
            
            await MainActor.run {
                if !Task.isCancelled {
                    withAnimation(.easeOut(duration: 0.5)) {
                        showIndicator = false
                    }
                }
            }
        }
    }
}

// MARK: - Device Motion Manager

@MainActor
class DeviceMotionManager: ObservableObject {
    @Published var tiltAngle: Double = 0
    @Published var isPortrait: Bool = true
    @Published var isSignificantlyTilted: Bool = false
    
    private let motionManager = CMMotionManager()
    private let updateInterval: TimeInterval = 1.0 / 30.0 // 30 FPS
    
    func startUpdates() {
        guard motionManager.isDeviceMotionAvailable else {
            print("⚠️ Device motion not available")
            return
        }
        
        motionManager.deviceMotionUpdateInterval = updateInterval
        
        motionManager.startDeviceMotionUpdates(to: .main) { [weak self] motion, error in
            guard let self = self, let motion = motion else { return }
            
            let attitude = motion.attitude
            
            // Determine orientation based on device rotation
            let currentOrientation = UIDevice.current.orientation
            self.isPortrait = currentOrientation.isPortrait || currentOrientation == .unknown
            
            // Calculate tilt angle based on orientation
            let angle: Double
            if self.isPortrait {
                // Portrait: measure roll (tilting left/right)
                angle = attitude.roll
            } else {
                // Landscape: measure pitch (tilting forward/back)
                angle = attitude.pitch
            }
            
            self.tiltAngle = angle
            self.isSignificantlyTilted = abs(angle) > 0.1 // ~6 degrees
        }
    }
    
    func stopUpdates() {
        motionManager.stopDeviceMotionUpdates()
    }
}

// MARK: - Extensions

extension UIDeviceOrientation {
    var isPortrait: Bool {
        return self == .portrait || self == .portraitUpsideDown
    }
}

#Preview {
    ZStack {
        Color.black.ignoresSafeArea()
        
        VStack {
            Text("Level Indicator Preview")
                .font(.headline)
                .foregroundColor(.white)
            
            Spacer()
            
            Text("Tilt your device to see the level indicator")
                .font(.caption)
                .foregroundColor(.gray)
                .multilineTextAlignment(.center)
        }
        .padding()
        
        LevelIndicatorView(showInPortrait: true, showInLandscape: true)
    }
}
