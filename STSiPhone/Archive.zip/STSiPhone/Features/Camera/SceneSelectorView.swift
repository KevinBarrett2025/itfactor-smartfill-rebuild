import SwiftUI

struct SceneSelectorView: View {
    @ObservedObject var sessionManager = SessionManager.shared
    @State private var showSceneMenu = false
    
    // NEW: Add onComplete callback to handle wrap action
    var onComplete: (() -> Void)?
    
    // NEW: Add proper initializer
    init(onComplete: (() -> Void)? = nil) {
        self.onComplete = onComplete
    }
    
    var body: some View {
        HStack(spacing: 8) {
            // Current scene/slate button
            Menu {
                // Scene options
                ForEach(1...sessionManager.totalScenes, id: \.self) { sceneNumber in
                    Button(action: {
                        sessionManager.switchToScene(sceneNumber)
                    }) {
                        HStack {
                            Text("Scene \(sceneNumber)")
                            // FIXED: Use valid SF Symbol
                            Image(systemName: "video.fill")
                            // FIXED: Proper checkmark logic - only show checkmark when NOT in slate OR keyframe photo mode AND matches current scene
                            if !sessionManager.isRecordingSlate && !sessionManager.isRecordingKeyframePhoto && sceneNumber == sessionManager.currentScene {
                                Image(systemName: "checkmark")
                            }
                            Spacer()
                            // Show take count for this scene
                            let takesCount = sessionManager.getTakesForScene(sceneNumber).count
                            if takesCount > 0 {
                                Text("(\(takesCount))")
                                    .font(.caption)
                                    .foregroundColor(.secondary)
                            }
                        }
                    }
                }
                
                Divider()
                
                // REDESIGNED: Slate as separate recording mode
                Button(action: {
                    sessionManager.switchToSlateMode()
                }) {
                    HStack {
                        Text("Slate")
                        Image(systemName: "tv")
                        if sessionManager.isRecordingSlate {
                            Image(systemName: "checkmark")
                        }
                        Spacer()
                        // Show slate take count
                        let slateTakesCount = sessionManager.getSlateTakesAsTakes().count
                        if slateTakesCount > 0 {
                            Text("(\(slateTakesCount))")
                                .font(.caption)
                                .foregroundColor(.secondary)
                        }
                    }
                }
                
                // FIXED: Use valid SF Symbol for keyframe photo
                Button(action: {
                    sessionManager.switchToKeyframePhotoMode()
                }) {
                    HStack {
                        Text("Keyframe Photo")
                        Image(systemName: "camera.fill")
                        if sessionManager.isRecordingKeyframePhoto {
                            Image(systemName: "checkmark")
                        }
                        Spacer()
                        // Show keyframe photo count
                        let keyframePhotosCount = sessionManager.getKeyframePhotoTakesAsTakes().count
                        if keyframePhotosCount > 0 {
                            Text("(\(keyframePhotosCount))")
                                .font(.caption)
                                .foregroundColor(.secondary)
                        }
                    }
                }
                
                // FIXED: Always show "That's a Wrap" option with proper styling and background shading
                Divider()
                
                Button(action: {
                    onComplete?()
                }) {
                    HStack {
                        Text("That's a Wrap")
                            .fontWeight(.semibold)
                            .foregroundStyle(.orange) // ENHANCED: Set apart with color
                        Image(systemName: "flag.checkered") // FIXED: Use valid SF Symbol
                            .foregroundStyle(.orange) // ENHANCED: Matching color
                        Spacer()
                        // Show completion indicator if takes exist
                        if !sessionManager.unifiedTakes.isEmpty {
                            Text("(\(sessionManager.unifiedTakes.count) takes)")
                                .font(.caption)
                                .foregroundColor(.orange.opacity(0.7))
                        }
                    }
                    .padding(.vertical, 8) // ENHANCED: Add padding for better touch area
                    .padding(.horizontal, 12) // ENHANCED: Add horizontal padding
                    .background(
                        RoundedRectangle(cornerRadius: 6)
                            .fill(.orange.opacity(0.15)) // ENHANCED: Background shading to set it apart
                            .overlay(
                                RoundedRectangle(cornerRadius: 6)
                                    .stroke(.orange.opacity(0.3), lineWidth: 1) // ENHANCED: Subtle border
                            )
                    )
                }
            } label: {
                HStack(spacing: 4) {
                    // REDESIGNED: Show current recording mode clearly
                    Text(sessionManager.currentRecordingMode)
                        .font(.caption)
                        .fontWeight(.medium)
                    
                    Image(systemName: "chevron.down")
                        .font(.caption2)
                }
                .foregroundColor(.white)
                .padding(.horizontal, 10)
                .padding(.vertical, 6)
                .background(.ultraThinMaterial.opacity(0.8), in: Capsule())
            }
        }
    }
}

#Preview {
    SceneSelectorView()
        .background(.black)
        .onAppear {
            SessionManager.shared.totalScenes = 3
            SessionManager.shared.currentScene = 2
        }
}
