import SwiftUI

struct SessionTakesModalView: View {
    @Binding var isPresented: Bool
    @State private var currentProject: Project
    @State private var currentSession: ProjectSession
    let slateConfiguration: SlateConfiguration?
    let onSlateAction: () -> Void
    
    // CRITICAL FIX: Repository is the SINGLE source of truth
    let repository: ProjectsRepository
    
    // NEW: Add callback for "That's a Wrap" navigation
    let onThatSAWrap: (() -> Void)?
    
    @ObservedObject private var sessionManager = SessionManager.shared
    @State private var selectedScene: Int = 1
    @State private var showExportModal = false
    
    // CRITICAL FIX: Remove unused unified display toggle - focus on repository data only
    @State private var selectedViewType: ViewType = .scenes
    
    // CRITICAL FIX: Add swipeable video player state like TakeReviewPage
    @State private var showSwipeablePlayer = false
    @State private var swipeablePlayerTakes: [ProjectTake] = []
    @State private var swipeablePlayerInitialIndex = 0
    
    // CRITICAL FIX: Define view types identical to TakeReviewPage with FIXED SF Symbols
    enum ViewType: CaseIterable {
        case scenes
        case slates
        case keyframes
        
        var displayName: String {
            switch self {
            case .scenes: return "Scenes"
            case .slates: return "Slates"
            case .keyframes: return "Photos"
            }
        }
        
        var icon: String {
            switch self {
            case .scenes: return "video.fill" // FIXED: Use valid SF Symbol
            case .slates: return "tv"
            case .keyframes: return "camera"
            }
        }
    }

    // CRITICAL FIX: Initialize with mutable state for repository reloading
    init(
        isPresented: Binding<Bool>,
        project: Project,
        session: ProjectSession,
        slateConfiguration: SlateConfiguration?,
        onSlateAction: @escaping () -> Void,
        repository: ProjectsRepository,
        onThatSAWrap: (() -> Void)? = nil // NEW: Optional callback for "That's a Wrap"
    ) {
        self._isPresented = isPresented
        self._currentProject = State(initialValue: project)
        self._currentSession = State(initialValue: session)
        self.slateConfiguration = slateConfiguration
        self.onSlateAction = onSlateAction
        self.repository = repository
        self.onThatSAWrap = onThatSAWrap
    }
    
    var body: some View {
        ZStack {
            // Backdrop
            Color.black.opacity(0.8)
                .ignoresSafeArea()
                .onTapGesture {
                    isPresented = false
                }
            
            // Main modal content
            VStack(spacing: 0) {
                // Header with close and title
                HStack {
                    Spacer()
                    
                    VStack(spacing: 4) {
                        HStack(spacing: 8) {
                            Image(systemName: "video.fill")
                                .font(.title2)
                                .foregroundColor(Theme.primary)
                            
                            Text("Session Takes")
                                .font(.headline)
                                .fontWeight(.bold)
                                .foregroundColor(.white)
                        }
                        
                        Text(currentProject.title)
                            .font(.caption)
                            .foregroundColor(.gray)
                    }
                    
                    Spacer()
                }
                .padding(.horizontal, 24)
                .padding(.vertical, 16)
                
                // CRITICAL FIX: Use identical tab system as TakeReviewPage
                horizontalTabs
                
                // Takes list for current selection - REPOSITORY DATA ONLY
                ScrollView {
                    LazyVStack(spacing: 12) {
                        // ENHANCED: SmartFill status indicator at the top of the takes list
                        SmartFillStatusIndicator(sessionID: currentSession.id)
                            .padding(.bottom, 8)
                        
                        if currentTakes.isEmpty {
                            // Empty state with context
                            VStack(spacing: 16) {
                                Image(systemName: currentViewEmptyStateIcon)
                                    .font(.system(size: 48))
                                    .foregroundColor(.gray)
                                
                                VStack(spacing: 8) {
                                    Text(currentViewEmptyStateTitle)
                                        .font(.headline)
                                        .foregroundColor(.white)
                                    
                                    Text(currentViewEmptyStateMessage)
                                        .font(.caption)
                                        .foregroundColor(.gray)
                                        .multilineTextAlignment(.center)
                                }
                            }
                            .padding(.vertical, 40)
                        } else {
                            // CRITICAL FIX: Display takes using ONLY repository data
                            ForEach(Array(currentTakes.enumerated()), id: \.element.id) { index, projectTake in
                                ModalTakeRowView(
                                    projectTake: projectTake,
                                    takeNumber: index + 1,
                                    isSlateContext: selectedViewType == .slates,
                                    isPhotoContext: selectedViewType == .keyframes,
                                    repository: repository,
                                    projectID: currentProject.id,
                                    sessionID: currentSession.id,
                                    onTakeSelected: { selectedTake in
                                        // CRITICAL FIX: Launch swipeable player like TakeReviewPage
                                        launchSwipeablePlayer(selectedTake: selectedTake, contextIndex: index)
                                    }
                                )
                            }
                        }
                    }
                    .padding(.horizontal, 24)
                }
                .frame(maxHeight: 400)
                
                // Bottom action bar
                HStack(spacing: 16) {
                    // Session stats - CRITICAL FIX: Use repository data only
                    VStack(alignment: .leading, spacing: 4) {
                        Text("\(currentSession.takes.count) Total Takes")
                            .font(.caption)
                            .fontWeight(.semibold)
                            .foregroundColor(.white)
                        
                        HStack(spacing: 12) {
                            HStack(spacing: 4) {
                                Image(systemName: "star.fill")
                                    .font(.caption2)
                                    .foregroundColor(.yellow)
                                Text("\(starredTakeCount)")
                                    .font(.caption2)
                                    .foregroundColor(.gray)
                            }
                            
                            HStack(spacing: 4) {
                                Image(systemName: "checkmark.circle.fill")
                                    .font(.caption2)
                                    .foregroundColor(.green)
                                Text("\(goodTakeCount)")
                                    .font(.caption2)
                                    .foregroundColor(.gray)
                            }
                        }
                    }
                    
                    Spacer()
                    
                    // ENHANCED: Two action buttons with equal sizing and professional styling
                    HStack(spacing: 12) {
                        // That's a Wrap button - only show if takes exist
                        if !currentSession.takes.isEmpty {
                            BrandedModalActionButton(
                                label: "That's a Wrap",
                                style: .completion
                            ) {
                                isPresented = false
                                // FIXED: Use the dedicated callback for navigation to TakeReviewPage
                                onThatSAWrap?()
                            }
                        }
                        
                        // Continue Recording button - primary style
                        BrandedModalActionButton(
                            label: "Continue Recording",
                            style: .primary
                        ) {
                            isPresented = false
                        }
                    }
                }
                .padding(.horizontal, 24)
                .padding(.vertical, 20)
            }
            .background(
                RoundedRectangle(cornerRadius: 24, style: .continuous)
                    .fill(Color(.systemGray6).opacity(0.95))
                    .overlay(
                        RoundedRectangle(cornerRadius: 24, style: .continuous)
                            .stroke(Color.white.opacity(0.2), lineWidth: 1)
                    )
            )
            .padding(.horizontal, 20)
            .padding(.vertical, 60)
        }
        .sheet(isPresented: $showExportModal) {
            if !currentSession.takes.isEmpty {
                ExportManagerView(
                    takes: convertSessionToEnhancedTakes(),
                    project: currentProject,
                    session: currentSession,
                    repository: repository,
                    onDismiss: {
                        showExportModal = false
                        reloadSessionData()
                    }
                )
            } else {
                VStack(spacing: 16) {
                    Image(systemName: "tray")
                        .font(.system(size: 48))
                        .foregroundColor(.gray)
                    
                    Text("No Takes to Export")
                        .font(.headline)
                        .foregroundColor(.primary)
                    
                    Text("Record some takes first, then you can export them.")
                        .font(.caption)
                        .foregroundColor(.secondary)
                        .multilineTextAlignment(.center)
                    
                    Button("Close") {
                        showExportModal = false
                    }
                    .font(.headline)
                    .padding()
                    .background(Color.blue, in: RoundedRectangle(cornerRadius: 12))
                    .foregroundColor(.white)
                }
                .padding()
            }
        }
        // CRITICAL FIX: Add SwipeableMediaPlayerView like TakeReviewPage (replaces SwipeableVideoPlayerView)
        .fullScreenCover(isPresented: $showSwipeablePlayer) {
            SwipeableMediaPlayerView(
                takes: swipeablePlayerTakes,
                session: currentSession,
                project: currentProject,
                initialIndex: swipeablePlayerInitialIndex,
                onDismiss: {
                    showSwipeablePlayer = false
                },
                onTakeAction: { action, take in
                    handleSwipeablePlayerAction(action, for: take)
                }
            )
        }
        // CRITICAL FIX: Identical notification listeners as TakeReviewPage
        .onReceive(NotificationCenter.default.publisher(for: Notification.Name("STSTakeRatingUpdated"))) { notification in
            if let sessionID = notification.userInfo?["sessionID"] as? UUID,
               sessionID == currentSession.id {
                reloadSessionData()
            }
        }
        .onReceive(NotificationCenter.default.publisher(for: Notification.Name("STSExportCompleted"))) { notification in
            if let sessionID = notification.userInfo?["sessionID"] as? UUID,
               sessionID == currentSession.id {
                reloadSessionData()
            }
        }
        // ENHANCED: Listen for SmartFill completion notifications with correct notification names
        .onReceive(NotificationCenter.default.publisher(for: Notification.Name("SmartFillProcessingDidComplete"))) { notification in
            if let sessionIDFromNotification = notification.userInfo?["sessionID"] as? UUID,
               sessionIDFromNotification == currentSession.id {
                reloadSessionData()
                print("🎨 SessionTakesModal: Reloaded after SmartFill completion")
            }
        }
        .onReceive(NotificationCenter.default.publisher(for: Notification.Name("SmartFillJobStatusDidChange"))) { notification in
            if let sessionIDFromNotification = notification.userInfo?["sessionID"] as? UUID,
               sessionIDFromNotification == currentSession.id,
               let status = notification.userInfo?["status"] as? String,
               status == "completed" {
                reloadSessionData()
                print("🎨 SessionTakesModal: Reloaded after SmartFill job completion")
            }
        }
        // ENHANCED: Listen for SessionManager SmartFill completion notifications
        .onReceive(NotificationCenter.default.publisher(for: Notification.Name("STSSmartFillCompleted"))) { notification in
            if let sessionIDFromNotification = notification.userInfo?["sessionID"] as? UUID,
               sessionIDFromNotification == currentSession.id {
                reloadSessionData()
                print("🎨 SessionTakesModal: Reloaded after SessionManager SmartFill update")
            }
        }
        // CRITICAL FIX: Load fresh data on appear and when session changes
        .onAppear {
            reloadSessionData()
            selectedScene = max(1, getLastSceneWithTakes())
            print("📊 SessionTakesModal: Appeared with \(currentSession.takes.count) takes")
        }
        .onChange(of: currentSession.id) { _, _ in
            reloadSessionData()
        }
    }
    
    // CRITICAL FIX: Launch swipeable player with contextual takes like TakeReviewPage
    private func launchSwipeablePlayer(selectedTake: ProjectTake, contextIndex: Int) {
        // Get contextual takes based on current view type
        let contextualTakes = getContextualTakes()
        
        // Find the actual index of the selected take within the contextual takes
        let actualIndex = contextualTakes.firstIndex(where: { $0.id == selectedTake.id }) ?? contextIndex
        
        swipeablePlayerTakes = contextualTakes
        swipeablePlayerInitialIndex = actualIndex
        showSwipeablePlayer = true
        
        print("🎬 SessionTakesModal: Launching swipeable player with \(contextualTakes.count) contextual takes, starting at index \(actualIndex)")
        print("📹 Selected take: \(URL(fileURLWithPath: selectedTake.filePath).lastPathComponent)")
    }
    
    // CRITICAL FIX: Get contextual takes based on current view type (like TakeReviewPage)
    private func getContextualTakes() -> [ProjectTake] {
        switch selectedViewType {
        case .scenes:
            // Only show takes for the currently selected scene
            return currentSession.takes.filter {
                $0.takeType == .regular && $0.sceneNumber == selectedScene
            }.sorted { $0.createdAt < $1.createdAt }
        case .slates:
            // Only show slate takes
            return currentSession.takes.filter {
                $0.takeType == .slate
            }.sorted { $0.createdAt < $1.createdAt }
        case .keyframes:
            // Only show keyframe photo takes
            return currentSession.takes.filter { take in
                take.durationSeconds == 0.0 && (
                    take.filePath.lowercased().contains("photo") ||
                    take.filePath.lowercased().contains("keyframe")
                )
            }.sorted { $0.createdAt < $1.createdAt }
        }
    }
    
    // CRITICAL FIX: Handle actions from swipeable player like TakeReviewPage
    private func handleSwipeablePlayerAction(_ action: TakeAction, for take: ProjectTake) {
        switch action {
        case .setRating(let rating):
            // Update rating through repository
            repository.setUnifiedTakeRating(
                takeID: take.id,
                sessionID: currentSession.id,
                projectID: currentProject.id,
                rating: rating
            )
            
            // Post notification for other views to update
            NotificationCenter.default.post(
                name: Notification.Name("STSTakeRatingUpdated"),
                object: nil,
                userInfo: [
                    "takeID": take.id,
                    "sessionID": currentSession.id,
                    "projectID": currentProject.id,
                    "rating": rating.rawValue
                ]
            )
            
            print("⭐ SessionTakesModal: Updated rating for \(URL(fileURLWithPath: take.filePath).lastPathComponent) to \(rating.rawValue)")
        case .share:
            // Handle share action
            print("📤 SessionTakesModal: Share action for \(URL(fileURLWithPath: take.filePath).lastPathComponent)")
            // Note: Share functionality would be handled by the SwipeableVideoPlayerView
        default:
            print("🎬 SessionTakesModal: Unhandled swipeable player action: \(action)")
        }
        
        // Reload data after any action
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
            reloadSessionData()
        }
    }
    
    // CRITICAL FIX: Identical reloadSessionData method as TakeReviewPage
    private func reloadSessionData() {
        // Reload project from repository
        if let freshProject = repository.project(by: currentProject.id) {
            currentProject = freshProject

            // Find the updated session within the fresh project
            if let freshSession = freshProject.sessions.first(where: { $0.id == currentSession.id }) {
                currentSession = freshSession
                print("🔄 SessionTakesModal: Reloaded session with \(freshSession.takes.count) takes")
            }
        }
    }
    
    // CRITICAL FIX: Horizontal tabs identical to TakeReviewPage
    @ViewBuilder
    private var horizontalTabs: some View {
        VStack(spacing: 12) {
            // Tab selector with dynamic text sizing
            HStack(spacing: 0) {
                ForEach(ViewType.allCases, id: \.self) { viewType in
                    Button(action: {
                        withAnimation(.easeInOut(duration: 0.3)) {
                            selectedViewType = viewType
                            if viewType == .scenes {
                                selectedScene = 1
                            }
                        }
                    }) {
                        HStack(spacing: 4) {
                            Image(systemName: viewType.icon)
                                .font(.system(size: 10))
                            Text(viewType.displayName)
                                .font(.system(size: 12))
                                .fontWeight(.medium)
                                .minimumScaleFactor(0.7)
                                .lineLimit(1)
                            
                            // Show counts using repository data
                            let count = getCountForViewType(viewType)
                            if count > 0 {
                                Text("(\(count))")
                                    .font(.system(size: 10))
                                    .foregroundStyle(.secondary)
                                    .minimumScaleFactor(0.8)
                                    .lineLimit(1)
                            }
                        }
                        .foregroundStyle(selectedViewType == viewType ? .white : .gray)
                        .padding(.horizontal, 8)
                        .padding(.vertical, 8)
                        .background(
                            RoundedRectangle(cornerRadius: 8)
                                .fill(selectedViewType == viewType ? Theme.primary : Color.clear)
                        )
                    }
                    .buttonStyle(PlainButtonStyle())
                    .frame(maxWidth: .infinity)
                }
            }
            
            // Scene selector (only show when scenes tab is selected)
            if selectedViewType == .scenes && getSceneCount() > 1 {
                HStack(spacing: 8) {
                    Text("Scene:")
                        .font(.caption)
                        .foregroundStyle(.gray)
                    
                    ForEach(1...getSceneCount(), id: \.self) { sceneNum in
                        Button(action: {
                            withAnimation(.easeInOut(duration: 0.2)) {
                                selectedScene = sceneNum
                            }
                        }) {
                            Text("\(sceneNum)")
                                .font(.caption)
                                .fontWeight(.medium)
                                .foregroundStyle(selectedScene == sceneNum ? .white : .gray)
                                .padding(.horizontal, 10)
                                .padding(.vertical, 6)
                                .background(
                                    RoundedRectangle(cornerRadius: 6)
                                        .fill(selectedScene == sceneNum ? Color.blue : Color.clear)
                                        .overlay(
                                            RoundedRectangle(cornerRadius: 6)
                                                .stroke(Color.blue.opacity(0.3), lineWidth: 1)
                                        )
                                )
                        }
                        .buttonStyle(PlainButtonStyle())
                    }
                    
                    Spacer()
                }
            }
        }
        .padding(.horizontal, 24)
        .padding(.bottom, 16)
    }
    
    // CRITICAL FIX: All computed properties use ONLY repository data
    private var currentTakes: [ProjectTake] {
        switch selectedViewType {
        case .scenes:
            return currentSession.takes.filter {
                $0.takeType == .regular && $0.sceneNumber == selectedScene
            }.sorted { $0.createdAt < $1.createdAt }
        case .slates:
            return currentSession.takes.filter {
                $0.takeType == .slate
            }.sorted { $0.createdAt < $1.createdAt }
        case .keyframes:
            return currentSession.takes.filter { take in
                take.durationSeconds == 0.0 && (
                    take.filePath.lowercased().contains("photo") ||
                    take.filePath.lowercased().contains("keyframe")
                )
            }.sorted { $0.createdAt < $1.createdAt }
        }
    }
    
    // Empty state properties
    private var currentViewEmptyStateIcon: String {
        switch selectedViewType {
        case .keyframes: return "photo.slash"
        case .slates: return "tv.slash"
        case .scenes: return "video.slash"
        }
    }
    
    private var currentViewEmptyStateTitle: String {
        switch selectedViewType {
        case .keyframes: return "No Keyframe Photos Yet"
        case .slates: return "No Slate Takes Yet"
        case .scenes: return "No Takes Yet"
        }
    }
    
    private var currentViewEmptyStateMessage: String {
        switch selectedViewType {
        case .keyframes: return "Capture keyframe photos to see them here"
        case .slates: return "Record some slate content to see it here"
        case .scenes: return "Start recording to see your takes here"
        }
    }
    
    // Helper methods using repository data only
    private func getCountForViewType(_ viewType: ViewType) -> Int {
        switch viewType {
        case .scenes:
            return currentSession.takes.filter { $0.takeType == .regular }.count
        case .slates:
            return currentSession.takes.filter { $0.takeType == .slate }.count
        case .keyframes:
            return currentSession.takes.filter { take in
                take.durationSeconds == 0.0 && (
                    take.filePath.lowercased().contains("photo") ||
                    take.filePath.lowercased().contains("keyframe")
                )
            }.count
        }
    }
    
    private func getSceneCount() -> Int {
        let sceneNumbers = Set(currentSession.takes.filter { $0.takeType == .regular && $0.sceneNumber > 0 }.map { $0.sceneNumber })
        return sceneNumbers.count
    }
    
    private func getLastSceneWithTakes() -> Int {
        let sceneNumbers = Set(currentSession.takes.filter { $0.takeType == .regular }.map { $0.sceneNumber })
        return sceneNumbers.max() ?? 1
    }
    
    private var starredTakeCount: Int {
        return currentSession.takes.filter { $0.rating == .favorite }.count
    }
    
    private var goodTakeCount: Int {
        return currentSession.takes.filter { $0.rating == .good }.count
    }
    
    // Helper for export
    private func convertSessionToEnhancedTakes() -> [EnhancedTake] {
        return currentSession.takes.enumerated().map { index, take in
            EnhancedTake(
                fileName: URL(fileURLWithPath: take.filePath).lastPathComponent,
                projectID: currentProject.id,
                sessionID: currentSession.id,
                filePath: take.filePath,
                duration: take.durationSeconds,
                fileSize: estimateFileSize(for: take.filePath),
                cameraPosition: "back",
                sceneNumber: take.sceneNumber,
                takeNumber: index + 1,
                isSlate: take.takeType == .slate,
                createdAt: take.createdAt
            )
        }
    }
    
    private func estimateFileSize(for filePath: String) -> Int64 {
        if FileManager.default.fileExists(atPath: filePath) {
            do {
                let attributes = try FileManager.default.attributesOfItem(atPath: filePath)
                return attributes[.size] as? Int64 ?? 0
            } catch {
                return 0
            }
        }
        return 0
    }
}

struct ModalTakeRowView: View {
    let projectTake: ProjectTake
    let takeNumber: Int
    let isSlateContext: Bool
    let isPhotoContext: Bool
    let repository: ProjectsRepository
    let projectID: UUID
    let sessionID: UUID
    
    // CRITICAL FIX: Replace sheet state with callback to parent for swipeable player
    let onTakeSelected: (ProjectTake) -> Void
    
    @State private var showSmartFillSubItem = false

    var body: some View {
        VStack(spacing: 0) {
            // ENHANCED: Main take row (parent) - identical structure to TakeReviewPage
            mainTakeRow
            
            // ENHANCED: SmartFill sub-item (child) - expandable, identical to TakeReviewPage
            if projectTake.hasSmartFilledVersion {
                smartFillSubItem
            }
        }
    }
    
    @ViewBuilder
    private var mainTakeRow: some View {
        HStack(spacing: 12) {
            // ENHANCED: Play/View button with parent/child indicator
            Button(action: {
                // CRITICAL FIX: Call parent to launch swipeable player instead of individual player
                onTakeSelected(projectTake)
            }) {
                ZStack {
                    // CRITICAL FIX: Use ThumbnailPreviewView for proper thumbnails
                    ThumbnailPreviewView(unifiedTake: createUnifiedTakeForOriginalThumbnail())
                        .frame(width: 36, height: 36)
                        .clipShape(Circle())
                    
                    // Context-aware overlay
                    if !isPhotoContext {
                        // Video play button overlay
                        Image(systemName: "play.fill")
                            .font(.system(size: 8))
                            .foregroundColor(.white)
                            .background(
                                Circle()
                                    .fill(contextColor.opacity(0.8))
                                    .frame(width: 16, height: 16)
                            )
                    } else {
                        // Photo view overlay
                        Image(systemName: "photo")
                            .font(.system(size: 8))
                            .foregroundColor(.white)
                            .background(
                                Circle()
                                    .fill(contextColor.opacity(0.8))
                                    .frame(width: 16, height: 16)
                            )
                    }
                    
                    // ENHANCED: Parent indicator badge for portrait videos with SmartFill
                    if projectTake.hasSmartFilledVersion {
                        VStack {
                            HStack {
                                Image(systemName: "1.circle.fill")
                                    .font(.system(size: 8))
                                    .foregroundStyle(.orange)
                                    .background(
                                        Circle()
                                            .fill(.black.opacity(0.7))
                                            .frame(width: 12, height: 12)
                                    )
                                Spacer()
                            }
                            Spacer()
                        }
                        .padding(2)
                    }
                }
            }
            
            // Take info with context
            VStack(alignment: .leading, spacing: 4) {
                HStack {
                    HStack(spacing: 6) {
                        Image(systemName: contextSmallIcon)
                            .font(.caption2)
                            .foregroundColor(contextColor)
                        
                        Text(contextDisplayName)
                            .font(.headline)
                            .foregroundColor(.white)
                            .lineLimit(1)
                    }
                    
                    Spacer()
                    
                    // ENHANCED: SmartFill toggle button (only for portrait videos with SmartFill)
                    if projectTake.hasSmartFilledVersion {
                        smartFillToggleButton
                    }
                    
                    if !isPhotoContext {
                        Text(formatDuration(projectTake.durationSeconds))
                            .font(.caption)
                            .fontWeight(.medium)
                            .foregroundColor(.gray)
                    }
                }
                
                HStack(spacing: 8) {
                    Text("\(timeAgo(from: projectTake.createdAt)) • \(contextLabel)")
                        .font(.caption)
                        .foregroundColor(.gray)
                    
                    // ENHANCED: SmartFill status for portrait videos with hierarchy indicator
                    if projectTake.capturedOrientation == .portrait {
                        Text("•")
                            .font(.caption)
                            .foregroundStyle(.gray)
                        
                        HStack(spacing: 2) {
                            Image(systemName: projectTake.hasSmartFilledVersion ? "1.circle" : "rectangle.portrait")
                                .font(.caption2)
                                .foregroundStyle(projectTake.hasSmartFilledVersion ? .green : .orange)
                            Text(projectTake.hasSmartFilledVersion ? "Original + Smart Fill" : "Portrait Only")
                                .font(.caption2)
                                .foregroundStyle(projectTake.hasSmartFilledVersion ? .green : .orange)
                        }
                    }
                }
            }
            
            // Quick actions - identical to TakeReviewPage
            HStack(spacing: 8) {
                Button(action: {
                    let newRating: TakeRating = projectTake.rating == .favorite ? .unrated : .favorite
                    updateTakeRating(newRating)
                }) {
                    Image(systemName: projectTake.rating == .favorite ? "star.fill" : "star")
                        .font(.system(size: 18))
                        .foregroundColor(projectTake.rating == .favorite ? .yellow : .gray)
                }
                
                Button(action: {
                    let newRating: TakeRating = projectTake.rating == .good ? .unrated : .good
                    updateTakeRating(newRating)
                }) {
                    Image(systemName: projectTake.rating == .good ? "checkmark.circle.fill" : "checkmark.circle")
                        .font(.system(size: 18))
                        .foregroundColor(projectTake.rating == .good ? .green : .gray)
                }
                
                Button(action: {
                    let newRating: TakeRating = projectTake.rating == .bad ? .unrated : .bad
                    updateTakeRating(newRating)
                }) {
                    Image(systemName: projectTake.rating == .bad ? "xmark.circle.fill" : "xmark.circle")
                        .font(.system(size: 18))
                        .foregroundColor(projectTake.rating == .bad ? .red : .gray)
                }
            }
        }
        .padding(16)
        .background(
            RoundedRectangle(cornerRadius: 12)
                .fill(Color.black.opacity(0.4))
                .overlay(
                    RoundedRectangle(cornerRadius: 12)
                        .stroke(contextColor.opacity(0.3), lineWidth: 1)
                )
        )
    }
    
    @ViewBuilder
    private var smartFillSubItem: some View {
        if showSmartFillSubItem {
            VStack(spacing: 0) {
                // Connecting line
                HStack {
                    Rectangle()
                        .fill(Color.green.opacity(0.3))
                        .frame(width: 2)
                        .padding(.leading, 24)
                    Spacer()
                }
                .frame(height: 8)
                
                // SmartFill sub-row - identical to TakeReviewPage
                HStack(spacing: 12) {
                    // Indent indicator
                    HStack(spacing: 4) {
                        Rectangle()
                            .fill(Color.green.opacity(0.3))
                            .frame(width: 2, height: 20)
                        
                        Rectangle()
                            .fill(Color.green.opacity(0.3))
                            .frame(width: 12, height: 2)
                    }
                    .padding(.leading, 6)
                    
                    // SmartFill thumbnail
                    smartFillVideoThumbnail
                    
                    // SmartFill info
                    VStack(alignment: .leading, spacing: 2) {
                        HStack(spacing: 6) {
                            Image(systemName: "rectangle.fill.badge.checkmark")
                                .font(.caption)
                                .foregroundStyle(.green)
                            Text("Smart Fill Version")
                                .font(.caption)
                                .fontWeight(.medium)
                                .foregroundStyle(.green)
                            
                            Spacer()
                            
                            Text("Enhanced for Export")
                                .font(.caption2)
                                .foregroundStyle(.green.opacity(0.8))
                        }
                        
                        HStack(spacing: 8) {
                            Text(formatDuration(projectTake.durationSeconds))
                                .font(.caption2)
                                .foregroundStyle(.secondary)
                            
                            Text("• Landscape Enhanced")
                                .font(.caption2)
                                .foregroundStyle(.green.opacity(0.8))
                            
                            Spacer()
                            
                            Text("Preferred for Export")
                                .font(.caption2)
                                .fontWeight(.medium)
                                .foregroundStyle(.green)
                                .padding(.horizontal, 6)
                                .padding(.vertical, 2)
                                .background(.green.opacity(0.15), in: Capsule())
                        }
                    }
                    
                    Spacer()
                    
                    // SmartFill specific actions
                    VStack(spacing: 4) {
                        Button {
                            // Play SmartFill version
                            onTakeSelected(projectTake) // This will use effectiveFilePath (SmartFill version)
                        } label: {
                            Image(systemName: "play.circle.fill")
                                .font(.title3)
                                .foregroundStyle(.green)
                        }
                        .buttonStyle(PlainButtonStyle())
                        
                        Text("Play")
                            .font(.caption2)
                            .foregroundStyle(.green)
                    }
                }
                .padding(12)
                .background(
                    RoundedRectangle(cornerRadius: 12)
                        .fill(Color.green.opacity(0.05))
                        .overlay(
                            RoundedRectangle(cornerRadius: 12)
                                .stroke(Color.green.opacity(0.2), lineWidth: 1)
                        )
                )
                .padding(.horizontal, 12)
                .contentShape(Rectangle())
                .onTapGesture {
                    // Play SmartFill version on tap
                    onTakeSelected(projectTake)
                }
            }
            .transition(.scale.combined(with: .opacity))
        }
    }
    
    @ViewBuilder
    private var smartFillToggleButton: some View {
        Button(action: {
            withAnimation(.easeInOut(duration: 0.3)) {
                showSmartFillSubItem.toggle()
            }
        }) {
            Image(systemName: showSmartFillSubItem ? "chevron.up.circle.fill" : "chevron.down.circle.fill")
                .font(.title3)
                .foregroundStyle(.green)
                .rotationEffect(.degrees(showSmartFillSubItem ? 0 : 180))
                .animation(.easeInOut(duration: 0.3), value: showSmartFillSubItem)
        }
        .buttonStyle(PlainButtonStyle())
    }
    
    @ViewBuilder
    private var smartFillVideoThumbnail: some View {
        Button {
            onTakeSelected(projectTake) // Play SmartFill version
        } label: {
            ZStack {
                // ENHANCED: SmartFill thumbnail (using effectiveFilePath which points to SmartFill version)
                ThumbnailPreviewView(unifiedTake: createUnifiedTakeForSmartFillThumbnail())
                    .frame(width: 32, height: 20)
                    .clipShape(RoundedRectangle(cornerRadius: 4))
                
                // SmartFill play overlay
                Image(systemName: "play.fill")
                    .font(.caption2)
                    .foregroundStyle(.white)
                    .background(
                        Circle()
                            .fill(.green.opacity(0.8))
                            .frame(width: 12, height: 12)
                    )
                
                // SmartFill badge
                VStack {
                    HStack {
                        Spacer()
                        Image(systemName: "rectangle.fill.badge.checkmark")
                            .font(.system(size: 6))
                            .foregroundStyle(.green)
                            .background(
                                Circle()
                                    .fill(.black.opacity(0.7))
                                    .frame(width: 10, height: 10)
                            )
                    }
                    Spacer()
                }
                .padding(1)
            }
        }
        .buttonStyle(PlainButtonStyle())
    }
    
    // Context styling - unchanged
    private var contextColor: Color {
        if isPhotoContext { return .orange }
        else if isSlateContext { return .purple }
        else { return .blue }
    }
    
    private var contextIcon: String {
        if isPhotoContext { return "photo" }
        else { return "play.fill" }
    }
    
    private var contextSmallIcon: String {
        if isPhotoContext { return "camera" }
        else if isSlateContext { return "tv" }
        else { return "video" }
    }
    
    private var contextLabel: String {
        if isPhotoContext { return "Keyframe Photo" }
        else if isSlateContext { return "Slate" }
        else { return "Scene \(projectTake.sceneNumber)" }
    }
    
    private var contextDisplayName: String {
        if isPhotoContext { return "Photo \(takeNumber)" }
        else if isSlateContext { return "Slate \(takeNumber)" }
        else { return "Take \(takeNumber)" }
    }
    
    // CRITICAL FIX: Create UnifiedTake for original thumbnail (always uses original filePath)
    private func createUnifiedTakeForOriginalThumbnail() -> UnifiedTake {
        return UnifiedTake(
            from: projectTake,
            projectID: projectID,
            sessionID: sessionID,
            fileName: URL(fileURLWithPath: projectTake.filePath).lastPathComponent, // Always original path
            takeNumber: takeNumber
        )
    }
    
    // ENHANCED: Create UnifiedTake for SmartFill thumbnail (uses SmartFill path)
    private func createUnifiedTakeForSmartFillThumbnail() -> UnifiedTake {
        return UnifiedTake(
            from: projectTake,
            projectID: projectID,
            sessionID: sessionID,
            fileName: URL(fileURLWithPath: projectTake.effectiveFilePath).lastPathComponent, // SmartFill path
            takeNumber: takeNumber
        )
    }

    // CRITICAL FIX: Create UnifiedTake for thumbnail generation
    private func createUnifiedTakeForThumbnail() -> UnifiedTake {
        return UnifiedTake(
            from: projectTake,
            projectID: projectID,
            sessionID: sessionID,
            fileName: URL(fileURLWithPath: projectTake.filePath).lastPathComponent,
            takeNumber: takeNumber
        )
    }
    
    private func formatDuration(_ duration: TimeInterval) -> String {
        let minutes = Int(duration) / 60
        let seconds = Int(duration) % 60
        return String(format: "%d:%02d", minutes, seconds)
    }
    
    private func timeAgo(from date: Date) -> String {
        let interval = Date().timeIntervalSince(date)
        if interval < 60 { return "now" }
        else if interval < 3600 { return "\(Int(interval / 60))m ago" }
        else { return "\(Int(interval / 3600))h ago" }
    }
    
    // CRITICAL FIX: Use repository for rating updates
    private func updateTakeRating(_ rating: TakeRating) {
        repository.setUnifiedTakeRating(
            takeID: projectTake.id,
            sessionID: sessionID,
            projectID: projectID,
            rating: rating
        )
        
        // Post notification for other views to update
        NotificationCenter.default.post(
            name: Notification.Name("STSTakeRatingUpdated"),
            object: nil,
            userInfo: [
                "takeID": projectTake.id,
                "sessionID": sessionID,
                "projectID": projectID,
                "rating": rating.rawValue
            ]
        )
        
        print("✅ ModalTakeRowView: Updated rating for \(URL(fileURLWithPath: projectTake.filePath).lastPathComponent) to \(rating.rawValue)")
    }
}
