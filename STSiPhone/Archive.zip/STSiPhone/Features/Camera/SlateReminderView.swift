import SwiftUI

// MARK: - Slate Reminder View
struct SlateReminderView: View {
    let slateConfiguration: SlateConfiguration
    let onContinue: () -> Void
    @Environment(\.dismiss) private var dismiss
    
    var body: some View {
        ZStack {
            // Semitransparent background
            Color.black.opacity(0.8)
                .ignoresSafeArea()
                .onTapGesture {
                    // Allow dismissing by tapping background
                    onContinue()
                }
            
            // Main content card
            VStack(spacing: 0) {
                // Header
                VStack(spacing: 16) {
                    Image(systemName: "person.crop.rectangle.fill")
                        .font(.system(size: 60))
                        .foregroundStyle(Theme.primary)
                    
                    VStack(spacing: 8) {
                        Text("Slate Reminder")
                            .font(Theme.Font.title)
                            .foregroundStyle(.white)
                        
                        Text("Remember to say this in your slate:")
                            .font(Theme.Font.body)
                            .foregroundStyle(.gray)
                            .multilineTextAlignment(.center)
                    }
                }
                .padding(.top, 32)
                .padding(.horizontal, 24)
                
                // Slate text display
                ScrollView {
                    VStack(spacing: 16) {
                        // Main slate text
                        Text(slateConfiguration.slateText)
                            .font(.title2)
                            .fontWeight(.medium)
                            .foregroundStyle(.white)
                            .multilineTextAlignment(.center)
                            .lineSpacing(8)
                            .padding(24)
                            .background(
                                RoundedRectangle(cornerRadius: 16, style: .continuous)
                                    .fill(Theme.primary.opacity(0.2))
                                    .overlay(
                                        RoundedRectangle(cornerRadius: 16, style: .continuous)
                                            .stroke(Theme.primary.opacity(0.5), lineWidth: 2)
                                    )
                            )
                        
                        // Helpful tips
                        if !slateConfiguration.isEmpty {
                            VStack(alignment: .leading, spacing: 8) {
                                HStack {
                                    Image(systemName: "lightbulb.fill")
                                        .font(.caption)
                                        .foregroundStyle(.yellow)
                                    
                                    Text("Pro Tips:")
                                        .font(Theme.Font.caption)
                                        .fontWeight(.semibold)
                                        .foregroundStyle(.white)
                                    
                                    Spacer()
                                }
                                
                                VStack(alignment: .leading, spacing: 4) {
                                    TipRow(tip: "Speak clearly and confidently")
                                    TipRow(tip: "Look directly into the camera")
                                    TipRow(tip: "Keep your slate concise and professional")
                                    if slateConfiguration.unionStatus != .none {
                                        TipRow(tip: "Mention your union status clearly")
                                    }
                                }
                            }
                            .padding(16)
                            .background(
                                RoundedRectangle(cornerRadius: 12, style: .continuous)
                                    .fill(Color.black.opacity(0.4))
                                    .overlay(
                                        RoundedRectangle(cornerRadius: 12, style: .continuous)
                                            .stroke(Color.white.opacity(0.1), lineWidth: 1)
                                    )
                            )
                        }
                    }
                    .padding(.horizontal, 24)
                }
                .frame(maxHeight: 400)
                
                // Continue button
                VStack(spacing: 16) {
                    BrandedPrimaryButton(
                        label: "Continue to Recording",
                        icon: "video.fill"
                    ) {
                        onContinue()
                    }
                    
                    Button("Skip Slate Reminder") {
                        onContinue()
                    }
                    .font(Theme.Font.body)
                    .foregroundStyle(.gray)
                }
                .padding(.horizontal, 24)
                .padding(.bottom, 32)
                .padding(.top, 24)
            }
            .background(
                RoundedRectangle(cornerRadius: 24, style: .continuous)
                    .fill(Color(.systemGray6).opacity(0.95))
                    .overlay(
                        RoundedRectangle(cornerRadius: 24, style: .continuous)
                            .stroke(Color.white.opacity(0.2), lineWidth: 1)
                    )
            )
            .padding(.horizontal, 32)
            .padding(.vertical, 60)
        }
    }
}

// MARK: - Helper Components
private struct TipRow: View {
    let tip: String
    
    var body: some View {
        HStack(alignment: .top, spacing: 8) {
            Image(systemName: "checkmark.circle.fill")
                .font(.caption2)
                .foregroundStyle(.green)
                .padding(.top, 2)
            
            Text(tip)
                .font(Theme.Font.caption)
                .foregroundStyle(.gray)
                .multilineTextAlignment(.leading)
            
            Spacer(minLength: 0)
        }
    }
}

// MARK: - Preview
#Preview {
    SlateReminderView(
        slateConfiguration: SlateConfiguration(
            actorName: "Sarah Johnson",
            height: "5'6\"",
            location: "Los Angeles, CA",
            unionStatus: .sagAftra,
            customNotes: "Thank you for your consideration"
        )
    ) {
        print("Continue to recording")
    }
}

// MARK: - Empty Slate Preview
#Preview("Empty Slate") {
    SlateReminderView(
        slateConfiguration: SlateConfiguration()
    ) {
        print("Continue to recording")
    }
}