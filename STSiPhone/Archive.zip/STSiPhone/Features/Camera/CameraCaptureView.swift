import SwiftUI
import AVFoundation
import AVFAudio
import Foundation

struct CameraCaptureView: View {
    let project: Project
    let session: ProjectSession
    let slateConfiguration: SlateConfiguration?
    let onComplete: () -> Void
    
    @StateObject private var engine = CameraEngine()
    @State private var savedTakes: [String] = []
    @State private var isRecording = false
    @State private var takeNumber = 1
    @State private var errorMessage: String?
    @State private var recordingStartDate: Date?
    @State private var recordingDuration: TimeInterval = 0
    @State private var recordingTimer: Timer?
    
    // NEW: Camera mode tracking - FIXED: Make reactive to SessionManager changes
    private var currentCameraMode: CameraEngine.CameraMode {
        return sessionManager.isRecordingKeyframePhoto ? .photo : .video
    }
    
    // NEW: Device orientation tracking for UI layout
    @State private var deviceOrientation = UIDevice.current.orientation
    @State private var isLandscape = false
    
    // PROFESSIONAL CONTROLS - State management
    @State private var showAudioControls = false
    @State private var showManualControls = false
    @State private var showAudioMeter = true
    
    // NEW: Level indicator control
    @State private var showLevelIndicator = true
    
    // NEW: Persistent manual controls lock state
    @State private var manualControlsLocked = false

    // SESSION MANAGER - State management
    @State private var showTakesModal = false
    @State private var showSessionManager = false
    @ObservedObject private var sessionManager = SessionManager.shared
    
    // Keep essential camera controls that were working
    @GestureState private var zoomGestureScale: CGFloat = 1.0
    @State private var currentZoom: CGFloat = 1.0
    @State private var showFocusIndicator = false
    @State private var focusLocation: CGPoint = .zero
    
    // FIXED: Add camera ready state to prevent two-press issue
    @State private var isCameraReady = false
    @State private var isInitializing = true
    @State private var initializationPhase: InitializationPhase = .starting

    // Add initialization phase tracking
    enum InitializationPhase {
        case starting
        case requestingPermissions
        case configuringCamera
        case ready
        case failed(String)
        
        // Helper property to check if failed
        var isFailed: Bool {
            if case .failed = self {
                return true
            }
            return false
        }
    }
    
    private var initializationPhaseMessage: String {
        switch initializationPhase {
        case .starting:
            return "Starting Camera..."
        case .requestingPermissions:
            return "Requesting Permissions"
        case .configuringCamera:
            return "Setting Up Camera"
        case .ready:
            return "Ready!"
        case .failed(_):
            return "Setup Failed"
        }
    }
    
    private var initializationPhaseDetails: String {
        switch initializationPhase {
        case .starting:
            return "Preparing camera system"
        case .requestingPermissions:
            return "Please allow camera and microphone access when prompted"
        case .configuringCamera:
            return "Configuring camera settings and session"
        case .ready:
            return "Camera is ready to use"
        case .failed(let error):
            return error
        }
    }
    
    // Simplified initializer - optional slate support but don't overcomplicate
    init(project: Project, session: ProjectSession, slateConfiguration: SlateConfiguration? = nil, onComplete: @escaping () -> Void) {
        self.project = project
        self.session = session
        self.slateConfiguration = slateConfiguration
        self.onComplete = onComplete
    }
    
    var body: some View {
        ZStack {
            // ENHANCED: Better loading screen with phase information
            if isInitializing {
                ZStack {
                    Color.black.ignoresSafeArea()
                    VStack(spacing: 20) {
                        // Animated loading indicator
                        ProgressView()
                            .scaleEffect(1.5)
                            .tint(.white)
                        
                        VStack(spacing: 8) {
                            Text(initializationPhaseMessage)
                                .font(.headline)
                                .foregroundColor(.white)
                                .multilineTextAlignment(.center)
                            
                            Text(initializationPhaseDetails)
                                .font(.subheadline)
                                .foregroundColor(.white.opacity(0.7))
                                .multilineTextAlignment(.center)
                                .padding(.horizontal, 40)
                        }
                        
                        // Show retry button if failed
                        if case .failed(_) = initializationPhase {
                            Button("Retry") {
                                retryInitialization()
                            }
                            .font(.headline)
                            .foregroundColor(.black)
                            .padding(.horizontal, 24)
                            .padding(.vertical, 12)
                            .background(Color.white)
                            .cornerRadius(8)
                        }
                    }
                }
                // CRITICAL: Prevent dismissal during initialization
                .interactiveDismissDisabled(!initializationPhase.isFailed)
            } else {
                // CORE: Camera preview background - EXACT from 744bbb3 working version
                CameraPreviewView(session: engine.session)
                    .ignoresSafeArea()
                    .gesture(
                        // Keep working pinch-to-zoom gesture - FIXED: Add NaN protection
                        MagnificationGesture()
                            .updating($zoomGestureScale) { value, state, _ in
                                // FIXED: Protect against invalid gesture values
                                guard !value.isNaN && !value.isInfinite else { return }
                                state = value
                                let newZoom = currentZoom * value
                                guard !newZoom.isNaN && !newZoom.isInfinite else { return }
                                engine.setZoom(factor: newZoom)
                            }
                            .onEnded { value in
                                // FIXED: Protect against invalid final zoom values
                                guard !value.isNaN && !value.isInfinite else { return }
                                let newZoom = currentZoom * value
                                guard !newZoom.isNaN && !newZoom.isInfinite else { return }
                                currentZoom = max(1.0, min(newZoom, 5.0))
                                engine.setZoom(factor: currentZoom)
                            }
                    )
                    .onTapGesture { location in
                        handleTapToFocus(at: location)
                    }
            }

            // UI ELEMENTS - Only show when camera is ready
            if isCameraReady && !isInitializing {
                cameraUIOverlays
            }
        }
        .onAppear {
            // FIXED: Streamlined setup to prevent two-press issue
            setupCameraOnce()
            updateOrientationState()
        }
        .onDisappear {
            cleanupCamera()
        }
        .onReceive(NotificationCenter.default.publisher(for: UIDevice.orientationDidChangeNotification)) { _ in
            updateOrientationState()
        }
        .onChange(of: sessionManager.isRecordingKeyframePhoto) { _, newValue in
            updateCameraEngineMode()
        }
        .onChange(of: sessionManager.isRecordingSlate) { _, _ in
            updateCameraEngineMode()
        }
        .alert("Camera Error", isPresented: Binding(get: { errorMessage != nil }, set: { _ in errorMessage = nil })) {
            Button("OK", role: .cancel) {}
        } message: {
            Text(errorMessage ?? "Unknown error")
        }
    }
    
    // NEW: Update orientation state for UI layout
    private func updateOrientationState() {
        let newOrientation = UIDevice.current.orientation
        
        // Only update if orientation is valid
        guard newOrientation.isValidInterfaceOrientation else { return }
        
        deviceOrientation = newOrientation
        
        withAnimation(.easeInOut(duration: 0.3)) {
            isLandscape = newOrientation.isLandscape
        }
        
        print("🔄 Orientation changed: \(newOrientation.description), isLandscape: \(isLandscape)")
    }
    
    // MARK: - UI Components - Enhanced for clarity
    @ViewBuilder
    private var cameraUIOverlays: some View {
        VStack {
            topBar
            
            
            Spacer()
            
            // NEW: Bottom corner controls layout - Left: Audio + Thumbnail, Right: Manual + Flip Camera
            HStack {
                // LEFT SIDE: Audio Controls (aligned stack) - ENHANCED: Hide when recording with transitions
                VStack(spacing: 8) {
                    Spacer()
                    
                    // ENHANCED: Audio meter appears in this exact position during recording
                    if isRecording && showAudioMeter {
                        ExternalAudioMeter(engine: engine, isVisible: .constant(true))
                            .transition(.scale.combined(with: .opacity))
                    }
                }
                .padding(.bottom, 20) // FIXED: Apply bottom padding to entire button stack
                .padding(.leading, 20) // FIXED: Apply leading padding to entire button stack for perfect alignment

                Spacer()
                
                // RIGHT SIDE: Manual Controls + Flip Camera (existing aligned stack) - ENHANCED: Hide when recording
                VStack(spacing: 8) {
                    Spacer()
                    
                    // Manual Controls button (appears above flip camera when needed) - ENHANCED: Hide when recording
                    if !isRecording {
                        Button(action: {
                            withAnimation { showManualControls.toggle() }
                        }) {
                            Image(systemName: "slider.horizontal.3")
                                .font(.system(size: 20, weight: .semibold))
                                .foregroundColor(.white)
                                .padding(12)
                                .background(.ultraThinMaterial, in: Circle())
                                .shadow(color: .black.opacity(0.3), radius: 4, x: 0, y: 2)
                        }
                        .transition(.scale.combined(with: .opacity))
                    }
                    
                    // Flip Camera button (primary bottom-right position) - ENHANCED: Hide when recording
                    if !isRecording {
                        Button(action: {
                            engine.switchCamera()
                        }) {
                            Image(systemName: "camera.rotate.fill")
                                .font(.system(size: 20, weight: .semibold))
                                .foregroundColor(.white)
                                .padding(12)
                                .background(.ultraThinMaterial, in: Circle())
                                .shadow(color: .black.opacity(0.3), radius: 4, x: 0, y: 2)
                        }
                        .transition(.scale.combined(with: .opacity))
                    }
                }
                .padding(.bottom, 20) // FIXED: Apply bottom padding to entire button stack
                .padding(.trailing, 20) // FIXED: Apply trailing padding to entire button stack for perfect alignment
            }
        }
        
        // ENHANCED: Advanced level indicator with smart show/hide behavior and user control
        if showLevelIndicator {
            LevelIndicatorView(
                showInPortrait: true,
                showInLandscape: true,
                customBottomPadding: calculateLevelIndicatorBottomPadding()
            )
        }
        
        // ENHANCED: Focus indicator - this was working
        if showFocusIndicator {
            FocusIndicator()
                .position(focusLocation)
                .animation(.easeInOut(duration: 0.3), value: focusLocation)
        }

        // SESSION MANAGER: Swipeable Take Manager - Right side
        if showSessionManager && !sessionManager.takes.isEmpty && !isRecording {
            VStack {
                Spacer()
                HStack {
                    Spacer()
                    SwipeableTakeManager()
                        .frame(maxWidth: 200)
                }
            }
            .transition(.move(edge: .trailing).combined(with: .opacity))
        }

        // PROFESSIONAL: Audio Controls Panel - ENHANCED: Hide when recording
        if showAudioControls && !isRecording {
            VStack {
                Spacer()
                HStack {
                    CompactAudioControlsPanel(engine: engine, isVisible: $showAudioControls)
                        .padding(.bottom, 120) // FIXED: Position above left side controls
                        .padding(.leading, 20) // FIXED: Align with left side controls
                    Spacer()
                }
            }
            .transition(.move(edge: .leading).combined(with: .opacity))
        }
        
        // NEW: Adaptive control layout based on orientation
        if isLandscape {
            landscapeControlsLayout
        } else {
            portraitControlsLayout
        }
        
        thumbnailPreview
        
        // PROFESSIONAL: Manual Controls Panel - Bottom sheet style
        if showManualControls {
            VStack {
                Spacer()
                CompactManualControlsPanel(
                    engine: engine,
                    isVisible: $showManualControls,
                    isLocked: $manualControlsLocked
                )
            }
            .transition(.move(edge: .bottom).combined(with: .opacity))
        }
        
        // SESSION MANAGER: Takes Modal - Full screen overlay
        if showTakesModal {
            SessionTakesModalView(
                isPresented: $showTakesModal,
                project: project,
                session: session,
                slateConfiguration: slateConfiguration,
                onSlateAction: {
                    // Handle slate action if needed
                    print("🎬 Slate action requested")
                },
                repository: sessionManager.repositoryInstance ?? InMemoryProjectsRepository(), // CRITICAL FIX: Pass repository for data consistency
                onThatSAWrap: {
                    // FIXED: Navigate to TakeReviewPage when "That's a Wrap" is tapped
                    print("🎬 That's a Wrap - navigating to TakeReviewPage")
                    onComplete() // This will dismiss camera and go to review
                }
            )
            .transition(.opacity)
            .zIndex(1000)
        }
    }
    
    @ViewBuilder
    private var thumbnailPreview: some View {
        VStack {
            Spacer()
            
            HStack {
                // Native camera-style thumbnail preview (very bottom left, square) - ENHANCED: Always show with empty state
                Button(action: {
                    showTakesModal = true
                }) {
                    ZStack {
                        if let latestTake = SessionManager.shared.getLatestUnifiedTake() {
                            // Show actual thumbnail when takes exist
                            ThumbnailPreviewView(unifiedTake: latestTake)
                                .frame(width: 50, height: 50)
                                .clipShape(RoundedRectangle(cornerRadius: 8))
                                .transition(.scale.combined(with: .opacity))
                        } else {
                            // Empty state thumbnail placeholder
                            RoundedRectangle(cornerRadius: 8)
                                .fill(Color.black.opacity(0.3))
                                .frame(width: 50, height: 50)
                                .overlay(
                                    RoundedRectangle(cornerRadius: 8)
                                        .stroke(Color.white.opacity(0.4), lineWidth: 1)
                                )
                                .overlay(
                                    Image(systemName: "photo.stack")
                                        .font(.system(size: 16, weight: .medium))
                                        .foregroundColor(.white.opacity(0.6))
                                )
                                .transition(.scale.combined(with: .opacity))
                        }
                    }
                    .overlay(
                        RoundedRectangle(cornerRadius: 8)
                            .stroke(Color.white.opacity(0.3), lineWidth: 1)
                    )
                    .shadow(color: .black.opacity(0.3), radius: 4, x: 2, y: 2)
                }
                .buttonStyle(PlainButtonStyle())
                .contentShape(RoundedRectangle(cornerRadius: 8))
                .padding(.bottom, max(safeAreaInsets.bottom + 10, 20))
                .padding(.leading, 15)
                .zIndex(100) // Ensure thumbnail is always on top
                
                Spacer()
            }
        }
    }
    
    // NEW: Landscape controls layout - CLEANED: Remove legacy review options
    @ViewBuilder
    private var landscapeControlsLayout: some View {
        HStack {
            // Left side controls - REMOVED: Complete button (now in SceneSelectorView)
            VStack(spacing: 12) {
                Spacer()
                Spacer()
            }
            .frame(maxWidth: 100)
            .padding(.leading, 20)
            
            Spacer()
            
            // Right side - Record button (middle position like iPhone camera)
            VStack {
                Spacer()
                
                recordButton
                
                Spacer()
            }
            .padding(.trailing, 30)
        }
    }
    
    // NEW: Portrait controls layout - record button at bottom center (original) - CLEANED UP
    @ViewBuilder
    private var portraitControlsLayout: some View {
        VStack(spacing: 10) {
            recordButton
        }
        .frame(maxHeight: .infinity, alignment: .bottom)
        .padding(.bottom, 34)
    }
    
    // NEW: Extracted record button component for reuse
    @ViewBuilder
    private var recordButton: some View {
        Button(action: recordTapped) {
            ZStack {
                Circle()
                    .fill(.white.opacity(0.15))
                    .frame(width: 92, height: 92)
                
                // ENHANCED: Different visual feedback for photo vs video mode
                if currentCameraMode == .photo {
                    // Photo mode: Square with camera icon
                    RoundedRectangle(cornerRadius: 12)
                        .fill(Color.white)
                        .frame(width: 68, height: 68)
                        .overlay(
                            Image(systemName: "camera.fill")
                                .font(.system(size: 24, weight: .medium))
                                .foregroundColor(.black)
                        )
                        .overlay(RoundedRectangle(cornerRadius: 12).stroke(Color.white, lineWidth: 3))
                } else {
                    // Video mode: Original circular design
                    Circle()
                        .fill(isRecording ? Color.red : Color.white)
                        .frame(width: 68, height: 68)
                        .overlay(Circle().stroke(Color.white, lineWidth: 3))
                    
                    if isRecording {
                        Circle()
                            .fill(Color.white.opacity(0.14))
                            .frame(width: 120, height: 120)
                            .blur(radius: 1)
                            .animation(.easeInOut(duration: 0.6).repeatForever(autoreverses: true), value: isRecording)
                    }
                }
            }
        }
        .accessibilityLabel(accessibilityLabelText)
        .disabled(!isCameraReady) // FIXED: Disable until camera is ready
    }
    
    // NEW: Dynamic accessibility label based on mode
    private var accessibilityLabelText: String {
        if currentCameraMode == .photo {
            return "Capture Keyframe Photo"
        } else if isRecording {
            return "Stop Recording"
        } else {
            return "Start Recording"
        }
    }
    
    @ViewBuilder
    private var topBar: some View {
        VStack {
            HStack {
                // ENHANCED: Hide scene selector when recording - SHOW ONLY when NOT recording with smooth transition
                if !isRecording {
                    SceneSelectorView(onComplete: onComplete)
                        .padding(.horizontal, 12)
                        .padding(.vertical, 6)
                        .background(.black.opacity(0.4), in: Capsule())
                        .transition(.scale.combined(with: .opacity))
                }

                Spacer()

                // ENHANCED: Hide settings menu when recording with smooth transition
                if !isRecording {
                    settingsMenu
                        .transition(.scale.combined(with: .opacity))
                }
            }
            .padding(.horizontal, 16)
            
            // ENHANCED: Show recording indicator below scene selector when recording
            if isRecording {
                HStack {
                    recordingIndicator
                    Spacer()
                }
                .padding(.horizontal, 16)
                .padding(.top, 8)
            }
            
            Spacer() // Push everything else down
        }
        .padding(.top, calculateTopBarTopPadding()) // SAFE: Use calculated positioning
    }
    
    @ViewBuilder
    private var recordingIndicator: some View {
        HStack(spacing: 4) {
            Circle()
                .fill(Color.red)
                .frame(width: 8, height: 8)
            Text("REC \(timeString(recordingDuration))")
                .font(.system(.caption, design: .monospaced))
                .foregroundColor(.red)
        }
    }
    
    @ViewBuilder
    private var statusIndicator: some View {
        HStack(spacing: 8) {
            // SESSION MANAGER: Show current scene and take count
            HStack(spacing: 4) {
                if sessionManager.totalScenes > 1 {
                    Text("Scene \(sessionManager.currentScene)")
                        .font(.caption)
                        .foregroundColor(.white.opacity(0.9))
                }
                
                if !sessionManager.takes.isEmpty {
                    Text("• \(sessionManager.takes.count) Takes")
                        .font(.caption)
                        .foregroundColor(.white.opacity(0.8))
                } else {
                    Text("• Ready")
                        .font(.caption)
                        .foregroundColor(.white.opacity(0.8))
                }
            }
            
            // Show zoom factor if zoomed - FIXED: Add NaN protection
            if currentZoom > 1.1 && !currentZoom.isNaN {
                Text("\(String(format: "%.1fx", currentZoom))")
                    .font(.caption)
                    .foregroundColor(.white.opacity(0.6))
            }
        }
    }
    
    @ViewBuilder
    private var settingsMenu: some View {
        Menu {
            // ENHANCED: Audio Meter Toggle with on/off state
            Toggle(isOn: $showAudioMeter) {
                HStack {
                    Text("Audio Meter")
                    Image(systemName: "waveform.path")
                }
            }
            
            // ENHANCED: Level Indicator Toggle with on/off state
            Toggle(isOn: $showLevelIndicator) {
                HStack {
                    Text("Level Indicator")
                    Image(systemName: "level")
                }
            }
            
            Divider()
            
            Button(action: { resetZoom() }) {
                HStack {
                    Text("Reset Zoom")
                    Image(systemName: "1.magnifyingglass")
                }
            }
            
        } label: {
            Image(systemName: "gearshape")
                .font(.system(size: 16, weight: .semibold))
                .foregroundColor(.white)
                .padding(10)
                .background(.ultraThinMaterial, in: Circle())
        }
    }
    
    // MARK: - Camera Controls - Keep working implementations
    
    private func handleTapToFocus(at location: CGPoint) {
        // FIXED: Add bounds checking to prevent invalid focus points
        let screenSize = UIScreen.main.bounds.size
        guard screenSize.width > 0 && screenSize.height > 0 &&
              !screenSize.width.isNaN && !screenSize.height.isNaN else {
            print("⚠️ Invalid screen size for tap-to-focus")
            return
        }
        
        let focusPoint = CGPoint(
            x: max(0, min(1, location.x / screenSize.width)),
            y: max(0, min(1, location.y / screenSize.height))
        )
        
        // Validate focus point
        guard !focusPoint.x.isNaN && !focusPoint.y.isNaN else {
            print("⚠️ Invalid focus point calculated")
            return
        }
        
        // Show focus indicator
        focusLocation = location
        showFocusIndicator = true
        
        // Hide after animation
        DispatchQueue.main.asyncAfter(deadline: .now() + 1.0) {
            showFocusIndicator = false
        }
        
        engine.setFocus(at: focusPoint)
    }
    
    private func resetZoom() {
        currentZoom = 1.0
        engine.setZoom(factor: 1.0)
    }

    // CORE: Record button logic - ENHANCED: Support both video and photo capture - SIMPLIFIED
    private func recordTapped() {
        // FIXED: Only allow recording when camera is ready
        guard isCameraReady else {
            print("⚠️ Camera not ready for recording")
            return
        }
        
        // FIXED: Camera mode is now automatically reactive - no manual update needed
        if currentCameraMode == .photo {
            // Photo capture mode
            capturePhoto()
        } else {
            // Video recording mode
            switch engine.state {
            case .running where !isRecording:
                // ENHANCED: Auto-dismiss all panels when recording starts for clean recording mode
                withAnimation(.easeInOut(duration: 0.3)) {
                    showAudioControls = false
                    showManualControls = false
                    showSessionManager = false
                    showTakesModal = false
                }
                
                startRecordingTimer()
                isRecording = true
                engine.startRecording()
            case .recording:
                engine.stopRecording()
                // Note: isRecording will be set to false in the notification handler
                // UI elements will automatically reappear when isRecording becomes false
            default:
                break
            }
        }
    }
    
    // NEW: Photo capture method
    private func capturePhoto() {
        guard engine.canCapturePhoto else {
            print("⚠️ Camera not ready for photo capture")
            return
        }
        
        engine.capturePhoto()
        print("📸 Photo capture initiated")
        
        // ENHANCED: Visual feedback for photo capture with brief animation
        withAnimation(.easeInOut(duration: 0.2)) {
            // Flash effect could be added here if desired
        }
    }
    
    // ENTERPRISE: Rock-solid UUID-based filename system with TIMESTAMP UNIQUENESS - PREVENT OVERWRITES
    private func makeTakeName() -> String {
        let projectId = project.id.uuidString.prefix(8)
        let sessionId = session.id.uuidString.prefix(8)
        let sceneNumber = sessionManager.currentScene
        
        // CRITICAL FIX: Add timestamp to ensure unique filenames and prevent overwriting
        let timestamp = Int(Date().timeIntervalSince1970)
        
        // ENTERPRISE: Handle different take types with UUID-based naming + timestamp uniqueness
        if sessionManager.isRecordingSlate {
            // Session-wide slate numbering with timestamp
            let currentSlateCount = sessionManager.getSlateTakesAsTakes().count + 1
            
            return "\(projectId)_\(sessionId)_SLATE\(currentSlateCount)_\(timestamp).mov"
        } else {
            // Scene-based take numbering with timestamp
            let currentSceneTakes = sessionManager.getTakesForScene(sceneNumber).count + 1
            
            return "\(projectId)_\(sessionId)_S\(sceneNumber)T\(currentSceneTakes)_\(timestamp).mov"
        }
    }
    
    // ENTERPRISE: UUID-based photo naming system with TIMESTAMP UNIQUENESS
    private func makePhotoName() -> String {
        let projectId = project.id.uuidString.prefix(8)
        let sessionId = session.id.uuidString.prefix(8)
        
        // CRITICAL FIX: Add timestamp to ensure unique filenames and prevent overwriting
        let timestamp = Int(Date().timeIntervalSince1970)
        
        if sessionManager.isRecordingKeyframePhoto {
            // Keyframe photos are session-wide, not scene-specific
            let keyframePhotoCount = sessionManager.getKeyframePhotoTakesAsTakes().count + 1
            
            return "\(projectId)_\(sessionId)_PHOTO_KF\(keyframePhotoCount)_\(timestamp).jpg"
        } else {
            // Regular scene photos
            let sceneNumber = sessionManager.currentScene
            let scenePhotoCount = sessionManager.getKeyframePhotoTakesAsTakes().filter {
                $0.sceneNumber == sceneNumber
            }.count + 1
            
            return "\(projectId)_\(sessionId)_PHOTO_S\(sceneNumber)P\(scenePhotoCount)_\(timestamp).jpg"
        }
    }

    // MARK: - Camera Setup - ENHANCED: Robust initialization with phase tracking
    @State private var processedFiles: Set<String> = []
    @State private var notificationObservers: [NSObjectProtocol] = []

    private func setupCameraOnce() {
        print("🎥 Starting enhanced camera setup...")
        isInitializing = true
        isCameraReady = false
        initializationPhase = .starting
        
        // CRITICAL FIX: Clear any existing observers to prevent duplicates
        cleanupNotificationObservers()
        
        // Phase 1: Request permissions with proper UI feedback
        initializationPhase = .requestingPermissions
        
        requestPermissionsIfNeeded {
            print("🎥 Permissions granted, proceeding to camera configuration...")
            
            // Phase 2: Configure camera system
            self.initializationPhase = .configuringCamera
            
            // Ensure project and session are ready
            SessionManager.shared.ensureProjectAndSessionInRepository(project: self.project, session: self.session)
            
            // UNIFIED: Enable unified models for this session
            SessionManager.shared.enableUnifiedModels()
            
            // Configure and start - same as working version
            self.engine.configureAndStart()
            // Level indicator now handled by LevelIndicatorView automatically
            
            // Start the session in SessionManager
            SessionManager.shared.startSession(project: self.project, session: self.session)
            
            // CRITICAL FIX: Setup notification observers only once per view instance
            self.setupNotificationObservers()
            
            // ENHANCED: More reliable completion with validation - SIMPLIFIED
            self.validateCameraSetupCompletion()
        }
    }
    
    private func setupNotificationObservers() {
        // Clear any existing observers first
        cleanupNotificationObservers()
        
        // Video recording observer
        let videoObserver = NotificationCenter.default.addObserver(forName: .stsDidRecordFile, object: nil, queue: .main) { note in
            guard let url = note.userInfo?["url"] as? URL else {
                print("❌ Recording notification missing URL")
                self.errorMessage = "Recording completed but file URL was missing"
                return
            }
            
            // CRITICAL FIX: Prevent duplicate processing of the same file
            let fileIdentifier = url.lastPathComponent
            guard !self.processedFiles.contains(fileIdentifier) else {
                print("⚠️ File \(fileIdentifier) already processed, skipping duplicate")
                return
            }
            self.processedFiles.insert(fileIdentifier)
            
            // Verify file was marked as verified in the notification
            let isVerified = note.userInfo?["verified"] as? Bool ?? false
            let fileSize = note.userInfo?["fileSize"] as? Int ?? 0
            
            // NEW: Extract orientation metadata
            let capturedOrientation = note.userInfo?["capturedOrientation"] as? VideoOrientation
            let deviceOrientation = note.userInfo?["deviceOrientation"] as? UIDeviceOrientation
            
            print("📹 Processing recorded file: \(url.lastPathComponent) (Verified: \(isVerified), Size: \(fileSize) bytes)")
            print("📱 Recorded with orientation: \(capturedOrientation?.displayName ?? "Unknown")")
            
            // Generate take name with SessionManager integration
            let fileName = self.makeTakeName()
            
            // Handle file persistence with enhanced error handling and orientation metadata
            self.persistRecordedFile(
                from: url,
                as: fileName,
                originalSize: fileSize,
                capturedOrientation: capturedOrientation
            )
            
            // Update UI state
            self.stopRecordingTimer()
            self.isRecording = false
        }
        
        // Photo capture observer
        let photoObserver = NotificationCenter.default.addObserver(forName: .stsDidCapturePhoto, object: nil, queue: .main) { note in
            guard let url = note.userInfo?["url"] as? URL else {
                print("❌ Photo notification missing URL")
                self.errorMessage = "Photo captured but file URL was missing"
                return
            }
            
            // CRITICAL FIX: Prevent duplicate processing of the same photo
            let fileIdentifier = url.lastPathComponent
            guard !self.processedFiles.contains(fileIdentifier) else {
                print("⚠️ Photo \(fileIdentifier) already processed, skipping duplicate")
                return
            }
            self.processedFiles.insert(fileIdentifier)
            
            let isVerified = note.userInfo?["verified"] as? Bool ?? false
            let fileSize = note.userInfo?["fileSize"] as? Int ?? 0
            
            // NEW: Extract orientation metadata
            let capturedOrientation = note.userInfo?["capturedOrientation"] as? VideoOrientation
            let deviceOrientation = note.userInfo?["deviceOrientation"] as? UIDeviceOrientation
            
            print("📸 Processing captured photo: \(url.lastPathComponent) (Verified: \(isVerified), Size: \(fileSize) bytes)")
            print("📱 Captured with orientation: \(capturedOrientation?.displayName ?? "Unknown")")
            
            // Generate photo name
            let fileName = self.makePhotoName()
            
            // Handle photo persistence with orientation metadata
            self.persistCapturedPhoto(
                from: url,
                as: fileName,
                originalSize: fileSize,
                capturedOrientation: capturedOrientation
            )
        }
        
        // Store observer references for cleanup
        notificationObservers = [videoObserver, photoObserver]
        print("✅ Notification observers setup complete with orientation support")
    }

    // CRITICAL FIX: Clean up notification observers to prevent leaks and duplicates
    private func cleanupNotificationObservers() {
        for observer in notificationObservers {
            NotificationCenter.default.removeObserver(observer)
        }
        notificationObservers.removeAll()
        processedFiles.removeAll()
        print("🧹 Notification observers cleaned up")
    }
    
    private func cleanupCamera() {
        engine.stopSession()
        // Level indicator cleanup is handled automatically by LevelIndicatorView
        stopRecordingTimer()
        
        // CRITICAL FIX: Use proper observer cleanup
        cleanupNotificationObservers()
        
        print("🧹 Camera cleanup complete")
    }
    
    // ENHANCED: More reliable completion with validation - SIMPLIFIED
    private func validateCameraSetupCompletion() {
        // Check if camera engine is actually running
        let maxAttempts = 10
        var attempts = 0
        
        func checkCameraState() {
            attempts += 1
            
            if engine.state == .running {
                // Success!
                DispatchQueue.main.async {
                    self.initializationPhase = .ready
                    self.isCameraReady = true
                    self.isInitializing = false
                    
                    print("✅ Camera setup complete and validated - ready for use")
                }
            } else if attempts < maxAttempts {
                // Retry after short delay
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.2) {
                    checkCameraState()
                }
            } else {
                // Failed after maximum attempts
                DispatchQueue.main.async {
                    self.initializationPhase = .failed("Camera failed to start properly. Please try again.")
                    print("❌ Camera setup failed after \(maxAttempts) attempts")
                }
            }
        }
        
        // Start validation after a brief delay
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.3) {
            checkCameraState()
        }
    }
    
    private func retryInitialization() {
        initializationPhase = .starting
        setupCameraOnce()
    }
    
    // MARK: - Permission Handling
    
    // ENHANCED: Better permission handling with phase tracking
    private func requestPermissionsIfNeeded(granted: @escaping () -> Void) {
        func requestMic(_ cont: @escaping () -> Void) {
            // FIXED: Use non-deprecated API for iOS 17+
            if #available(iOS 17.0, *) {
                AVAudioApplication.requestRecordPermission { ok in
                    DispatchQueue.main.async {
                        if ok {
                            cont()
                        } else {
                            self.initializationPhase = .failed("Microphone permission is required to record audio.")
                        }
                    }
                }
            } else {
                AVAudioSession.sharedInstance().requestRecordPermission { ok in
                    DispatchQueue.main.async {
                        if ok {
                            cont()
                        } else {
                            self.initializationPhase = .failed("Microphone permission is required to record audio.")
                        }
                    }
                }
            }
        }

        switch AVCaptureDevice.authorizationStatus(for: .video) {
        case .authorized:
            requestMic(granted)
        case .notDetermined:
            AVCaptureDevice.requestAccess(for: .video) { ok in
                DispatchQueue.main.async {
                    if ok {
                        requestMic(granted)
                    } else {
                        self.initializationPhase = .failed("Camera permission is required to record video.")
                    }
                }
            }
        default:
            initializationPhase = .failed("Camera permission is required. Please enable it in Settings.")
        }
    }
    
    // CORE: Recording timer - EXACT from 744bbb3 working version
    private func startRecordingTimer() {
        stopRecordingTimer()
        recordingStartDate = Date()
        recordingDuration = 0
        recordingTimer = Timer.scheduledTimer(withTimeInterval: 0.1, repeats: true) { _ in
            if let start = recordingStartDate {
                recordingDuration = Date().timeIntervalSince(start)
            }
        }
    }
    
    private func stopRecordingTimer() {
        recordingTimer?.invalidate()
        recordingTimer = nil
    }
    
    // CORE: Time formatting - EXACT from 744bbb3 working version
    private func timeString(_ duration: TimeInterval) -> String {
        // FIXED: Protect against NaN/infinite duration values
        guard !duration.isNaN && !duration.isInfinite && duration >= 0 else {
            return "0:00.0"
        }
        
        let min = Int(duration) / 60
        let sec = Int(duration) % 60
        let ms = Int((duration * 10).truncatingRemainder(dividingBy: 10))
        return String(format: "%d:%02d.%d", min, sec, ms)
    }
    
    // ENHANCED: File persistence with immediate save and background SmartFill processing
    private func persistRecordedFile(from sourceURL: URL, as fileName: String, originalSize: Int, capturedOrientation: VideoOrientation? = nil) {
        do {
            // CRITICAL FIX: Verify source file still exists AND copy instead of move
            guard FileManager.default.fileExists(atPath: sourceURL.path) else {
                throw NSError(domain: "STS.FileSystem", code: -1,
                            userInfo: [NSLocalizedDescriptionKey: "Source file no longer exists: \(sourceURL.path)"])
            }
            
            // Get file size before any operations
            let sourceSize = (try? FileManager.default.attributesOfItem(atPath: sourceURL.path)[.size] as? Int) ?? 0
            print("✅ Source file verified: \(sourceURL.path) (Size: \(String(format: "%.2f MB", Double(sourceSize) / 1024 / 1024)))")
            print("📱 Captured orientation: \(capturedOrientation?.displayName ?? "Unknown")")
            
            // Copy to documents directory
            let docs = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first!
            let destination = docs.appendingPathComponent(fileName)
            
            // CRITICAL FIX: Don't remove existing files - use unique timestamps instead
            if FileManager.default.fileExists(atPath: destination.path) {
                print("⚠️ File already exists but using unique timestamp filename: \(fileName)")
                throw NSError(domain: "STS.FileSystem", code: -3,
                            userInfo: [NSLocalizedDescriptionKey: "File already exists despite unique naming: \(fileName)"])
            }
            
            // COPY file instead of moving it
            try FileManager.default.copyItem(at: sourceURL, to: destination)
            print("✅ Video copied to: \(destination.path)")
            
            // Verify the copy was successful
            guard FileManager.default.fileExists(atPath: destination.path) else {
                throw NSError(domain: "STS.FileSystem", code: -2,
                            userInfo: [NSLocalizedDescriptionKey: "File copy completed but destination file not found"])
            }
            
            // Get final file size for verification
            let finalSize = (try? FileManager.default.attributesOfItem(atPath: destination.path)[.size] as? Int) ?? 0
            let finalSizeMB = Double(finalSize) / 1024 / 1024
            
            print("✅ Video successfully persisted: \(destination.path)")
            print("📊 File size: \(String(format: "%.2f MB", finalSizeMB)) MB (Source: \(sourceSize) bytes, Final: \(finalSize) bytes)")
            
            // FIRST: Update SessionManager with the original file immediately
            self.extractVideoMetadataAndUpdateSession(
                filePath: destination.path,
                fileName: fileName,
                fileSize: Int64(finalSize),
                capturedOrientation: capturedOrientation
            )
        } catch {
            print("❌ File persistence failed: \(error)")
            errorMessage = "Failed to save recording: \(error.localizedDescription)"
        }
    }
    
    // MARK: - Video Metadata Extraction
    
    private func extractVideoMetadataAndUpdateSession(filePath: String, fileName: String, fileSize: Int64, capturedOrientation: VideoOrientation? = nil) {
        // Extract video duration using AVAsset with timeout protection
        let asset = AVURLAsset(url: URL(fileURLWithPath: filePath))
        
        Task {
            do {
                // Add timeout protection to prevent system hangs
                let duration = try await withTimeout(seconds: 5.0) {
                    try await asset.load(.duration)
                }
                
                let durationSeconds = duration.seconds
                
                // Validate duration is not NaN/infinite
                let safeDuration = (!durationSeconds.isNaN && !durationSeconds.isInfinite && durationSeconds > 0) ? durationSeconds : 0.0
                
                // Also try to extract orientation from video metadata if not provided
                let finalOrientation: VideoOrientation?
                if let capturedOrientation = capturedOrientation {
                    finalOrientation = capturedOrientation
                } else {
                    // Try to extract orientation from video metadata
                    finalOrientation = try await self.extractOrientationFromVideoMetadata(asset: asset)
                }
                
                print("✅ Video metadata extracted: Duration: \(safeDuration)s, Orientation: \(finalOrientation?.displayName ?? "Unknown")")
                
                // Update SessionManager on main thread
                await MainActor.run {
                    self.updateSessionManagerWithMetadata(
                        fileName: fileName,
                        filePath: filePath,
                        duration: safeDuration,
                        fileSize: fileSize,
                        capturedOrientation: finalOrientation
                    )
                }
                
            } catch {
                print("❌ Video metadata extraction failed: \(error)")
                
                // Fallback with default values
                await MainActor.run {
                    self.updateSessionManagerWithMetadata(
                        fileName: fileName,
                        filePath: filePath,
                        duration: 0.0,  // Default duration
                        fileSize: fileSize,
                        capturedOrientation: capturedOrientation
                    )
                }
            }
        }
    }
    
    private func extractOrientationFromVideoMetadata(asset: AVURLAsset) async throws -> VideoOrientation? {
        let videoTracks = try await asset.loadTracks(withMediaType: .video)
        guard let videoTrack = videoTracks.first else { return nil }
        
        let naturalSize = try await videoTrack.load(.naturalSize)
        let preferredTransform = try await videoTrack.load(.preferredTransform)
        
        // Determine orientation based on natural size and transform
        let isPortrait = naturalSize.height > naturalSize.width
        
        // Check transform to see if video was recorded in portrait but transformed
        let angle = atan2(preferredTransform.b, preferredTransform.a) * 180 / .pi
        let normalizedAngle = angle < 0 ? angle + 360 : angle
        
        // Determine orientation based on both natural size and transform
        switch normalizedAngle {
        case 45..<135, 225..<315:  // Portrait ranges (90° ± 45°, 270° ± 45°)
            return .portrait
        default:  // Landscape ranges (0° ± 45°, 180° ± 45°)
            return .landscape
        }
    }
    
    // SessionManager update method with orientation support
    private func updateSessionManagerWithMetadata(fileName: String, filePath: String, duration: TimeInterval, fileSize: Int64, capturedOrientation: VideoOrientation? = nil) {
        // Update SessionManager directly without remove/re-add to prevent cascading notifications
        SessionManager.shared.addUnifiedTakeWithOrientation(
            fileName: fileName,
            projectID: self.project.id,
            sessionID: self.session.id,
            filePath: filePath,
            duration: duration,
            fileSize: fileSize,
            cameraPosition: self.engine.currentCameraPosition == .front ? "front" : "back",
            capturedOrientation: capturedOrientation,  // Pass orientation
            notes: nil
        )
        
        print("✅ SessionManager updated with unified take - Duration: \(duration)s, Size: \(fileSize) bytes")
        print("📱 Orientation: \(capturedOrientation?.displayName ?? "Unknown")")
        print("📍 File path stored: \(filePath)")
    }

    // MARK: - Photo Persistence
    
    private func persistCapturedPhoto(from sourceURL: URL, as fileName: String, originalSize: Int, capturedOrientation: VideoOrientation? = nil) {
        do {
            // Verify source file still exists
            guard FileManager.default.fileExists(atPath: sourceURL.path) else {
                throw NSError(domain: "STS.FileSystem", code: -1,
                            userInfo: [NSLocalizedDescriptionKey: "Source photo no longer exists: \(sourceURL.path)"])
            }
            
            // Get file size before any operations
            let sourceSize = (try? FileManager.default.attributesOfItem(atPath: sourceURL.path)[.size] as? Int) ?? 0
            print("📁 Source photo verified: \(sourceURL.path) (Size: \(sourceSize) bytes)")
            print("📱 Photo captured with orientation: \(capturedOrientation?.displayName ?? "Unknown")")
            
            // Copy to documents directory
            let docs = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first!
            let destination = docs.appendingPathComponent(fileName)
            
            // Don't remove existing photos - use unique timestamps instead
            if FileManager.default.fileExists(atPath: destination.path) {
                print("⚠️ Photo already exists but using unique timestamp filename: \(fileName)")
                throw NSError(domain: "STS.FileSystem", code: -3,
                            userInfo: [NSLocalizedDescriptionKey: "Photo already exists despite unique naming: \(fileName)"])
            }
            
            // Copy photo
            try FileManager.default.copyItem(at: sourceURL, to: destination)
            print("✅ Photo copied to: \(destination.path)")
            
            // Verify the copy was successful
            guard FileManager.default.fileExists(atPath: destination.path) else {
                throw NSError(domain: "STS.FileSystem", code: -2,
                            userInfo: [NSLocalizedDescriptionKey: "Photo copy completed but destination file not found"])
            }
            
            // Get final file size for verification
            let finalSize = (try? FileManager.default.attributesOfItem(atPath: destination.path)[.size] as? Int) ?? 0
            let finalSizeMB = Double(finalSize) / 1024 / 1024
            
            print("✅ Photo successfully persisted: \(destination.path)")
            print("📊 Photo size: \(String(format: "%.2f MB", finalSizeMB)) (Source: \(sourceSize) bytes, Final: \(finalSize) bytes)")
            
            // Update SessionManager with photo take including orientation
            updateSessionManagerWithPhoto(
                fileName: fileName,
                filePath: destination.path,
                fileSize: Int64(finalSize),
                capturedOrientation: capturedOrientation
            )
            
        } catch {
            print("❌ Photo persistence failed: \(error)")
            errorMessage = "Failed to save photo: \(error.localizedDescription)"
        }
    }
    
    // Photo SessionManager update method with orientation support
    private func updateSessionManagerWithPhoto(fileName: String, filePath: String, fileSize: Int64, capturedOrientation: VideoOrientation? = nil) {
        // Update SessionManager directly without remove/re-add to prevent cascading notifications
        SessionManager.shared.addUnifiedPhotoTakeWithOrientation(
            fileName: fileName,
            projectID: self.project.id,
            sessionID: self.session.id,
            filePath: filePath,
            fileSize: fileSize,
            cameraPosition: self.engine.currentCameraPosition == .front ? "front" : "back",
            capturedOrientation: capturedOrientation,  // Pass orientation
            notes: nil
        )
        
        print("✅ SessionManager updated with photo take - Size: \(fileSize) bytes")
        print("📱 Photo orientation: \(capturedOrientation?.displayName ?? "Unknown")")
        print("📍 Photo path stored: \(filePath)")
    }

    // MARK: - Dynamic Positioning Helpers
    
    private var safeAreaInsets: (top: CGFloat, bottom: CGFloat) {
        let windowScene = UIApplication.shared.connectedScenes.first as? UIWindowScene
        let window = windowScene?.windows.first
        let top = window?.safeAreaInsets.top ?? 44
        let bottom = window?.safeAreaInsets.bottom ?? 34
        return (top: top, bottom: bottom)
    }
    
    private func calculateLayoutMetrics() -> LayoutMetrics {
        let safeArea = safeAreaInsets
        let isPortraitMode = !isLandscape
        
        let manualControlsHeight: CGFloat = 180
        let audioControlsHeight: CGFloat = 140
        let levelIndicatorHeight: CGFloat = 80
        let topBarHeight: CGFloat = 60
        
        let screenHeight = UIScreen.main.bounds.height
        let availableHeight = screenHeight - safeArea.top - safeArea.bottom
        
        if isPortraitMode {
            return calculatePortraitLayout(
                availableHeight: availableHeight,
                safeArea: safeArea,
                manualControlsHeight: manualControlsHeight,
                audioControlsHeight: audioControlsHeight,
                levelIndicatorHeight: levelIndicatorHeight,
                topBarHeight: topBarHeight
            )
        } else {
            return calculateLandscapeLayout(
                availableHeight: availableHeight,
                safeArea: safeArea,
                manualControlsHeight: manualControlsHeight,
                audioControlsHeight: audioControlsHeight,
                levelIndicatorHeight: levelIndicatorHeight,
                topBarHeight: topBarHeight
            )
        }
    }
    
    private func calculatePortraitLayout(
        availableHeight: CGFloat,
        safeArea: (top: CGFloat, bottom: CGFloat),
        manualControlsHeight: CGFloat,
        audioControlsHeight: CGFloat,
        levelIndicatorHeight: CGFloat,
        topBarHeight: CGFloat
    ) -> LayoutMetrics {
        var metrics = LayoutMetrics()
        
        metrics.topBarPadding = safeArea.top + 12
        
        var currentBottomOffset: CGFloat = 20 // Base safe area padding
        
        if showManualControls {
            metrics.manualControlsBottom = currentBottomOffset
            currentBottomOffset += manualControlsHeight + 20 // Add spacing
        }
        
        if showLevelIndicator {
            if showManualControls {
                metrics.levelIndicatorBottom = currentBottomOffset - 20
                currentBottomOffset = max(currentBottomOffset, metrics.levelIndicatorBottom + levelIndicatorHeight + 20)
            } else {
                metrics.levelIndicatorBottom = 150
                currentBottomOffset = max(currentBottomOffset, metrics.levelIndicatorBottom + levelIndicatorHeight + 20)
            }
        }
        
        if showAudioControls {
            if showLevelIndicator {
                metrics.audioControlsBottom = currentBottomOffset + 20
                currentBottomOffset = max(currentBottomOffset, metrics.audioControlsBottom + audioControlsHeight + 20)
            } else if showManualControls {
                metrics.audioControlsBottom = currentBottomOffset + 20
                currentBottomOffset = max(currentBottomOffset, metrics.audioControlsBottom + audioControlsHeight + 20)
            } else {
                metrics.audioControlsBottom = 200
                currentBottomOffset = max(currentBottomOffset, metrics.audioControlsBottom + audioControlsHeight + 20)
            }
        }
        
        let minTopClearance = safeArea.top + topBarHeight + 20
        if currentBottomOffset > availableHeight - minTopClearance {
            let compressionRatio = (availableHeight - minTopClearance) / currentBottomOffset
            metrics.audioControlsBottom *= compressionRatio
            metrics.levelIndicatorBottom *= compressionRatio
            metrics.manualControlsBottom *= compressionRatio
        }
        
        return metrics
    }
    
    private func calculateLandscapeLayout(
        availableHeight: CGFloat,
        safeArea: (top: CGFloat, bottom: CGFloat),
        manualControlsHeight: CGFloat,
        audioControlsHeight: CGFloat,
        levelIndicatorHeight: CGFloat,
        topBarHeight: CGFloat
    ) -> LayoutMetrics {
        var metrics = LayoutMetrics()
        
        metrics.topBarPadding = max(safeArea.top + 4, 8) // Very tight top spacing
        
        let minBottomSafeArea: CGFloat = max(safeArea.bottom + 4, 8)
        var currentBottomOffset: CGFloat = minBottomSafeArea // FIXED: Initialize currentBottomOffset
        
        if showManualControls {
            metrics.manualControlsBottom = minBottomSafeArea
            currentBottomOffset += manualControlsHeight + 20 // Update offset
        }
        
        if showLevelIndicator {
            if showManualControls && showAudioControls {
                metrics.levelIndicatorBottom = minBottomSafeArea + manualControlsHeight + 10 // FIXED: Use proper calculation
            } else if showManualControls {
                metrics.levelIndicatorBottom = currentBottomOffset + 10
                currentBottomOffset = max(currentBottomOffset, metrics.levelIndicatorBottom + levelIndicatorHeight + 20)
            } else {
                metrics.levelIndicatorBottom = 80 // FIXED: Use reasonable landscape default
                currentBottomOffset = max(currentBottomOffset, metrics.levelIndicatorBottom + levelIndicatorHeight + 20)
            }
        }
        
        if showAudioControls {
            if showManualControls && showLevelIndicator {
                let safeMiddlePosition = (availableHeight * 0.4) // 40% down from top
                metrics.audioControlsBottom = max(safeMiddlePosition, minBottomSafeArea + 160)
            } else if showManualControls {
                metrics.audioControlsBottom = minBottomSafeArea + 120
            } else if showLevelIndicator {
                metrics.audioControlsBottom = max(metrics.levelIndicatorBottom + 60, minBottomSafeArea + 100)
            } else {
                metrics.audioControlsBottom = minBottomSafeArea + 80
            }
        }
        
        let maxTopPosition = availableHeight - safeArea.top - 40 // Leave 40pt clearance from top
        
        if showAudioControls && (metrics.audioControlsBottom + audioControlsHeight) > maxTopPosition {
            metrics.audioControlsBottom = max(maxTopPosition - audioControlsHeight, minBottomSafeArea + 40)
        }
        
        if showAudioControls && showLevelIndicator && (metrics.levelIndicatorBottom + levelIndicatorHeight + 20) > metrics.audioControlsBottom {
            metrics.levelIndicatorBottom = max(metrics.audioControlsBottom - levelIndicatorHeight - 10, minBottomSafeArea + 20)
        }
        
        return metrics
    }
    
    private func calculateAudioControlsBottomPadding() -> CGFloat {
        let metrics = calculateLayoutMetrics()
        return metrics.audioControlsBottom
    }
    
    private func calculateTopBarTopPadding() -> CGFloat {
        let metrics = calculateLayoutMetrics()
        return metrics.topBarPadding
    }
    
    private func calculateLevelIndicatorBottomPadding() -> CGFloat {
        let metrics = calculateLayoutMetrics()
        return metrics.levelIndicatorBottom
    }
    
    private func calculateManualControlsBottomPadding() -> CGFloat {
        let metrics = calculateLayoutMetrics()
        return metrics.manualControlsBottom
    }

    struct LayoutMetrics {
        var topBarPadding: CGFloat = 0
        var audioControlsBottom: CGFloat = 0
        var levelIndicatorBottom: CGFloat = 0
        var manualControlsBottom: CGFloat = 0
    }
}

// Update camera engine mode immediately when SessionManager changes
extension CameraCaptureView {
    private func updateCameraEngineMode() {
        guard isCameraReady else { return }
        
        if currentCameraMode == .photo {
            engine.switchToPhotoMode()
            print("📸 Camera engine switched to photo mode")
        } else {
            engine.switchToVideoMode()
            print("📹 Camera engine switched to video mode")
        }
    }
}

// Focus Indicator View

struct FocusIndicator: View {
    var body: some View {
        ZStack {
            Circle()
                .stroke(Color.yellow, lineWidth: 2)
                .frame(width: 60, height: 60)
            
            Circle()
                .stroke(Color.yellow, lineWidth: 1)
                .frame(width: 40, height: 40)
        }
        .opacity(0.8)
    }
}

// Timeout Helper Function

// Timeout protection to prevent system hangs
func withTimeout<T>(seconds: Double, operation: @escaping () async throws -> T) async throws -> T {
    return try await withThrowingTaskGroup(of: T.self) { group in
        group.addTask {
            try await operation()
        }
        
        group.addTask {
            try await Task.sleep(nanoseconds: UInt64(seconds * 1_000_000_000))
            throw TimeoutError.operationTimedOut
        }
        
        let result = try await group.next()!
        group.cancelAll()
        return result
    }
}

enum TimeoutError: Error, LocalizedError {
    case operationTimedOut
    
    var errorDescription: String? {
        switch self {
        case .operationTimedOut:
            return "Operation timed out"
        }
    }
}

// Preview
struct CameraCaptureView_Previews: PreviewProvider {
    static var previews: some View {
        CameraCaptureView(
            project: Project(title: "Sample Project", castingOffice: "Sample Casting"),
            session: ProjectSession(type: .selfTape, roleName: "Sample Role")
        ) {
            print("Preview completed")
        }
    }
}
