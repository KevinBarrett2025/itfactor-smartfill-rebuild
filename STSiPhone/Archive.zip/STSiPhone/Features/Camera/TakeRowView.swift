import SwiftUI

struct TakeRowView: View {
    let take: Take
    @ObservedObject var sessionManager = SessionManager.shared
    
    var body: some View {
        HStack(spacing: 6) {
            // Take name with timestamp
            VStack(alignment: .leading, spacing: 2) {
                Text(takeDisplayName)
                    .font(.caption2)
                    .foregroundColor(.white)
                    .lineLimit(1)
                
                Text(timeAgo)
                    .font(.caption2)
                    .foregroundColor(.white.opacity(0.7))
            }
            
            // Status indicators - UNIFIED: Use TakeRating instead of individual booleans
            HStack(spacing: 4) {
                if take.rating == .good {
                    Image(systemName: "checkmark.circle.fill")
                        .font(.caption)
                        .foregroundColor(.green)
                }
                
                if take.rating == .favorite {
                    Image(systemName: "star.fill")
                        .font(.caption)
                        .foregroundColor(.yellow)
                }
                
                if take.rating == .bad {
                    Image(systemName: "xmark.circle.fill")
                        .font(.caption)
                        .foregroundColor(.red)
                }
            }
            
            Spacer()
            
            // Quick action buttons - UNIFIED: Use unified rating system
            HStack(spacing: 8) {
                // Good take toggle
                Button(action: { 
                    let newRating: TakeRating = take.rating == .good ? .unrated : .good
                    updateTakeRating(newRating)
                }) {
                    Image(systemName: take.rating == .good ? "checkmark.circle.fill" : "checkmark.circle")
                        .font(.caption)
                        .foregroundColor(take.rating == .good ? .green : .white.opacity(0.6))
                }
                
                // Star toggle
                Button(action: { 
                    let newRating: TakeRating = take.rating == .favorite ? .unrated : .favorite
                    updateTakeRating(newRating)
                }) {
                    Image(systemName: take.rating == .favorite ? "star.fill" : "star")
                        .font(.caption)
                        .foregroundColor(take.rating == .favorite ? .yellow : .white.opacity(0.6))
                }
                
                // Bad take toggle
                Button(action: { 
                    let newRating: TakeRating = take.rating == .bad ? .unrated : .bad
                    updateTakeRating(newRating)
                }) {
                    Image(systemName: take.rating == .bad ? "xmark.circle.fill" : "xmark.circle")
                        .font(.caption)
                        .foregroundColor(take.rating == .bad ? .red : .white.opacity(0.6))
                }
                
                // Delete button
                Button(action: { 
                    withAnimation(.easeInOut(duration: 0.3)) {
                        sessionManager.delete(take)
                    }
                }) {
                    Image(systemName: "trash.circle")
                        .font(.caption)
                        .foregroundColor(.red.opacity(0.8))
                }
            }
        }
        .padding(.horizontal, 10)
        .padding(.vertical, 6)
        .background(.ultraThinMaterial.opacity(0.8), in: Capsule())
        .overlay(
            Capsule().stroke(Color.white.opacity(0.15), lineWidth: 1)
        )
    }
    
    private var takeDisplayName: String {
        // Extract a cleaner name from fileName
        let name = take.fileName.replacingOccurrences(of: ".mov", with: "")
        if name.contains("_Take") {
            let components = name.components(separatedBy: "_Take")
            if components.count > 1 {
                return "Take \(components.last ?? "1")"
            }
        }
        return name
    }
    
    private var timeAgo: String {
        let timeInterval = Date().timeIntervalSince(take.createdAt)
        
        if timeInterval < 60 {
            return "\(Int(timeInterval))s ago"
        } else if timeInterval < 3600 {
            return "\(Int(timeInterval / 60))m ago"
        } else {
            return "\(Int(timeInterval / 3600))h ago"
        }
    }
    
    // UNIFIED: Helper method to update take ratings
    private func updateTakeRating(_ newRating: TakeRating) {
        // For legacy Take model, we need to find project/session context
        // This is a limitation - ideally we'd have that context
        // For now, use SessionManager's legacy methods but log the need for improvement
        
        switch newRating {
        case .good:
            sessionManager.toggleGood(take)
        case .favorite:
            sessionManager.toggleStar(take)
        case .bad:
            sessionManager.markBad(take)
        case .unrated:
            sessionManager.resetRating(take)
        }
        
        print("✅ TakeRowView: Updated take rating to \(newRating.rawValue)")
    }
}

#Preview {
    let sampleTake = Take(
        segmentId: UUID(),
        fileName: "Scene1_Take3.mov",
        duration: 45.2,
        rating: .favorite
    )
    
    TakeRowView(take: sampleTake)
}
