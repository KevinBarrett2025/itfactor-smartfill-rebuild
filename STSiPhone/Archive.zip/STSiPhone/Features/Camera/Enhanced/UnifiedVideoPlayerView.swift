import SwiftUI
import AVFoundation
import AVKit
import CoreGraphics

// ENHANCED: Video player context for different use cases
public enum VideoPlayerContext {
    case fullscreenPlayer
    case takePreview
    case sessionReview
    case export
}

// CRITICAL FIX: Enhanced AVPlayerViewController with Orientation Management - MADE PUBLIC
public class EnhancedAVPlayerViewController: AVPlayerViewController {
    var coordinator: CustomAVPlayerViewController.Coordinator?
    var videoData: VideoPlayerDisplayData?
    
    // ORIENTATION FIX: Add orientation management
    private var orientationManager: VideoOrientationManager?
    
    // CRITICAL FIX: Add video lifecycle management - FIXED: Default to true for normal playback
    public var isCurrentlyVisible: Bool = true {
        didSet {
            handleVisibilityChange()
        }
    }
    
    // CRITICAL FIX: Flag to track if this is part of swipeable video collection
    public var isPartOfSwipeableCollection: Bool = false
    
    // NEW: Track control visibility with timer-based approach
    private var controlVisibilityTimer: Timer?
    private var lastControlsVisible: Bool = true
    public var onControlVisibilityChanged: ((Bool) -> Void)?
    
    // CRITICAL FIX: Handle visibility changes to manage playback - REFINED logic
    private func handleVisibilityChange() {
        // CRITICAL FIX: Only apply visibility logic if part of a swipeable collection
        guard isPartOfSwipeableCollection else { return }
        
        guard let player = self.player else { return }
        
        if isCurrentlyVisible {
            // Don't auto-play when becoming visible - let user control playback
            print("📱 Video now visible - waiting for user to play")
        } else {
            // Pause playback when no longer visible (only if playing)
            if player.rate > 0 {
                print("⏸️ Pausing video playback - no longer visible")
                player.pause()
            }
        }
    }
    
    // CRITICAL FIX: Add method to force pause (for immediate stopping)
    public func pauseVideo() {
        player?.pause()
        print("⏹️ Force paused video")
    }
    
    // CRITICAL FIX: Add method to resume video
    public func resumeVideo() {
        guard let player = player, player.currentItem != nil else { return }
        player.play()
        print("▶️ Resumed video playback")
    }
    
    // NEW: Setup control visibility monitoring with timer-based detection
    public func setupControlVisibilityMonitoring() {
        // Start timer to periodically check control visibility
        controlVisibilityTimer = Timer.scheduledTimer(withTimeInterval: 0.1, repeats: true) { [weak self] _ in
            self?.checkControlVisibility()
        }
        
        print("🎮 Setup control visibility monitoring with timer approach")
    }
    
    // NEW: Check if controls are currently visible using view hierarchy
    private func checkControlVisibility() {
        let controlsVisible = areControlsVisible()
        
        if controlsVisible != lastControlsVisible {
            lastControlsVisible = controlsVisible
            DispatchQueue.main.async {
                self.onControlVisibilityChanged?(controlsVisible)
            }
        }
    }
    
    // NEW: Detect if controls are visible by examining view hierarchy
    private func areControlsVisible() -> Bool {
        // Look for transport controls view in the view hierarchy
        return findTransportControlsView(in: view) != nil
    }
    
    // NEW: Recursively find transport controls view
    private func findTransportControlsView(in view: UIView) -> UIView? {
        // Check if this view or its subviews contain transport controls
        for subview in view.subviews {
            let className = String(describing: type(of: subview))
            
            // Look for AVKit transport controls
            if className.contains("Transport") ||
               className.contains("Controls") ||
               className.contains("Playback") {
                // Check if it's actually visible (not hidden and has alpha > 0)
                if !subview.isHidden && subview.alpha > 0.1 {
                    return subview
                }
            }
            
            // Recursively search subviews
            if let found = findTransportControlsView(in: subview) {
                return found
            }
        }
        
        return nil
    }
    
    public override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        handleOrientationChange()
    }
    
    public override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        setupOrientationHandling()
    }
    
    public override func viewDidDisappear(_ animated: Bool) {
        super.viewDidDisappear(animated)
        cleanupOrientationHandling()
        
        // Clean up control visibility timer
        controlVisibilityTimer?.invalidate()
        controlVisibilityTimer = nil
    }
    
    // RESTORE: Orientation handling that was making landscape work
    private func setupOrientationHandling() {
        NotificationCenter.default.addObserver(
            self,
            selector: #selector(deviceOrientationChanged),
            name: UIDevice.orientationDidChangeNotification,
            object: nil
        )
    }
    
    private func cleanupOrientationHandling() {
        NotificationCenter.default.removeObserver(
            self,
            name: UIDevice.orientationDidChangeNotification,
            object: nil
        )
    }
    
    @objc private func deviceOrientationChanged() {
        DispatchQueue.main.async {
            self.handleOrientationChange()
        }
    }
    
    // RESTORE: Handle orientation changes with proper frame updates
    private func handleOrientationChange() {
        updateVideoLayerForCurrentOrientation()
        
        let orientation = UIDevice.current.orientation
        print("🔄 Orientation changed to: \(orientationDescription(orientation))")
    }
    
    private func orientationDescription(_ orientation: UIDeviceOrientation) -> String {
        switch orientation {
        case .portrait: return "Portrait"
        case .landscapeLeft: return "Landscape Left"
        case .landscapeRight: return "Landscape Right"
        case .portraitUpsideDown: return "Portrait Upside Down"
        case .faceUp: return "Face Up"
        case .faceDown: return "Face Down"
        default: return "Unknown"
        }
    }
    
    // RESTORE: Update video layer frame for current orientation
    func updateVideoLayerForCurrentOrientation() {
        guard let playerLayer = getPlayerLayer() else { return }
        
        DispatchQueue.main.async {
            playerLayer.frame = self.view.bounds
            print("📐 Updated player layer frame to: \(self.view.bounds)")
        }
    }
    
    // RESTORE: Get player layer for frame updates
    private func getPlayerLayer() -> AVPlayerLayer? {
        return findPlayerLayerInView(view)
    }
    
    private func findPlayerLayerInView(_ view: UIView) -> AVPlayerLayer? {
        if let playerLayer = view.layer as? AVPlayerLayer {
            return playerLayer
        }
        
        if let sublayers = view.layer.sublayers {
            for sublayer in sublayers {
                if let playerLayer = sublayer as? AVPlayerLayer {
                    return playerLayer
                }
            }
        }
        
        for subview in view.subviews {
            if let playerLayer = findPlayerLayerInView(subview) {
                return playerLayer
            }
        }
        
        return nil
    }
}

struct UnifiedVideoPlayerView: UIViewControllerRepresentable {
    let url: URL?
    let context: VideoPlayerContext
    
    // BACKWARD COMPATIBILITY: Support direct URL initialization
    init(url: URL) {
        self.url = url
        self.context = .takePreview
    }
    
    // ENHANCED: Context-aware initialization
    init(context: VideoPlayerContext, url: URL? = nil) {
        self.context = context
        self.url = url
    }

    func makeUIViewController(context: Context) -> EnhancedAVPlayerViewController {
        let avPlayerVC = EnhancedAVPlayerViewController()
        
        // Use URL if provided directly, otherwise get from VideoPlayerService
        let playerURL = url ?? VideoPlayerService.shared.currentURL
        
        if let validURL = playerURL {
            // RESEARCH-BASED FIX: Let AVPlayerViewController handle orientation naturally
            setupPlayerNaturally(avPlayerVC, videoURL: validURL)
        }
        
        avPlayerVC.showsPlaybackControls = true
        
        // ORIENTATION FIX: Use resizeAspect for natural aspect ratios with proper orientation handling
        avPlayerVC.videoGravity = .resizeAspect
        avPlayerVC.allowsPictureInPicturePlayback = true
        
        // Context-specific configurations
        switch self.context {
        case .fullscreenPlayer:
            avPlayerVC.modalPresentationStyle = .fullScreen
            avPlayerVC.showsPlaybackControls = true
        case .takePreview:
            avPlayerVC.showsPlaybackControls = true
        case .sessionReview:
            avPlayerVC.showsPlaybackControls = true
            avPlayerVC.allowsPictureInPicturePlayback = false
        case .export:
            avPlayerVC.showsPlaybackControls = false
            avPlayerVC.allowsPictureInPicturePlayback = false
        }
        
        print("✅ UnifiedVideoPlayerView: Configured EnhancedAVPlayerViewController with natural orientation handling")
        return avPlayerVC
    }
    
    func updateUIViewController(_ controller: EnhancedAVPlayerViewController, context: Context) {
        // Update player URL if it changes from VideoPlayerService
        if url == nil, let newURL = VideoPlayerService.shared.currentURL,
           controller.player?.currentItem?.asset != AVURLAsset(url: newURL) {
            
            // RESEARCH-BASED FIX: Use natural setup on updates too
            setupPlayerNaturally(controller, videoURL: newURL)
            print("🔄 UnifiedVideoPlayerView: Updated player with new URL using natural approach")
        }
        
    }
    
    // RESEARCH-BASED FIX: Natural setup without forcing video composition
    private func setupPlayerNaturally(_ playerViewController: EnhancedAVPlayerViewController, videoURL: URL) {
        // Simply create AVPlayer with URL - let AVPlayerViewController handle orientation
        let player = AVPlayer(url: videoURL)
        playerViewController.player = player
        
        print("✅ UnifiedVideoPlayerView: Set up player naturally - letting AVPlayerViewController handle orientation automatically")
        print("   💡 Research finding: AVPlayerViewController respects video rotation metadata without composition")
    }
}

// MARK: - VideoPlayerService Integration
extension VideoPlayerService {
}

// MARK: - Preview
#Preview {
    if let sampleURL = Bundle.main.url(forResource: "sample_video", withExtension: "mp4") {
        UnifiedVideoPlayerView(url: sampleURL)
    } else {
        Text("No sample video available")
            .foregroundColor(.gray)
    }
}
