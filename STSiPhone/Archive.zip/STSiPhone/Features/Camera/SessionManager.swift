import Foundation
import AVFoundation

// MARK: - Enhanced Session Manager with UNIFIED MODEL SUPPORT
// Phase 1C: Adding UnifiedTake support alongside existing EnhancedTake system
// PRESERVATION-FIRST: All existing functionality maintained

public class SessionManager: ObservableObject {
    public static let shared = SessionManager()
    
    @Published private(set) var currentSession: SessionState?
    
    // EXISTING: Keep original takes for compatibility
    @Published private(set) var activeTakes: [EnhancedTake] = []
    
    // ENHANCED: Add unified takes support alongside existing system
    @Published private(set) var unifiedTakes: [UnifiedTake] = []
    @Published private(set) var useUnifiedModels: Bool = false
    
    @Published var currentScene: Int = 1
    @Published var totalScenes: Int = 1
    
    // REDESIGNED: Slate as separate recording mode, not a modifier
    @Published var isRecordingSlate: Bool = false // NEW: Replace isSlateNext with recording mode
    @Published var hasRecordedSlate: Bool = false
    @Published var slateSkippedForSession: Bool = false
    
    // NEW: Keyframe photo recording mode
    @Published var isRecordingKeyframePhoto: Bool = false
    @Published var hasRecordedKeyframePhoto: Bool = false
    
    // CORE INTEGRATION FIX: Add repository injection
    private var repository: ProjectsRepository?
    
    // CORE INTEGRATION FIX: Public access to repository for CameraCaptureView
    public var repositoryInstance: ProjectsRepository? {
        return repository
    }
    
    private init() {}
    
    // CORE INTEGRATION FIX: Configure repository with enhanced logging
    public func configure(with repository: ProjectsRepository) {
        self.repository = repository
        
        // CRITICAL FIX: Enable unified model support in repository immediately
        if let inMemoryRepo = repository as? InMemoryProjectsRepository {
            inMemoryRepo.enableUnifiedModelSupport()
        }
        
        print("📹 SessionManager: Configured with repository and enabled unified model support")
    }
    
    // ENHANCED: Enable unified models with seamless migration - ALWAYS ENABLE FOR NEW SESSIONS
    public func enableUnifiedModels() {
        if useUnifiedModels {
            print("🔄 SessionManager: Unified models already enabled")
            return
        }
        
        print("🔄 SessionManager: Enabling unified models...")
        
        // Convert existing takes to unified format if any exist
        if !activeTakes.isEmpty {
            unifiedTakes = activeTakes.map { UnifiedTake(from: $0) }
            print("✅ Converted \(activeTakes.count) existing takes to unified format")
        }
        
        useUnifiedModels = true
        print("✅ SessionManager: Unified models enabled with \(unifiedTakes.count) takes")
    }
    
    // MARK: - Session Management (PRESERVED) with UNIFIED DEFAULT
    public func startSession(project: Project, session: ProjectSession) {
        currentSession = SessionState(
            project: project,
            session: session,
            startTime: Date()
        )
        activeTakes = []
        unifiedTakes = []
        
        // ENHANCED: Initialize scene management from project
        currentScene = 1
        totalScenes = max(1, project.sceneCount) // Ensure at least 1 scene
        
        isRecordingSlate = false // REDESIGNED: New slate mode initialization
        hasRecordedSlate = false
        slateSkippedForSession = false
        
        // CRITICAL FIX: Always enable unified models for new sessions
        enableUnifiedModels()
        
        print("📹 SessionManager: Started session for \(project.title) with \(totalScenes) scenes and unified models enabled")
    }
    
    func endSession() {
        guard let session = currentSession else { return }
        print("📹 SessionManager: Ended session for \(session.project.title) with \(effectiveTakeCount) takes")
        
        // CORE INTEGRATION FIX: Persist all takes to repository before clearing
        persistAllTakesToRepository()
        
        currentSession = nil
        activeTakes = []
        unifiedTakes = []
    }
    
    // MARK: - Enhanced Take Management with UNIFIED SUPPORT

    // ENHANCED: New unified take addition method with Smart Fill orientation capture
    func addUnifiedTakeWithOrientation(
        fileName: String,
        projectID: UUID,
        sessionID: UUID,
        filePath: String? = nil,
        duration: TimeInterval = 0,
        fileSize: Int64 = 0,
        cameraPosition: String = "back",
        capturedOrientation: VideoOrientation? = nil,  // NEW: Smart Fill orientation
        notes: String? = nil,
        videoMarkers: [UnifiedVideoMarker] = []
    ) {
        // CRITICAL FIX: Properly calculate scene numbers and take numbers based on current mode
        let (sceneNum, takeNum, slateNum, slateIDStr) = calculateTakeOrganization()
        
        let unifiedTake = UnifiedTake(
            fileName: fileName,
            projectID: projectID,
            sessionID: sessionID,
            filePath: filePath ?? fileName,
            duration: duration,
            fileSize: fileSize,
            cameraPosition: cameraPosition,
            sceneNumber: sceneNum,          // FIXED: Use calculated scene number
            takeNumber: takeNum,            // FIXED: Use calculated take number
            slateNumber: slateNum,          // FIXED: Add slate number
            slateID: slateIDStr,            // FIXED: Add slate ID
            isSlate: isRecordingSlate,      // REDESIGNED: Use recording mode
            isPhoto: false,                 // Default to video - use addUnifiedPhotoTakeWithOrientation for photos
            isKeyframePhoto: false,
            capturedOrientation: capturedOrientation,  // NEW: Store captured orientation
            rating: .unrated,
            notes: notes,
            videoMarkers: videoMarkers
        )
        
        if useUnifiedModels {
            unifiedTakes.append(unifiedTake)
        } else {
            // Convert to legacy for compatibility
            activeTakes.append(unifiedTake.toEnhancedTake())
        }
        
        let orientationStr = capturedOrientation?.displayName ?? "Unknown"
        print("📹 SessionManager: Added unified take with orientation \(fileName) - Scene: \(sceneNum), Take: \(takeNum), Slate: \(slateNum ?? "none"), Orientation: \(orientationStr)")
        
        // Persist to repository
        persistUnifiedTakeToRepository(unifiedTake)
        
        print("🔍 SMARTFILL TRIGGER: About to check if SmartFill processing should be triggered")
        print("   📱 Captured orientation: \(capturedOrientation?.displayName ?? "nil")")
        print("   🎬 Is recording slate: \(isRecordingSlate)")
        print("   📸 Is photo: false (this is a video)")
        
        // 🚨 DISABLED AUTO-PROCESSING: SmartFill should only be applied manually via editor
        // Users should have full control over which videos get SmartFill processing
        // Task { @MainActor in
        //     triggerSmartFillProcessingIfNeeded(unifiedTake: unifiedTake)
        // }
        
        print("📱 SessionManager: Auto-SmartFill disabled - manual processing only via editor")

        // REDESIGNED: Update slate recorded status
        if isRecordingSlate {
            hasRecordedSlate = true
        }
    }
    
    // 🔥 NEW: Auto-trigger SmartFill processing for portrait videos
    @MainActor
    private func triggerSmartFillProcessingIfNeeded(unifiedTake: UnifiedTake) {
        print("🔍 SMARTFILL AUTO-TRIGGER DEBUG: Analyzing take for auto-processing")
        print("   🆔 Take ID: \(unifiedTake.id)")
        print("   📁 Filename: \(unifiedTake.fileName)")
        print("   📱 Captured orientation: \(unifiedTake.capturedOrientation?.displayName ?? "nil")")
        print("   📷 Is photo: \(unifiedTake.isPhoto)")
        print("   🎬 Is slate: \(unifiedTake.isSlate)")
        
        // Only exclude photos - process ALL videos (both scene videos AND slate videos)
        guard let orientation = unifiedTake.capturedOrientation,
              orientation == .portrait,
              !unifiedTake.isPhoto else {
            
            let reason = unifiedTake.isPhoto ? "is photo" :
                        unifiedTake.capturedOrientation == nil ? "no orientation captured" :
                        "orientation is \(unifiedTake.capturedOrientation?.displayName ?? "unknown")"
            print("📱 SessionManager: Skipping SmartFill auto-processing - \(reason)")
            return
        }
        
        // 🔥 ENHANCED: Check if SmartFill is enabled globally
        let settings = SmartFillSettings()
        guard settings.defaultEnabled else {
            print("📱 SessionManager: SmartFill disabled globally, skipping auto-processing")
            return
        }
        
        print("✅ SMARTFILL AUTO-TRIGGER: Portrait video detected, SmartFill enabled - proceeding with auto-processing")
        
        // Generate SmartFill output path
        let inputURL = URL(fileURLWithPath: unifiedTake.filePath)
        let fileName = inputURL.deletingPathExtension().lastPathComponent
        let smartFillFileName = "\(fileName)_smartfill.mov"
        
        // Create SmartFill directory if needed
        let documentsPath = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first!
        let smartFillDir = documentsPath.appendingPathComponent("SmartFill")
        
        do {
            try FileManager.default.createDirectory(at: smartFillDir, withIntermediateDirectories: true)
        } catch {
            print("❌ SessionManager: Could not create SmartFill directory: \(error)")
            return
        }
        
        let outputPath = smartFillDir.appendingPathComponent(smartFillFileName).path
        
        print("🎯 SessionManager: Auto-enqueuing SmartFill job for portrait video")
        print("   📁 Input: \(unifiedTake.filePath)")
        print("   📁 Output: \(outputPath)")
        print("   📱 Orientation: \(orientation.displayName)")
        print("   ⚙️ Settings: Enabled=\(settings.defaultEnabled), Blur=\(settings.defaultBlurRadius), Scale=\(settings.backgroundScale)")
        
        // 🔥 CRITICAL FIX: Validate input file exists before enqueuing
        guard FileManager.default.fileExists(atPath: unifiedTake.filePath) else {
            print("❌ SessionManager: Input file does not exist, cannot enqueue SmartFill job: \(unifiedTake.filePath)")
            return
        }
        
        // 🔥 CRITICAL FIX: Pre-set the SmartFill path in repository BEFORE processing
        // This ensures UI shows that SmartFill is "expected" even before processing completes
        if let repository = repositoryInstance {
            repository.updateTakeWithSmartFillPath(
                takeID: unifiedTake.id,
                smartFilledPath: outputPath,
                in: unifiedTake.sessionID,
                in: unifiedTake.projectID
            )
            print("🔄 SessionManager: Pre-set SmartFill path in repository before processing")
        }
        
        // 🚀 ARCHITECTURAL FIX: Use SmartFillUnifiedInterface instead of SmartFillProcessingManager
        // This routes through the proper migration manager to choose the best system
        Task {
            do {
                let result = try await SmartFillUnifiedInterface.shared.processVideo(
                    inputURL: URL(fileURLWithPath: unifiedTake.filePath),
                    outputURL: URL(fileURLWithPath: outputPath),
                    settings: settings,
                    progressCallback: nil
                )
                
                print("✅ SessionManager: SmartFill processing completed successfully")
                print("   🎬 Compositor used: \(result.compositorUsed.displayName)")
                print("   ⏱️ Processing time: \(String(format: "%.2f", result.processingTime))s")
                
                // Update repository with completion
                await MainActor.run {
                    if let repository = repositoryInstance {
                        repository.updateTakeWithSmartFillPath(
                            takeID: unifiedTake.id,
                            smartFilledPath: outputPath,
                            in: unifiedTake.sessionID,
                            in: unifiedTake.projectID
                        )
                    }
                    
                    // Post success notification
                    NotificationCenter.default.post(
                        name: Notification.Name("STSSmartFillCompleted"),
                        object: nil,
                        userInfo: [
                            "takeID": unifiedTake.id,
                            "sessionID": unifiedTake.sessionID,
                            "projectID": unifiedTake.projectID,
                            "smartFillPath": outputPath,
                            "compositor": result.compositorUsed.displayName,
                            "processingTime": result.processingTime
                        ]
                    )
                }
                
            } catch {
                print("❌ SessionManager: SmartFill processing failed: \(error)")
                
                await MainActor.run {
                    // Post failure notification
                    NotificationCenter.default.post(
                        name: Notification.Name("STSSmartFillFailed"),
                        object: nil,
                        userInfo: [
                            "takeID": unifiedTake.id,
                            "sessionID": unifiedTake.sessionID,
                            "projectID": unifiedTake.projectID,
                            "error": error.localizedDescription
                        ]
                    )
                }
            }
        }

        print("✅ SessionManager: SmartFill processing initiated via unified interface for \(fileName)")
    }
    
    // NEW: Add unified photo take method with orientation - ENHANCED for Smart Fill
    func addUnifiedPhotoTakeWithOrientation(
        fileName: String,
        projectID: UUID,
        sessionID: UUID,
        filePath: String? = nil,
        fileSize: Int64 = 0,
        cameraPosition: String = "back",
        capturedOrientation: VideoOrientation? = nil,  // NEW: Smart Fill orientation
        notes: String? = nil
    ) {
        // CRITICAL FIX: Photos have their own organization logic
        let photoSceneNum: Int
        let photoTakeNum: Int
        
        if isRecordingKeyframePhoto {
            // Keyframe photos are session-wide
            photoSceneNum = -1  // Special scene number for keyframe photos
            photoTakeNum = getKeyframePhotoTakesAsTakes().count + 1
        } else {
            // Regular scene photos (if we implement this feature)
            photoSceneNum = currentScene
            photoTakeNum = getKeyframePhotoTakesAsTakes().count + 1
        }
        
        let unifiedTake = UnifiedTake(
            fileName: fileName,
            projectID: projectID,
            sessionID: sessionID,
            filePath: filePath ?? fileName,
            duration: 0, // Photos have 0 duration
            fileSize: fileSize,
            cameraPosition: cameraPosition,
            sceneNumber: photoSceneNum,     // FIXED: Use calculated photo scene number
            takeNumber: photoTakeNum,       // FIXED: Use calculated photo take number
            isSlate: false,                 // Photos are not slate takes
            isPhoto: true,                  // This is a photo
            isKeyframePhoto: isRecordingKeyframePhoto,
            capturedOrientation: capturedOrientation,  // NEW: Store captured orientation
            rating: .unrated,
            notes: notes
        )
        
        if useUnifiedModels {
            unifiedTakes.append(unifiedTake)
        } else {
            // Convert to legacy for compatibility
            activeTakes.append(unifiedTake.toEnhancedTake())
        }
        
        let orientationStr = capturedOrientation?.displayName ?? "Unknown"
        print("📸 SessionManager: Added unified photo take with orientation \(fileName) - Scene: \(photoSceneNum), Take: \(photoTakeNum), Keyframe: \(isRecordingKeyframePhoto), Orientation: \(orientationStr)")
        
        // Persist to repository
        persistUnifiedTakeToRepository(unifiedTake)
        
        // Update keyframe photo recorded status
        if isRecordingKeyframePhoto {
            hasRecordedKeyframePhoto = true
        }
    }
    
    // CRITICAL FIX: Add method to calculate proper take organization
    private func calculateTakeOrganization() -> (sceneNumber: Int, takeNumber: Int, slateNumber: String?, slateID: String?) {
        if isRecordingSlate {
            // PHASE 1B FIX: Session-wide slate numbering instead of scene-based
            // BEFORE: Sequential slate numbering within scene (WRONG - creates S1SL1, S2SL1)
            // AFTER: Session-wide slate numbering (CORRECT - creates SLATE1, SLATE2, SLATE3)
            let sessionSlateCount = getSlateTakesAsTakes().count + 1  // All slates in session
            
            // PHASE 1B FIX: Create proper session-wide slate identifiers
            let slateNumberStr = "\(sessionSlateCount)"      // "1", "2", "3"
            let slateID = "SLATE\(sessionSlateCount)"        // "SLATE1", "SLATE2", "SLATE3"
            
            return (
                sceneNumber: -2,                    // PHASE 1B FIX: Special scene number for slates (-2 for session-wide slates)
                takeNumber: sessionSlateCount,      // Sequential slate numbering across entire session
                slateNumber: slateNumberStr,
                slateID: slateID
            )
        } else {
            // CRITICAL FIX: Sequential take numbering within scene - FIXED LOGIC
            let currentSceneTakes = getTakesForScene(currentScene)
            let takeNumber = currentSceneTakes.count + 1
            
            return (
                sceneNumber: currentScene,
                takeNumber: takeNumber,      // Sequential scene take numbering - FIXED
                slateNumber: nil,
                slateID: nil
            )
        }
    }
    
    // ENHANCED: Computed property for effective take count
    private var effectiveTakeCount: Int {
        return useUnifiedModels ? unifiedTakes.count : activeTakes.count
    }
    
    // FIXED: Add method to remove take if it exists (for metadata updates)
    func removeTakeIfExists(fileName: String) {
        if useUnifiedModels {
            if let index = unifiedTakes.firstIndex(where: { $0.fileName == fileName }) {
                unifiedTakes.remove(at: index)
                print("🗑️ SessionManager: Removed existing unified take \(fileName) for metadata update")
            }
        } else {
            if let index = activeTakes.firstIndex(where: { $0.fileName == fileName }) {
                activeTakes.remove(at: index)
                print("🗑️ SessionManager: Removed existing take \(fileName) for metadata update")
            }
        }
    }
    
    // ENHANCED: Unified persistence method - CRITICAL FIX for scene organization and UUID consistency
    private func persistUnifiedTakeToRepository(_ unifiedTake: UnifiedTake) {
        guard let repository = repository else {
            print("⚠️ SessionManager: No repository configured, unified take not persisted!")
            return
        }
        
        // CRITICAL FIX: Convert UnifiedTake to ProjectTake with proper scene organization AND CONSISTENT UUID
        let projectTake = ProjectTake(
            id: unifiedTake.id,                      // CRITICAL FIX: Use the same UUID from UnifiedTake!
            filePath: unifiedTake.filePath,
            durationSeconds: unifiedTake.duration,
            thumbnailPath: nil,
            takeNotes: unifiedTake.notes,
            createdAt: unifiedTake.createdAt,
            videoMarkers: [], // Video markers will be handled later
            rating: unifiedTake.rating,
            sceneNumber: unifiedTake.sceneNumber,    // CRITICAL FIX: Preserve scene number
            takeNumber: unifiedTake.takeNumber,      // CRITICAL FIX: Preserve take number
            slateNumber: unifiedTake.slateNumber,    // CRITICAL FIX: Preserve slate number
            slateID: unifiedTake.slateID,           // CRITICAL FIX: Preserve slate ID
            capturedOrientation: unifiedTake.capturedOrientation,  // CRITICAL FIX: Preserve orientation
            takeType: unifiedTake.isSlate ? .slate : .regular  // CRITICAL FIX: Set take type (must come after capturedOrientation)
        )
        
        repository.addTake(projectTake, to: unifiedTake.sessionID, in: unifiedTake.projectID)
        
        print("✅ SessionManager: Persisted unified take to repository - \(unifiedTake.fileName) (S\(unifiedTake.sceneNumber)T\(unifiedTake.takeNumber)) with MATCHING UUID: \(unifiedTake.id)")
    }
    
    // EXISTING: Keep original persistence method - CLEANED and FIXED for UUID consistency
    private func persistTakeToRepository(_ enhancedTake: EnhancedTake) {
        guard let repository = repository else {
            print("⚠️ SessionManager: No repository configured, take not persisted!")
            return
        }
        
        // CRITICAL FIX: Convert EnhancedTake to ProjectTake using SAME UUID and rating directly
        let projectTake = ProjectTake(
            id: enhancedTake.id,                     // CRITICAL FIX: Use the same UUID!
            filePath: enhancedTake.filePath,
            durationSeconds: enhancedTake.duration,
            thumbnailPath: nil,
            takeNotes: enhancedTake.notes,
            rating: enhancedTake.rating             // CLEANED: Direct rating assignment!
        )
        
        repository.addTake(projectTake, to: enhancedTake.sessionID, in: enhancedTake.projectID)
        
        print("✅ SessionManager: Persisted take to repository - \(enhancedTake.fileName) with MATCHING UUID: \(enhancedTake.id)")
    }
    
    // ENHANCED: Batch persist with unified support
    private func persistAllTakesToRepository() {
        guard let repository = repository else {
            print("⚠️ SessionManager: No repository configured, takes not persisted!")
            return
        }
        
        if useUnifiedModels {
            print("📹 SessionManager: Persisting \(unifiedTakes.count) unified takes to repository...")
            for unifiedTake in unifiedTakes {
                persistUnifiedTakeToRepository(unifiedTake)
            }
        } else {
            print("📹 SessionManager: Persisting \(activeTakes.count) takes to repository...")
            for enhancedTake in activeTakes {
                persistTakeToRepository(enhancedTake)
            }
        }
        
        print("✅ SessionManager: All takes persisted to repository")
    }
    
    // MARK: - Scene and Slate Management - REDESIGNED
    
    // REDESIGNED: Switch to slate recording mode
    func switchToSlateMode() {
        isRecordingSlate = true
        isRecordingKeyframePhoto = false // Ensure only one mode active
        print("📹 SessionManager: Switched to slate recording mode")
    }
    
    // REDESIGNED: Switch to scene recording mode
    func switchToSceneMode() {
        isRecordingSlate = false
        isRecordingKeyframePhoto = false // Ensure only one mode active
        print("📹 SessionManager: Switched to scene recording mode")
    }
    
    // NEW: Switch to keyframe photo mode
    func switchToKeyframePhotoMode() {
        isRecordingSlate = false
        isRecordingKeyframePhoto = true
        print("📸 SessionManager: Switched to keyframe photo mode")
    }
    
    // REDESIGNED: Get current recording mode description - ENHANCED: Photo support
    var currentRecordingMode: String {
        if isRecordingKeyframePhoto {
            return "Keyframe Photo"
        } else if isRecordingSlate {
            return "Slate"
        } else {
            return "Scene \(currentScene)"
        }
    }
    
    // EXISTING: Keep for backwards compatibility - CRITICAL FIX
    func enableSlateForNextTake() {
        switchToSlateMode()
        print("⚠️ SessionManager: enableSlateForNextTake() is deprecated, use switchToSlateMode()")
    }
    
    func skipSlateForSession() {
        slateSkippedForSession = true
        isRecordingSlate = false
        print("📹 SessionManager: Slate skipped for this session")
    }
    
    func nextScene() {
        isRecordingSlate = false // Ensure we're in scene mode
        isRecordingKeyframePhoto = false // FIXED: Also ensure we're not in keyframe photo mode
        currentScene += 1
        if currentScene > totalScenes {
            totalScenes = currentScene
        }
        print("📹 SessionManager: Advanced to scene \(currentScene)")
    }
    
    func previousScene() {
        isRecordingSlate = false // Ensure we're in scene mode
        isRecordingKeyframePhoto = false // FIXED: Also ensure we're not in keyframe photo mode
        if currentScene > 1 {
            currentScene -= 1
        }
        print("📹 SessionManager: Returned to scene \(currentScene)")
    }
    
    func switchToScene(_ sceneNumber: Int) {
        isRecordingSlate = false // Ensure we're in scene mode
        isRecordingKeyframePhoto = false // FIXED: Also ensure we're not in keyframe photo mode
        currentScene = sceneNumber
        if sceneNumber > totalScenes {
            totalScenes = sceneNumber
        }
        print("📹 SessionManager: Switched to scene \(sceneNumber)")
    }
    
    // PHASE 1B FIX: Add method to restore scene state when resuming sessions
    public func restoreSceneState(sceneNumber: Int) {
        isRecordingSlate = false // Ensure we're in scene mode
        isRecordingKeyframePhoto = false // Ensure we're not in photo mode
        currentScene = sceneNumber
        if sceneNumber > totalScenes {
            totalScenes = sceneNumber
        }
        print("🎬 SessionManager: Restored scene state to scene \(sceneNumber)")
    }
    
    // MARK: - Backwards Compatibility - CRITICAL SECTION
    
    // DEPRECATED: For backwards compatibility with existing code that checks isSlateNext
    var isSlateNext: Bool {
        return isRecordingSlate
    }
    
    // REDESIGNED: Get takes with slate separation
    func getTakesForCurrentScene() -> [Take] {
        if isRecordingSlate {
            return getSlateTakesAsTakes()
        } else {
            return getTakesForScene(currentScene)
        }
    }
    
    func getTakesForScene(_ sceneNumber: Int) -> [Take] {
        if useUnifiedModels {
            // Convert UnifiedTakes to Takes for UI compatibility - filter out slate takes
            return unifiedTakes.filter { $0.sceneNumber == sceneNumber && !$0.isSlate }.map { unifiedTake in
                Take(
                    segmentId: unifiedTake.sessionID,
                    fileName: unifiedTake.fileName,
                    filePath: unifiedTake.filePath,
                    duration: unifiedTake.duration,
                    takeNumber: unifiedTake.takeNumber,
                    sceneNumber: unifiedTake.sceneNumber,
                    rating: unifiedTake.rating,
                    createdAt: unifiedTake.createdAt
                )
            }
        } else {
            // Convert EnhancedTakes to Takes for compatibility - filter out slate takes
            return activeTakes.filter { $0.sceneNumber == sceneNumber && !$0.isSlate }
                .map { enhancedTake in
                    Take(
                        segmentId: enhancedTake.sessionID,
                        fileName: enhancedTake.fileName,
                        filePath: enhancedTake.filePath,
                        duration: enhancedTake.duration,
                        takeNumber: enhancedTake.takeNumber,
                        sceneNumber: enhancedTake.sceneNumber,
                        rating: enhancedTake.rating,
                        createdAt: enhancedTake.createdAt
                    )
                }
        }
    }
    
    // REDESIGNED: Get slate takes as regular Take objects for UI consistency
    func getSlateTakesAsTakes() -> [Take] {
        if useUnifiedModels {
            return unifiedTakes.filter { $0.isSlate }.map { unifiedTake in
                Take(
                    segmentId: unifiedTake.sessionID,
                    fileName: unifiedTake.fileName,
                    filePath: unifiedTake.filePath,
                    duration: unifiedTake.duration,
                    takeNumber: unifiedTake.takeNumber,
                    sceneNumber: 0, // Slate takes use scene 0
                    rating: unifiedTake.rating,
                    createdAt: unifiedTake.createdAt
                )
            }
        } else {
            return activeTakes.filter { $0.isSlate }.map { enhancedTake in
                Take(
                    segmentId: enhancedTake.sessionID,
                    fileName: enhancedTake.fileName,
                    filePath: enhancedTake.filePath,
                    duration: enhancedTake.duration,
                    takeNumber: enhancedTake.takeNumber,
                    sceneNumber: 0, // Slate takes use scene 0
                    rating: enhancedTake.rating,
                    createdAt: enhancedTake.createdAt
                )
            }
        }
    }
    
    // NEW: Get keyframe photo takes as regular Take objects for UI consistency
    func getKeyframePhotoTakesAsTakes() -> [Take] {
        if useUnifiedModels {
            return unifiedTakes.filter { $0.isKeyframePhoto }.map { unifiedTake in
                Take(
                    segmentId: unifiedTake.sessionID,
                    fileName: unifiedTake.fileName,
                    filePath: unifiedTake.filePath,
                    duration: unifiedTake.duration, // Will be 0 for photos
                    takeNumber: unifiedTake.takeNumber,
                    sceneNumber: -1, // Keyframe photos use scene -1
                    rating: unifiedTake.rating,
                    createdAt: unifiedTake.createdAt
                )
            }
        } else {
            // Legacy support: filter by filename pattern since we don't have isKeyframePhoto in EnhancedTake
            return activeTakes.filter { $0.fileName.contains("_Photo_") }.map { enhancedTake in
                Take(
                    segmentId: enhancedTake.sessionID,
                    fileName: enhancedTake.fileName,
                    filePath: enhancedTake.filePath,
                    duration: enhancedTake.duration,
                    takeNumber: enhancedTake.takeNumber,
                    sceneNumber: -1, // Keyframe photos use scene -1
                    rating: enhancedTake.rating,
                    createdAt: enhancedTake.createdAt
                )
            }
        }
    }
    
    // ENHANCED: Unified take retrieval methods
    func getUnifiedTakesForScene(_ sceneNumber: Int) -> [UnifiedTake] {
        if useUnifiedModels {
            return unifiedTakes.filter { $0.sceneNumber == sceneNumber && !$0.isSlate }
        } else {
            return activeTakes.filter { $0.sceneNumber == sceneNumber && !$0.isSlate }
                .map { UnifiedTake(from: $0) }
        }
    }
    
    // MARK: - Enhanced Take Retrieval
    
    // Get latest unified take for thumbnail preview
    public func getLatestUnifiedTake() -> UnifiedTake? {
        guard useUnifiedModels else {
            // Fallback to convert latest legacy take if needed
            guard let latestTake = activeTakes.last else { return nil }
            return UnifiedTake(from: latestTake)
        }
        
        // Return latest unified take
        return unifiedTakes.last
    }
    
    // MARK: - Export Support with UNIFIED SUPPORT
    var takes: [EnhancedTake] {
        if useUnifiedModels {
            return unifiedTakes.map { $0.toEnhancedTake() }
        } else {
            return activeTakes
        }
    }
    
    // ENHANCED: Export unified takes
    var unifiedTakesForExport: [UnifiedTake] {
        if useUnifiedModels {
            return unifiedTakes
        } else {
            return activeTakes.map { UnifiedTake(from: $0) }
        }
    }
    
    // MARK: - Take Rating Management with UNIFIED SUPPORT
    
    func toggleStar(_ take: Take) {
        if useUnifiedModels {
            if let index = unifiedTakes.firstIndex(where: { $0.fileName == take.fileName }) {
                unifiedTakes[index].rating = (unifiedTakes[index].rating == .favorite) ? .unrated : .favorite
                syncUnifiedRatingToRepository(unifiedTakes[index])
            }
        } else {
            if let index = activeTakes.firstIndex(where: { $0.fileName == take.fileName }) {
                activeTakes[index].rating = (activeTakes[index].rating == .favorite) ? .unrated : .favorite
                syncRatingToRepository(activeTakes[index])
            }
        }
        
        print("📹 SessionManager: Toggled star for take \(take.fileName)")
    }
    
    func toggleGood(_ take: Take) {
        if useUnifiedModels {
            if let index = unifiedTakes.firstIndex(where: { $0.fileName == take.fileName }) {
                unifiedTakes[index].rating = (unifiedTakes[index].rating == .good) ? .unrated : .good
                syncUnifiedRatingToRepository(unifiedTakes[index])
            }
        } else {
            if let index = activeTakes.firstIndex(where: { $0.fileName == take.fileName }) {
                activeTakes[index].rating = (activeTakes[index].rating == .good) ? .unrated : .good
                syncRatingToRepository(activeTakes[index])
            }
        }
        
        print("📹 SessionManager: Toggled good for take \(take.fileName)")
    }
    
    func markBad(_ take: Take) {
        if useUnifiedModels {
            if let index = unifiedTakes.firstIndex(where: { $0.fileName == take.fileName }) {
                unifiedTakes[index].rating = .bad
                syncUnifiedRatingToRepository(unifiedTakes[index])
            }
        } else {
            if let index = activeTakes.firstIndex(where: { $0.fileName == take.fileName }) {
                activeTakes[index].rating = .bad
                syncRatingToRepository(activeTakes[index])
            }
        }
        
        print("📹 SessionManager: Marked bad for take \(take.fileName)")
    }
    
    func resetRating(_ take: Take) {
        if useUnifiedModels {
            if let index = unifiedTakes.firstIndex(where: { $0.fileName == take.fileName }) {
                unifiedTakes[index].rating = .unrated
                syncUnifiedRatingToRepository(unifiedTakes[index])
            }
        } else {
            if let index = activeTakes.firstIndex(where: { $0.fileName == take.fileName }) {
                activeTakes[index].rating = .unrated
                syncRatingToRepository(activeTakes[index])
            }
        }
        
        print("📹 SessionManager: Reset rating for take \(take.fileName)")
    }
    
    func getSlateTakes() -> [EnhancedTake] {
        if useUnifiedModels {
            return unifiedTakes.filter { $0.isSlate }.map { $0.toEnhancedTake() }
        } else {
            return activeTakes.filter { $0.isSlate }
        }
    }
    
    func getUnifiedSlateTakes() -> [UnifiedTake] {
        if useUnifiedModels {
            return unifiedTakes.filter { $0.isSlate }
        } else {
            return activeTakes.filter { $0.isSlate }.map { UnifiedTake(from: $0) }
        }
    }
    
    func getStarredTakes() -> [EnhancedTake] {
        if useUnifiedModels {
            return unifiedTakes.filter { $0.rating == .favorite }.map { $0.toEnhancedTake() }
        } else {
            return activeTakes.filter { $0.rating == .favorite }
        }
    }
    
    func getUnifiedStarredTakes() -> [UnifiedTake] {
        if useUnifiedModels {
            return unifiedTakes.filter { $0.rating == .favorite }
        } else {
            return activeTakes.filter { $0.rating == .favorite }.map { UnifiedTake(from: $0) }
        }
    }
    
    func getGoodTakes() -> [EnhancedTake] {
        if useUnifiedModels {
            return unifiedTakes.filter { $0.rating == .good }.map { $0.toEnhancedTake() }
        } else {
            return activeTakes.filter { $0.rating == .good }
        }
    }
    
    func getBadTakes() -> [EnhancedTake] {
        if useUnifiedModels {
            return unifiedTakes.filter { $0.rating == .bad }.map { $0.toEnhancedTake() }
        } else {
            return activeTakes.filter { $0.rating == .bad }
        }
    }
    
    func exportSelectedTakes() -> [EnhancedTake] {
        if useUnifiedModels {
            let selectedTakes = unifiedTakes.filter { $0.rating == .favorite || $0.isBest }
            print("📹 SessionManager: Exporting \(selectedTakes.count) selected unified takes")
            return selectedTakes.map { $0.toEnhancedTake() }
        } else {
            let selectedTakes = activeTakes.filter { $0.rating == .favorite || $0.isBest }
            print("📹 SessionManager: Exporting \(selectedTakes.count) selected takes")
            return selectedTakes
        }
    }
    
    func exportSelectedUnifiedTakes() -> [UnifiedTake] {
        if useUnifiedModels {
            let selectedTakes = unifiedTakes.filter { $0.rating == .favorite || $0.isBest }
            print("📹 SessionManager: Exporting \(selectedTakes.count) selected unified takes")
            return selectedTakes
        } else {
            let selectedTakes = activeTakes.filter { $0.rating == .favorite || $0.isBest }
            print("📹 SessionManager: Exporting \(selectedTakes.count) selected takes as unified")
            return selectedTakes.map { UnifiedTake(from: $0) }
        }
    }
    
    func exportAllTakes() -> [EnhancedTake] {
        if useUnifiedModels {
            print("📹 SessionManager: Exporting all \(unifiedTakes.count) unified takes")
            return unifiedTakes.map { $0.toEnhancedTake() }
        } else {
            print("📹 SessionManager: Exporting all \(activeTakes.count) takes")
            return activeTakes
        }
    }
    
    func exportAllUnifiedTakes() -> [UnifiedTake] {
        if useUnifiedModels {
            print("📹 SessionManager: Exporting all \(unifiedTakes.count) unified takes")
            return unifiedTakes
        } else {
            print("📹 SessionManager: Exporting all \(activeTakes.count) takes as unified")
            return activeTakes.map { UnifiedTake(from: $0) }
        }
    }
    
    // ENHANCED: Unified rating sync method - CLEANED
    private func syncUnifiedRatingToRepository(_ unifiedTake: UnifiedTake) {
        guard let repository = repository else { return }
        
        // CLEANED: Direct rating update through unified API
        repository.setUnifiedTakeRating(
            takeID: unifiedTake.id,
            sessionID: unifiedTake.sessionID,
            projectID: unifiedTake.projectID,
            rating: unifiedTake.rating
        )
        
        print("✅ SessionManager: Synced unified rating change to repository")
    }
    
    // EXISTING: Keep original rating sync method - CLEANED
    private func syncRatingToRepository(_ enhancedTake: EnhancedTake) {
        guard let repository = repository else { return }
        
        // CLEANED: Direct rating update through unified API
        repository.setUnifiedTakeRating(
            takeID: enhancedTake.id,
            sessionID: enhancedTake.sessionID,
            projectID: enhancedTake.projectID,
            rating: enhancedTake.rating
        )
        
        print("✅ SessionManager: Synced rating change to repository")
    }
    
    // Add delete method that takes Take parameter for UI compatibility
    func delete(_ take: Take) {
        if useUnifiedModels {
            if let index = unifiedTakes.firstIndex(where: { $0.fileName == take.fileName }) {
                let unifiedTake = unifiedTakes[index]
                
                // Delete video file if it exists
                do {
                    try VideoFileManager.shared.deleteVideo(at: unifiedTake.filePath)
                } catch {
                    print("⚠️ Could not delete video file: \(error)")
                }
                
                // Remove from unified takes
                unifiedTakes.remove(at: index)
            }
        } else {
            if let index = activeTakes.firstIndex(where: { $0.fileName == take.fileName }) {
                let enhancedTake = activeTakes[index]
                
                // Delete video file if it exists
                do {
                    try VideoFileManager.shared.deleteVideo(at: enhancedTake.filePath)
                } catch {
                    print("⚠️ Could not delete video file: \(error)")
                }
                
                // Remove from active takes
                activeTakes.remove(at: index)
            }
        }
        
        print("📹 SessionManager: Deleted take \(take.fileName)")
    }
    
    // MARK: - Session Validation (PRESERVED)
    func canCompleteSession() -> Bool {
        if slateSkippedForSession || hasRecordedSlate {
            return true
        }
        // Require slate unless explicitly skipped
        return false
    }
    
    // MARK: - Repository Integration Methods
    
    // CORE INTEGRATION FIX: Ensure project and session exist in repository
    public func ensureProjectAndSessionInRepository(project: Project, session: ProjectSession) {
        guard let repository = repository else {
            print("⚠️ SessionManager: No repository configured, cannot ensure project/session exists!")
            return
        }
        
        // Check if project exists, if not add it
        if repository.project(by: project.id) == nil {
            print("📁 SessionManager: Adding project \(project.title) to repository")
            repository.insert(project: project)
        } else {
            print("📁 SessionManager: Project \(project.title) already exists in repository")
        }
        
        // Check if session exists in the project
        if let existingProject = repository.project(by: project.id) {
            let sessionExists = existingProject.sessions.contains { $0.id == session.id }
            if !sessionExists {
                print("📁 SessionManager: Adding session \(session.type.rawValue) to project \(project.title)")
                repository.append(session: session, to: project.id)
            } else {
                print("📁 SessionManager: Session \(session.type.rawValue) already exists in project")
            }
        }
        
        print("✅ SessionManager: Project and session ensured in repository")
    }
    
    // UNIFIED RATING API: The ONLY method that should be used for take ratings - ENHANCED for Step 3C + PHASE 1C-C
    public func setUnifiedTakeRating(
        takeID: UUID,
        sessionID: UUID,
        projectID: UUID,
        rating: TakeRating
    ) {
        print("🔄 SessionManager: Setting unified rating \(rating.rawValue) for take \(takeID)")
        
        // STEP 3C: Enhanced error handling and validation
        guard let repository = repository else {
            print("❌ SessionManager: No repository configured, rating update failed!")
            return
        }
        
        // STEP 3C: Validate IDs before proceeding
        guard takeID != UUID(), sessionID != UUID(), projectID != UUID() else {
            print("❌ SessionManager: Invalid IDs provided for rating update")
            return
        }
        
        // PHASE 1C-C: CRITICAL FIX - Photo Mutual Exclusion Validation
        if rating == .good {
            applyPhotoMutualExclusionIfNeeded(
                targetTakeID: takeID,
                sessionID: sessionID,
                projectID: projectID
            )
        }
        
        // CRITICAL FIX: Update repository first (single source of truth)
        repository.setUnifiedTakeRating(
            takeID: takeID,
            sessionID: sessionID,
            projectID: projectID,
            rating: rating
        )
        
        // STEP 3C: Enhanced internal state sync with better error handling
        syncRatingToInternalStateWithValidation(takeID: takeID, rating: rating)
        
        // CRITICAL FIX: Immediately sync ALL data from repository to ensure consistency
        syncFromRepositoryWithErrorHandling()
        
        // STEP 3C: Send enhanced notification with comprehensive data
        sendRatingUpdateNotification(
            takeID: takeID,
            sessionID: sessionID,
            projectID: projectID,
            rating: rating
        )
        
        print("✅ SessionManager: Bidirectional rating sync completed for take \(takeID)")
    }
    
    // PHASE 1C-C: NEW - Photo Mutual Exclusion Logic
    private func applyPhotoMutualExclusionIfNeeded(
        targetTakeID: UUID,
        sessionID: UUID,
        projectID: UUID
    ) {
        // Find the target take being marked as good
        var targetTakeIsKeyframePhoto = false
        
        // Check in unified takes
        if let targetTake = unifiedTakes.first(where: { $0.id == targetTakeID }) {
            targetTakeIsKeyframePhoto = targetTake.isKeyframePhoto
        } else if let targetTake = activeTakes.first(where: { $0.id == targetTakeID }) {
            // Check legacy takes using filename pattern for keyframe photos
            targetTakeIsKeyframePhoto = targetTake.fileName.contains("_Photo_") ||
                                       targetTake.fileName.contains("PHOTO_KF")
        }
        
        // Only apply mutual exclusion for keyframe photos
        guard targetTakeIsKeyframePhoto else {
            print("📋 Photo mutual exclusion: Target take is not a keyframe photo - no exclusion needed")
            return
        }
        
        print("📸 PHASE 1C-C: Applying keyframe photo mutual exclusion for take \(targetTakeID)")
        
        // Auto-downgrade other keyframe photos that are marked as good
        var downgradeCount = 0
        
        // Handle unified takes
        for (index, take) in unifiedTakes.enumerated() {
            if take.id != targetTakeID &&
               take.isKeyframePhoto &&
               take.rating == .good {
                
                // Downgrade this keyframe photo to unrated
                unifiedTakes[index].rating = .unrated
                unifiedTakes[index].isBest = false
                
                // Update repository
                repository?.setUnifiedTakeRating(
                    takeID: take.id,
                    sessionID: sessionID,
                    projectID: projectID,
                    rating: .unrated
                )
                
                downgradeCount += 1
                print("📸 Downgraded keyframe photo: \(take.fileName) from good to unrated")
            }
        }
        
        // Handle legacy takes
        for (index, take) in activeTakes.enumerated() {
            let isKeyframePhoto = take.fileName.contains("_Photo_") ||
                                 take.fileName.contains("PHOTO_KF")
            
            if take.id != targetTakeID &&
               isKeyframePhoto &&
               take.rating == .good {
                
                // Downgrade this keyframe photo to unrated
                activeTakes[index].rating = .unrated
                activeTakes[index].isBest = false
                
                // Update repository
                repository?.setUnifiedTakeRating(
                    takeID: take.id,
                    sessionID: sessionID,
                    projectID: projectID,
                    rating: .unrated
                )
                
                downgradeCount += 1
                print("📸 Downgraded legacy keyframe photo: \(take.fileName) from good to unrated")
            }
        }
        
        if downgradeCount > 0 {
            print("✅ PHASE 1C-C: Photo mutual exclusion completed - downgraded \(downgradeCount) other keyframe photo(s)")
            
            // Notify UI of the batch changes
            DispatchQueue.main.async { [weak self] in
                self?.objectWillChange.send()
            }
        } else {
            print("📋 Photo mutual exclusion: No other good keyframe photos found - no downgrades needed")
        }
    }
    
    // STEP 3C: Enhanced internal state sync with validation
    private func syncRatingToInternalStateWithValidation(takeID: UUID, rating: TakeRating) {
        var stateUpdated = false
        
        // Update unified takes array with validation
        if let index = unifiedTakes.firstIndex(where: { $0.id == takeID }) {
            // STEP 3C: Atomic update to prevent race conditions
            unifiedTakes[index].rating = rating
            
            // Also update isBest flag for UI consistency
            switch rating {
            case .good:
                unifiedTakes[index].isBest = true
            case .bad, .unrated, .favorite:
                unifiedTakes[index].isBest = false
            }
            
            stateUpdated = true
            print("✅ Updated unified take internal state: \(rating.rawValue)")
        }
        
        // Update legacy takes array for compatibility with validation
        if let index = activeTakes.firstIndex(where: { $0.id == takeID }) {
            // STEP 3C: Atomic update to prevent race conditions
            activeTakes[index].rating = rating
            
            switch rating {
            case .good:
                activeTakes[index].isBest = true
            case .bad, .unrated, .favorite:
                activeTakes[index].isBest = false
            }
            
            stateUpdated = true
            print("✅ Updated legacy take internal state: \(rating.rawValue)")
        }
        
        // STEP 3C: Ensure UI updates only if state actually changed
        if stateUpdated {
            // CRITICAL FIX: Force UI update immediately with 60fps optimization
            DispatchQueue.main.async { [weak self] in
                self?.objectWillChange.send()
            }
        } else {
            print("⚠️ SessionManager: Take \(takeID) not found in internal state")
        }
    }
    
    // STEP 3C: Enhanced repository sync with error handling
    public func syncFromRepositoryWithErrorHandling() {
        guard let repository = repository else {
            print("⚠️ SessionManager: No repository for sync")
            return
        }
        
        // Reload current session data from repository with error handling
        guard let currentSession = currentSession else {
            print("⚠️ SessionManager: No current session for sync")
            return
        }
        
        do {
            guard let updatedProject = repository.project(by: currentSession.project.id) else {
                print("⚠️ SessionManager: Project not found during sync: \(currentSession.project.id)")
                return
            }
            
            guard let updatedSession = updatedProject.sessions.first(where: { $0.id == currentSession.session.id }) else {
                print("⚠️ SessionManager: Session not found during sync: \(currentSession.session.id)")
                return
            }
            
            // STEP 3C: Convert updated repository takes to unified format with error handling
            let updatedUnifiedTakes = updatedSession.takes.enumerated().compactMap { (index, projectTake) in
                do {
                    let fileName = URL(fileURLWithPath: projectTake.filePath).lastPathComponent
                    return try UnifiedTake.safeConversion(
                        from: projectTake,
                        projectID: currentSession.project.id,
                        sessionID: currentSession.session.id,
                        fileName: fileName,
                        takeNumber: index + 1
                    )
                } catch {
                    print("⚠️ SessionManager: Failed to convert take during sync: \(error)")
                    return nil
                }
            }
            
            // STEP 3C: Update internal state with batch optimization for 60fps
            DispatchQueue.main.async { [weak self] in
                guard let self = self else { return }
                
                self.unifiedTakes = updatedUnifiedTakes
                self.activeTakes = updatedUnifiedTakes.map { $0.toEnhancedTake() }
                
                // Single UI update for better performance
                self.objectWillChange.send()
            }
            
            print("🔄 SessionManager: Enhanced sync completed - \(updatedUnifiedTakes.count) takes")
            
        } catch {
            print("❌ SessionManager: Repository sync failed: \(error)")
        }
    }
    
    // STEP 3C: Enhanced notification system with comprehensive data
    private func sendRatingUpdateNotification(
        takeID: UUID,
        sessionID: UUID,
        projectID: UUID,
        rating: TakeRating
    ) {
        // STEP 3C: Create comprehensive notification payload
        let notificationData: [String: Any] = [
            "takeID": takeID,
            "sessionID": sessionID,
            "projectID": projectID,
            "rating": rating.rawValue,
            "timestamp": Date().timeIntervalSince1970,
            "source": "SessionManager"
        ]
        
        // STEP 3C: Send on main queue for immediate UI updates
        DispatchQueue.main.async {
            NotificationCenter.default.post(
                name: Notification.Name("STSTakeRatingUpdated"),
                object: nil,
                userInfo: notificationData
            )
        }
        
        print("📢 SessionManager: Enhanced rating notification sent for take \(takeID)")
    }
    
    // STEP 3C: Wrapper for backward compatibility with enhanced error handling
    public func syncFromRepository() {
        syncFromRepositoryWithErrorHandling()
    }
    
    // MARK: - Take ID Resolution (for UnifiedTakePlayerView integration)
    
    func getTakeID(for fileName: String) -> UUID? {
        if useUnifiedModels {
            return unifiedTakes.first(where: { $0.fileName == fileName })?.id
        } else {
            return activeTakes.first(where: { $0.fileName == fileName })?.id
        }
    }
    
    func getUnifiedTake(by id: UUID) -> UnifiedTake? {
        if useUnifiedModels {
            return unifiedTakes.first(where: { $0.id == id })
        } else {
            return activeTakes.first(where: { $0.id == id }).map { UnifiedTake(from: $0) }
        }
    }
    
    func getUnifiedTake(by fileName: String) -> UnifiedTake? {
        if useUnifiedModels {
            return unifiedTakes.first(where: { $0.fileName == fileName })
        } else {
            return activeTakes.first(where: { $0.fileName == fileName }).map { UnifiedTake(from: $0) }
        }
    }
    
    // MARK: - Storage Information with UNIFIED SUPPORT
    func getTotalStorageUsed() -> Int64 {
        if useUnifiedModels {
            return unifiedTakes.reduce(0) { $0 + $1.fileSize }
        } else {
            return activeTakes.reduce(0) { $0 + $1.fileSize }
        }
    }
    
    func getFormattedStorageUsed() -> String {
        let totalBytes = getTotalStorageUsed()
        return ByteCountFormatter.string(fromByteCount: totalBytes, countStyle: .file)
    }
    
    // MARK: - Migration Helpers
    
    /// Get current take count regardless of model type
    var currentTakeCount: Int {
        return useUnifiedModels ? unifiedTakes.count : activeTakes.count
    }
    
    /// Check if unified models are available
    var hasUnifiedTakes: Bool {
        return !unifiedTakes.isEmpty
    }
    
    // MARK: - SmartFill Support Methods - NEW for Phase 2-3 Integration
    
    /// Update take with SmartFill processed file path
    public func updateTakeWithSmartFill(takeID: UUID, smartFillPath: String, sessionID: UUID, projectID: UUID) {
        // Update unified takes first
        if let index = unifiedTakes.firstIndex(where: { $0.id == takeID }) {
            unifiedTakes[index].smartFilledFilePath = smartFillPath
            print("✅ SessionManager: Updated unified take with SmartFill path: \(URL(fileURLWithPath: smartFillPath).lastPathComponent)")
        }
        
        // Update repository
        if let repository = repositoryInstance {
            repository.updateTakeWithSmartFillPath(
                takeID: takeID,
                smartFilledPath: smartFillPath,
                in: sessionID,
                in: projectID
            )
            
            print("✅ Repository updated with SmartFill path for takeID: \(takeID)")
            print("📁 SmartFill path: \(smartFillPath)")
            print("💾 File exists: \(FileManager.default.fileExists(atPath: smartFillPath))")
            
            // ENHANCED: Post completion notification for UI updates
            NotificationCenter.default.post(
                name: Notification.Name("STSSmartFillCompleted"),
                object: nil,
                userInfo: [
                    "takeID": takeID,
                    "sessionID": sessionID,
                    "projectID": projectID,
                    "smartFillPath": smartFillPath
                ]
            )
            
            print("📢 Posted STSSmartFillCompleted notification")
        }
        
        print("✅ SessionManager: Updated take with SmartFill path: \(URL(fileURLWithPath: smartFillPath).lastPathComponent)")
    }
    
    /// Get SmartFill status for current session
    public func getSmartFillStatus() -> SmartFillSessionStatus? {
        guard let currentSession = currentSession,
              let repository = repository else { return nil }
        
        return repository.getSmartFillStatus(
            for: currentSession.session.id,
            in: currentSession.project.id
        )
    }
    
    /// Get all unified takes - convenience method for external access
    public func getAllUnifiedTakes() -> [UnifiedTake] {
        if useUnifiedModels {
            return unifiedTakes
        } else {
            return activeTakes.map { UnifiedTake(from: $0) }
        }
    }
    
    /// Find unified take by filename - used by SmartFill processing
    public func findUnifiedTake(byFileName fileName: String) -> UnifiedTake? {
        if useUnifiedModels {
            return unifiedTakes.first(where: { $0.fileName == fileName })
        } else {
            return activeTakes.first(where: { $0.fileName == fileName }).map { UnifiedTake(from: $0) }
        }
    }
}

// MARK: - Enhanced Session State (PRESERVED)
struct SessionState {
    let project: Project
    let session: ProjectSession
    let startTime: Date
    var endTime: Date?
    
    var duration: TimeInterval {
        (endTime ?? Date()).timeIntervalSince(startTime)
    }
}

// MARK: - Enhanced Take Model for SessionManager (PRESERVED for compatibility)
public struct EnhancedTake: Identifiable, Codable, Equatable {
    public let id = UUID()
    public let fileName: String
    public let projectID: UUID
    public let sessionID: UUID
    public let filePath: String
    public let duration: TimeInterval
    public let fileSize: Int64
    public let cameraPosition: String
    public let sceneNumber: Int
    public let takeNumber: Int
    public let isSlate: Bool
    public var rating: TakeRating
    public var isBest: Bool
    public let notes: String?
    public let createdAt: Date
    
    public init(
        fileName: String,
        projectID: UUID,
        sessionID: UUID,
        filePath: String,
        duration: TimeInterval,
        fileSize: Int64,
        cameraPosition: String,
        sceneNumber: Int,
        takeNumber: Int,
        isSlate: Bool = false,
        rating: TakeRating = .unrated,
        isBest: Bool = false,
        notes: String? = nil,
        createdAt: Date = Date()
    ) {
        self.fileName = fileName
        self.projectID = projectID
        self.sessionID = sessionID
        self.filePath = filePath
        self.duration = duration
        self.fileSize = fileSize
        self.cameraPosition = cameraPosition
        self.sceneNumber = sceneNumber
        self.takeNumber = takeNumber
        self.isSlate = isSlate
        self.rating = rating
        self.isBest = isBest || (takeNumber == 1 && !isSlate) // First non-slate take is automatically best
        self.notes = notes
        self.createdAt = createdAt
    }
    
    public var formattedFileSize: String {
        ByteCountFormatter.string(fromByteCount: fileSize, countStyle: .file)
    }
    
    public var formattedDuration: String {
        let minutes = Int(duration) / 60
        let seconds = Int(duration) % 60
        return String(format: "%d:%02d", minutes, seconds)
    }
}
