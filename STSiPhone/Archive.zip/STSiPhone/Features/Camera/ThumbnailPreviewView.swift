import SwiftUI
import AVFoundation

// MARK: - Native Camera-Style Thumbnail Preview
struct ThumbnailPreviewView: View {
    let unifiedTake: UnifiedTake
    
    @State private var thumbnail: UIImage?
    @State private var isLoading = true
    @State private var loadError: String?
    
    var body: some View {
        ZStack {
            // Background
            RoundedRectangle(cornerRadius: 8)
                .fill(Color.black.opacity(0.8))
            
            if isLoading {
                // Loading state
                VStack(spacing: 2) {
                    ProgressView()
                        .scaleEffect(0.6)
                        .tint(.white)
                    
                    Text("Loading")
                        .font(.caption2)
                        .foregroundColor(.white.opacity(0.7))
                }
            } else if let thumbnail = thumbnail {
                // Thumbnail image - Square aspect ratio
                Image(uiImage: thumbnail)
                    .resizable()
                    .aspectRatio(contentMode: .fill)
                    .clipped()
                    .cornerRadius(8)
                
                // Overlay info - SIMPLIFIED for square format
                VStack {
                    HStack {
                        Spacer()
                        
                        // Rating indicator (top right)
                        if unifiedTake.rating != .unrated {
                            Image(systemName: unifiedTake.rating.iconName)
                                .font(.caption2)
                                .foregroundColor(unifiedTake.rating.color)
                                .padding(2)
                                .background(Color.black.opacity(0.6), in: Circle())
                        }
                        
                        // NEW: SmartFill indicator badge if SmartFill version is being used
                        if unifiedTake.hasSmartFilledVersion {
                            Image(systemName: "rectangle.fill.badge.checkmark")
                                .font(.caption2)
                                .foregroundColor(.green)
                                .padding(2)
                                .background(Color.black.opacity(0.6), in: Circle())
                        }
                    }
                    
                    Spacer()
                    
                    HStack {
                        // Take number indicator
                        Text("\(unifiedTake.takeNumber)")
                            .font(.caption2)
                            .fontWeight(.bold)
                            .foregroundColor(.white)
                            .padding(.horizontal, 4)
                            .padding(.vertical, 1)
                            .background(Color.black.opacity(0.6), in: Capsule())
                        
                        Spacer()
                    }
                }
                .padding(3)
                
            } else if loadError != nil {
                // Error state
                VStack(spacing: 2) {
                    Image(systemName: "exclamationmark.triangle")
                        .font(.caption2)
                        .foregroundColor(.yellow)
                    
                    Text("Error")
                        .font(.caption2)
                        .foregroundColor(.white.opacity(0.7))
                }
            } else {
                // No thumbnail available
                VStack(spacing: 2) {
                    Image(systemName: unifiedTake.isPhoto ? "photo.slash" : "video.slash")
                        .font(.caption2)
                        .foregroundColor(.gray)
                    
                    Text("No Preview")
                        .font(.caption2)
                        .foregroundColor(.white.opacity(0.7))
                }
            }
            
            // ENHANCED: Content type indicator - play button for video, camera icon for photo
            if thumbnail != nil {
                if unifiedTake.isPhoto {
                    // Photo indicator
                    Circle()
                        .fill(Color.white.opacity(0.8))
                        .frame(width: 16, height: 16)
                        .overlay(
                            Image(systemName: "camera.fill")
                                .font(.system(size: 6))
                                .foregroundColor(.black)
                        )
                        .shadow(color: .black.opacity(0.3), radius: 1)
                } else {
                    // Video play button
                    Circle()
                        .fill(Color.white.opacity(0.8))
                        .frame(width: 16, height: 16)
                        .overlay(
                            Image(systemName: "play.fill")
                                .font(.system(size: 6))
                                .foregroundColor(.black)
                        )
                        .shadow(color: .black.opacity(0.3), radius: 1)
                }
            }
        }
        .onAppear {
            loadThumbnail()
        }
        .onChange(of: unifiedTake.id) { _, _ in
            loadThumbnail()
        }
    }
    
    private func loadThumbnail() {
        thumbnail = nil
        isLoading = true
        loadError = nil
        
        Task {
            do {
                let generatedThumbnail: UIImage
                
                // ENHANCED: Load different thumbnail based on content type
                if unifiedTake.isPhoto {
                    generatedThumbnail = try await generatePhotoThumbnail()
                } else {
                    generatedThumbnail = try await generateVideoThumbnail()
                }
                
                await MainActor.run {
                    self.thumbnail = generatedThumbnail
                    self.isLoading = false
                }
                
            } catch {
                await MainActor.run {
                    self.loadError = error.localizedDescription
                    self.isLoading = false
                }
                print("❌ ThumbnailPreviewView: Failed to generate thumbnail for \(unifiedTake.fileName) - \(error)")
            }
        }
    }
    
    // NEW: Photo thumbnail generation
    private func generatePhotoThumbnail() async throws -> UIImage {
        // Get photo URL
        let photoURL = try getContentURL()
        
        // Load photo data
        let photoData = try Data(contentsOf: photoURL)
        
        // Create UIImage from data
        guard let fullSizeImage = UIImage(data: photoData) else {
            throw ThumbnailError.thumbnailGenerationFailed("Could not create UIImage from photo data")
        }
        
        // Resize to thumbnail size (square, 100x100 at 2x for retina)
        let thumbnailSize = CGSize(width: 100, height: 100)
        
        let renderer = UIGraphicsImageRenderer(size: thumbnailSize)
        let thumbnailImage = renderer.image { _ in
            fullSizeImage.draw(in: CGRect(origin: .zero, size: thumbnailSize))
        }
        
        return thumbnailImage
    }
    
    private func generateVideoThumbnail() async throws -> UIImage {
        // Get video URL using same strategy as UnifiedTakePlayerView
        let videoURL = try getContentURL()
        
        let asset = AVURLAsset(url: videoURL)
        let imageGenerator = AVAssetImageGenerator(asset: asset)
        
        // Configure for better thumbnail quality - UPDATED for square format
        imageGenerator.appliesPreferredTrackTransform = true
        imageGenerator.maximumSize = CGSize(width: 100, height: 100) // Square at 2x for retina
        
        // Generate thumbnail from 10% into the video (usually better than first frame)
        let duration = try await asset.load(.duration)
        let thumbnailTime = CMTime(seconds: duration.seconds * 0.1, preferredTimescale: 600)
        
        let cgImage = try await imageGenerator.image(at: thumbnailTime).image
        return UIImage(cgImage: cgImage)
    }
    
    // ENHANCED: Unified content URL resolution for both photos and videos with SmartFill support
    private func getContentURL() throws -> URL {
        // CRITICAL FIX: First try to get SmartFill version if available
        let effectiveFileName: String
        
        // Check if this UnifiedTake has SmartFill version available
        if unifiedTake.hasSmartFilledVersion {
            effectiveFileName = URL(fileURLWithPath: unifiedTake.effectiveFilePath).lastPathComponent
            print("🎨 ThumbnailPreview: Using SmartFill version - \(effectiveFileName)")
        } else {
            effectiveFileName = unifiedTake.fileName
        }
        
        // Strategy 1: Try VideoFileManager with effective filename (works for both videos and photos)
        do {
            let contentURL = try VideoFileManager.shared.getVideoURL(for: effectiveFileName)
            return contentURL
        } catch {
            // Continue to next strategy
        }
        
        // Strategy 2: Check Documents directory with effective filename
        let documentsPath = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first!
        let documentsURL = documentsPath.appendingPathComponent(effectiveFileName)
        
        if FileManager.default.fileExists(atPath: documentsURL.path) {
            return documentsURL
        }
        
        // Strategy 3: Use effective file path directly
        if unifiedTake.hasSmartFilledVersion,
           let smartFillPath = unifiedTake.smartFilledFilePath,
           !smartFillPath.isEmpty && smartFillPath != "/" {
            let smartFillURL = URL(fileURLWithPath: smartFillPath)
            if FileManager.default.fileExists(atPath: smartFillURL.path) {
                return smartFillURL
            }
        }
        
        // Strategy 4: Fallback to original file path if SmartFill not available or not found
        if !unifiedTake.filePath.isEmpty && unifiedTake.filePath != "/" {
            let originalURL = URL(fileURLWithPath: unifiedTake.filePath)
            if FileManager.default.fileExists(atPath: originalURL.path) {
                print("🎬 ThumbnailPreview: Falling back to original file - \(originalURL.lastPathComponent)")
                return originalURL
            }
        }
        
        throw ThumbnailError.contentFileNotFound("No file found for \(unifiedTake.fileName)")
    }
    
    private func formatDuration(_ duration: TimeInterval) -> String {
        guard duration > 0 && duration.isFinite else { return "0:00" }
        
        let minutes = Int(duration) / 60
        let seconds = Int(duration) % 60
        return String(format: "%d:%02d", minutes, seconds)
    }
}

// MARK: - Thumbnail Error

enum ThumbnailError: LocalizedError {
    case contentFileNotFound(String)
    case thumbnailGenerationFailed(String)
    
    var errorDescription: String? {
        switch self {
        case .contentFileNotFound(let fileName):
            return "Content file not found: \(fileName)"
        case .thumbnailGenerationFailed(let error):
            return "Failed to generate thumbnail: \(error)"
        }
    }
}

#Preview {
    let sampleTake = UnifiedTake(
        fileName: "Sample_Take1.mov",
        projectID: UUID(),
        sessionID: UUID(),
        filePath: "/sample/path/Sample_Take1.mov",
        duration: 45.5,
        fileSize: 1024000,
        cameraPosition: "back",
        sceneNumber: 1,
        takeNumber: 1,
        rating: .good,
        notes: nil
    )
    
    HStack {
        Button(action: {
            print("Thumbnail tapped in preview")
        }) {
            ThumbnailPreviewView(unifiedTake: sampleTake)
                .frame(width: 60, height: 80)
        }
        
        Spacer()
    }
    .padding()
    .background(.black)
}
