import AVFoundation
import UIKit

final class CameraEngine: NSObject, ObservableObject {
    enum EngineState {
        case idle, configuring, running, recording, capturing // Added capturing for photo mode
    }
    
    enum CameraPosition {
        case front, back
    }
    
    // NEW: Camera capture mode
    enum CameraMode {
        case video, photo
    }

    // CORE STATE - from proven working 744bbb3
    @Published private(set) var state: EngineState = .idle
    @Published private(set) var lastError: Error?
    
    // NEW: Current capture mode
    @Published private(set) var currentMode: CameraMode = .video

    // ENHANCED PROPERTIES - restored for professional controls
    @Published private(set) var currentZoomFactor: CGFloat = 1.0
    @Published private(set) var isExposureLocked: Bool = false
    @Published private(set) var isWhiteBalanceLocked: Bool = false
    @Published private(set) var exposureValue: Float = 0.0
    @Published private(set) var temperatureValue: Float = 5000.0
    @Published private(set) var tintValue: Float = 0.0
    @Published private(set) var currentCameraPosition: CameraPosition = .back
    @Published private(set) var audioSource: String = "Built-in Microphone"
    @Published private(set) var audioLevel: Float = -60.0
    
    // NEW: Smart Fill orientation support
    @Published private(set) var currentOrientation: VideoOrientation = .landscape
    @Published private(set) var deviceOrientation: UIDeviceOrientation = .portrait

    // CORE AVFoundation - from proven working 744bbb3
    let session = AVCaptureSession()
    private let sessionQueue = DispatchQueue(label: "sts.camera.session")
    private let videoOutput = AVCaptureMovieFileOutput()
    
    // NEW: Photo capture output
    private let photoOutput = AVCapturePhotoOutput()
    
    private var backgroundTaskID: UIBackgroundTaskIdentifier = .invalid
    
    // PROFESSIONAL CONTROLS - Audio monitoring
    private var audioLevelTimer: Timer?
    
    // UPDATED: iOS 17+ rotation coordinator for modern orientation handling
    private var rotationCoordinator: AVCaptureDevice.RotationCoordinator?
    private var orientationObserver: NSObjectProtocol?

    // Camera device reference for controls - FIXED: Ensure we only get VIDEO devices, not audio
    private var currentDevice: AVCaptureDevice? {
        return session.inputs.compactMap { $0 as? AVCaptureDeviceInput }
            .first(where: { $0.device.hasMediaType(.video) })?.device
    }
    
    // Audio device reference - Separate and specific for audio devices
    private var currentAudioDevice: AVCaptureDevice? {
        return session.inputs.compactMap { $0 as? AVCaptureDeviceInput }
            .first(where: { $0.device.hasMediaType(.audio) })?.device
    }

    // MARK: - Lifecycle - UPDATED: iOS 17+ rotation coordinator
    override init() {
        super.init()
        setupOrientationMonitoring()
    }
    
    deinit {
        stopOrientationMonitoring()
    }
    
    // UPDATED: iOS 17+ rotation coordinator setup
    private func setupOrientationMonitoring() {
        // Start device orientation notifications (fallback for older APIs)
        UIDevice.current.beginGeneratingDeviceOrientationNotifications()
        
        orientationObserver = NotificationCenter.default.addObserver(
            forName: UIDevice.orientationDidChangeNotification,
            object: nil,
            queue: .main
        ) { [weak self] _ in
            self?.updateOrientation()
        }
        
        // NEW: Setup iOS 17+ rotation coordinator
        if let device = AVCaptureDevice.default(for: .video) {
            rotationCoordinator = AVCaptureDevice.RotationCoordinator(device: device, previewLayer: nil)
            print("✅ iOS 17+ rotation coordinator initialized")
        }
        
        // Initial orientation detection
        updateOrientation()
    }
    
    private func stopOrientationMonitoring() {
        UIDevice.current.endGeneratingDeviceOrientationNotifications()
        if let observer = orientationObserver {
            NotificationCenter.default.removeObserver(observer)
            orientationObserver = nil
        }
        
        // UPDATED: Clean up rotation coordinator
        rotationCoordinator = nil
    }
    
    // UPDATED: Modern orientation detection using iOS 17+ APIs
    private func updateOrientation() {
        let deviceOrientation = UIDevice.current.orientation
        self.deviceOrientation = deviceOrientation
        
        // Determine video orientation based on device orientation
        let videoOrientation: VideoOrientation
        
        switch deviceOrientation {
        case .portrait, .portraitUpsideDown:
            videoOrientation = .portrait
        case .landscapeLeft, .landscapeRight:
            videoOrientation = .landscape
        case .faceUp, .faceDown, .unknown:
            // For flat orientations, maintain current orientation
            videoOrientation = currentOrientation
        @unknown default:
            videoOrientation = .landscape
        }
        
        if videoOrientation != currentOrientation {
            currentOrientation = videoOrientation
            print("📱 Orientation changed to: \(videoOrientation.displayName)")
            
            // UPDATED: Apply rotation using iOS 17+ API
            applyCurrentOrientationToConnections()
        }
    }
    
    // UPDATED: Apply orientation using iOS 17+ videoRotationAngle API
    private func applyCurrentOrientationToConnections() {
        sessionQueue.async { [weak self] in
            guard let self = self else { return }
            
            let rotationAngle = self.rotationAngleFromDeviceOrientation(self.deviceOrientation)
            
            // Apply to video output connection - UPDATED: Use isVideoRotationAngleSupported with angle parameter
            if let videoConnection = self.videoOutput.connection(with: .video),
               videoConnection.isVideoRotationAngleSupported(rotationAngle) {
                videoConnection.videoRotationAngle = rotationAngle
                print("✅ Applied rotation angle \(rotationAngle)° to video output")
            }
            
            // Apply to photo output connection - UPDATED: Use isVideoRotationAngleSupported with angle parameter
            if let photoConnection = self.photoOutput.connection(with: .video),
               photoConnection.isVideoRotationAngleSupported(rotationAngle) {
                photoConnection.videoRotationAngle = rotationAngle
                print("✅ Applied rotation angle \(rotationAngle)° to photo output")
            }
        }
    }
    
    // UPDATED: Convert device orientation to rotation angle for iOS 17+ - REVERTED: Back to original working values
    private func rotationAngleFromDeviceOrientation(_ orientation: UIDeviceOrientation) -> CGFloat {
        switch orientation {
        case .portrait:
            return 90  // Portrait
        case .portraitUpsideDown:
            return 270  // Portrait Upside Down
        case .landscapeLeft:
            return 0   // Landscape Left (device rotated left, home button on right)
        case .landscapeRight:
            return 180 // Landscape Right (device rotated right, home button on left)
        default:
            return 90  // Default to portrait
        }
    }

    func configureAndStart() {
        guard state == .idle else { return }
        state = .configuring

        sessionQueue.async { [weak self] in
            guard let self = self else { return }
            self.session.beginConfiguration()

            // Preset: high for solid quality / smallish files. We'll swap later if needed.
            if self.session.canSetSessionPreset(.high) {
                self.session.sessionPreset = .high
            }

            // Inputs
            do {
                // Camera
                guard let camera = AVCaptureDevice.default(.builtInWideAngleCamera, for: .video, position: .back) else {
                    throw NSError(domain: "STS.Camera", code: -1, userInfo: [NSLocalizedDescriptionKey: "No back camera"])
                }
                let videoInput = try AVCaptureDeviceInput(device: camera)
                if self.session.canAddInput(videoInput) {
                    self.session.addInput(videoInput)
                }

                // Audio
                if let mic = AVCaptureDevice.default(for: .audio) {
                    let audioInput = try AVCaptureDeviceInput(device: mic)
                    if self.session.canAddInput(audioInput) {
                        self.session.addInput(audioInput)
                    }
                }
            } catch {
                DispatchQueue.main.async { self.lastError = error; self.state = .idle }
                self.session.commitConfiguration()
                return
            }

            // Outputs
            if self.session.canAddOutput(self.videoOutput) {
                self.session.addOutput(self.videoOutput)
                if let connection = self.videoOutput.connection(with: .video) {
                    connection.preferredVideoStabilizationMode = .standard
                }
            }
            
            // NEW: Add photo output for keyframe photo capture
            if self.session.canAddOutput(self.photoOutput) {
                self.session.addOutput(self.photoOutput)
                // Configure photo output for high quality
                self.photoOutput.isHighResolutionCaptureEnabled = true
                if self.photoOutput.isLivePhotoCaptureSupported {
                    self.photoOutput.isLivePhotoCaptureEnabled = false // Disable Live Photos for faster capture
                }
            }

            self.session.commitConfiguration()
            self.session.startRunning()

            DispatchQueue.main.async {
                self.state = .running
                // FIXED: Simplified property initialization - avoid complex white balance queries
                self.initializeCameraProperties()
                self.updateAudioProperties()
                self.startAudioLevelMonitoring()
                
                // UPDATED: Apply initial orientation using iOS 17+ API
                self.updateOrientation()
            }
        }
    }

    func stopSession() {
        stopAudioLevelMonitoring()
        sessionQueue.async { [weak self] in
            guard let self = self else { return }
            if self.session.isRunning { self.session.stopRunning() }
            DispatchQueue.main.async { self.state = .idle }
        }
    }

    // MARK: - Recording - UPDATED: Modern orientation tracking
    func startRecording() {
        guard state == .running, !videoOutput.isRecording else { return }

        backgroundTaskID = UIApplication.shared.beginBackgroundTask(withName: "STSRecording")

        let url = Self.makeOutputURL()
        videoOutput.startRecording(to: url, recordingDelegate: self)
        DispatchQueue.main.async {
            self.state = .recording
            print("🎬 Recording started with orientation: \(self.currentOrientation.displayName)")
        }
    }

    func stopRecording() {
        guard videoOutput.isRecording else { return }
        videoOutput.stopRecording()
        print("🎬 Recording stopped")
    }

    private static func makeOutputURL() -> URL {
        let directory = FileManager.default.temporaryDirectory
        let filename = "STS_\(UUID().uuidString).mov"
        return directory.appendingPathComponent(filename)
    }
    
    // MARK: - Camera Controls - Full Professional Implementation with Device Capability Checking
    func setFocus(at point: CGPoint) {
        guard let device = currentDevice else { return }
        sessionQueue.async {
            do {
                try device.lockForConfiguration()
                if device.isFocusPointOfInterestSupported {
                    device.focusPointOfInterest = point
                    if device.isFocusModeSupported(.autoFocus) {
                        device.focusMode = .autoFocus
                    }
                }
                if device.isExposurePointOfInterestSupported {
                    device.exposurePointOfInterest = point
                    if device.isExposureModeSupported(.autoExpose) {
                        device.exposureMode = .autoExpose
                    }
                }
                device.unlockForConfiguration()
            } catch {
                print("Focus config error: \(error)")
                DispatchQueue.main.async { self.lastError = error }
            }
        }
    }

    func setZoom(factor: CGFloat) {
        guard let device = currentDevice else { return }
        sessionQueue.async {
            do {
                try device.lockForConfiguration()
                let maxZoom = min(device.activeFormat.videoMaxZoomFactor, 5.0)
                let zoom = max(1.0, min(factor, maxZoom))
                device.videoZoomFactor = zoom
                device.unlockForConfiguration()
                
                DispatchQueue.main.async {
                    self.currentZoomFactor = zoom
                }
            } catch {
                print("Zoom config error: \(error)")
            }
        }
    }

    // PROFESSIONAL EXPOSURE CONTROL - FIXED: Attempt direct control with graceful fallback (Apple's recommended approach)
    func setExposure(compensation: Float) {
        guard let device = currentDevice else { return }
        
        // FIXED: Enhanced NaN protection for exposure values
        guard !compensation.isNaN && !compensation.isInfinite else {
            print("⚠️ Invalid exposure compensation value: \(compensation)")
            return
        }
        
        // Modern iPhones support exposure controls on both cameras, so attempt directly
        
        sessionQueue.async {
            do {
                try device.lockForConfiguration()
                let clampedValue = max(device.minExposureTargetBias, min(device.maxExposureTargetBias, compensation))
                
                // FIXED: Additional validation before setting
                guard !clampedValue.isNaN && !clampedValue.isInfinite else {
                    print("⚠️ Clamped exposure value is invalid: \(clampedValue)")
                    device.unlockForConfiguration()
                    return
                }
                
                device.setExposureTargetBias(clampedValue) { _ in }
                device.unlockForConfiguration()
                
                DispatchQueue.main.async {
                    self.exposureValue = clampedValue
                }
                print("✅ Exposure set successfully on \(self.currentCameraPosition) camera: \(clampedValue)")
            } catch {
                print("⚠️ Exposure config error on \(self.currentCameraPosition) camera: \(error)")
                // Don't treat this as a fatal error - just log and continue
            }
        }
    }
    
    // FIXED: Enhanced white balance - attempt direct control with graceful fallback
    func setWhiteBalance(temperature: Float, tint: Float) {
        guard let device = currentDevice else { return }
        
        // FIXED: Enhanced validation and safe ranges
        let safeTemp = max(3000.0, min(8000.0, temperature)) // Safe temperature range
        let safeTint = max(-150.0, min(150.0, tint)) // Safe tint range
        
        guard !safeTemp.isNaN && !safeTemp.isInfinite &&
              !safeTint.isNaN && !safeTint.isInfinite else {
            print("⚠️ Invalid white balance values - temp: \(temperature), tint: \(tint)")
            return
        }
        
        sessionQueue.async {
            do {
                try device.lockForConfiguration()
                
                // FIXED: Use safe gain calculation method
                let redGain: Float = 2000.0 / safeTemp
                let blueGain: Float = safeTemp / 2000.0
                let greenGain: Float = 1.0 + (safeTint / 100.0)
                
                // Ensure gains are within valid device limits
                let maxGain = device.maxWhiteBalanceGain
                let minGain: Float = 1.0
                
                let normalizedGains = AVCaptureDevice.WhiteBalanceGains(
                    redGain: max(minGain, min(redGain, maxGain)),
                    greenGain: max(minGain, min(greenGain, maxGain)),
                    blueGain: max(minGain, min(blueGain, maxGain))
                )
                
                // Final validation of normalized gains
                guard normalizedGains.redGain >= minGain && normalizedGains.redGain <= maxGain &&
                      normalizedGains.greenGain >= minGain && normalizedGains.greenGain <= maxGain &&
                      normalizedGains.blueGain >= minGain && normalizedGains.blueGain <= maxGain else {
                    print("⚠️ Calculated gains are out of range")
                    device.unlockForConfiguration()
                    return
                }
                
                device.setWhiteBalanceModeLocked(with: normalizedGains) { _ in }
                device.unlockForConfiguration()
                
                DispatchQueue.main.async {
                    self.temperatureValue = safeTemp
                    self.tintValue = safeTint
                    self.isWhiteBalanceLocked = true
                }
                print("✅ White balance set successfully on \(self.currentCameraPosition) camera: temp=\(safeTemp), tint=\(safeTint)")
            } catch {
                print("⚠️ White balance config error on \(self.currentCameraPosition) camera: \(error)")
                // Graceful fallback - reset to auto mode
                do {
                    try device.lockForConfiguration()
                    device.whiteBalanceMode = .continuousAutoWhiteBalance
                    device.unlockForConfiguration()
                    DispatchQueue.main.async {
                        self.isWhiteBalanceLocked = false
                        print("🔄 Fell back to auto white balance on \(self.currentCameraPosition) camera")
                    }
                } catch {
                    print("⚠️ Could not set auto white balance: \(error)")
                }
            }
        }
    }
    
    func toggleExposureLock() {
        guard let device = currentDevice else { return }
        
        sessionQueue.async {
            do {
                try device.lockForConfiguration()
                if device.exposureMode == .locked {
                    device.exposureMode = .continuousAutoExposure
                    DispatchQueue.main.async {
                        self.isExposureLocked = false
                        print("🔓 Exposure unlocked on \(self.currentCameraPosition) camera")
                    }
                } else {
                    device.exposureMode = .locked
                    DispatchQueue.main.async {
                        self.isExposureLocked = true
                        print("🔒 Exposure locked on \(self.currentCameraPosition) camera")
                    }
                }
                device.unlockForConfiguration()
            } catch {
                print("⚠️ Exposure lock toggle error on \(self.currentCameraPosition) camera: \(error)")
            }
        }
    }
    
    func toggleWhiteBalanceLock() {
        guard let device = currentDevice else { return }
        
        sessionQueue.async {
            do {
                try device.lockForConfiguration()
                if device.whiteBalanceMode == .locked {
                    device.whiteBalanceMode = .continuousAutoWhiteBalance
                    DispatchQueue.main.async {
                        self.isWhiteBalanceLocked = false
                        print("🔓 White balance unlocked on \(self.currentCameraPosition) camera")
                    }
                } else {
                    device.whiteBalanceMode = .locked
                    DispatchQueue.main.async {
                        self.isWhiteBalanceLocked = true
                        print("🔒 White balance locked on \(self.currentCameraPosition) camera")
                    }
                }
                device.unlockForConfiguration()
            } catch {
                print("⚠️ White balance lock toggle error on \(self.currentCameraPosition) camera: \(error)")
            }
        }
    }

    func unlockExposure() {
        guard let device = currentDevice else { return }
        
        do {
            try device.lockForConfiguration()
            device.exposureMode = .continuousAutoExposure
            device.unlockForConfiguration()
            DispatchQueue.main.async {
                self.isExposureLocked = false
            }
            print("✅ Exposure unlocked on \(currentCameraPosition) camera")
        } catch {
            print("⚠️ Failed to unlock exposure on \(currentCameraPosition) camera: \(error)")
        }
    }

    func unlockWhiteBalance() {
        guard let device = currentDevice else { return }
        
        do {
            try device.lockForConfiguration()
            device.whiteBalanceMode = .continuousAutoWhiteBalance
            device.unlockForConfiguration()
            DispatchQueue.main.async {
                self.isWhiteBalanceLocked = false
            }
            print("✅ White balance unlocked on \(currentCameraPosition) camera")
        } catch {
            print("⚠️ Failed to unlock white balance on \(currentCameraPosition) camera: \(error)")
        }
    }
    
    // ENHANCED: Auto-correct method - attempt controls on both cameras
    func autoCorrectCamera() {
        guard let device = currentDevice else { return }
        
        do {
            try device.lockForConfiguration()
            
            // Reset exposure to auto
            device.exposureMode = .continuousAutoExposure
            if device.exposureTargetBias != 0 {
                device.setExposureTargetBias(0) { _ in
                    print("🎥 Auto-correct: Exposure bias reset to 0 on \(self.currentCameraPosition) camera")
                }
            }
            
            // Reset white balance to auto
            device.whiteBalanceMode = .continuousAutoWhiteBalance
            
            device.unlockForConfiguration()
            
            // Update our stored values to reflect the auto settings
            DispatchQueue.main.async {
                self.exposureValue = 0.0
                self.temperatureValue = 5500.0 // Default daylight temperature
                self.tintValue = 0.0
                self.isExposureLocked = false
                self.isWhiteBalanceLocked = false
            }
            
            print("✅ Auto-correct applied successfully on \(self.currentCameraPosition) camera")
            
        } catch {
            print("⚠️ Auto-correct failed on \(self.currentCameraPosition) camera: \(error)")
        }
    }
    
    // NEW: Camera switching functionality - ENHANCED: Better device management and error handling
    func switchCamera() {
        guard state == .running else { return }
        
        let targetPosition: AVCaptureDevice.Position = (currentCameraPosition == .back) ? .front : .back
        let newCameraPosition: CameraPosition = (currentCameraPosition == .back) ? .front : .back
        
        print("🎥 Attempting to switch from \(currentCameraPosition) to \(newCameraPosition) camera")
        
        sessionQueue.async { [weak self] in
            guard let self = self else { return }
            
            self.session.beginConfiguration()
            
            // CRITICAL FIX: Find and remove ONLY the video input, preserve audio input
            let videoInput = self.session.inputs.compactMap { $0 as? AVCaptureDeviceInput }
                .first(where: { $0.device.hasMediaType(.video) })
            
            let audioInput = self.session.inputs.compactMap { $0 as? AVCaptureDeviceInput }
                .first(where: { $0.device.hasMediaType(.audio) })
            
            // Remove only the video input, keep audio input
            if let currentVideoInput = videoInput {
                self.session.removeInput(currentVideoInput)
                print("🔄 Removed video input: \(currentVideoInput.device.localizedName)")
            }
            
            // Add new camera input
            do {
                guard let newCamera = AVCaptureDevice.default(.builtInWideAngleCamera, for: .video, position: targetPosition) else {
                    // Fallback: re-add the previous video camera if new camera fails
                    if let previousVideoInput = videoInput {
                        if self.session.canAddInput(previousVideoInput) {
                            self.session.addInput(previousVideoInput)
                            print("🔄 Restored previous video input after failure")
                        }
                    }
                    self.session.commitConfiguration()
                    print("❌ Failed to find camera for position: \(targetPosition)")
                    return
                }
                
                let newVideoInput = try AVCaptureDeviceInput(device: newCamera)
                
                if self.session.canAddInput(newVideoInput) {
                    self.session.addInput(newVideoInput)
                    print("✅ Added new video input: \(newCamera.localizedName)")
                    
                    // Update video stabilization for the new connection
                    if let connection = self.videoOutput.connection(with: .video) {
                        connection.preferredVideoStabilizationMode = .standard
                    }
                    
                    self.session.commitConfiguration()
                    
                    // Verify we have the correct device before updating properties
                    let verifyDevice = self.session.inputs.compactMap { $0 as? AVCaptureDeviceInput }
                        .first(where: { $0.device.hasMediaType(.video) })?.device
                    
                    print("🔍 Verification - Current video device: \(verifyDevice?.localizedName ?? "None")")
                    
                    // CRITICAL: Update properties on main thread with enhanced safety
                    DispatchQueue.main.async {
                        self.currentCameraPosition = newCameraPosition
                        // Reset zoom when switching cameras
                        self.currentZoomFactor = 1.0
                        
                        // ENHANCED: Reset to safe defaults before re-initializing
                        self.exposureValue = 0.0
                        self.temperatureValue = 5000.0
                        self.tintValue = 0.0
                        self.isExposureLocked = false
                        self.isWhiteBalanceLocked = false
                        
                        // Re-initialize camera properties for new device with capability checking
                        self.initializeCameraProperties()
                        
                        // UPDATED: Apply current orientation to new camera connections
                        self.applyCurrentOrientationToConnections()
                        
                        // Log capabilities for debugging
                        self.logDeviceCapabilities()
                    }
                    
                    print("✅ Camera switched to: \(newCameraPosition)")
                    
                } else {
                    // Fallback: re-add the previous video camera
                    if let previousVideoInput = videoInput {
                        if self.session.canAddInput(previousVideoInput) {
                            self.session.addInput(previousVideoInput)
                            print("🔄 Restored previous video input - cannot add new input")
                        }
                    }
                    self.session.commitConfiguration()
                    print("❌ Cannot add new camera input")
                }
                
            } catch {
                // Fallback: re-add the previous video camera
                if let previousVideoInput = videoInput {
                    if self.session.canAddInput(previousVideoInput) {
                        self.session.addInput(previousVideoInput)
                        print("🔄 Restored previous video input after error")
                    }
                }
                self.session.commitConfiguration()
                print("❌ Error creating camera input: \(error)")
                DispatchQueue.main.async {
                    self.lastError = error
                }
            }
        }
    }
    
    // MARK: - Camera Mode Management - NEW: Professional mode switching
    
    func switchToVideoMode() {
        guard currentMode != .video else { return }
        currentMode = .video
        print("🎥 Switched to video capture mode")
    }
    
    func switchToPhotoMode() {
        guard currentMode != .photo else { return }
        currentMode = .photo
        print("📸 Switched to photo capture mode")
    }
    
    // NEW: Photo capture method - ENHANCED: Orientation capture support
    func capturePhoto() {
        guard currentMode == .photo && state == .running else {
            print("⚠️ Cannot capture photo - wrong mode or state")
            return
        }
        
        guard photoOutput.connection(with: .video) != nil else {
            print("⚠️ No photo output connection available")
            return
        }
        
        // Set state to capturing during photo processing
        state = .capturing
        
        // Configure photo settings - FIXED: Proper photo settings initialization
        var photoSettings: AVCapturePhotoSettings
        
        // Use high quality JPEG format - FIXED: Proper initialization with format
        if photoOutput.availablePhotoCodecTypes.contains(.jpeg) {
            photoSettings = AVCapturePhotoSettings(format: [AVVideoCodecKey: AVVideoCodecType.jpeg])
        } else {
            // Fallback to default settings
            photoSettings = AVCapturePhotoSettings()
        }
        
        // Enable high resolution capture if available
        photoSettings.isHighResolutionPhotoEnabled = photoOutput.isHighResolutionCaptureEnabled
        
        // Disable flash for self-tape consistency
        photoSettings.flashMode = .off
        
        // Capture the photo
        photoOutput.capturePhoto(with: photoSettings, delegate: self)
        
        print("📸 Photo capture initiated with orientation: \(currentOrientation.displayName)")
    }
    
    // Check if photo capture is available
    var canCapturePhoto: Bool {
        return currentMode == .photo && state == .running && photoOutput.connection(with: .video) != nil
    }
    
    // Check if video recording is available
    var canRecordVideo: Bool {
        return currentMode == .video && state == .running && !videoOutput.isRecording
    }
    
    // MARK: - Device Capability Helpers - FIXED: More realistic capability detection
    
    /// Check if current camera device supports manual exposure controls
    /// Note: Due to iOS bugs, we assume modern devices support exposure controls and handle errors gracefully
    var supportsManualExposure: Bool {
        guard let device = currentDevice else { return false }
        // Modern iPhones support exposure controls on both cameras, despite what isExposureModeSupported reports
        return true // Assume support and handle errors gracefully in actual usage
    }
    
    /// Check if current camera device supports manual white balance controls
    /// Note: Due to iOS bugs, we assume modern devices support WB controls and handle errors gracefully
    var supportsManualWhiteBalance: Bool {
        guard let device = currentDevice else { return false }
        // Modern iPhones support white balance controls on both cameras
        return true // Assume support and handle errors gracefully in actual usage
    }
    
    /// Check if current camera device supports focus controls
    var supportsFocusControl: Bool {
        guard let device = currentDevice else { return false }
        return device.isFocusPointOfInterestSupported && device.isFocusModeSupported(.autoFocus)
    }
    
    /// Get a summary of current device capabilities for debugging
    func logDeviceCapabilities() {
        guard let device = currentDevice else {
            print("⚠️ No current device to check capabilities")
            return
        }
        
        print("📱 Device Capabilities for \(currentCameraPosition) camera:")
        print("   - Model: \(device.localizedName)")
        print("   - isExposureModeSupported(.locked): \(device.isExposureModeSupported(.locked))")
        print("   - isExposureModeSupported(.continuousAutoExposure): \(device.isExposureModeSupported(.continuousAutoExposure))")
        print("   - isWhiteBalanceModeSupported(.locked): \(device.isWhiteBalanceModeSupported(.locked))")
        print("   - isWhiteBalanceModeSupported(.continuousAutoWhiteBalance): \(device.isWhiteBalanceModeSupported(.continuousAutoWhiteBalance))")
        print("   - Focus Control: \(supportsFocusControl)")
        print("   - Max Zoom: \(device.activeFormat.videoMaxZoomFactor)")
        print("   - Exposure Range: \(device.minExposureTargetBias) to \(device.maxExposureTargetBias)")
        print("   - Note: We attempt controls regardless of isSupported results due to iOS bugs")
    }

    // MARK: - Audio Level Monitoring - Professional Implementation
    private func startAudioLevelMonitoring() {
        stopAudioLevelMonitoring()
        
        audioLevelTimer = Timer.scheduledTimer(withTimeInterval: 0.1, repeats: true) { [weak self] _ in
            self?.updateAudioLevel()
        }
    }
    
    private func stopAudioLevelMonitoring() {
        audioLevelTimer?.invalidate()
        audioLevelTimer = nil
    }
    
    private func updateAudioLevel() {
        // Simulate audio level for UI - in real implementation would use AVAudioEngine
        // This provides realistic audio meter behavior for the professional panels
        let baseLevel: Float = -25.0
        let variation: Float = Float.random(in: -10.0...5.0)
        let candidateLevel = baseLevel + variation
        let newLevel = max(-50.0, min(0.0, candidateLevel))
        
        // FIXED: Enhanced guard against NaN/infinite values that cause CoreGraphics errors
        guard !newLevel.isNaN && !newLevel.isInfinite else {
            print("⚠️ CameraEngine: Audio level calculation resulted in invalid value, using fallback")
            DispatchQueue.main.async {
                self.audioLevel = -30.0 // Safe fallback value
            }
            return
        }
        
        // Additional validation for the random number generation
        guard !baseLevel.isNaN && !variation.isNaN && !candidateLevel.isNaN else {
            print("⚠️ CameraEngine: Random audio level components invalid")
            DispatchQueue.main.async {
                self.audioLevel = -30.0 // Safe fallback value
            }
            return
        }
        
        DispatchQueue.main.async {
            self.audioLevel = newLevel
        }
    }
    
    // MARK: - Property Updates - FIXED: Attempt to read actual device state with graceful fallbacks
    private func initializeCameraProperties() {
        guard let device = currentDevice else { return }
        
        // Always safe to read zoom factor
        currentZoomFactor = device.videoZoomFactor
        
        // Attempt to read exposure properties - handle any errors gracefully
        do {
            isExposureLocked = device.exposureMode == .locked
            exposureValue = device.exposureTargetBias
            print("✅ Read exposure properties for \(currentCameraPosition) camera: locked=\(isExposureLocked), value=\(exposureValue)")
        } catch {
            // Graceful fallback
            isExposureLocked = false
            exposureValue = 0.0
            print("⚠️ Could not read exposure properties for \(currentCameraPosition) camera, using defaults: \(error)")
        }
        
        // Attempt to read white balance properties - handle any errors gracefully
        do {
            isWhiteBalanceLocked = device.whiteBalanceMode == .locked
            print("✅ Read white balance properties for \(currentCameraPosition) camera: locked=\(isWhiteBalanceLocked)")
        } catch {
            // Graceful fallback
            isWhiteBalanceLocked = false
            print("⚠️ Could not read white balance properties for \(currentCameraPosition) camera, using defaults: \(error)")
        }
        
        // Use safe default values for temperature/tint - these are UI-only values anyway
        temperatureValue = 5000.0 // Standard daylight temperature
        tintValue = 0.0 // Neutral tint
        
        print("✅ Camera properties initialized for \(currentCameraPosition) camera - attempting all controls")
    }
    
    private func updateAudioProperties() {
        if let audioDevice = currentAudioDevice {
            audioSource = audioDevice.localizedName
        } else {
            audioSource = "Built-in Microphone"
        }
    }
}

// MARK: - AVCaptureFileOutputRecordingDelegate - UPDATED: iOS 17+ orientation tracking
extension CameraEngine: AVCaptureFileOutputRecordingDelegate {
    func fileOutput(_ output: AVCaptureFileOutput, didFinishRecordingTo outputFileURL: URL, from connections: [AVCaptureConnection], error: Error?) {
        if backgroundTaskID != .invalid {
            UIApplication.shared.endBackgroundTask(backgroundTaskID)
            backgroundTaskID = .invalid
        }

        DispatchQueue.main.async { [weak self] in
            guard let self = self else { return }
            
            // Handle any recording errors first
            if let error = error {
                print("❌ Recording failed: \(error)")
                self.lastError = error
                self.state = .running
                return
            }
            
            self.state = .running
            
            // ENHANCED: Handle file persistence with orientation metadata
            self.handleRecordedFile(at: outputFileURL)
        }
    }
    
    // MARK: - File Persistence - ENHANCED: Orientation metadata
    private func handleRecordedFile(at sourceURL: URL) {
        // Verify source file exists before attempting move
        guard FileManager.default.fileExists(atPath: sourceURL.path) else {
            print("❌ Source file doesn't exist: \(sourceURL.path)")
            self.lastError = NSError(domain: "STS.FileSystem", code: -1,
                                   userInfo: [NSLocalizedDescriptionKey: "Recorded file not found"])
            return
        }
        
        // Get file size for logging
        let fileSize = (try? FileManager.default.attributesOfItem(atPath: sourceURL.path)[.size] as? Int) ?? 0
        let fileSizeMB = Double(fileSize) / 1024 / 1024
        
        print("✅ Source file verified: \(sourceURL.path) (Size: \(String(format: "%.2f", fileSizeMB)) MB)")
        print("📱 Recorded with orientation: \(currentOrientation.displayName)")
        
        // Post notification with the verified temp file URL and orientation metadata
        NotificationCenter.default.post(
            name: .stsDidRecordFile,
            object: nil,
            userInfo: [
                "url": sourceURL,
                "fileSize": fileSize,
                "verified": true,
                "capturedOrientation": currentOrientation,  // NEW: Orientation metadata
                "deviceOrientation": deviceOrientation
            ]
        )
    }
}

// MARK: - AVCapturePhotoCaptureDelegate - ENHANCED: Orientation metadata
extension CameraEngine: AVCapturePhotoCaptureDelegate {
    
    func photoOutput(_ output: AVCapturePhotoOutput, didFinishProcessingPhoto photo: AVCapturePhoto, error: Error?) {
        DispatchQueue.main.async { [weak self] in
            guard let self = self else { return }
            
            // Handle any capture errors first
            if let error = error {
                print("❌ Photo capture failed: \(error)")
                self.lastError = error
                self.state = .running
                return
            }
            
            self.state = .running
            
            // ENHANCED: Handle captured photo data with orientation
            self.handleCapturedPhoto(photo)
        }
    }
    
    // MARK: - Photo Processing - ENHANCED: Orientation metadata
    private func handleCapturedPhoto(_ photo: AVCapturePhoto) {
        // Extract image data
        guard let imageData = photo.fileDataRepresentation() else {
            print("❌ Could not get photo data representation")
            self.lastError = NSError(domain: "STS.PhotoCapture", code: -1,
                                   userInfo: [NSLocalizedDescriptionKey: "Could not get photo data"])
            return
        }
        
        // Verify image data is valid
        guard UIImage(data: imageData) != nil else {
            print("❌ Could not create UIImage from photo data")
            self.lastError = NSError(domain: "STS.PhotoCapture", code: -2,
                                   userInfo: [NSLocalizedDescriptionKey: "Invalid photo data"])
            return
        }
        
        // Save photo to temporary location
        let tempURL = Self.makePhotoOutputURL()
        
        do {
            try imageData.write(to: tempURL)
            print("✅ Photo saved to temporary location: \(tempURL.path)")
            print("📱 Captured with orientation: \(currentOrientation.displayName)")
            
            // Get file size for logging
            let fileSize = imageData.count
            let fileSizeMB = Double(fileSize) / 1024 / 1024
            
            print("📊 Photo captured: \(String(format: "%.2f", fileSizeMB)) MB")
            
            // Post notification with the captured photo URL and orientation metadata
            NotificationCenter.default.post(
                name: .stsDidCapturePhoto,
                object: nil,
                userInfo: [
                    "url": tempURL,
                    "fileSize": fileSize,
                    "verified": true,
                    "capturedOrientation": currentOrientation,  // NEW: Orientation metadata
                    "deviceOrientation": deviceOrientation
                ]
            )
            
        } catch {
            print("❌ Failed to save photo: \(error)")
            self.lastError = error
        }
    }
    
    private static func makePhotoOutputURL() -> URL {
        let directory = FileManager.default.temporaryDirectory
        let filename = "STS_Photo_\(UUID().uuidString).jpg"
        return directory.appendingPathComponent(filename)
    }
}

extension Notification.Name {
    static let stsDidRecordFile = Notification.Name("stsDidRecordFile")
    static let stsDidCapturePhoto = Notification.Name("stsDidCapturePhoto") // NEW: Photo capture notification
}
