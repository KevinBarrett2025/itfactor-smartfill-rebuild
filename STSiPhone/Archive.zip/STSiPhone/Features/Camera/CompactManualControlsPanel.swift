import SwiftUI

struct CompactManualControlsPanel: View {
    @ObservedObject var engine: CameraEngine
    @Binding var isVisible: Bool
    
    // NEW: Accept lock state as binding from parent for persistence
    @Binding var isLocked: Bool
    
    // ENHANCED: Enable controls for both cameras - modern iPhones support manual controls on both
    private var currentDeviceSupportsManualControls: Bool {
        // Modern iPhones support manual controls on both front and back cameras
        return true
    }
    
    private var supportsExposureControl: Bool {
        // Enable for both cameras and handle errors gracefully in the engine
        return true
    }
    
    private var supportsWhiteBalanceControl: Bool {
        // Enable for both cameras and handle errors gracefully in the engine
        return true
    }

    var body: some View {
        VStack {
            Spacer() // Push panel to bottom
            
            VStack(spacing: 8) {
                // Top row: Lock, Close, and Auto buttons
                HStack {
                    // Lock button 
                    Button(action: {
                        withAnimation(.easeInOut(duration: 0.2)) {
                            isLocked.toggle()
                        }
                    }) {
                        Image(systemName: isLocked ? "lock.fill" : "lock.open")
                            .font(.system(size: 14, weight: .semibold))
                            .foregroundColor(isLocked ? .red : .gray)
                            .padding(6)
                            .background(
                                Circle()
                                    .fill(isLocked ? Color.red.opacity(0.15) : Color.gray.opacity(0.15))
                                    .overlay(
                                        Circle()
                                            .stroke(isLocked ? Color.red.opacity(0.3) : Color.gray.opacity(0.3), lineWidth: 1)
                                    )
                            )
                    }
                    .disabled(!currentDeviceSupportsManualControls)
                    .opacity(currentDeviceSupportsManualControls ? 1.0 : 0.5)
                    
                    Spacer()
                    
                    // Auto-correct button in center
                    Button(action: {
                        withAnimation(.easeInOut(duration: 0.3)) {
                            engine.autoCorrectCamera()
                        }
                    }) {
                        HStack(spacing: 4) {
                            Image(systemName: "wand.and.stars")
                                .font(.system(size: 12, weight: .semibold))
                            Text("Auto")
                                .font(.system(size: 11, weight: .semibold))
                        }
                        .foregroundColor(.blue)
                        .padding(.horizontal, 8)
                        .padding(.vertical, 4)
                        .background(
                            RoundedRectangle(cornerRadius: 12)
                                .fill(Color.blue.opacity(0.15))
                                .overlay(
                                    RoundedRectangle(cornerRadius: 12)
                                        .stroke(Color.blue.opacity(0.3), lineWidth: 1)
                                )
                        )
                    }
                    .disabled(isLocked)
                    .opacity(isLocked ? 0.5 : 1.0)
                    
                    Spacer()
                    
                    // Close button
                    Button(action: { withAnimation { isVisible = false } }) {
                        Image(systemName: "xmark.circle.fill")
                            .font(.system(size: 16, weight: .bold))
                            .foregroundColor(.white)
                    }
                }
                
                // ENHANCED: Show appropriate controls based on device capabilities
                if currentDeviceSupportsManualControls {
                    // Full manual controls for both front and back cameras (modern iPhones support both)
                    VStack(spacing: 8) {
                        // Exposure control
                        if supportsExposureControl {
                            HStack(spacing: 8) {
                                Image(systemName: "sun.max")
                                    .font(.caption2)
                                    .foregroundColor(.yellow)
                                    .frame(width: 16)
                                Slider(value: Binding(
                                    get: { Double(engine.exposureValue) },
                                    set: { engine.setExposure(compensation: Float($0)) }
                                ), in: -2.0...2.0, step: 0.05)
                                .accentColor(.yellow)
                                .disabled(isLocked)
                                Text(String(format: "%.1f", engine.exposureValue))
                                    .font(.caption2)
                                    .foregroundColor(.white)
                                    .frame(width: 28, alignment: .trailing)
                                    .monospacedDigit()
                            }
                            .opacity(isLocked ? 0.5 : 1.0)
                        }

                        // Temperature control
                        if supportsWhiteBalanceControl {
                            HStack(spacing: 8) {
                                Image(systemName: "thermometer")
                                    .font(.caption2)
                                    .foregroundColor(.orange)
                                    .frame(width: 16)
                                Slider(value: Binding(
                                    get: { Double(engine.temperatureValue) },
                                    set: { newTemp in
                                        engine.setWhiteBalance(temperature: Float(newTemp), tint: engine.tintValue)
                                    }
                                ), in: 2500...8000, step: 100)
                                .accentColor(.orange)
                                .disabled(isLocked)
                                Text("\(Int(engine.temperatureValue))")
                                    .font(.caption2)
                                    .foregroundColor(.white)
                                    .frame(width: 36, alignment: .trailing)
                                    .monospacedDigit()
                            }
                            .opacity(isLocked ? 0.5 : 1.0)

                            // Tint control
                            HStack(spacing: 8) {
                                Text("G")
                                    .font(.caption2.bold())
                                    .foregroundColor(.green)
                                    .frame(width: 8)
                                Slider(value: Binding(
                                    get: { Double(engine.tintValue) },
                                    set: { newTint in
                                        engine.setWhiteBalance(temperature: engine.temperatureValue, tint: Float(newTint))
                                    }
                                ), in: -150...150, step: 10)
                                .accentColor(.purple)
                                .disabled(isLocked)
                                Text("M")
                                    .font(.caption2.bold())
                                    .foregroundColor(.purple)
                                    .frame(width: 8)
                                Text(String(format: "%+.0f", engine.tintValue))
                                    .font(.caption2)
                                    .foregroundColor(.white)
                                    .frame(width: 28, alignment: .trailing)
                                    .monospacedDigit()
                            }
                            .opacity(isLocked ? 0.5 : 1.0)
                        }
                    }
                } else {
                    // This should rarely happen on modern devices
                    VStack(spacing: 8) {
                        HStack {
                            Image(systemName: "info.circle")
                                .font(.caption2)
                                .foregroundColor(.orange)
                            Text("Manual controls not available")
                                .font(.caption2)
                                .foregroundColor(.white.opacity(0.8))
                        }
                        .padding(.vertical, 4)
                    }
                }
            }
            .padding(.horizontal, 16)
            .padding(.vertical, 12)
            .background(.ultraThinMaterial.opacity(0.93))
            .clipShape(RoundedRectangle(cornerRadius: 18, style: .continuous))
            .overlay(
                RoundedRectangle(cornerRadius: 18, style: .continuous)
                    .stroke(Color.white.opacity(0.22), lineWidth: 1)
            )
            .shadow(radius: 7)
            .padding(.horizontal, 12)
            .padding(.bottom, 20) // Move to bottom of screen, minimal padding for safe area
            .animation(.easeInOut(duration: 0.21), value: isVisible)
        }
    }
}
