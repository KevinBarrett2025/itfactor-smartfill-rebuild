import SwiftUI
import PDFKit
import UniformTypeIdentifiers

struct DocumentPreviewView: View {
    let documentURL: URL
    let documentTitle: String
    @Environment(\.dismiss) private var dismiss
    @State private var documentContent: DocumentContent?
    @State private var isLoading = true
    @State private var errorMessage: String?
    
    private enum DocumentContent {
        case pdf(PDFDocument)
        case text(String)
        case unsupported
    }
    
    var body: some View {
        NavigationStack {
            ZStack {
                BrandBackground()
                    .ignoresSafeArea()
                
                if isLoading {
                    VStack(spacing: 16) {
                        ProgressView()
                            .scaleEffect(1.5)
                            .tint(Theme.primary)
                        
                        Text("Loading document...")
                            .font(Theme.Font.body)
                            .foregroundStyle(.white)
                    }
                } else if let errorMessage = errorMessage {
                    VStack(spacing: 16) {
                        Image(systemName: "exclamationmark.triangle")
                            .font(.system(size: 60))
                            .foregroundStyle(.red)
                        
                        Text("Unable to load document")
                            .font(Theme.Font.title)
                            .foregroundStyle(.white)
                        
                        Text(errorMessage)
                            .font(Theme.Font.body)
                            .foregroundStyle(.gray)
                            .multilineTextAlignment(.center)
                            .padding(.horizontal)
                    }
                } else {
                    documentContentView
                }
            }
            .navigationTitle(documentTitle)
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    Button {
                        dismiss()
                    } label: {
                        Image(systemName: "xmark.circle.fill")
                            .font(.title2)
                            .foregroundStyle(.white.opacity(0.8))
                    }
                }
                
                ToolbarItem(placement: .navigationBarTrailing) {
                    if documentContent != nil {
                        ShareButton(documentURL: documentURL)
                    }
                }
            }
        }
        .task {
            await loadDocument()
        }
    }
    
    @ViewBuilder
    private var documentContentView: some View {
        switch documentContent {
        case .pdf(let pdfDocument):
            PDFPreviewView(pdfDocument: pdfDocument)
                .background(Color.black.opacity(0.1))
                .clipShape(RoundedRectangle(cornerRadius: 12))
                .padding(.horizontal, 16)
                .padding(.vertical, 8)
            
        case .text(let textContent):
            TextPreviewView(content: textContent)
                .padding(.horizontal, 16)
                .padding(.vertical, 8)
            
        case .unsupported:
            VStack(spacing: 16) {
                Image(systemName: "doc.questionmark")
                    .font(.system(size: 60))
                    .foregroundStyle(.orange)
                
                Text("Unsupported file type")
                    .font(Theme.Font.title)
                    .foregroundStyle(.white)
                
                Text("This file type cannot be previewed, but you can still share it.")
                    .font(Theme.Font.body)
                    .foregroundStyle(.gray)
                    .multilineTextAlignment(.center)
                    .padding(.horizontal)
            }
            
        case .none:
            EmptyView()
        }
    }
    
    private func loadDocument() async {
        defer { isLoading = false }
        
        // Check if file exists and is accessible
        guard documentURL.startAccessingSecurityScopedResource() else {
            errorMessage = "Unable to access the document file."
            return
        }
        
        defer { documentURL.stopAccessingSecurityScopedResource() }
        
        do {
            // Determine file type
            let resourceValues = try documentURL.resourceValues(forKeys: [.contentTypeKey])
            
            if let contentType = resourceValues.contentType {
                if contentType.conforms(to: .pdf) {
                    // Load PDF
                    if let pdfDocument = PDFDocument(url: documentURL) {
                        documentContent = .pdf(pdfDocument)
                    } else {
                        errorMessage = "Invalid or corrupted PDF file."
                    }
                } else if contentType.conforms(to: .text) || contentType.conforms(to: .plainText) {
                    // Load text file
                    let textContent = try String(contentsOf: documentURL, encoding: .utf8)
                    documentContent = .text(textContent)
                } else {
                    documentContent = .unsupported
                }
            } else {
                // Fallback: try to determine by file extension
                let pathExtension = documentURL.pathExtension.lowercased()
                
                switch pathExtension {
                case "pdf":
                    if let pdfDocument = PDFDocument(url: documentURL) {
                        documentContent = .pdf(pdfDocument)
                    } else {
                        errorMessage = "Invalid or corrupted PDF file."
                    }
                case "txt":
                    let textContent = try String(contentsOf: documentURL, encoding: .utf8)
                    documentContent = .text(textContent)
                default:
                    documentContent = .unsupported
                }
            }
        } catch {
            errorMessage = "Error loading document: \(error.localizedDescription)"
        }
    }
}

struct PDFPreviewView: View {
    let pdfDocument: PDFDocument
    
    var body: some View {
        DocumentPDFView(pdfDocument: pdfDocument)
            .background(Color.white)
    }
}

struct DocumentPDFView: UIViewRepresentable {
    let pdfDocument: PDFDocument
    
    func makeUIView(context: Context) -> PDFView {
        let pdfView = PDFView()
        pdfView.document = pdfDocument
        pdfView.autoScales = true
        pdfView.displayMode = .singlePageContinuous
        pdfView.displayDirection = .vertical
        pdfView.backgroundColor = UIColor.white
        return pdfView
    }
    
    func updateUIView(_ pdfView: PDFView, context: Context) {
        pdfView.document = pdfDocument
    }
}

struct TextPreviewView: View {
    let content: String
    @State private var fontSize: Double = 16
    
    var body: some View {
        VStack(spacing: 0) {
            // Font size controls
            HStack {
                Text("Text Size")
                    .font(.caption)
                    .foregroundStyle(.gray)
                
                Spacer()
                
                HStack(spacing: 16) {
                    Button {
                        fontSize = max(12, fontSize - 2)
                    } label: {
                        Image(systemName: "textformat.size.smaller")
                            .font(.caption)
                            .foregroundStyle(fontSize > 12 ? Theme.primary : .gray)
                    }
                    .disabled(fontSize <= 12)
                    
                    Text("\(Int(fontSize))")
                        .font(.caption)
                        .foregroundStyle(.white)
                        .frame(minWidth: 20)
                    
                    Button {
                        fontSize = min(24, fontSize + 2)
                    } label: {
                        Image(systemName: "textformat.size.larger")
                            .font(.caption)
                            .foregroundStyle(fontSize < 24 ? Theme.primary : .gray)
                    }
                    .disabled(fontSize >= 24)
                }
            }
            .padding(.horizontal, 16)
            .padding(.vertical, 8)
            .background(
                RoundedRectangle(cornerRadius: 8)
                    .fill(Color.black.opacity(0.3))
                    .overlay(
                        RoundedRectangle(cornerRadius: 8)
                            .stroke(Color.white.opacity(0.2), lineWidth: 1)
                    )
            )
            .padding(.bottom, 12)
            
            // Text content
            ScrollView {
                Text(content)
                    .font(.system(size: fontSize))
                    .foregroundStyle(.white)
                    .multilineTextAlignment(.leading)
                    .lineSpacing(4)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .padding(16)
                    .background(
                        RoundedRectangle(cornerRadius: 12)
                            .fill(Color.black.opacity(0.4))
                            .overlay(
                                RoundedRectangle(cornerRadius: 12)
                                    .stroke(Color.white.opacity(0.1), lineWidth: 1)
                            )
                    )
            }
        }
    }
}

struct ShareButton: View {
    let documentURL: URL
    @State private var showShareSheet = false
    
    var body: some View {
        Button {
            showShareSheet = true
        } label: {
            Image(systemName: "square.and.arrow.up")
                .font(.title2)
                .foregroundStyle(.white.opacity(0.8))
        }
        .sheet(isPresented: $showShareSheet) {
            ShareSheet(activityItems: [documentURL])
        }
    }
}

struct ShareSheet: UIViewControllerRepresentable {
    let activityItems: [Any]
    
    func makeUIViewController(context: Context) -> UIActivityViewController {
        let activityViewController = UIActivityViewController(
            activityItems: activityItems,
            applicationActivities: nil
        )
        return activityViewController
    }
    
    func updateUIViewController(_ uiViewController: UIActivityViewController, context: Context) {}
}

#Preview {
    // Create a sample text file for preview
    if let sampleURL = Bundle.main.url(forResource: "sample", withExtension: "txt") {
        DocumentPreviewView(documentURL: sampleURL, documentTitle: "Sample Document")
    } else {
        Text("No sample document available")
    }
}
