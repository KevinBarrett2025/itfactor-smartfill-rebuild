import SwiftUI
import PDFKit

struct CombinedDocumentView: View {
    let documents: [DocumentReference]
    @Environment(\.dismiss) private var dismiss
    @State private var selectedDocument = 0
    @State private var isLoading = true
    @State private var loadedDocuments: [LoadedDocument] = []
    
    struct DocumentReference {
        let url: URL
        let title: String
        let type: DocumentType
    }
    
    enum DocumentType {
        case breakdown
        case sides
        case script
        case other(String)
        
        var displayName: String {
            switch self {
            case .breakdown: return "Breakdown"
            case .sides: return "Sides"
            case .script: return "Script"
            case .other(let name): return name
            }
        }
        
        var iconName: String {
            switch self {
            case .breakdown: return "doc.text"
            case .sides: return "theatermasks"
            case .script: return "doc.richtext"
            case .other: return "doc"
            }
        }
        
        var color: Color {
            switch self {
            case .breakdown: return .blue
            case .sides: return .purple
            case .script: return .green
            case .other: return .orange
            }
        }
    }
    
    private struct LoadedDocument {
        let reference: DocumentReference
        let content: DocumentContent
    }
    
    private enum DocumentContent {
        case pdf(PDFDocument)
        case text(String)
        case error(String)
    }
    
    var body: some View {
        NavigationStack {
            ZStack {
                BrandBackground()
                    .ignoresSafeArea()
                
                if isLoading {
                    loadingView
                } else {
                    VStack(spacing: 0) {
                        // Document Selector
                        documentSelector
                        
                        // Document Content
                        documentContentView
                    }
                }
            }
            .navigationTitle("Combined Documents")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    Button {
                        dismiss()
                    } label: {
                        Image(systemName: "xmark.circle.fill")
                            .font(.title2)
                            .foregroundStyle(.white.opacity(0.8))
                    }
                }
                
                ToolbarItem(placement: .navigationBarTrailing) {
                    if !loadedDocuments.isEmpty, selectedDocument < loadedDocuments.count {
                        ShareButton(documentURL: loadedDocuments[selectedDocument].reference.url)
                    }
                }
            }
        }
        .task {
            await loadAllDocuments()
        }
    }
    
    private var loadingView: some View {
        VStack(spacing: 16) {
            ProgressView()
                .scaleEffect(1.5)
                .tint(Theme.primary)
            
            Text("Loading documents...")
                .font(Theme.Font.body)
                .foregroundStyle(.white)
            
            Text("Combining \(documents.count) document\(documents.count == 1 ? "" : "s")")
                .font(Theme.Font.caption)
                .foregroundStyle(.gray)
        }
    }
    
    private var documentSelector: some View {
        ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: 12) {
                ForEach(0..<loadedDocuments.count, id: \.self) { index in
                    let document = loadedDocuments[index]
                    let isSelected = selectedDocument == index
                    
                    Button {
                        withAnimation(.easeInOut(duration: 0.2)) {
                            selectedDocument = index
                        }
                    } label: {
                        HStack(spacing: 8) {
                            Image(systemName: document.reference.type.iconName)
                                .font(.caption)
                                .foregroundStyle(isSelected ? .white : document.reference.type.color)
                            
                            Text(document.reference.type.displayName)
                                .font(.caption)
                                .fontWeight(isSelected ? .semibold : .medium)
                                .foregroundStyle(isSelected ? .white : document.reference.type.color)
                        }
                        .padding(.horizontal, 12)
                        .padding(.vertical, 8)
                        .background(
                            RoundedRectangle(cornerRadius: 20)
                                .fill(isSelected ? document.reference.type.color : document.reference.type.color.opacity(0.1))
                                .overlay(
                                    RoundedRectangle(cornerRadius: 20)
                                        .stroke(document.reference.type.color.opacity(0.3), lineWidth: 1)
                                )
                        )
                    }
                    .buttonStyle(PlainButtonStyle())
                }
            }
            .padding(.horizontal, 16)
        }
        .padding(.vertical, 12)
        .background(
            Rectangle()
                .fill(Color.black.opacity(0.2))
                .overlay(alignment: .bottom) {
                    Rectangle()
                        .frame(height: 1)
                        .foregroundColor(Color.white.opacity(0.1))
                }
        )
    }
    
    @ViewBuilder
    private var documentContentView: some View {
        if !loadedDocuments.isEmpty, selectedDocument < loadedDocuments.count {
            let selectedDoc = loadedDocuments[selectedDocument]
            
            switch selectedDoc.content {
            case .pdf(let pdfDocument):
                PDFPreviewView(pdfDocument: pdfDocument)
                    .background(Color.black.opacity(0.1))
                    .clipShape(RoundedRectangle(cornerRadius: 12))
                    .padding(.horizontal, 16)
                    .padding(.vertical, 8)
                
            case .text(let textContent):
                TextPreviewView(content: textContent)
                    .padding(.horizontal, 16)
                    .padding(.vertical, 8)
                
            case .error(let errorMessage):
                VStack(spacing: 16) {
                    Image(systemName: "exclamationmark.triangle")
                        .font(.system(size: 40))
                        .foregroundStyle(.red)
                    
                    Text("Error loading document")
                        .font(Theme.Font.headline)
                        .foregroundStyle(.white)
                    
                    Text(errorMessage)
                        .font(Theme.Font.caption)
                        .foregroundStyle(.gray)
                        .multilineTextAlignment(.center)
                        .padding(.horizontal)
                }
                .frame(maxWidth: .infinity, maxHeight: .infinity)
            }
        } else {
            VStack(spacing: 16) {
                Image(systemName: "doc.questionmark")
                    .font(.system(size: 60))
                    .foregroundStyle(.gray)
                
                Text("No documents available")
                    .font(Theme.Font.title)
                    .foregroundStyle(.white)
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity)
        }
    }
    
    private func loadAllDocuments() async {
        defer { isLoading = false }
        
        var loaded: [LoadedDocument] = []
        
        for document in documents {
            guard document.url.startAccessingSecurityScopedResource() else {
                loaded.append(LoadedDocument(
                    reference: document,
                    content: .error("Unable to access document file")
                ))
                continue
            }
            
            defer { document.url.stopAccessingSecurityScopedResource() }
            
            do {
                let resourceValues = try document.url.resourceValues(forKeys: [.contentTypeKey])
                
                if let contentType = resourceValues.contentType {
                    if contentType.conforms(to: .pdf) {
                        if let pdfDocument = PDFDocument(url: document.url) {
                            loaded.append(LoadedDocument(
                                reference: document,
                                content: .pdf(pdfDocument)
                            ))
                        } else {
                            loaded.append(LoadedDocument(
                                reference: document,
                                content: .error("Invalid PDF file")
                            ))
                        }
                    } else if contentType.conforms(to: .text) || contentType.conforms(to: .plainText) {
                        let textContent = try String(contentsOf: document.url, encoding: .utf8)
                        loaded.append(LoadedDocument(
                            reference: document,
                            content: .text(textContent)
                        ))
                    } else {
                        loaded.append(LoadedDocument(
                            reference: document,
                            content: .error("Unsupported file type")
                        ))
                    }
                } else {
                    // Fallback by extension
                    let pathExtension = document.url.pathExtension.lowercased()
                    
                    switch pathExtension {
                    case "pdf":
                        if let pdfDocument = PDFDocument(url: document.url) {
                            loaded.append(LoadedDocument(
                                reference: document,
                                content: .pdf(pdfDocument)
                            ))
                        } else {
                            loaded.append(LoadedDocument(
                                reference: document,
                                content: .error("Invalid PDF file")
                            ))
                        }
                    case "txt":
                        let textContent = try String(contentsOf: document.url, encoding: .utf8)
                        loaded.append(LoadedDocument(
                            reference: document,
                            content: .text(textContent)
                        ))
                    default:
                        loaded.append(LoadedDocument(
                            reference: document,
                            content: .error("Unsupported file type")
                        ))
                    }
                }
            } catch {
                loaded.append(LoadedDocument(
                    reference: document,
                    content: .error("Error loading: \(error.localizedDescription)")
                ))
            }
        }
        
        await MainActor.run {
            loadedDocuments = loaded
        }
    }
}

// MARK: - Helper Extensions

extension CombinedDocumentView.DocumentType {
    static func from(fileName: String) -> CombinedDocumentView.DocumentType {
        let lowercased = fileName.lowercased()
        
        if lowercased.contains("breakdown") {
            return .breakdown
        } else if lowercased.contains("sides") {
            return .sides
        } else if lowercased.contains("script") {
            return .script
        } else {
            return .other(fileName)
        }
    }
}

#Preview {
    CombinedDocumentView(documents: [
        CombinedDocumentView.DocumentReference(
            url: URL(fileURLWithPath: "/path/to/breakdown.pdf"),
            title: "Character Breakdown",
            type: .breakdown
        ),
        CombinedDocumentView.DocumentReference(
            url: URL(fileURLWithPath: "/path/to/sides.pdf"),
            title: "Scene Sides",
            type: .sides
        )
    ])
}