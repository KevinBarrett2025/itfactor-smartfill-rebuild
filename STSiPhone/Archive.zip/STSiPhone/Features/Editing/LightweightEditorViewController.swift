import UIKit
import AVFoundation
// NOTE: These dependencies need to be added via SPM:
// - PryntTrimmerView: https://github.com/HHK1/PryntTrimmerView
// - TOCropViewController: https://github.com/TimOliver/TOCropViewController
// import PryntTrimmerView
// import TOCropViewController
import SwiftUI

/// UPDATED: Swift 6 actor isolation compliance for AVFoundation operations
class LightweightEditorViewController: UIViewController, SmartFillProcessingDelegate {

    private var player: AVPlayer!
    private var playerLayer: AVPlayerLayer!
    private var trimmerView: UIView! // Placeholder for TrimmerView
    private var asset: AVAsset
    private var cropRect: CGRect?
    
    // PHASE 2: Smart Fill Settings Integration
    @State private var showingSmartFillSettings = false
    private var smartFillSettings = SmartFillSettings()
    
    // PHASE 3: Processing Integration Context
    public var takeID: UUID?
    public var sessionID: UUID?
    public var projectID: UUID?
    public var originalVideoPath: String?
    public var capturedOrientation: VideoOrientation?
    
    // CRITICAL FIX: Repository instance for SmartFill updates
    public var repository: ProjectsRepository?
    
    // Callback for saving edits
    var onSaveEdits: ((AVAsset, CMTimeRange?, CGRect?) -> Void)?
    var onCancel: (() -> Void)?
    
    // PHASE 2: Smart Fill Settings callback
    var onApplySmartFill: ((SmartFillSettings) -> Void)?
    
    // PHASE 3: SmartFill processing completion callback
    var onSmartFillComplete: ((String) -> Void)? // Called with SmartFill output path

    init(asset: AVAsset) {
        self.asset = asset
        super.init(nibName: nil, bundle: nil)
    }
    
    // PHASE 3: Enhanced initializer with processing context
    convenience init(
        asset: AVAsset,
        takeID: UUID,
        sessionID: UUID,
        projectID: UUID,
        originalVideoPath: String,
        capturedOrientation: VideoOrientation?,
        repository: ProjectsRepository? = nil
    ) {
        self.init(asset: asset)
        self.takeID = takeID
        self.sessionID = sessionID
        self.projectID = projectID
        self.originalVideoPath = originalVideoPath
        self.capturedOrientation = capturedOrientation
        self.repository = repository
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .black
        
        // CRITICAL FIX: Set up SmartFill processing delegate
        SmartFillProcessingManager.shared.delegate = self
        
        // UPDATED: Setup player on main actor for Swift 6 compliance
        Task { @MainActor in
            setupPlayer()
        }
        
        setupTrimmer()
        setupButtons()
    }
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        
        // 🚨 CRITICAL FIX: Use safe frame calculations to prevent "Invalid frame dimension" crashes
        let safeArea = view.safeAreaInsets
        let availableHeight = max(0, view.bounds.height - safeArea.top - safeArea.bottom)
        let playerHeight = max(100, availableHeight * 0.6) // Ensure minimum height
        
        let safeBounds = FrameSafety.safeBounds(from: view)
        let playerFrame = CGRect(
            x: 0,
            y: safeArea.top,
            width: max(100, safeBounds.width), // Ensure minimum width
            height: playerHeight
        )
        
        // Validate frame before setting
        let validatedFrame = FrameSafety.safeFrame(playerFrame)
        
        #if DEBUG
        FrameSafety.validateFrame(validatedFrame, context: "LightweightEditor PlayerLayer")
        #endif
        
        playerLayer?.frame = validatedFrame
    }
    
    // UPDATED: Swift 6 actor isolation compliance
    @MainActor
    private func setupPlayer() {
        // FIXED: AVPlayerItem creation is now on main actor (Swift 6 compliance)
        player = AVPlayer(playerItem: AVPlayerItem(asset: asset))
        playerLayer = AVPlayerLayer(player: player)
        playerLayer.videoGravity = .resizeAspect
        
        // Initial frame - will be updated in viewDidLayoutSubviews
        playerLayer.frame = CGRect(x: 0, y: 60, width: view.bounds.width, height: view.bounds.height / 2)
        view.layer.addSublayer(playerLayer)
        
        // Add tap gesture to play/pause
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(togglePlayback))
        view.addGestureRecognizer(tapGesture)
    }
    
    @objc private func togglePlayback() {
        if player.timeControlStatus == .playing {
            player.pause()
        } else {
            player.play()
        }
    }
    
    private func setupTrimmer() {
        // TODO: Replace with actual TrimmerView when dependencies are added
        // trimmerView = TrimmerView()
        // trimmerView.asset = asset
        // trimmerView.delegate = self
        // trimmerView.maxDuration = 60.0
        
        // Placeholder for now
        let placeholder = UIView()
        placeholder.backgroundColor = UIColor.gray.withAlphaComponent(0.3)
        placeholder.layer.cornerRadius = 8
        
        let label = UILabel()
        label.text = "Trimmer View (Add PryntTrimmerView dependency)"
        label.textColor = .white
        label.font = UIFont.systemFont(ofSize: 12)
        label.textAlignment = .center
        placeholder.addSubview(label)
        
        label.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([
            label.centerXAnchor.constraint(equalTo: placeholder.centerXAnchor),
            label.centerYAnchor.constraint(equalTo: placeholder.centerYAnchor)
        ])
        
        placeholder.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(placeholder)
        
        // 🚨 ENHANCED: Use priority-safe constraints to prevent layout conflicts
        NSLayoutConstraint.activate([
            placeholder.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: NSLayoutConstraint.safeConstant(20)),
            placeholder.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: NSLayoutConstraint.safeConstant(-20)),
            placeholder.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor, constant: NSLayoutConstraint.safeConstant(-100)),
            placeholder.heightAnchor.constraint(equalToConstant: NSLayoutConstraint.safeConstant(80))
        ])
        
        trimmerView = placeholder
    }
    
    private func setupButtons() {
        let cropButton = UIButton(type: .system)
        cropButton.setTitle("Crop", for: .normal)
        cropButton.setTitleColor(.white, for: .normal)
        cropButton.backgroundColor = UIColor.orange.withAlphaComponent(0.8)
        cropButton.layer.cornerRadius = 8
        cropButton.addTarget(self, action: #selector(openCrop), for: .touchUpInside)
        
        // PHASE 2: Smart Fill Settings Button
        let smartFillButton = UIButton(type: .system)
        smartFillButton.setTitle("Smart Fill", for: .normal)
        smartFillButton.setTitleColor(.white, for: .normal)
        smartFillButton.backgroundColor = UIColor.purple.withAlphaComponent(0.8)
        smartFillButton.layer.cornerRadius = 8
        
        // Add person.and.background.dotted icon
        let smartFillConfig = UIImage.SymbolConfiguration(pointSize: 16, weight: .medium)
        let smartFillIcon = UIImage(systemName: "person.and.background.dotted", withConfiguration: smartFillConfig)
        smartFillButton.setImage(smartFillIcon, for: .normal)
        smartFillButton.tintColor = .white
        
        // 🚨 CRITICAL FIX: Replace deprecated imageEdgeInsets with modern UIButton.Configuration
        if var config = smartFillButton.configuration {
            config.imagePadding = 8
            config.contentInsets = .init(top: 0, leading: 12, bottom: 0, trailing: 12)
            smartFillButton.configuration = config
        } else {
            // Fallback for buttons without configuration
            var config = UIButton.Configuration.plain()
            config.image = smartFillIcon
            config.title = "Smart Fill"
            config.imagePadding = 8
            config.contentInsets = .init(top: 0, leading: 12, bottom: 0, trailing: 12)
            config.baseForegroundColor = .white
            config.background.backgroundColor = UIColor.purple.withAlphaComponent(0.8)
            config.cornerStyle = .small
            smartFillButton.configuration = config
        }
        
        smartFillButton.addTarget(self, action: #selector(openSmartFillSettings), for: .touchUpInside)
        
        let saveButton = UIButton(type: .system)
        saveButton.setTitle("Save", for: .normal)
        saveButton.setTitleColor(.white, for: .normal)
        saveButton.backgroundColor = UIColor.green.withAlphaComponent(0.8)
        saveButton.layer.cornerRadius = 8
        saveButton.addTarget(self, action: #selector(saveEdits), for: .touchUpInside)
        
        let cancelButton = UIButton(type: .system)
        cancelButton.setTitle("Cancel", for: .normal)
        cancelButton.setTitleColor(.white, for: .normal)
        cancelButton.backgroundColor = UIColor.red.withAlphaComponent(0.8)
        cancelButton.layer.cornerRadius = 8
        cancelButton.addTarget(self, action: #selector(cancelEdits), for: .touchUpInside)
        
        let stack = UIStackView(arrangedSubviews: [cropButton, smartFillButton, cancelButton, saveButton])
        stack.axis = .horizontal
        stack.distribution = .fillEqually
        stack.spacing = 12
        stack.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(stack)
        
        NSLayoutConstraint.activate([
            stack.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            stack.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
            stack.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor, constant: -20),
            stack.heightAnchor.constraint(equalToConstant: 50)
        ])
    }
    
    @objc private func openCrop() {
        // TODO: Replace with actual TOCropViewController when dependencies are added
        let alert = UIAlertController(
            title: "Crop Feature",
            message: "Add TOCropViewController dependency to enable cropping",
            preferredStyle: .alert
        )
        alert.addAction(UIAlertAction(title: "OK", style: .default))
        present(alert, animated: true)
        
        /* Future implementation with TOCropViewController:
        let imageGenerator = AVAssetImageGenerator(asset: asset)
        if let cgImage = try? imageGenerator.copyCGImage(at: .zero, actualTime: nil) {
            let image = UIImage(cgImage: cgImage)
            let cropVC = CropViewController(image: image)
            cropVC.delegate = self
            present(cropVC, animated: true, completion: nil)
        }
        */
    }
    
    // PHASE 2: Smart Fill Settings Action with Preview
    @objc private func openSmartFillSettings() {
        // Get video URL for preview
        let previewURL: URL?
        var originalSize: CGSize?
        
        if let originalPath = originalVideoPath {
            previewURL = URL(fileURLWithPath: originalPath)
            
            // Extract original video size for preview
            Task { @MainActor in
                let previewAsset = AVURLAsset(url: URL(fileURLWithPath: originalPath))
                if let videoTrack = try? await previewAsset.loadTracks(withMediaType: .video).first {
                    let naturalSize = try? await videoTrack.load(.naturalSize)
                    originalSize = naturalSize
                }
            }
        } else {
            previewURL = nil
        }
        
        let smartFillModal = UIHostingController(
            rootView: SmartFillSettingsModal(
                currentSettings: smartFillSettings,
                previewVideoURL: previewURL,
                originalVideoSize: originalSize,
                onApplySettings: { [weak self] newSettings in
                    self?.smartFillSettings = newSettings
                    self?.onApplySmartFill?(newSettings)
                    
                    // PHASE 3: Trigger SmartFill processing with custom settings
                    self?.processWithSmartFill(settings: newSettings)
                },
                onCancel: {
                    // Modal dismisses automatically
                }
            )
        )
        
        smartFillModal.modalPresentationStyle = .pageSheet
        
        if let sheet = smartFillModal.sheetPresentationController {
            sheet.detents = [.medium(), .large()]
            sheet.prefersGrabberVisible = true
        }
        
        present(smartFillModal, animated: true)
    }
    
    // PHASE 3: SmartFill Processing Integration
    private func processWithSmartFill(settings: SmartFillSettings) {
        guard let takeID = takeID,
              let sessionID = sessionID,
              let projectID = projectID else {
            print("❌ LightweightEditorViewController: Missing context for SmartFill processing")
            showAlert(title: "Processing Error", message: "Missing video context information")
            return
        }
        
        // 🔥 CRITICAL FIX: Use asset URL if originalVideoPath is not available
        let originalPath: String
        if let originalVideoPath = originalVideoPath {
            originalPath = originalVideoPath
        } else {
            // Extract path from the asset
            if let urlAsset = asset as? AVURLAsset {
                originalPath = urlAsset.url.path
            } else {
                print("❌ LightweightEditorViewController: No original video path available")
                showAlert(title: "Processing Error", message: "Cannot determine video file location")
                return
            }
        }
        
        print("🎬 LightweightEditorViewController: Using original path: \(originalPath)")
        
        // 🔥 CRITICAL FIX: Add comprehensive validation before processing
        do {
            // Validate original file exists and is readable
            guard FileManager.default.fileExists(atPath: originalPath) else {
                print("❌ LightweightEditorViewController: Original file not found: \(originalPath)")
                
                // 🔥 ENHANCED: Try to find the file in common directories
                let fileName = URL(fileURLWithPath: originalPath).lastPathComponent
                print("🔍 Searching for file: \(fileName)")
                
                if let foundPath = VideoFileManager.shared.findVideoFile(named: fileName) {
                    print("✅ Found file at: \(foundPath)")
                    // Recursively call with the found path
                    let originalVideoPathBackup = self.originalVideoPath
                    self.originalVideoPath = foundPath
                    processWithSmartFill(settings: settings)
                    self.originalVideoPath = originalVideoPathBackup
                    return
                } else {
                    showAlert(title: "File Not Found", message: "Original video file could not be found. Please try recording the video again.")
                    return
                }
            }
            
            // SAFETY CHECK: Validate file is actually a video file
            let inputURL = URL(fileURLWithPath: originalPath)
            let asset = AVURLAsset(url: inputURL)
            
            // Quick validation to prevent crashes
            let videoTracks = asset.tracks(withMediaType: .video)
            guard !videoTracks.isEmpty else {
                print("❌ LightweightEditorViewController: No video tracks found in file")
                showAlert(title: "Invalid Video", message: "The selected file is not a valid video")
                return
            }
            
            // SAFETY CHECK: Validate settings are reasonable to prevent processing crashes
            guard settings.defaultBlurRadius >= 0 && settings.defaultBlurRadius <= 100,
                  settings.defaultDarkenAmount >= 0 && settings.defaultDarkenAmount <= 1.0,
                  settings.backgroundScale >= 1.0 && settings.backgroundScale <= 20.0 else {
                print("❌ LightweightEditorViewController: Invalid SmartFill settings")
                showAlert(title: "Invalid Settings", message: "SmartFill settings contain invalid values")
                return
            }
            
            // SAFETY CHECK: Validate render size is reasonable
            guard settings.defaultRenderSize.width >= 480 && settings.defaultRenderSize.width <= 4320,
                  settings.defaultRenderSize.height >= 270 && settings.defaultRenderSize.height <= 2160 else {
                print("❌ LightweightEditorViewController: Invalid render size")
                showAlert(title: "Invalid Render Size", message: "Render size must be between 480x270 and 4K resolution")
                return
            }
            
            // Generate output path for SmartFill result using relative path strategy
            let fileName = inputURL.deletingPathExtension().lastPathComponent
            let outputFileName = "\(fileName)_smartfill.mov" // Use .mov for compatibility
            let documentsPath = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
            let smartFillDir = documentsPath.appendingPathComponent("SmartFill")
            let outputPath = smartFillDir.appendingPathComponent(outputFileName).path
            
            // SAFETY CHECK: Ensure output path is different from input path
            guard outputPath != originalPath else {
                print("❌ LightweightEditorViewController: Output path same as input path")
                showAlert(title: "Path Conflict", message: "Cannot overwrite original video file")
                return
            }
            
            // Create SmartFill directory safely
            try FileManager.default.createDirectory(at: smartFillDir, withIntermediateDirectories: true)
            
            // SAFETY CHECK: Ensure we can write to output directory
            let testFile = smartFillDir.appendingPathComponent("test_write.tmp")
            try "test".write(to: testFile, atomically: true, encoding: .utf8)
            try FileManager.default.removeItem(at: testFile)
            
            print("🎬 LightweightEditorViewController: Validated inputs, starting SmartFill processing")
            print("   📁 Input: \(originalPath)")
            print("   📁 Output: \(outputPath)")
            print("   📱 Orientation: \(capturedOrientation?.displayName ?? "Unknown")")
            print("   ⚙️ Settings: Blur=\(settings.defaultBlurRadius), Darken=\(settings.defaultDarkenAmount), Scale=\(settings.backgroundScale)")
            print("   📐 Render Size: \(settings.defaultRenderSize)")
            
            // 🚀 CRITICAL FIX: Use SmartFillUnifiedInterface with delegate pattern
            Task {
                do {
                    let result = try await SmartFillUnifiedInterface.shared.processVideo(
                        inputURL: inputURL,
                        outputURL: URL(fileURLWithPath: outputPath),
                        settings: settings,
                        progressCallback: { progress in
                            DispatchQueue.main.async {
                                print("📊 SmartFill processing progress: \(Int(progress * 100))%")
                                // Could update UI here with progress indicator
                            }
                        }
                    )
                    
                    await MainActor.run {
                        print("✅ LightweightEditorViewController: SmartFill processing completed successfully")
                        print("   🎬 Compositor used: \(result.compositorUsed.displayName)")
                        print("   ⏱️ Processing time: \(String(format: "%.2f", result.processingTime))s")
                        
                        // Validate output file exists
                        if FileManager.default.fileExists(atPath: outputPath) {
                            // CRITICAL FIX: Update repository with SmartFill path
                            self.updateRepositoryWithSmartFillResult(takeID: takeID, sessionID: sessionID, projectID: projectID, outputPath: outputPath)
                            
                            self.showAlert(
                                title: "SmartFill Complete",
                                message: "Portrait video has been enhanced and is ready for export.",
                                completion: { [weak self] in
                                    self?.onSmartFillComplete?(outputPath)
                                }
                            )
                        } else {
                            self.showAlert(
                                title: "SmartFill Issue",
                                message: "SmartFill processing completed but the output file is not available. Please try again."
                            )
                        }
                    }
                    
                } catch {
                    await MainActor.run {
                        print("❌ LightweightEditorViewController: SmartFill processing failed: \(error)")
                        self.showAlert(
                            title: "SmartFill Failed",
                            message: "Could not process video: \(error.localizedDescription)"
                        )
                    }
                }
            }
            
            // Show processing feedback
            showProcessingAlert()
            
            print("✅ LightweightEditorViewController: SmartFill processing started with unified interface")
            
        } catch {
            print("❌ LightweightEditorViewController: SmartFill validation failed: \(error)")
            showAlert(
                title: "Validation Error",
                message: "Could not validate video for SmartFill processing: \(error.localizedDescription)"
            )
        }
    }
    
    // CRITICAL FIX: Method to update repository with SmartFill result
    private func updateRepositoryWithSmartFillResult(takeID: UUID, sessionID: UUID, projectID: UUID, outputPath: String) {
        guard let repository = repository else {
            print("❌ LightweightEditorViewController: No repository available for SmartFill update")
            return
        }
        
        // Convert absolute path to relative path for storage
        let outputURL = URL(fileURLWithPath: outputPath)
        let relativePath = VideoVariantResolver.relativePath(from: outputURL)
        
        repository.updateTakeWithSmartFillPath(
            takeID: takeID,
            smartFilledPath: relativePath,
            in: sessionID,
            in: projectID
        )
        
        print("✅ LightweightEditorViewController: Updated repository with SmartFill path")
        print("   📁 Relative path: \(relativePath)")
        
        // Post notification for UI updates
        NotificationCenter.default.post(
            name: Notification.Name("STSSmartFillCompleted"),
            object: nil,
            userInfo: [
                "takeID": takeID,
                "sessionID": sessionID,
                "projectID": projectID,
                "smartFillPath": outputPath,
                "relativePath": relativePath,
                "originalPath": originalVideoPath ?? ""
            ]
        )
    }
    
    // MARK: - SmartFillProcessingDelegate Methods
    
    public func smartFillDidFinish(takeID: UUID, outputURL: URL) {
        print("✅ LightweightEditorViewController: SmartFill delegate callback - processing completed")
        print("   📁 Output: \(outputURL.path)")
        
        DispatchQueue.main.async {
            // The repository update was already handled in processWithSmartFill
            // This is just a confirmation callback
        }
    }
    
    public func smartFillDidFail(takeID: UUID, error: Error) {
        print("❌ LightweightEditorViewController: SmartFill delegate callback - processing failed")
        print("   Error: \(error.localizedDescription)")
        
        DispatchQueue.main.async {
            self.showAlert(
                title: "SmartFill Processing Failed",
                message: "Could not process video: \(error.localizedDescription)"
            )
        }
    }
    
    private func handleSmartFillJobUpdate(_ notification: Notification) {
        // This method is now obsolete as we use SmartFillUnifiedInterface directly
        print("⚠️ LightweightEditorViewController: Legacy SmartFill job notification received - ignoring")
    }
    
    private func showProcessingAlert() {
        // 🔥 CRITICAL FIX: Check for existing modals before showing processing alert
        guard presentedViewController == nil else {
            print("⚠️ LightweightEditorViewController: Modal already presented, skipping processing alert")
            return
        }
        
        let alert = UIAlertController(
            title: "SmartFill Processing",
            message: "Your portrait video is being enhanced in the background. You'll be notified when complete.",
            preferredStyle: .alert
        )
        alert.addAction(UIAlertAction(title: "OK", style: .default))
        present(alert, animated: true)
    }
    
    private func showAlert(title: String, message: String, completion: (() -> Void)? = nil) {
        // 🔥 CRITICAL FIX: Prevent modal presentation conflicts
        guard presentedViewController == nil else {
            print("⚠️ LightweightEditorViewController: Modal already presented, queuing alert")
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                self.showAlert(title: title, message: message, completion: completion)
            }
            return
        }
        
        let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default) { _ in
            completion?()
        })
        present(alert, animated: true)
    }
    
    @objc private func saveEdits() {
        // Get trim range from trimmer (placeholder for now)
        let trimRange: CMTimeRange? = nil // TODO: Get from actual trimmer
        
        // Call completion handler
        onSaveEdits?(asset, trimRange, cropRect)
        
        dismiss(animated: true, completion: nil)
    }
    
    @objc private func cancelEdits() {
        onCancel?()
        dismiss(animated: true, completion: nil)
    }
    
    deinit {
        // Clean up observers
        NotificationCenter.default.removeObserver(self)
    }
}

// MARK: - Future TrimmerViewDelegate implementation
/*
extension LightweightEditorViewController: TrimmerViewDelegate {
    func didChangePositionBar(_ playerTime: CMTime) {
        player.seek(to: playerTime, toleranceBefore: .zero, toleranceAfter: .zero)
    }
}
*/

// MARK: - Future CropViewControllerDelegate implementation
/*
extension LightweightEditorViewController: CropViewControllerDelegate {
    func cropViewController(_ cropViewController: CropViewController, didCropToRect rect: CGRect, angle: Int) {
        cropRect = rect
        cropViewController.dismiss(animated: true, completion: nil)
    }
}
*/
