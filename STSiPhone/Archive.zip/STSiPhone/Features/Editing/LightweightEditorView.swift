import SwiftUI
import AVFoundation

struct LightweightEditorView: UIViewControllerRepresentable {
    let asset: AVAsset
    let onSave: (AVAsset, CMTimeRange?, CGRect?) -> Void
    let onCancel: () -> Void
    
    // PHASE 3: Optional processing context for SmartFill integration
    var takeID: UUID?
    var sessionID: UUID?
    var projectID: UUID?
    var originalVideoPath: String?
    var capturedOrientation: VideoOrientation?
    
    // PHASE 3: Enhanced initializer with processing context
    init(
        asset: AVAsset,
        onSave: @escaping (AVAsset, CMTimeRange?, CGRect?) -> Void,
        onCancel: @escaping () -> Void,
        takeID: UUID? = nil,
        sessionID: UUID? = nil,
        projectID: UUID? = nil,
        originalVideoPath: String? = nil,
        capturedOrientation: VideoOrientation? = nil
    ) {
        self.asset = asset
        self.onSave = onSave
        self.onCancel = onCancel
        self.takeID = takeID
        self.sessionID = sessionID
        self.projectID = projectID
        self.originalVideoPath = originalVideoPath
        self.capturedOrientation = capturedOrientation
    }
    
    func makeUIViewController(context: Context) -> LightweightEditorViewController {
        // PHASE 3: Use enhanced initializer if processing context is available
        let editor: LightweightEditorViewController
        
        if let takeID = takeID,
           let sessionID = sessionID,
           let projectID = projectID,
           let originalVideoPath = originalVideoPath {
            editor = LightweightEditorViewController(
                asset: asset,
                takeID: takeID,
                sessionID: sessionID,
                projectID: projectID,
                originalVideoPath: originalVideoPath,
                capturedOrientation: capturedOrientation,
                repository: SessionManager.shared.repositoryInstance  // CRITICAL FIX: Pass repository
            )
        } else {
            editor = LightweightEditorViewController(asset: asset)
        }
        
        editor.onSaveEdits = { asset, trimRange, cropRect in
            onSave(asset, trimRange, cropRect)
        }
        
        editor.onCancel = {
            onCancel()
        }
        
        return editor
    }
    
    func updateUIViewController(_ uiViewController: LightweightEditorViewController, context: Context) {
        // No updates needed
    }
}

// MARK: - Preview Helper
#Preview {
    // Create a simple test asset
    let url = Bundle.main.url(forResource: "test", withExtension: "mov") ?? URL(fileURLWithPath: "")

        let asset = AVURLAsset(url: url)

    LightweightEditorView(
        asset: asset,
        onSave: { asset, trimRange, cropRect in
            print("Save: \(asset), trim: \(String(describing: trimRange)), crop: \(String(describing: cropRect))")
        },
        onCancel: {
            print("Cancel")
        }
    )
}
