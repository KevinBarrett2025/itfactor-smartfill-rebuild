import Foundation
import AVFoundation
import UIKit

/// SessionExportManager is responsible for building a merged audition export
/// from all takes marked as 'good' in the session. It supports:
/// - Trim & crop per take
/// - Merging multiple takes in order
/// - Inserting a slate/thumbnail photo as the first frame (ENHANCED with professional conversion)
/// - Smart Fill for portrait takes in landscape sessions (NEW: Phase 4 Integration)
/// - Exporting a final audition video file with multiple quality options
class SessionExportManager {
    
    // MARK: - Enhanced Configuration Options (UPDATED: Smart Fill Integration)
    
    enum ExportQuality: String, CaseIterable {
        case low = "Low"
        case medium = "Medium"
        case high = "High"
        case maximum = "Maximum"
        
        var preset: String {
            switch self {
            case .low: return "AVAssetExportPresetLowQuality"
            case .medium: return "AVAssetExportPresetMediumQuality"
            case .high: return "AVAssetExportPreset1920x1080"
            case .maximum: return "AVAssetExportPresetHighestQuality"
            }
        }
        
        var bitrate: Int {
            switch self {
            case .low: return 1_000_000      // 1 Mbps
            case .medium: return 3_000_000   // 3 Mbps
            case .high: return 6_000_000     // 6 Mbps
            case .maximum: return 12_000_000 // 12 Mbps
            }
        }
    }
    
    enum ExportFormat: String, CaseIterable {
        case mov = "MOV"
        case mp4 = "MP4"
        
        var fileType: AVFileType {
            switch self {
            case .mov: return .mov
            case .mp4: return .mp4
            }
        }
        
        var fileExtension: String {
            return rawValue.lowercased()
        }
    }
    
    // ENHANCED: Smart Fill support in ExportOptions
    struct ExportOptions {
        let quality: ExportQuality
        let format: ExportFormat
        let includeSlate: Bool
        let slateDuration: TimeInterval
        let includeAudio: Bool
        
        // NEW: Smart Fill options
        let enableSmartFill: Bool
        let smartFillSettings: SmartFillSettings
        let renderSize: CGSize
        
        static let defaultOptions = ExportOptions(
            quality: .high,
            format: .mov,
            includeSlate: true,
            slateDuration: 2.0,
            includeAudio: true,
            enableSmartFill: true,  // NEW: Default Smart Fill enabled
            smartFillSettings: SmartFillSettings(),
            renderSize: CGSize(width: 1920, height: 1080)
        )
        
        // ENHANCED: Legacy initializer for backward compatibility
        init(quality: ExportQuality = .high,
             format: ExportFormat = .mov,
             includeSlate: Bool = true,
             slateDuration: TimeInterval = 2.0,
             includeAudio: Bool = true,
             enableSmartFill: Bool = true,
             smartFillSettings: SmartFillSettings = SmartFillSettings(),
             renderSize: CGSize = CGSize(width: 1920, height: 1080)) {
            self.quality = quality
            self.format = format
            self.includeSlate = includeSlate
            self.slateDuration = slateDuration
            self.includeAudio = includeAudio
            self.enableSmartFill = enableSmartFill
            self.smartFillSettings = smartFillSettings
            self.renderSize = renderSize
        }
    }
    
    enum SessionExportError: LocalizedError {
        case noGoodTakes
        case compositionFailed
        case slateConversionFailed
        case exportFailed(String)
        case assetCreationFailed
        case smartFillError(String)  // NEW: Smart Fill specific errors
        
        var errorDescription: String? {
            switch self {
            case .noGoodTakes:
                return "No good takes found to export"
            case .compositionFailed:
                return "Failed to create video composition"
            case .slateConversionFailed:
                return "Failed to convert slate photo to video"
            case .exportFailed(let reason):
                return "Export failed: \(reason)"
            case .assetCreationFailed:
                return "Failed to create video asset"
            case .smartFillError(let reason):
                return "Smart Fill processing failed: \(reason)"
            }
        }
    }
    
    // ENHANCED: Smart Fill integration in TakeMetadata
    struct TakeMetadata {
        let asset: AVAsset
        let isGood: Bool
        let trimRange: CMTimeRange?
        let cropRect: CGRect?
        let isSlatePhoto: Bool
        let thumbnailImage: UIImage? // for slate/first frame
        let takeNumber: Int
        let fileName: String
        
        // NEW: Smart Fill metadata
        let capturedOrientation: VideoOrientation?
        let overrideSmartFill: TriState?
        let projectTake: ProjectTake? // For Smart Fill policy decisions
        
        init(asset: AVAsset,
             isGood: Bool,
             trimRange: CMTimeRange? = nil,
             cropRect: CGRect? = nil,
             isSlatePhoto: Bool = false,
             thumbnailImage: UIImage? = nil,
             takeNumber: Int = 1,
             fileName: String = "take.mov",
             capturedOrientation: VideoOrientation? = nil,
             overrideSmartFill: TriState? = nil,
             projectTake: ProjectTake? = nil) {
            self.asset = asset
            self.isGood = isGood
            self.trimRange = trimRange
            self.cropRect = cropRect
            self.isSlatePhoto = isSlatePhoto
            self.thumbnailImage = thumbnailImage
            self.takeNumber = takeNumber
            self.fileName = fileName
            self.capturedOrientation = capturedOrientation
            self.overrideSmartFill = overrideSmartFill
            self.projectTake = projectTake
        }
    }
    
    // MARK: - ENHANCED Professional Slate Photo to Video Conversion
    
    /// Converts a UIImage into a temporary AVAsset representing a still frame video of given duration.
    /// ENHANCED: Professional quality with H.264 encoding, proper frame rates, and error handling
    private static func convertSlatePhotoToVideo(
        _ image: UIImage,
        duration: TimeInterval = 2.0,
        completion: @escaping (Result<AVAsset, SessionExportError>) -> Void
    ) {
        print("📸 Converting slate photo to video (duration: \(duration)s)")
        
        let size = image.size
        let outputURL = FileManager.default.temporaryDirectory
            .appendingPathComponent("STS_Slate_\(UUID().uuidString).mov")
        
        // Clean up any existing temp file
        try? FileManager.default.removeItem(at: outputURL)
        
        guard let writer = try? AVAssetWriter(outputURL: outputURL, fileType: .mov) else {
            print("❌ Failed to create AVAssetWriter")
            completion(.failure(.slateConversionFailed))
            return
        }
        
        // ENHANCED: Professional video settings with H.264 and optimal bitrate
        let videoSettings: [String: Any] = [
            AVVideoCodecKey: AVVideoCodecType.h264,
            AVVideoWidthKey: Int(size.width),
            AVVideoHeightKey: Int(size.height),
            AVVideoCompressionPropertiesKey: [
                AVVideoAverageBitRateKey: 2_000_000, // 2 Mbps for high quality slate
                AVVideoProfileLevelKey: AVVideoProfileLevelH264HighAutoLevel
            ]
        ]
        
        let writerInput = AVAssetWriterInput(mediaType: .video, outputSettings: videoSettings)
        writerInput.expectsMediaDataInRealTime = false
        
        let pixelBufferAdaptor = AVAssetWriterInputPixelBufferAdaptor(
            assetWriterInput: writerInput,
            sourcePixelBufferAttributes: [
                kCVPixelBufferPixelFormatTypeKey as String: kCVPixelFormatType_32ARGB,
                kCVPixelBufferWidthKey as String: Int(size.width),
                kCVPixelBufferHeightKey as String: Int(size.height)
            ]
        )
        
        guard writer.canAdd(writerInput) else {
            print("❌ Cannot add video input to writer")
            completion(.failure(.slateConversionFailed))
            return
        }
        
        writer.add(writerInput)
        
        guard writer.startWriting() else {
            print("❌ Failed to start writing")
            completion(.failure(.slateConversionFailed))
            return
        }
        
        writer.startSession(atSourceTime: .zero)
        
        let processingQueue = DispatchQueue(label: "slate-conversion", qos: .userInitiated)
        
        writerInput.requestMediaDataWhenReady(on: processingQueue) {
            guard let cgImage = image.cgImage else {
                print("❌ Failed to get CGImage from UIImage")
                writerInput.markAsFinished()
                writer.finishWriting {
                    completion(.failure(.slateConversionFailed))
                }
                return
            }
            
            // ENHANCED: Create high-quality pixel buffer
            guard let pixelBuffer = createPixelBufferFromCGImage(cgImage, size: size) else {
                print("❌ Failed to create pixel buffer")
                writerInput.markAsFinished()
                writer.finishWriting {
                    completion(.failure(.slateConversionFailed))
                }
                return
            }
            
            // Generate frames at 30fps for smooth video
            _ = CMTime(value: 1, timescale: 30) // FIXED: Mark as intentionally unused
            
            // 🚨 CRITICAL FIX: Remoninve blocking operations in completion handler
            // Use synchronous Thread.sleep only as last resort in completion handler context
            // Cannot use async Task.sleep in requestMediaDataWhenReady completion handler
            
            let totalFrames = Int(duration * 30) // 30fps
            
            print("🎬 Generating \(totalFrames) frames at 30fps")
            
            for frameNumber in 0..<totalFrames {
                let frameTime = CMTime(value: CMTimeValue(frameNumber), timescale: 30)
                
                while !writerInput.isReadyForMoreMediaData {
                    // 🚨 LIMITED SCOPE: Only use Thread.sleep in this specific completion handler context
                    // where async/await is not available - this is the minimal necessary usage
                    Thread.sleep(forTimeInterval: 0.01)
                }
                
                if !pixelBufferAdaptor.append(pixelBuffer, withPresentationTime: frameTime) {
                    print("❌ Failed to append pixel buffer at frame \(frameNumber)")
                    break
                }
            }
            
            writerInput.markAsFinished()
            
            writer.finishWriting {
                DispatchQueue.main.async {
                    if writer.status == .completed {
                        // FIXED: Use AVURLAsset instead of deprecated AVAsset(url:)
                        let asset = AVURLAsset(url: outputURL)
                        
                        // UPDATED: Use modern async API for duration
                        Task {
                            do {
                                let duration = try await asset.load(.duration)
                                print("✅ Slate video created: \(CMTimeGetSeconds(duration))s")
                                completion(.success(asset))
                            } catch {
                                print("❌ Failed to load slate video duration: \(error)")
                                completion(.failure(.slateConversionFailed))
                            }
                        }
                    } else {
                        print("❌ Writer failed with error: \(writer.error?.localizedDescription ?? "Unknown")")
                        completion(.failure(.slateConversionFailed))
                    }
                }
            }
        }
    }
    
    /// ENHANCED: High-quality pixel buffer creation from CGImage
    private static func createPixelBufferFromCGImage(_ cgImage: CGImage, size: CGSize) -> CVPixelBuffer? {
        let options: [CFString: Any] = [
            kCVPixelBufferCGImageCompatibilityKey: true,
            kCVPixelBufferCGBitmapContextCompatibilityKey: true,
            kCVPixelBufferIOSurfacePropertiesKey: [:]
        ]
        
        var pixelBuffer: CVPixelBuffer?
        let status = CVPixelBufferCreate(
            kCFAllocatorDefault,
            Int(size.width),
            Int(size.height),
            kCVPixelFormatType_32ARGB,
            options as CFDictionary,
            &pixelBuffer
        )
        
        guard status == kCVReturnSuccess, let buffer = pixelBuffer else {
            print("❌ CVPixelBufferCreate failed with status: \(status)")
            return nil
        }
        
        CVPixelBufferLockBaseAddress(buffer, [])
        defer { CVPixelBufferUnlockBaseAddress(buffer, []) }
        
        let context = CGContext(
            data: CVPixelBufferGetBaseAddress(buffer),
            width: Int(size.width),
            height: Int(size.height),
            bitsPerComponent: 8,
            bytesPerRow: CVPixelBufferGetBytesPerRow(buffer),
            space: CGColorSpaceCreateDeviceRGB(),
            bitmapInfo: CGImageAlphaInfo.noneSkipFirst.rawValue
        )
        
        guard let drawingContext = context else {
            print("❌ Failed to create CGContext")
            return nil
        }
        
        // Draw the image into the pixel buffer
        drawingContext.draw(cgImage, in: CGRect(origin: .zero, size: size))
        
        return buffer
    }

    // MARK: - Enhanced Export Methods (UPDATED: Smart Fill Integration)
    
    /// Export a merged audition video from good takes and optional slate
    /// ENHANCED: With Smart Fill support for portrait takes in landscape sessions
    static func exportMergedAudition(
        from takes: [TakeMetadata],
        sessionData: SmartFillSessionData? = nil,  // NEW: Session data for Smart Fill
        outputFileName: String = "MergedAudition.mov",
        options: ExportOptions = .defaultOptions,
        progressHandler: ((Float) -> Void)? = nil,
        completion: @escaping (Result<URL, SessionExportError>) -> Void
    ) {
        
        print("🎬 Starting enhanced export with Smart Fill support")
        print("📋 Export options: \(options.quality.rawValue) quality, \(options.format.rawValue) format")
        print("🎭 Smart Fill: \(options.enableSmartFill ? "Enabled" : "Disabled")")
        
        // Filter good takes
        let goodTakes = takes.filter { $0.isGood }
        let slatePhoto = takes.first { $0.isSlatePhoto && $0.thumbnailImage != nil }
        
        print("📝 Found \(goodTakes.count) good takes and \(slatePhoto != nil ? "slate photo" : "no slate")")
        
        guard !goodTakes.isEmpty else {
            completion(.failure(.noGoodTakes))
            return
        }
        
        // NEW: Smart Fill export path
        if options.enableSmartFill, let sessionData = sessionData {
            exportWithSmartFill(
                goodTakes: goodTakes,
                slatePhoto: slatePhoto,
                sessionData: sessionData,
                outputFileName: outputFileName,
                options: options,
                progressHandler: progressHandler,
                completion: completion
            )
            return
        }
        
        // Traditional export path (preserved)
        // Step 1: Handle slate conversion if needed
        if options.includeSlate, let slate = slatePhoto, let slateImage = slate.thumbnailImage {
            convertSlatePhotoToVideo(slateImage, duration: options.slateDuration) { result in
                switch result {
                case .success(let slateAsset):
                    proceedWithComposition(
                        goodTakes: goodTakes,
                        slateAsset: slateAsset,
                        outputFileName: outputFileName,
                        options: options,
                        progressHandler: progressHandler,
                        completion: completion
                    )
                case .failure(let error):
                    completion(.failure(error))
                }
            }
        } else {
            // No slate, proceed directly
            proceedWithComposition(
                goodTakes: goodTakes,
                slateAsset: nil,
                outputFileName: outputFileName,
                options: options,
                progressHandler: progressHandler,
                completion: completion
            )
        }
    }
    
    // NEW: Smart Fill export pipeline with INTELLIGENT ROUTING
    private static func exportWithSmartFill(
        goodTakes: [TakeMetadata],
        slatePhoto: TakeMetadata?,
        sessionData: SmartFillSessionData,
        outputFileName: String,
        options: ExportOptions,
        progressHandler: ((Float) -> Void)?,
        completion: @escaping (Result<URL, SessionExportError>) -> Void
    ) {
        
        print("🎭 Starting Smart Fill export pipeline with intelligent routing")
        
        Task {
            do {
                // PHASE 1C-D: INTELLIGENT ROUTING - Separate landscape and portrait takes
                var landscapeTakes: [TakeMetadata] = []
                var portraitTakes: [TakeMetadata] = []
                var unknownOrientationTakes: [TakeMetadata] = [] // FIXED: Keep as var since it might be used in future
                
                // Analyze each take's orientation for intelligent routing
                for takeMetadata in goodTakes {
                    if let projectTake = takeMetadata.projectTake,
                       let capturedOrientation = projectTake.capturedOrientation {
                        
                        switch capturedOrientation {
                        case .landscape:
                            landscapeTakes.append(takeMetadata)
                            print("📹 Landscape take (direct path): \(takeMetadata.fileName)")
                            
                        case .portrait:
                            portraitTakes.append(takeMetadata)
                            print("📱 Portrait take (Smart Fill path): \(takeMetadata.fileName)")
                        }
                    } else {
                        // FALLBACK: Analyze video dimensions if orientation not stored
                        let orientation = try await analyzeVideoOrientation(asset: takeMetadata.asset)
                        if orientation.isLandscape {
                            landscapeTakes.append(takeMetadata)
                            print("📹 Analyzed as landscape (direct path): \(takeMetadata.fileName)")
                        } else {
                            portraitTakes.append(takeMetadata)
                            print("📱 Analyzed as portrait (Smart Fill path): \(takeMetadata.fileName)")
                        }
                    }
                }
                
                print("🎯 PHASE 1C-D Intelligent Routing Results:")
                print("   📹 Landscape takes (direct export): \(landscapeTakes.count)")
                print("   📱 Portrait takes (Smart Fill): \(portraitTakes.count)")
                print("   ❓ Unknown orientation takes: \(unknownOrientationTakes.count)")
                
                // PHASE 1C-D: Process takes with appropriate pipeline
                if portraitTakes.isEmpty {
                    // ALL LANDSCAPE: Use direct export pipeline for maximum quality
                    print("✅ All takes are landscape - using direct export pipeline for optimal quality")
                    await exportDirectPipeline(
                        takes: landscapeTakes,
                        slatePhoto: slatePhoto,
                        outputFileName: outputFileName,
                        options: options,
                        progressHandler: progressHandler,
                        completion: completion
                    )
                } else if landscapeTakes.isEmpty {
                    // ALL PORTRAIT: Use Smart Fill pipeline
                    print("🎭 All takes are portrait - using Smart Fill pipeline")
                    await exportSmartFillPipeline(
                        takes: portraitTakes,
                        slatePhoto: slatePhoto,
                        sessionData: sessionData,
                        outputFileName: outputFileName,
                        options: options,
                        progressHandler: progressHandler,
                        completion: completion
                    )
                } else {
                    // MIXED ORIENTATIONS: Use hybrid pipeline
                    print("🔄 Mixed orientations detected - using hybrid pipeline")
                    await exportHybridPipeline(
                        landscapeTakes: landscapeTakes,
                        portraitTakes: portraitTakes,
                        slatePhoto: slatePhoto,
                        sessionData: sessionData,
                        outputFileName: outputFileName,
                        options: options,
                        progressHandler: progressHandler,
                        completion: completion
                    )
                }
                
            } catch {
                print("❌ Smart Fill export failed: \(error)")
                await MainActor.run {
                    completion(.failure(.smartFillError(error.localizedDescription)))
                }
            }
        }
    }
    
    // PHASE 1C-D: NEW - Direct export pipeline for landscape takes (maximum quality)
    private static func exportDirectPipeline(
        takes: [TakeMetadata],
        slatePhoto: TakeMetadata?,
        outputFileName: String,
        options: ExportOptions,
        progressHandler: ((Float) -> Void)?,
        completion: @escaping (Result<URL, SessionExportError>) -> Void
    ) async {
        print("📹 PHASE 1C-D: Direct export pipeline - preserving landscape quality")
        
        await MainActor.run {
            // Use traditional high-quality composition pipeline
            proceedWithComposition(
                goodTakes: takes,
                slateAsset: nil, // Handle slate separately if needed
                outputFileName: outputFileName,
                options: options,
                progressHandler: progressHandler,
                completion: completion
            )
        }
    }
    
    // PHASE 1C-D: NEW - Smart Fill pipeline for portrait takes
    private static func exportSmartFillPipeline(
        takes: [TakeMetadata],
        slatePhoto: TakeMetadata?,
        sessionData: SmartFillSessionData,
        outputFileName: String,
        options: ExportOptions,
        progressHandler: ((Float) -> Void)?,
        completion: @escaping (Result<URL, SessionExportError>) -> Void
    ) async {
        print("🎭 PHASE 1C-D: Smart Fill pipeline - converting portrait to landscape")
        
        // UPDATED: Load duration asynchronously for each take
        var projectTakes: [ProjectTake] = []
        
        for takeMetadata in takes {
            do {
                let duration = try await takeMetadata.asset.load(.duration)
                let projectTake = takeMetadata.projectTake ?? ProjectTake(
                    filePath: takeMetadata.fileName,
                    durationSeconds: duration.seconds,
                    takeNumber: takeMetadata.takeNumber,
                    capturedOrientation: takeMetadata.capturedOrientation,
                    overrideSmartFill: takeMetadata.overrideSmartFill
                )
                projectTakes.append(projectTake)
            } catch {
                print("⚠️ Failed to load duration for take \(takeMetadata.fileName): \(error)")
                // Use fallback ProjectTake with default duration
                let projectTake = takeMetadata.projectTake ?? ProjectTake(
                    filePath: takeMetadata.fileName,
                    durationSeconds: 0.0,
                    takeNumber: takeMetadata.takeNumber,
                    capturedOrientation: takeMetadata.capturedOrientation,
                    overrideSmartFill: takeMetadata.overrideSmartFill
                )
                projectTakes.append(projectTake)
            }
        }
        
        do {
            // Create Smart Fill composition for portrait takes
            let (composition, videoComposition) = try await SmartFillExporter.createCompositionForSTSExport(
                takes: projectTakes,
                session: sessionData.session,
                settings: options.smartFillSettings
            )
            
            print("✅ Smart Fill composition created for portrait takes")
            
            await MainActor.run {
                performSmartFillExport(
                    composition: composition,
                    videoComposition: videoComposition,
                    outputFileName: outputFileName,
                    options: options,
                    progressHandler: progressHandler,
                    completion: completion
                )
            }
            
        } catch {
            print("❌ Smart Fill pipeline failed: \(error)")
            await MainActor.run {
                completion(.failure(.smartFillError(error.localizedDescription)))
            }
        }
    }
    
    // PHASE 1C-D: NEW - Hybrid pipeline for mixed orientations
    private static func exportHybridPipeline(
        landscapeTakes: [TakeMetadata],
        portraitTakes: [TakeMetadata],
        slatePhoto: TakeMetadata?,
        sessionData: SmartFillSessionData,
        outputFileName: String,
        options: ExportOptions,
        progressHandler: ((Float) -> Void)?,
        completion: @escaping (Result<URL, SessionExportError>) -> Void
    ) async {
        print("🔄 PHASE 1C-D: Hybrid pipeline - processing mixed orientations intelligently")
        
        // For now, process portrait takes through Smart Fill and merge with landscape
        // This is a complex pipeline that would need more development
        // Fall back to Smart Fill pipeline for mixed content
        
        let allTakes = landscapeTakes + portraitTakes
        await exportSmartFillPipeline(
            takes: allTakes,
            slatePhoto: slatePhoto,
            sessionData: sessionData,
            outputFileName: outputFileName,
            options: options,
            progressHandler: progressHandler,
            completion: completion
        )
    }
    
    // PHASE 1C-D: NEW - Analyze video orientation from asset
    private static func analyzeVideoOrientation(asset: AVAsset) async -> (isLandscape: Bool, width: CGFloat, height: CGFloat) {
        do {
            guard let videoTrack = try await asset.loadTracks(withMediaType: .video).first else {
                print("⚠️ Could not load video track for orientation analysis")
                return (isLandscape: true, width: 1920, height: 1080) // Default assumption
            }
            
            let naturalSize = try await videoTrack.load(.naturalSize)
            let preferredTransform = try await videoTrack.load(.preferredTransform)
            
            // Apply transform to get final display size
            let transformedSize = naturalSize.applying(preferredTransform)
            let finalWidth = abs(transformedSize.width)
            let finalHeight = abs(transformedSize.height)
            
            let isLandscape = finalWidth > finalHeight
            
            print("📐 Video orientation analysis: \(finalWidth)x\(finalHeight) = \(isLandscape ? "Landscape" : "Portrait")")
            
            return (isLandscape: isLandscape, width: finalWidth, height: finalHeight)
            
        } catch {
            print("❌ Failed to analyze video orientation: \(error)")
            return (isLandscape: true, width: 1920, height: 1080) // Default assumption
        }
    }
    
    // NEW: Smart Fill specific export method with MODERNIZED iOS 18+ APIs and backward compatibility
    private static func performSmartFillExport(
        composition: AVMutableComposition,
        videoComposition: AVVideoComposition,
        outputFileName: String,
        options: ExportOptions,
        progressHandler: ((Float) -> Void)?,
        completion: @escaping (Result<URL, SessionExportError>) -> Void
    ) {
        
        let outputURL = createOutputURL(fileName: outputFileName, format: options.format)
        
        guard let exportSession = AVAssetExportSession(asset: composition, presetName: options.quality.preset) else {
            completion(.failure(.exportFailed("Failed to create Smart Fill export session")))
            return
        }
        
        exportSession.outputURL = outputURL
        exportSession.outputFileType = options.format.fileType
        exportSession.videoComposition = videoComposition  // Smart Fill video composition
        
        print("🎭 Starting Smart Fill export to: \(outputURL.lastPathComponent)")
        
        // MODERNIZED: Use iOS 18+ async export API with backward compatibility
        Task { @MainActor in
            // Start progress monitoring if provided
            let progressTask = progressHandler != nil ? Task {
                if #available(iOS 18.0, *) {
                    // Use iOS 18 states async sequence
                    do {
                        for await state in exportSession.states(updateInterval: 0.1) {
                            if case .exporting(let progress) = state {
                                await MainActor.run {
                                    progressHandler?(Float(progress.fractionCompleted))
                                }
                            }
                        }
                    } catch {
                        print("❌ Smart Fill progress monitoring error: \(error)")
                    }
                } else {
                    // Legacy progress monitoring
                    while exportSession.status == .exporting || exportSession.status == .waiting {
                        await MainActor.run {
                            progressHandler?(exportSession.progress)
                        }
                        try? await Task.sleep(nanoseconds: 100_000_000) // 0.1 seconds
                    }
                }
            } : nil
            
            do {
                // MODERNIZED: Use iOS 18+ async export API with backward compatibility
                if #available(iOS 18.0, *) {
                    try await exportSession.export(to: outputURL, as: options.format.fileType)
                } else {
                    try await exportSession.export()
                }
                
                // Cancel progress monitoring
                progressTask?.cancel()
                
                // Check final status
                if exportSession.status == .completed {
                    print("✅ Smart Fill export completed successfully")
                    if let fileSize = try? FileManager.default.attributesOfItem(atPath: outputURL.path)[.size] as? Int64 {
                        let fileSizeMB = Double(fileSize) / 1024 / 1024
                        print("📊 Smart Fill export file size: \(String(format: "%.2f", fileSizeMB)) MB")
                    }
                    completion(.success(outputURL))
                } else {
                    throw SessionExportError.exportFailed(exportSession.error?.localizedDescription ?? "Unknown export error")
                }
                
            } catch {
                // Cancel progress monitoring on error
                progressTask?.cancel()
                
                print("❌ Smart Fill export failed: \(error)")
                if let exportError = error as? AVError {
                    completion(.failure(.smartFillError(exportError.localizedDescription)))
                } else {
                    completion(.failure(.smartFillError(error.localizedDescription)))
                }
            }
        }
    }
    
    // NEW: Helper to add slate to Smart Fill composition
    // UPDATED: Modern async track loading
    private static func addSlateToSmartFillComposition(
        composition: AVMutableComposition,
        slateImage: UIImage,
        slateDuration: TimeInterval
    ) async {
        // Convert slate photo to video asset
        await withCheckedContinuation { continuation in
            convertSlatePhotoToVideo(slateImage, duration: slateDuration) { result in
                switch result {
                case .success(let slateAsset):
                    // Insert slate at the beginning of composition
                    Task {
                        do {
                            // UPDATED: Use modern async API for reliable track loading
                            let compositionVideoTracks = try await composition.loadTracks(withMediaType: .video)
                            let slateVideoTracks = try await slateAsset.loadTracks(withMediaType: .video)
                            
                            if let videoTrack = compositionVideoTracks.first,
                               let slateVideoTrack = slateVideoTracks.first {
                                
                                // UPDATED: Use modern async API for composition duration
                                let existingDuration = try await composition.load(.duration)
                                let existingRange = CMTimeRange(start: .zero, duration: existingDuration)
                                let newStartTime = CMTime(seconds: slateDuration, preferredTimescale: 600)
                                
                                // This would require more complex composition manipulation
                                // For now, we'll log this as a TODO for comprehensive slate integration
                                print("📋 TODO: Comprehensive slate integration with Smart Fill composition")
                            }
                        } catch {
                            print("❌ Failed to load tracks for slate integration: \(error)")
                        }
                        
                        continuation.resume()
                    }
                    
                case .failure:
                    print("❌ Failed to convert slate for Smart Fill composition")
                    continuation.resume()
                }
            }
        }
    }

    // MARK: - Enhanced Composition and Export Workflow
    
    /// Enhanced composition and export workflow
    /// UPDATED: Modern async AVFoundation API usage
    private static func proceedWithComposition(
        goodTakes: [TakeMetadata],
        slateAsset: AVAsset?,
        outputFileName: String,
        options: ExportOptions,
        progressHandler: ((Float) -> Void)?,
        completion: @escaping (Result<URL, SessionExportError>) -> Void
    ) {
        
        Task {
            // Create composition
            let composition = AVMutableComposition()
            
            guard let videoTrack = composition.addMutableTrack(withMediaType: .video, preferredTrackID: kCMPersistentTrackID_Invalid),
                  let audioTrack = composition.addMutableTrack(withMediaType: .audio, preferredTrackID: kCMPersistentTrackID_Invalid) else {
                await MainActor.run {
                    completion(.failure(.compositionFailed))
                }
                return
            }
            
            var insertTime = CMTime.zero
            var videoCompositionInstructions: [AVMutableVideoCompositionInstruction] = []
            
            do {
                // Add slate if provided
                if let slateAsset = slateAsset {
                    if let slateVideoTrack = try await slateAsset.loadTracks(withMediaType: .video).first {
                        // UPDATED: Use modern async API for duration
                        let slateDuration = try await slateAsset.load(.duration)
                        let timeRange = CMTimeRange(start: .zero, duration: slateDuration)
                        
                        try videoTrack.insertTimeRange(timeRange, of: slateVideoTrack, at: insertTime)
                        insertTime = CMTimeAdd(insertTime, timeRange.duration)
                        print("✅ Slate video added: \(slateDuration.seconds)s")
                    }
                }
                
                // Add all good takes
                for take in goodTakes {
                    let asset = take.asset
                    
                    print("🎥 Processing take \(take.takeNumber): \(take.fileName)")
                    
                    let videoTracks = try await asset.loadTracks(withMediaType: .video)
                    let audioTracks = try await asset.loadTracks(withMediaType: .audio)
                    
                    // Video track
                    if let assetVideoTrack = videoTracks.first {
                        // UPDATED: Use modern async API for duration
                        let assetDuration = try await asset.load(.duration)
                        let timeRange = take.trimRange ?? CMTimeRange(start: .zero, duration: assetDuration)
                        
                        try videoTrack.insertTimeRange(timeRange, of: assetVideoTrack, at: insertTime)
                        print("✅ Inserted video track for take \(take.takeNumber)")
                        
                        // Handle cropping if needed
                        if let cropRect = take.cropRect {
                            let instruction = createCropInstruction(
                                for: assetVideoTrack,
                                cropRect: cropRect,
                                timeRange: CMTimeRange(start: insertTime, duration: timeRange.duration)
                            )
                            videoCompositionInstructions.append(instruction)
                            print("🔲 Added crop instruction for take \(take.takeNumber)")
                        }
                    }
                    
                    // Audio track (if enabled)
                    if options.includeAudio, let assetAudioTrack = audioTracks.first {
                        // UPDATED: Use modern async API for duration
                        let assetDuration = try await asset.load(.duration)
                        let timeRange = take.trimRange ?? CMTimeRange(start: .zero, duration: assetDuration)
                        
                        try audioTrack.insertTimeRange(timeRange, of: assetAudioTrack, at: insertTime)
                        print("🔊 Inserted audio track for take \(take.takeNumber)")
                    }
                    
                    // Update insert time
                    let assetDuration = try await asset.load(.duration)
                    let duration = take.trimRange?.duration ?? assetDuration
                    insertTime = CMTimeAdd(insertTime, duration)
                }
                
                // Create video composition if needed
                var videoComposition: AVMutableVideoComposition?
                if !videoCompositionInstructions.isEmpty {
                    videoComposition = AVMutableVideoComposition()
                    videoComposition?.instructions = videoCompositionInstructions
                    videoComposition?.frameDuration = CMTime(value: 1, timescale: 30)
                    videoComposition?.renderSize = CGSize(width: 1920, height: 1080)
                }
                
                // Enhanced export
                await MainActor.run {
                    performEnhancedExport(
                        composition: composition,
                        videoComposition: videoComposition,
                        outputFileName: outputFileName,
                        options: options,
                        progressHandler: progressHandler,
                        completion: completion
                    )
                }
                
            } catch {
                print("❌ Failed to create composition: \(error)")
                await MainActor.run {
                    completion(.failure(.exportFailed("Failed to create composition: \(error.localizedDescription)")))
                }
            }
        }
    }
    
    /// MODERNIZED: Professional export with iOS 18+ async APIs and backward compatibility
    private static func performEnhancedExport(
        composition: AVMutableComposition,
        videoComposition: AVMutableVideoComposition?,
        outputFileName: String,
        options: ExportOptions,
        progressHandler: ((Float) -> Void)?,
        completion: @escaping (Result<URL, SessionExportError>) -> Void
    ) {
        
        let outputURL = createOutputURL(fileName: outputFileName, format: options.format)
        
        guard let exportSession = AVAssetExportSession(asset: composition, presetName: options.quality.preset) else {
            completion(.failure(.exportFailed("Failed to create export session")))
            return
        }
        
        exportSession.outputURL = outputURL
        exportSession.outputFileType = options.format.fileType
        exportSession.videoComposition = videoComposition
        
        print("📤 Starting enhanced export to: \(outputURL.lastPathComponent)")
        print("🎯 Quality: \(options.quality.rawValue), Format: \(options.format.rawValue)")
        
        // MODERNIZED: Use iOS 18+ async export API with backward compatibility
        Task { @MainActor in
            // Start progress monitoring if provided
            let progressTask = progressHandler != nil ? Task {
                if #available(iOS 18.0, *) {
                    // Use iOS 18 states async sequence
                    do {
                        for await state in exportSession.states(updateInterval: 0.1) {
                            if case .exporting(let progress) = state {
                                await MainActor.run {
                                    progressHandler?(Float(progress.fractionCompleted))
                                }
                            }
                        }
                    } catch {
                        print("❌ Enhanced export progress monitoring error: \(error)")
                    }
                } else {
                    // Legacy progress monitoring
                    while exportSession.status == .exporting || exportSession.status == .waiting {
                        await MainActor.run {
                            progressHandler?(exportSession.progress)
                        }
                        try? await Task.sleep(nanoseconds: 100_000_000) // 0.1 seconds
                    }
                }
            } : nil
            
            do {
                // MODERNIZED: Use iOS 18+ async export API with backward compatibility
                if #available(iOS 18.0, *) {
                    try await exportSession.export(to: outputURL, as: options.format.fileType)
                } else {
                    try await exportSession.export()
                }
                
                // Cancel progress monitoring
                progressTask?.cancel()
                
                // Check final status
                if exportSession.status == .completed {
                    print("✅ Enhanced export completed successfully")
                    // Log file size
                    if let fileSize = try? FileManager.default.attributesOfItem(atPath: outputURL.path)[.size] as? Int64 {
                        let fileSizeMB = Double(fileSize) / 1024 / 1024
                        print("📊 Export file size: \(String(format: "%.2f", fileSizeMB)) MB")
                    }
                    completion(.success(outputURL))
                } else {
                    throw SessionExportError.exportFailed(exportSession.error?.localizedDescription ?? "Unknown export error")
                }
                
            } catch {
                // Cancel progress monitoring on error
                progressTask?.cancel()
                
                print("❌ Enhanced export failed: \(error)")
                if let exportError = error as? AVError {
                    completion(.failure(.exportFailed(exportError.localizedDescription)))
                } else {
                    completion(.failure(.exportFailed(error.localizedDescription)))
                }
            }
        }
    }
    
    // MARK: - Helper Methods (Enhanced)
    
    private static func createCropInstruction(
        for videoTrack: AVAssetTrack,
        cropRect: CGRect,
        timeRange: CMTimeRange
    ) -> AVMutableVideoCompositionInstruction {
        
        let instruction = AVMutableVideoCompositionInstruction()
        instruction.timeRange = timeRange
        
        let layerInstruction = AVMutableVideoCompositionLayerInstruction(assetTrack: videoTrack)
        
        // Create transform for cropping
        let cropTransform = CGAffineTransform(
            translationX: -cropRect.origin.x,
            y: -cropRect.origin.y
        ).scaledBy(
            x: 1.0 / cropRect.width,
            y: 1.0 / cropRect.height
        )
        
        layerInstruction.setTransform(cropTransform, at: .zero)
        instruction.layerInstructions = [layerInstruction]
        
        return instruction
    }
    
    private static func createOutputURL(fileName: String, format: ExportFormat) -> URL {
        // Create output URL in documents directory with proper extension
        let documentsPath = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first!
        let exportsDir = documentsPath.appendingPathComponent("STS_Exports")
        
        // Create exports directory if it doesn't exist
        try? FileManager.default.createDirectory(at: exportsDir, withIntermediateDirectories: true)
        
        // Ensure proper file extension
        let baseFileName = (fileName as NSString).deletingPathExtension
        let finalFileName = "\(baseFileName).\(format.fileExtension)"
        let outputURL = exportsDir.appendingPathComponent(finalFileName)
        
        // Remove existing file if it exists
        try? FileManager.default.removeItem(at: outputURL)
        
        return outputURL
    }
    
    // MARK: - Convenience Methods (Enhanced)
    
    /// Create TakeMetadata from SessionManager Take (Enhanced)
    static func createTakeMetadata(from sessionTake: Take, asset: AVAsset) -> TakeMetadata {
        let isGood = sessionTake.rating == .good || sessionTake.rating == .favorite
        
        return TakeMetadata(
            asset: asset,
            isGood: isGood,
            takeNumber: sessionTake.takeNumber,
            fileName: sessionTake.fileName
        )
    }
    
    /// Create TakeMetadata from UnifiedTake (NEW)
    static func createTakeMetadata(from unifiedTake: UnifiedTake) -> TakeMetadata? {
        // FIXED: Use AVURLAsset instead of deprecated AVAsset(url:)
        guard let asset = try? AVURLAsset(url: URL(fileURLWithPath: unifiedTake.filePath)) else {
            print("❌ Failed to create asset from path: \(unifiedTake.filePath)")
            return nil
        }
        
        let isGood = unifiedTake.rating == .good || unifiedTake.rating == .favorite
        
        return TakeMetadata(
            asset: asset,
            isGood: isGood,
            takeNumber: unifiedTake.takeNumber,
            fileName: unifiedTake.fileName
        )
    }
    
    /// Get good takes count for preview (Enhanced)
    static func getGoodTakesCount(from takes: [TakeMetadata]) -> Int {
        return takes.filter { $0.isGood }.count
    }
    
    /// Get total duration of good takes (UPDATED: Modern async API)
    static func getTotalDuration(from takes: [TakeMetadata], includeSlate: Bool = true, slateDuration: TimeInterval = 2.0) async -> TimeInterval {
        var totalDuration: TimeInterval = 0
        
        // Add slate duration if applicable
        if includeSlate && takes.contains(where: { $0.isSlatePhoto && $0.thumbnailImage != nil }) {
            totalDuration += slateDuration
        }
        
        // Add good takes duration using modern async API
        for take in takes.filter({ $0.isGood }) {
            do {
                if let trimRange = take.trimRange {
                    totalDuration += trimRange.duration.seconds
                } else {
                    // UPDATED: Use modern async duration loading
                    let duration = try await take.asset.load(.duration)
                    totalDuration += duration.seconds
                }
            } catch {
                print("⚠️ Could not load duration for take \(take.fileName): \(error)")
                // Continue with other takes
            }
        }
        
        return totalDuration
    }
    
    /// Preview export information (UPDATED: Async version)
    static func getExportPreview(from takes: [TakeMetadata], options: ExportOptions = .defaultOptions) async -> (goodTakes: Int, totalDuration: TimeInterval, hasSlate: Bool) {
        let goodTakesCount = getGoodTakesCount(from: takes)
        let totalDuration = await getTotalDuration(from: takes, includeSlate: options.includeSlate, slateDuration: options.slateDuration)
        let hasSlate = takes.contains { $0.isSlatePhoto && $0.thumbnailImage != nil }
        
        return (goodTakes: goodTakesCount, totalDuration: totalDuration, hasSlate: hasSlate)
    }
}

// MARK: - Smart Fill Supporting Data Structures

/// Session data required for Smart Fill processing
public struct SmartFillSessionData {
    let session: ProjectSession
    let project: Project?
    
    init(session: ProjectSession, project: Project? = nil) {
        self.session = session
        self.project = project
    }
}

/// Preview information for Smart Fill export
public struct SmartFillExportPreview {
    let totalTakes: Int
    let portraitTakes: Int
    let landscapeTakes: Int
    let willApplySmartFill: Bool
    let smartFillTakes: Int
    let estimatedDuration: TimeInterval
    
    var hasPortraitTakes: Bool { portraitTakes > 0 }
    var hasMixedOrientations: Bool { portraitTakes > 0 && landscapeTakes > 0 }
    
    var summaryText: String {
        if willApplySmartFill {
            return "Smart Fill will be applied to \(smartFillTakes) portrait take\(smartFillTakes == 1 ? "" : "s")"
        } else if hasPortraitTakes {
            return "\(portraitTakes) portrait take\(portraitTakes == 1 ? "" : "s") will export as-is"
        } else {
            return "All takes are landscape - no Smart Fill needed"
        }
    }
    
    var iconName: String {
        if willApplySmartFill {
            return "rectangle.fill.badge.checkmark"
        } else if hasPortraitTakes {
            return "rectangle.portrait.fill"
        } else {
            return "rectangle.fill"
        }
    }
}

// MARK: - Legacy Support

extension SessionExportManager {
    /// Legacy method for backward compatibility
    static func exportMergedAudition(
        from takes: [TakeMetadata],
        outputFileName: String = "MergedAudition.mov",
        completion: @escaping (Result<URL, Error>) -> Void
    ) {
        exportMergedAudition(
            from: takes,
            outputFileName: outputFileName,
            options: .defaultOptions
        ) { result in
            switch result {
            case .success(let url):
                completion(.success(url))
            case .failure(let error):
                completion(.failure(error))
            }
        }
    }
}
