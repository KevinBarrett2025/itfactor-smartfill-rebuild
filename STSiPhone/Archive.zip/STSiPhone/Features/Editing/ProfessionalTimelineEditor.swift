import SwiftUI
import AVFoundation

// MARK: - Professional Timeline Editor
// Native SwiftUI implementation for professional video editing capabilities

struct ProfessionalTimelineEditor: View {
    let videoFile: VideoFile
    let onSave: (EditedVideoResult) -> Void
    let onCancel: () -> Void
    
    @StateObject private var editorViewModel = TimelineEditorViewModel()
    @State private var showingExportOptions = false
    @State private var editingComplete = false
    
    var body: some View {
        ZStack {
            Color.black.ignoresSafeArea()
            
            VStack(spacing: 0) {
                // Header with controls
                headerControls
                
                // Video preview
                videoPreviewSection
                
                // Timeline editor
                timelineSection
                
                // Control panel
                controlPanel
            }
        }
        .navigationBarHidden(true)
        .onAppear {
            editorViewModel.loadVideo(videoFile)
        }
        .sheet(isPresented: $showingExportOptions) {
            EditExportOptionsView(
                editResult: editorViewModel.generateEditResult(),
                onSave: onSave,
                onCancel: { showingExportOptions = false }
            )
        }
    }
    
    // MARK: - Header Controls
    
    private var headerControls: some View {
        HStack {
            Button("Cancel") {
                onCancel()
            }
            .foregroundColor(.white)
            
            Spacer()
            
            Text("Timeline Editor")
                .font(.headline)
                .foregroundColor(.white)
            
            Spacer()
            
            Button("Export") {
                showingExportOptions = true
            }
            .foregroundColor(.blue)
            .fontWeight(.semibold)
            .disabled(!editorViewModel.hasEdits)
        }
        .padding()
        .background(Color.black.opacity(0.8))
    }
    
    // MARK: - Video Preview Section
    
    private var videoPreviewSection: some View {
        GeometryReader { geometry in
            ZStack {
                // Video player
                VideoPlayerView(
                    player: editorViewModel.player,
                    currentTime: $editorViewModel.currentTime,
                    orientationTransform: editorViewModel.videoOrientationTransform // CRITICAL FIX: Pass orientation transform
                )
                .aspectRatio(16/9, contentMode: .fit)
                .clipShape(RoundedRectangle(cornerRadius: 8))
                
                // Playback overlay
                playbackOverlay
                
                // Crop overlay if active
                if editorViewModel.editingMode == .crop {
                    CropOverlay(
                        cropRect: $editorViewModel.cropRect,
                        videoSize: editorViewModel.videoSize
                    )
                }
            }
        }
        .frame(maxHeight: 300)
        .padding()
    }
    
    private var playbackOverlay: some View {
        VStack {
            Spacer()
            
            HStack {
                // Play/Pause button
                Button(action: editorViewModel.togglePlayback) {
                    Image(systemName: editorViewModel.isPlaying ? "pause.fill" : "play.fill")
                        .font(.title)
                        .foregroundColor(.white)
                        .padding(12)
                        .background(Color.black.opacity(0.6), in: Circle())
                }
                
                Spacer()
                
                // Current time display
                Text(formatTime(editorViewModel.currentTime))
                    .font(.system(.caption, design: .monospaced))
                    .foregroundColor(.white)
                    .padding(.horizontal, 8)
                    .padding(.vertical, 4)
                    .background(Color.black.opacity(0.6), in: Capsule())
            }
            .padding()
        }
    }
    
    // MARK: - Timeline Section
    
    private var timelineSection: some View {
        VStack(spacing: 12) {
            // Timeline scrubber
            TimelineScrubber(
                duration: editorViewModel.videoDuration,
                currentTime: $editorViewModel.currentTime,
                trimRange: $editorViewModel.trimRange,
                markers: editorViewModel.markers,
                onSeek: editorViewModel.seek(to:),
                onAddMarker: editorViewModel.addMarker(at:)
            )
            .frame(height: 120)
            .background(Color.gray.opacity(0.2), in: RoundedRectangle(cornerRadius: 8))
            
            // Zoom controls
            HStack {
                Text("Timeline Zoom")
                    .font(.caption)
                    .foregroundColor(.gray)
                
                Spacer()
                
                Slider(value: $editorViewModel.timelineZoom, in: 1...10, step: 1)
                    .frame(width: 100)
                
                Text("\(Int(editorViewModel.timelineZoom))x")
                    .font(.caption)
                    .foregroundColor(.gray)
                    .frame(minWidth: 25)
            }
            .padding(.horizontal)
        }
        .padding()
        .background(Color.black.opacity(0.3))
    }
    
    // MARK: - Control Panel
    
    private var controlPanel: some View {
        VStack(spacing: 16) {
            // Editing mode selector
            editingModeSelector
            
            // Mode-specific controls
            modeSpecificControls
        }
        .padding()
        .background(Color.black.opacity(0.8))
    }
    
    private var editingModeSelector: some View {
        HStack(spacing: 12) {
            ForEach(EditingMode.allCases, id: \.self) { mode in
                Button {
                    editorViewModel.editingMode = mode
                } label: {
                    VStack(spacing: 4) {
                        Image(systemName: mode.iconName)
                            .font(.title2)
                        
                        Text(mode.displayName)
                            .font(.caption)
                    }
                    .foregroundColor(editorViewModel.editingMode == mode ? .blue : .gray)
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 8)
                    .background(
                        RoundedRectangle(cornerRadius: 8)
                            .fill(editorViewModel.editingMode == mode ? Color.blue.opacity(0.2) : Color.clear)
                    )
                }
            }
        }
    }
    
    @ViewBuilder
    private var modeSpecificControls: some View {
        switch editorViewModel.editingMode {
        case .trim:
            trimControls
        case .crop:
            cropControls
        case .markers:
            markerControls
        case .filters:
            filterControls
        }
    }
    
    private var trimControls: some View {
        VStack(spacing: 12) {
            HStack {
                Text("Trim Video")
                    .font(.headline)
                    .foregroundColor(.white)
                
                Spacer()
                
                if editorViewModel.trimRange != nil {
                    Button("Reset Trim") {
                        editorViewModel.resetTrim()
                    }
                    .foregroundColor(.orange)
                }
            }
            
            if let trimRange = editorViewModel.trimRange {
                HStack {
                    VStack(alignment: .leading) {
                        Text("Start:")
                            .font(.caption)
                            .foregroundColor(.gray)
                        Text(formatTime(CMTimeGetSeconds(trimRange.start)))
                            .font(.system(.body, design: .monospaced))
                            .foregroundColor(.white)
                    }
                    
                    Spacer()
                    
                    VStack(alignment: .trailing) {
                        Text("Duration:")
                            .font(.caption)
                            .foregroundColor(.gray)
                        Text(formatTime(CMTimeGetSeconds(trimRange.duration)))
                            .font(.system(.body, design: .monospaced))
                            .foregroundColor(.white)
                    }
                }
                .padding()
                .background(Color.gray.opacity(0.2), in: RoundedRectangle(cornerRadius: 8))
            }
        }
    }
    
    private var cropControls: some View {
        VStack(spacing: 12) {
            HStack {
                Text("Crop Video")
                    .font(.headline)
                    .foregroundColor(.white)
                
                Spacer()
                
                if editorViewModel.cropRect != .zero {
                    Button("Reset Crop") {
                        editorViewModel.resetCrop()
                    }
                    .foregroundColor(.orange)
                }
            }
            
            // Crop presets
            HStack(spacing: 8) {
                ForEach(CropPreset.allCases, id: \.self) { preset in
                    Button(preset.displayName) {
                        editorViewModel.applyCropPreset(preset)
                    }
                    .font(.caption)
                    .foregroundColor(.white)
                    .padding(.horizontal, 12)
                    .padding(.vertical, 6)
                    .background(Color.blue.opacity(0.6), in: Capsule())
                }
            }
        }
    }
    
    private var markerControls: some View {
        VStack(spacing: 12) {
            HStack {
                Text("Video Markers")
                    .font(.headline)
                    .foregroundColor(.white)
                
                Spacer()
                
                Text("\(editorViewModel.markers.count) markers")
                    .font(.caption)
                    .foregroundColor(.gray)
            }
            
            Button("Add Marker at Current Time") {
                editorViewModel.addMarker(at: editorViewModel.currentTime)
            }
            .foregroundColor(.white)
            .frame(maxWidth: .infinity)
            .padding()
            .background(Color.green.opacity(0.6), in: RoundedRectangle(cornerRadius: 8))
        }
    }
    
    private var filterControls: some View {
        VStack(spacing: 12) {
            HStack {
                Text("Video Filters")
                    .font(.headline)
                    .foregroundColor(.white)
                
                Spacer()
            }
            
            // Color adjustment sliders
            VStack(spacing: 8) {
                FilterSlider(
                    title: "Brightness",
                    value: $editorViewModel.brightness,
                    range: -1...1
                )
                
                FilterSlider(
                    title: "Contrast",
                    value: $editorViewModel.contrast,
                    range: 0...2
                )
                
                FilterSlider(
                    title: "Saturation",
                    value: $editorViewModel.saturation,
                    range: 0...2
                )
            }
        }
    }
    
    // MARK: - Helper Methods
    
    private func formatTime(_ seconds: Double) -> String {
        guard seconds.isFinite && seconds >= 0 else { return "0:00" }
        
        let minutes = Int(seconds) / 60
        let remainingSeconds = Int(seconds) % 60
        let milliseconds = Int((seconds.truncatingRemainder(dividingBy: 1)) * 100)
        
        return String(format: "%d:%02d.%02d", minutes, remainingSeconds, milliseconds)
    }
}

// MARK: - Supporting Views and Models

enum EditingMode: CaseIterable {
    case trim, crop, markers, filters
    
    var displayName: String {
        switch self {
        case .trim: return "Trim"
        case .crop: return "Crop"
        case .markers: return "Markers"
        case .filters: return "Filters"
        }
    }
    
    var iconName: String {
        switch self {
        case .trim: return "scissors"
        case .crop: return "crop"
        case .markers: return "flag"
        case .filters: return "camera.filters"
        }
    }
}

enum CropPreset: CaseIterable {
    case square, portrait, landscape, cinema
    
    var displayName: String {
        switch self {
        case .square: return "1:1"
        case .portrait: return "9:16"
        case .landscape: return "16:9"
        case .cinema: return "21:9"
        }
    }
    
    var aspectRatio: CGFloat {
        switch self {
        case .square: return 1.0
        case .portrait: return 9.0/16.0
        case .landscape: return 16.0/9.0
        case .cinema: return 21.0/9.0
        }
    }
}

struct EditedVideoResult {
    let originalVideoFile: VideoFile
    let trimRange: CMTimeRange?
    let cropRect: CGRect
    let markers: [VideoMarker]
    let brightness: Float
    let contrast: Float
    let saturation: Float
    let hasEdits: Bool
    
    var editSummary: String {
        var edits: [String] = []
        
        if let trimRange = trimRange {
            edits.append("Trimmed to \(Int(CMTimeGetSeconds(trimRange.duration)))s")
        }
        
        if cropRect != .zero {
            edits.append("Cropped")
        }
        
        if !markers.isEmpty {
            edits.append("\(markers.count) markers")
        }
        
        if brightness != 0 || contrast != 1 || saturation != 1 {
            edits.append("Color adjusted")
        }
        
        return edits.isEmpty ? "No edits" : edits.joined(separator: ", ")
    }
}

// MARK: - Timeline Scrubber

struct TimelineScrubber: View {
    let duration: Double
    @Binding var currentTime: Double
    @Binding var trimRange: CMTimeRange?
    let markers: [VideoMarker]
    let onSeek: (Double) -> Void
    let onAddMarker: (Double) -> Void
    
    @State private var isDragging = false
    @State private var dragOffset: CGFloat = 0
    
    var body: some View {
        GeometryReader { geometry in
            ZStack(alignment: .leading) {
                // Background track
                Rectangle()
                    .fill(Color.gray.opacity(0.3))
                    .frame(height: 4)
                
                // Played portion
                Rectangle()
                    .fill(Color.blue)
                    .frame(
                        width: CGFloat(currentTime / duration) * geometry.size.width,
                        height: 4
                    )
                
                // Trim range overlay
                if let trimRange = trimRange {
                    let startX = CGFloat(CMTimeGetSeconds(trimRange.start) / duration) * geometry.size.width
                    let width = CGFloat(CMTimeGetSeconds(trimRange.duration) / duration) * geometry.size.width
                    
                    Rectangle()
                        .fill(Color.green.opacity(0.3))
                        .frame(width: width, height: 20)
                        .offset(x: startX)
                }
                
                // Markers
                ForEach(markers) { marker in
                    let markerX = CGFloat(marker.timestamp / duration) * geometry.size.width
                    
                    VStack(spacing: 2) {
                        Rectangle()
                            .fill(marker.type.color)
                            .frame(width: 2, height: 30)
                        
                        Text(marker.title)
                            .font(.system(size: 8))
                            .foregroundColor(.white)
                            .padding(.horizontal, 4)
                            .padding(.vertical, 2)
                            .background(marker.type.color.opacity(0.8), in: Capsule())
                    }
                    .offset(x: markerX - 1)
                }
                
                // Playhead
                Rectangle()
                    .fill(Color.white)
                    .frame(width: 2, height: 40)
                    .offset(x: CGFloat(currentTime / duration) * geometry.size.width - 1)
                
                // Invisible drag area
                Rectangle()
                    .fill(Color.clear)
                    .contentShape(Rectangle())
                    .gesture(
                        DragGesture()
                            .onChanged { value in
                                isDragging = true
                                let progress = max(0, min(1, value.location.x / geometry.size.width))
                                let newTime = progress * duration
                                currentTime = newTime
                                onSeek(newTime)
                            }
                            .onEnded { _ in
                                isDragging = false
                            }
                    )
                    .onTapGesture { location in
                        let progress = location.x / geometry.size.width
                        let newTime = progress * duration
                        currentTime = newTime
                        onSeek(newTime)
                    }
            }
        }
    }
}

// MARK: - Crop Overlay

struct CropOverlay: View {
    @Binding var cropRect: CGRect
    let videoSize: CGSize
    
    var body: some View {
        GeometryReader { geometry in
            ZStack {
                // Dimmed overlay
                Rectangle()
                    .fill(Color.black.opacity(0.5))
                
                // Crop window
                Rectangle()
                    .fill(Color.clear)
                    .border(Color.white, width: 2)
                    .frame(
                        width: cropRect.width * geometry.size.width,
                        height: cropRect.height * geometry.size.height
                    )
                    .offset(
                        x: cropRect.origin.x * geometry.size.width,
                        y: cropRect.origin.y * geometry.size.height
                    )
            }
        }
    }
}

// MARK: - Filter Slider

struct FilterSlider: View {
    let title: String
    @Binding var value: Float
    let range: ClosedRange<Float>
    
    var body: some View {
        HStack {
            Text(title)
                .font(.caption)
                .foregroundColor(.white)
                .frame(width: 80, alignment: .leading)
            
            Slider(value: $value, in: range)
                .accentColor(.blue)
            
            Text(String(format: "%.1f", value))
                .font(.system(.caption, design: .monospaced))
                .foregroundColor(.gray)
                .frame(width: 40, alignment: .trailing)
        }
    }
}

// MARK: - Export Options View

struct EditExportOptionsView: View {
    let editResult: EditedVideoResult
    let onSave: (EditedVideoResult) -> Void
    let onCancel: () -> Void
    
    var body: some View {
        NavigationView {
            VStack(spacing: 20) {
                Text("Export Edited Video")
                    .font(.title2)
                    .fontWeight(.semibold)
                
                VStack(alignment: .leading, spacing: 8) {
                    Text("Edit Summary:")
                        .font(.headline)
                    
                    Text(editResult.editSummary)
                        .font(.body)
                        .foregroundColor(.secondary)
                }
                .frame(maxWidth: .infinity, alignment: .leading)
                .padding()
                .background(Color.secondary.opacity(0.1), in: RoundedRectangle(cornerRadius: 8))
                
                Spacer()
                
                Button("Export Edited Video") {
                    onSave(editResult)
                }
                .font(.headline)
                .foregroundColor(.white)
                .frame(maxWidth: .infinity)
                .padding()
                .background(Color.blue, in: RoundedRectangle(cornerRadius: 10))
            }
            .padding()
            .navigationTitle("Export")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    Button("Cancel") {
                        onCancel()
                    }
                }
            }
        }
    }
}

// MARK: - Preview

#Preview {
    let sampleVideoFile = VideoFile(
        filePath: "/path/to/video.mov",
        fileName: "sample.mov",
        metadata: VideoMetadata(
            projectTitle: "Sample Project",
            duration: 120.0
        ),
        fileSize: 50_000_000,
        createdAt: Date()
    )
    
    ProfessionalTimelineEditor(
        videoFile: sampleVideoFile,
        onSave: { result in
            print("Save result: \(result.editSummary)")
        },
        onCancel: {
            print("Cancel editing")
        }
    )
}
