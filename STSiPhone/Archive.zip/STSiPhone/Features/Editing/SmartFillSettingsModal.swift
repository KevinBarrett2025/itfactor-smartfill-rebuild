import SwiftUI
import AVFoundation

/// Smart Fill Settings Modal for Editor Integration
/// PHASE 3: Enhanced with real-time preview using exact export composition
struct SmartFillSettingsModal: View {
    @State private var settings: SmartFillSettings
    @Environment(\.dismiss) private var dismiss
    
    // PHASE 3: Real preview support
    let previewVideoURL: URL?
    let originalVideoSize: CGSize?
    
    // Callback for applying settings
    var onApplySettings: ((SmartFillSettings) -> Void)?
    var onCancel: (() -> Void)?
    
    init(currentSettings: SmartFillSettings = SmartFillSettings(),
         previewVideoURL: URL? = nil,
         originalVideoSize: CGSize? = nil,
         onApplySettings: ((SmartFillSettings) -> Void)? = nil,
         onCancel: (() -> Void)? = nil) {
        self._settings = State(initialValue: currentSettings)
        self.previewVideoURL = previewVideoURL
        self.originalVideoSize = originalVideoSize
        self.onApplySettings = onApplySettings
        self.onCancel = onCancel
    }
    
    var body: some View {
        NavigationView {
            ZStack {
                BrandBackground()
                    .ignoresSafeArea()
                
                SmartFillSettingsContent(
                    settings: $settings,
                    previewVideoURL: previewVideoURL,
                    originalVideoSize: originalVideoSize
                )
            }
            .navigationTitle("Smart Fill Settings")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    Button("Cancel") {
                        onCancel?()
                        dismiss()
                    }
                }
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("Apply") {
                        onApplySettings?(settings)
                        dismiss()
                    }
                    .fontWeight(.semibold)
                    .foregroundStyle(Theme.primary)
                }
            }
        }
    }
}

/// Reusable Smart Fill Settings Content
/// PHASE 3: Enhanced with real-time preview system
struct SmartFillSettingsContent: View {
    @Binding var settings: SmartFillSettings
    @State private var showingAdvancedSettings = false
    
    // PHASE 3: Real preview support
    let previewVideoURL: URL?
    let originalVideoSize: CGSize?
    
    // Local state for UI bindings
    @State private var defaultEnabled: Bool
    @State private var blurRadius: Double
    @State private var darkenAmount: Double
    @State private var backgroundScale: Double // 🎯 ENTERPRISE: Master Brain #275 background scale
    @State private var renderWidth: Double
    @State private var renderHeight: Double
    @State private var selectedPresetName: String
    @State private var useNewCompositor: Bool // PHASE 3: New compositor toggle
    
    init(settings: Binding<SmartFillSettings>,
         previewVideoURL: URL? = nil,
         originalVideoSize: CGSize? = nil) {
        self._settings = settings
        self.previewVideoURL = previewVideoURL
        self.originalVideoSize = originalVideoSize
        
        // Initialize local state from settings
        let currentSettings = settings.wrappedValue
        self._defaultEnabled = State(initialValue: currentSettings.defaultEnabled)
        self._blurRadius = State(initialValue: Double(currentSettings.defaultBlurRadius))
        self._darkenAmount = State(initialValue: Double(currentSettings.defaultDarkenAmount))
        self._backgroundScale = State(initialValue: Double(currentSettings.backgroundScale)) // 🎯 ENTERPRISE
        self._renderWidth = State(initialValue: Double(currentSettings.defaultRenderSize.width))
        self._renderHeight = State(initialValue: Double(currentSettings.defaultRenderSize.height))
        self._useNewCompositor = State(initialValue: currentSettings.useNewCompositor) // PHASE 3
        
        // Determine current preset - fixed initialization
        let preset = SmartFillSettings.Preset.allCases.first { preset in
            preset.blurRadius == currentSettings.defaultBlurRadius &&
            preset.darkenAmount == currentSettings.defaultDarkenAmount
        }
        
        let presetName: String
        if let preset = preset {
            switch preset {
            case .subtle: presetName = "Subtle"
            case .medium: presetName = "Medium"
            case .dramatic: presetName = "Dramatic"
            }
        } else {
            presetName = "Custom"
        }
        
        self._selectedPresetName = State(initialValue: presetName)
    }
    
    var body: some View {
        List {
            // PHASE 3: Real-time preview section (only if video URL provided)
            if let previewURL = previewVideoURL {
                Section("Live Preview") {
                    VStack(spacing: 12) {
                        // 🔧 DEBUG: Show preview status
                        HStack {
                            Text("Preview Status:")
                                .font(.caption)
                                .foregroundStyle(.secondary)
                            Spacer()
                            VStack(alignment: .trailing) {
                                Text("Video URL: ✅")
                                    .font(.caption2)
                                    .foregroundStyle(.green)
                                Text("Beta Toggle: \(useNewCompositor ? "✅ ON" : "❌ OFF")")
                                    .font(.caption2)
                                    .foregroundStyle(useNewCompositor ? .green : .orange)
                            }
                        }
                        .padding(.horizontal)
                        
                        if useNewCompositor {
                            SmartFillRealPreviewSection(
                                videoURL: previewURL,
                                settings: settings
                            )
                        } else {
                            // Show message when beta toggle is off
                            VStack(spacing: 8) {
                                Image(systemName: "eye.slash")
                                    .font(.largeTitle)
                                    .foregroundStyle(.secondary)
                                
                                Text("Preview Unavailable")
                                    .font(.headline)
                                
                                Text("Enable 'Enhanced Compositor (Beta)' to see live preview")
                                    .font(.caption)
                                    .foregroundStyle(.secondary)
                                    .multilineTextAlignment(.center)
                            }
                            .frame(height: 160)
                            .frame(maxWidth: .infinity)
                            .background(
                                RoundedRectangle(cornerRadius: 12)
                                    .stroke(Color.white.opacity(0.2), lineWidth: 1)
                            )
                        }
                    }
                    .listRowBackground(Color.clear)
                    .listRowInsets(EdgeInsets())
                }
            }
            
            Section {
                VStack(alignment: .leading, spacing: 12) {
                    HStack {
                        Image(systemName: "person.and.background.dotted")
                            .font(.title2)
                            .foregroundStyle(Theme.primary)
                        
                        VStack(alignment: .leading, spacing: 4) {
                            Text("Smart Portrait Fill")
                                .font(.headline)
                                .foregroundStyle(Theme.textPrimary)
                            
                            Text("Automatically enhance portrait videos in landscape sessions with a blurred background")
                                .font(.caption)
                                .foregroundStyle(.secondary)
                                .multilineTextAlignment(.leading)
                        }
                    }
                    
                    Toggle("Enable by Default", isOn: $defaultEnabled)
                        .tint(Theme.primary)
                        .onChange(of: defaultEnabled) { _, newValue in
                            updateSettings()
                        }
                }
                .padding(.vertical, 8)
            } header: {
                Text("Smart Fill")
            }
            .listRowBackground(Color.clear)
            
            // PHASE 3: New compositor toggle (for testing)
            if defaultEnabled {
                Section("Processing Engine") {
                    VStack(alignment: .leading, spacing: 8) {
                        Toggle("Use Enhanced Compositor (Beta)", isOn: $useNewCompositor)
                            .tint(Theme.primary)
                            .onChange(of: useNewCompositor) { _, newValue in
                                updateSettings()
                            }
                        
                        if useNewCompositor {
                            Text("🚀 Uses industry-standard video composition for better quality and performance")
                                .font(.caption)
                                .foregroundStyle(.green)
                        } else {
                            Text("Uses legacy frame processing (stable)")
                                .font(.caption)
                                .foregroundStyle(.secondary)
                        }
                    }
                    .padding(.vertical, 4)
                    .listRowBackground(Color.clear)
                }
            }
            
            if defaultEnabled {
                Section("Quality Presets") {
                    SmartFillPresetRow(
                        title: "Subtle",
                        description: "Light blur, minimal darkening",
                        isSelected: selectedPresetName == "Subtle",
                        preset: .subtle
                    ) {
                        applyPreset(.subtle)
                    }
                    .listRowBackground(Color.clear)
                    
                    SmartFillPresetRow(
                        title: "Medium",
                        description: "Balanced blur and darkening",
                        isSelected: selectedPresetName == "Medium",
                        preset: .medium
                    ) {
                        applyPreset(.medium)
                    }
                    .listRowBackground(Color.clear)
                    
                    SmartFillPresetRow(
                        title: "Dramatic",
                        description: "Strong blur, pronounced darkening",
                        isSelected: selectedPresetName == "Dramatic",
                        preset: .dramatic
                    ) {
                        applyPreset(.dramatic)
                    }
                    .listRowBackground(Color.clear)
                }
                
                Section("Advanced Settings") {
                    SettingsRow(
                        icon: "slider.horizontal.3",
                        title: "Custom Settings",
                        subtitle: "Fine-tune blur, darkness, and background scale",
                        action: {
                            showingAdvancedSettings = true
                        }
                    )
                    .listRowBackground(Color.clear)
                }
                
                Section("Export Quality") {
                    HStack {
                        Text("Render Size")
                            .foregroundStyle(Theme.textPrimary)
                        
                        Spacer()
                        
                        Menu {
                            Button("1920×1080 (Full HD)") {
                                renderWidth = 1920
                                renderHeight = 1080
                                updateSettings()
                            }
                            Button("1280×720 (HD)") {
                                renderWidth = 1280
                                renderHeight = 720
                                updateSettings()
                            }
                            Button("3840×2160 (4K)") {
                                renderWidth = 3840
                                renderHeight = 2160
                                updateSettings()
                            }
                        } label: {
                            Text("\(Int(renderWidth))×\(Int(renderHeight))")
                                .foregroundStyle(.secondary)
                        }
                    }
                    .listRowBackground(Color.clear)
                }
            }
            
            Section("How It Works") {
                VStack(alignment: .leading, spacing: 12) {
                    HStack(spacing: 12) {
                        Image(systemName: "1.circle.fill")
                            .foregroundStyle(Theme.primary)
                        
                        VStack(alignment: .leading, spacing: 2) {
                            Text("Detection")
                                .font(.subheadline)
                                .fontWeight(.medium)
                            Text("App identifies portrait videos in landscape sessions")
                                .font(.caption)
                                .foregroundStyle(.secondary)
                        }
                    }
                    
                    HStack(spacing: 12) {
                        Image(systemName: "2.circle.fill")
                            .foregroundStyle(Theme.primary)
                        
                        VStack(alignment: .leading, spacing: 2) {
                            Text("Enhancement")
                                .font(.subheadline)
                                .fontWeight(.medium)
                            Text(useNewCompositor ?
                                "Creates professional composition with industry-standard tools" :
                                "Creates blurred background from the same video")
                                .font(.caption)
                                .foregroundStyle(.secondary)
                        }
                    }
                    
                    HStack(spacing: 12) {
                        Image(systemName: "3.circle.fill")
                            .foregroundStyle(Theme.primary)
                        
                        VStack(alignment: .leading, spacing: 2) {
                            Text("Export")
                                .font(.subheadline)
                                .fontWeight(.medium)
                            Text("Composite preserves your performance while filling the frame")
                                .font(.caption)
                                .foregroundStyle(.secondary)
                        }
                    }
                }
                .padding(.vertical, 8)
                .listRowBackground(Color.clear)
            }
        }
        .listStyle(.plain)
        .scrollContentBackground(.hidden)
        .sheet(isPresented: $showingAdvancedSettings) {
            SmartFillAdvancedSettingsView(
                blurRadius: $blurRadius,
                darkenAmount: $darkenAmount,
                backgroundScale: $backgroundScale // 🎯 ENTERPRISE: Pass background scale
            )
            .onDisappear {
                updateSettings()
            }
        }
    }
    
    private func applyPreset(_ preset: SmartFillSettings.Preset) {
        selectedPresetName = presetName(for: preset) ?? "Custom"
        blurRadius = Double(preset.blurRadius)
        darkenAmount = Double(preset.darkenAmount)
        updateSettings()
    }
    
    private func presetName(for preset: SmartFillSettings.Preset?) -> String? {
        guard let preset = preset else { return nil }
        switch preset {
        case .subtle: return "Subtle"
        case .medium: return "Medium"
        case .dramatic: return "Dramatic"
        }
    }
    
    private func updateSettings() {
        settings = SmartFillSettings(
            defaultEnabled: defaultEnabled,
            defaultBlurRadius: CGFloat(blurRadius),
            defaultDarkenAmount: CGFloat(darkenAmount),
            defaultRenderSize: CGSize(width: renderWidth, height: renderHeight),
            backgroundScale: CGFloat(backgroundScale), // 🎯 ENTERPRISE: Include background scale
            useNewCompositor: useNewCompositor // PHASE 3: Include compositor choice
        )
    }
}

// PHASE 3: Real-time preview section using STILL-FRAME PREVIEW (CRASH FIX)
struct SmartFillRealPreviewSection: View {
    let videoURL: URL
    let settings: SmartFillSettings
    
    // 🚨 CRITICAL FIX: Use still preview to avoid AVPlayerItem crashes
    @State private var previewImage: UIImage?
    @State private var isGenerating = false
    @State private var error: Error?
    
    var body: some View {
        VStack(spacing: 12) {
            HStack {
                Image(systemName: "photo.fill")
                    .foregroundStyle(.blue)
                Text("Still Preview")
                    .font(.headline)
                    .foregroundStyle(Theme.textPrimary)
                Spacer()
                
                if settings.useNewCompositor {
                    Text("SAFE")
                        .font(.caption2)
                        .fontWeight(.bold)
                        .foregroundStyle(.white)
                        .padding(.horizontal, 6)
                        .padding(.vertical, 2)
                        .background(.green, in: Capsule())
                }
            }
            
            // 🚨 CRITICAL FIX: Still frame preview - NO VIDEO PLAYERS
            SafeSizeContainer(minimumSize: CGSize(width: 200, height: 112)) { size in
                Group {
                    if let image = previewImage {
                        Image(uiImage: image)
                            .resizable()
                            .aspectRatio(16/9, contentMode: .fit)
                            .clipShape(RoundedRectangle(cornerRadius: 8))
                            .overlay(
                                RoundedRectangle(cornerRadius: 8)
                                    .stroke(Color.white.opacity(0.2), lineWidth: 1)
                            )
                    } else if isGenerating {
                        RoundedRectangle(cornerRadius: 8)
                            .fill(Color.black.opacity(0.3))
                            .overlay(
                                VStack(spacing: 8) {
                                    ProgressView()
                                        .progressViewStyle(CircularProgressViewStyle(tint: .blue))
                                    Text("Generating Preview...")
                                        .font(.caption)
                                        .foregroundStyle(.secondary)
                                }
                            )
                    } else if let error = error {
                        RoundedRectangle(cornerRadius: 8)
                            .fill(Color.red.opacity(0.1))
                            .overlay(
                                VStack(spacing: 8) {
                                    Image(systemName: "exclamationmark.triangle")
                                        .foregroundStyle(.red)
                                    Text("Preview Failed")
                                        .font(.caption)
                                        .foregroundStyle(.red)
                                }
                            )
                    } else {
                        RoundedRectangle(cornerRadius: 8)
                            .fill(Color.black.opacity(0.3))
                            .overlay(
                                VStack(spacing: 8) {
                                    Image(systemName: "photo")
                                        .font(.title2)
                                        .foregroundStyle(.secondary)
                                    Text("Tap to Generate")
                                        .font(.caption)
                                        .foregroundStyle(.secondary)
                                }
                            )
                            .onTapGesture {
                                generateStillPreview()
                            }
                    }
                }
                .frame(height: 160)
            }
            
            Text("🎯 Still-frame preview with SmartFill effect (crash-safe)")
                .font(.caption)
                .foregroundStyle(.green)
                .multilineTextAlignment(.center)
            
            HStack {
                Button("Regenerate") {
                    generateStillPreview()
                }
                .font(.caption)
                .disabled(isGenerating)
                
                Spacer()
                
                Text("Blur: \(Int(settings.defaultBlurRadius)), Scale: \(String(format: "%.1f", settings.backgroundScale))")
                    .font(.caption2)
                    .foregroundStyle(.secondary)
            }
        }
        .padding()
        .onAppear {
            // Generate initial preview
            generateStillPreview()
        }
        .onChange(of: settings.defaultBlurRadius) { _, _ in
            generateStillPreview()
        }
        .onChange(of: settings.defaultDarkenAmount) { _, _ in
            generateStillPreview()
        }
        .onChange(of: settings.backgroundScale) { _, _ in
            generateStillPreview()
        }
    }
    
    // 🚨 CRITICAL FIX: Generate still preview without any video players
    private func generateStillPreview() {
        guard !isGenerating else { return }
        
        isGenerating = true
        error = nil
        
        print("🖼️ SmartFillRealPreviewSection: Generating still preview")
        
        Task {
            do {
                let asset = AVURLAsset(url: videoURL)
                let generator = SmartFillStillPreviewGenerator(asset: asset)
                
                let image = try await generator.makePreviewImage(
                    targetSize: CGSize(width: 1920, height: 1080),
                    settings: settings
                )
                
                await MainActor.run {
                    self.previewImage = image
                    self.isGenerating = false
                    print("✅ SmartFillRealPreviewSection: Preview generated successfully")
                }
                
            } catch {
                await MainActor.run {
                    self.error = error
                    self.isGenerating = false
                    print("❌ SmartFillRealPreviewSection: Preview generation failed: \(error)")
                }
            }
        }
    }
}

// MARK: - Extensions for Preset Support
extension SmartFillSettings.Preset: CaseIterable {
    public static var allCases: [SmartFillSettings.Preset] {
        return [.subtle, .medium, .dramatic]
    }
}

#Preview {
    SmartFillSettingsModal()
}
