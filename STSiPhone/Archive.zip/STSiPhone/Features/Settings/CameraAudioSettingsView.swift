import SwiftUI

struct CameraAudioSettingsView: View {
    var body: some View {
        VStack(spacing: 16) {
            Text("Camera & Audio Settings")
                .font(Theme.Font.title)

            Text("Future: Camera selection, mic input, quality options.")
                .font(Theme.Font.body)
                .foregroundStyle(.gray)
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .background(BrandBackground().ignoresSafeArea())
    }
}

#Preview {
    CameraAudioSettingsView()
}