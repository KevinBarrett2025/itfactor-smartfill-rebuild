import SwiftUI

/// PHASE 4: Migration dashboard for monitoring and controlling SmartFill transition
/// This provides visibility and control over the migration process
struct SmartFillMigrationDashboard: View {
    
    @State private var migrationStats = SmartFillMigrationManager.shared.getMigrationStats()
    @State private var currentStrategy: SmartFillMigrationManager.MigrationStrategy = .smartRouting
    @State private var rolloutPercentage: Double = 25
    @State private var showingAdvancedSettings = false
    
    var body: some View {
        ZStack {
            BrandBackground()
                .ignoresSafeArea()
            
            List {
                // PHASE 4: Migration Overview
                Section("Migration Status") {
                    migrationOverviewCard
                        .listRowBackground(Color.clear)
                }
                
                // PHASE 4: Performance Comparison
                Section("Performance Comparison") {
                    performanceComparisonCard
                        .listRowBackground(Color.clear)
                }
                
                // PHASE 4: Migration Controls
                Section("Migration Controls") {
                    migrationControlsCard
                        .listRowBackground(Color.clear)
                }
                
                // PHASE 4: Advanced Settings
                Section("Advanced Settings") {
                    Button("Advanced Migration Settings") {
                        showingAdvancedSettings = true
                    }
                    .foregroundStyle(Theme.primary)
                    .listRowBackground(Color.clear)
                }
                
                // PHASE 4: Debug Actions (only in debug builds)
                #if DEBUG
                Section("Debug Actions") {
                    debugActionsCard
                        .listRowBackground(Color.clear)
                }
                #endif
            }
            .listStyle(.plain)
            .scrollContentBackground(.hidden)
        }
        .navigationTitle("SmartFill Migration")
        .navigationBarTitleDisplayMode(.inline)
        .sheet(isPresented: $showingAdvancedSettings) {
            SmartFillAdvancedMigrationSettings()
        }
        .onAppear {
            refreshStats()
        }
    }
    
    // MARK: - Phase 4: Migration Overview Card
    
    @ViewBuilder
    private var migrationOverviewCard: some View {
        STSCard(elevation: .elevated) {
            VStack(alignment: .leading, spacing: 16) {
                HStack {
                    Image(systemName: "chart.line.uptrend.xyaxis")
                        .font(.title2)
                        .foregroundStyle(Theme.primary)
                    
                    VStack(alignment: .leading, spacing: 2) {
                        Text("Migration Progress")
                            .font(.headline)
                            .foregroundStyle(Theme.textPrimary)
                        
                        Text("Transitioning to industry-standard compositor")
                            .font(.caption)
                            .foregroundStyle(.secondary)
                    }
                    
                    Spacer()
                    
                    Button("Refresh") {
                        refreshStats()
                    }
                    .font(.caption)
                    .foregroundStyle(Theme.primary)
                }
                
                // PHASE 4: Migration Statistics
                HStack(spacing: 20) {
                    migrationStatCard(
                        title: "Total Processed",
                        value: "\(migrationStats.totalProcessed)",
                        icon: "video.fill",
                        color: .blue
                    )
                    
                    migrationStatCard(
                        title: "New System Usage",
                        value: newSystemUsagePercentage,
                        icon: "sparkles",
                        color: .green
                    )
                    
                    migrationStatCard(
                        title: "Success Rate",
                        value: overallSuccessRate,
                        icon: "checkmark.circle.fill",
                        color: .green
                    )
                }
            }
        }
    }
    
    // MARK: - Phase 4: Performance Comparison Card
    
    @ViewBuilder
    private var performanceComparisonCard: some View {
        STSCard(elevation: .elevated) {
            VStack(alignment: .leading, spacing: 16) {
                HStack {
                    Image(systemName: "speedometer")
                        .font(.title2)
                        .foregroundStyle(.orange)
                    
                    Text("Performance Metrics")
                        .font(.headline)
                        .foregroundStyle(Theme.textPrimary)
                    
                    Spacer()
                }
                
                // PHASE 4: Side-by-side comparison
                HStack(spacing: 16) {
                    // Legacy System
                    VStack(alignment: .leading, spacing: 8) {
                        Text("Legacy System")
                            .font(.subheadline)
                            .fontWeight(.semibold)
                            .foregroundStyle(.orange)
                        
                        performanceMetricRow(
                            label: "Success Rate",
                            value: String(format: "%.1f%%", migrationStats.legacySuccessRate * 100),
                            color: migrationStats.legacySuccessRate > 0.9 ? .green : .orange
                        )
                        
                        performanceMetricRow(
                            label: "Avg Time",
                            value: String(format: "%.2fs", migrationStats.averageLegacyTime),
                            color: .secondary
                        )
                        
                        performanceMetricRow(
                            label: "Processed",
                            value: "\(migrationStats.legacySuccess + migrationStats.legacyFailures)",
                            color: .secondary
                        )
                    }
                    
                    Divider()
                    
                    // New System
                    VStack(alignment: .leading, spacing: 8) {
                        Text("New System")
                            .font(.subheadline)
                            .fontWeight(.semibold)
                            .foregroundStyle(.green)
                        
                        performanceMetricRow(
                            label: "Success Rate",
                            value: String(format: "%.1f%%", migrationStats.newSuccessRate * 100),
                            color: migrationStats.newSuccessRate > 0.9 ? .green : .orange
                        )
                        
                        performanceMetricRow(
                            label: "Avg Time",
                            value: String(format: "%.2fs", migrationStats.averageNewTime),
                            color: .secondary
                        )
                        
                        performanceMetricRow(
                            label: "Processed",
                            value: "\(migrationStats.newSuccess + migrationStats.newFailures)",
                            color: .secondary
                        )
                    }
                }
                
                // PHASE 4: Performance ratio
                if migrationStats.averageLegacyTime > 0 && migrationStats.averageNewTime > 0 {
                    HStack {
                        Text("Performance Improvement:")
                            .font(.caption)
                            .foregroundStyle(.secondary)
                        
                        Spacer()
                        
                        Text("\(String(format: "%.1fx", migrationStats.performanceRatio)) faster")
                            .font(.caption)
                            .fontWeight(.medium)
                            .foregroundStyle(migrationStats.performanceRatio > 1 ? .green : .orange)
                    }
                    .padding(.top, 8)
                }
            }
        }
    }
    
    // MARK: - Phase 4: Migration Controls Card
    
    @ViewBuilder
    private var migrationControlsCard: some View {
        STSCard(elevation: .elevated) {
            VStack(alignment: .leading, spacing: 16) {
                HStack {
                    Image(systemName: "gearshape.fill")
                        .font(.title2)
                        .foregroundStyle(Theme.primary)
                    
                    Text("Migration Strategy")
                        .font(.headline)
                        .foregroundStyle(Theme.textPrimary)
                }
                
                // PHASE 4: Strategy picker
                Picker("Migration Strategy", selection: $currentStrategy) {
                    Text("Smart Routing").tag(SmartFillMigrationManager.MigrationStrategy.smartRouting)
                    Text("A/B Testing").tag(SmartFillMigrationManager.MigrationStrategy.aBTesting)
                    Text("User Choice").tag(SmartFillMigrationManager.MigrationStrategy.userChoice)
                    Text("New Only").tag(SmartFillMigrationManager.MigrationStrategy.newOnly)
                    Text("Legacy Only").tag(SmartFillMigrationManager.MigrationStrategy.legacyOnly)
                }
                .pickerStyle(.segmented)
                .onChange(of: currentStrategy) { _, newValue in
                    SmartFillMigrationManager.shared.setMigrationStrategy(newValue)
                }
                
                // PHASE 4: Rollout percentage (for relevant strategies)
                if currentStrategy == .smartRouting || currentStrategy == .aBTesting {
                    VStack(alignment: .leading, spacing: 8) {
                        HStack {
                            Text("Rollout Percentage")
                                .font(.subheadline)
                                .foregroundStyle(Theme.textPrimary)
                            
                            Spacer()
                            
                            Text("\(Int(rolloutPercentage))%")
                                .font(.caption)
                                .fontWeight(.medium)
                                .foregroundStyle(Theme.primary)
                        }
                        
                        Slider(value: $rolloutPercentage, in: 0...100, step: 5)
                            .tint(Theme.primary)
                            .onChange(of: rolloutPercentage) { _, newValue in
                                SmartFillMigrationManager.shared.setRolloutPercentage(Int(newValue))
                            }
                        
                        Text("Percentage of eligible videos that use the new system")
                            .font(.caption)
                            .foregroundStyle(.secondary)
                    }
                }
                
                // PHASE 4: Quick action buttons
                HStack(spacing: 12) {
                    Button("Reset Stats") {
                        SmartFillMigrationManager.shared.resetMigrationStats()
                        refreshStats()
                    }
                    .buttonStyle(.bordered)
                    .controlSize(.small)
                    
                    Spacer()
                    
                    Button("Export Report") {
                        exportMigrationReport()
                    }
                    .buttonStyle(.borderedProminent)
                    .controlSize(.small)
                }
            }
        }
    }
    
    // MARK: - Phase 4: Debug Actions (Debug builds only)
    
    #if DEBUG
    @ViewBuilder
    private var debugActionsCard: some View {
        STSCard(elevation: .elevated) {
            VStack(alignment: .leading, spacing: 12) {
                HStack {
                    Image(systemName: "ladybug.fill")
                        .font(.title2)
                        .foregroundStyle(.pink)
                    
                    Text("Debug Actions")
                        .font(.headline)
                        .foregroundStyle(Theme.textPrimary)
                }
                
                VStack(spacing: 8) {
                    Button("Simulate High Success (New)") {
                        SmartFillMigrationManager.shared.simulateMigrationScenario("high_success_new")
                        refreshStats()
                    }
                    .buttonStyle(.bordered)
                    .controlSize(.small)
                    
                    Button("Simulate Mixed Results") {
                        SmartFillMigrationManager.shared.simulateMigrationScenario("mixed_results")
                        refreshStats()
                    }
                    .buttonStyle(.bordered)
                    .controlSize(.small)
                    
                    Button("Print Debug Status") {
                        SmartFillMigrationManager.shared.printDebugStatus()
                    }
                    .buttonStyle(.bordered)
                    .controlSize(.small)
                }
            }
        }
    }
    #endif
    
    // MARK: - Phase 4: Helper Views
    
    private func migrationStatCard(title: String, value: String, icon: String, color: Color) -> some View {
        VStack(spacing: 4) {
            Image(systemName: icon)
                .font(.title3)
                .foregroundStyle(color)
            
            Text(value)
                .font(.headline)
                .fontWeight(.bold)
                .foregroundStyle(Theme.textPrimary)
            
            Text(title)
                .font(.caption2)
                .foregroundStyle(.secondary)
                .multilineTextAlignment(.center)
        }
        .frame(maxWidth: .infinity)
    }
    
    private func performanceMetricRow(label: String, value: String, color: Color) -> some View {
        HStack {
            Text(label)
                .font(.caption)
                .foregroundStyle(.secondary)
            
            Spacer()
            
            Text(value)
                .font(.caption)
                .fontWeight(.medium)
                .foregroundStyle(color)
        }
    }
    
    // MARK: - Phase 4: Computed Properties
    
    private var newSystemUsagePercentage: String {
        let total = migrationStats.newSuccess + migrationStats.newFailures
        guard migrationStats.totalProcessed > 0 else { return "0%" }
        let percentage = Double(total) / Double(migrationStats.totalProcessed) * 100
        return String(format: "%.1f%%", percentage)
    }
    
    private var overallSuccessRate: String {
        let totalSuccess = migrationStats.legacySuccess + migrationStats.newSuccess
        guard migrationStats.totalProcessed > 0 else { return "0%" }
        let rate = Double(totalSuccess) / Double(migrationStats.totalProcessed) * 100
        return String(format: "%.1f%%", rate)
    }
    
    // MARK: - Phase 4: Actions
    
    private func refreshStats() {
        migrationStats = SmartFillMigrationManager.shared.getMigrationStats()
    }
    
    private func exportMigrationReport() {
        // PHASE 4: Could implement report export functionality
        print("📊 Migration report export requested")
        // For now, just print to console
        SmartFillMigrationManager.shared.printDebugStatus()
    }
}

// MARK: - Phase 4: Advanced Migration Settings Sheet

struct SmartFillAdvancedMigrationSettings: View {
    @Environment(\.dismiss) private var dismiss
    
    var body: some View {
        NavigationView {
            ZStack {
                BrandBackground()
                    .ignoresSafeArea()
                
                List {
                    Section("Migration Timing") {
                        Text("Advanced timing controls coming soon...")
                            .foregroundStyle(.secondary)
                    }
                    
                    Section("Quality Thresholds") {
                        Text("Quality threshold configuration coming soon...")
                            .foregroundStyle(.secondary)
                    }
                    
                    Section("Rollback Triggers") {
                        Text("Automatic rollback configuration coming soon...")
                            .foregroundStyle(.secondary)
                    }
                }
                .listStyle(.plain)
                .scrollContentBackground(.hidden)
            }
            .navigationTitle("Advanced Migration")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("Done") {
                        dismiss()
                    }
                }
            }
        }
    }
}

#Preview {
    NavigationView {
        SmartFillMigrationDashboard()
    }
}