import Foundation

public final class InMemoryProjectsRepository: ProjectsRepository {
    private var projects: [Project] = []
    
    // CRITICAL: Add persistence paths
    private let documentsDirectory: URL
    private let projectsFileURL: URL
    
    public init() {
        // Set up persistence paths
        self.documentsDirectory = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first!
        self.projectsFileURL = documentsDirectory.appendingPathComponent("STSProjects.json")
        
        // ENTERPRISE: Load persisted projects ONLY - NO SAMPLE DATA
        loadProjectsFromDisk()
        
        print("📂 Repository initialized with \(projects.count) persisted projects")
    }
    
    // MARK: - Data Persistence
    
    private func saveProjectsToDisk() {
        do {
            let encoder = JSONEncoder()
            encoder.dateEncodingStrategy = .iso8601
            let data = try encoder.encode(projects)
            try data.write(to: projectsFileURL)
            print("💾 Repository: Saved \(projects.count) projects to disk")
        } catch {
            print("❌ Repository: Failed to save projects: \(error)")
        }
    }
    
    private func loadProjectsFromDisk() {
        guard FileManager.default.fileExists(atPath: projectsFileURL.path) else {
            print("📂 Repository: No saved projects found - starting with empty state")
            projects = []
            return
        }
        
        do {
            let data = try Data(contentsOf: projectsFileURL)
            let decoder = JSONDecoder()
            decoder.dateDecodingStrategy = .iso8601
            let loadedProjects = try decoder.decode([Project].self, from: data)
            
            // CRITICAL FIX: Deduplicate projects by ID to prevent ForEach chaos
            var uniqueProjects: [Project] = []
            var seenIDs: Set<UUID> = []
            
            for project in loadedProjects {
                if !seenIDs.contains(project.id) {
                    uniqueProjects.append(project)
                    seenIDs.insert(project.id)
                } else {
                    print("⚠️ Repository: Removed duplicate project ID: \(project.id) (\(project.title))")
                }
            }
            
            projects = uniqueProjects
            
            // Save cleaned data back to disk if duplicates were found
            if uniqueProjects.count != loadedProjects.count {
                print("🔧 Repository: Found \(loadedProjects.count - uniqueProjects.count) duplicate projects - saving cleaned data")
                saveProjectsToDisk()
            }
            
            print("✅ Repository: Successfully loaded \(uniqueProjects.count) projects from disk")
        } catch {
            print("❌ Repository: Failed to load projects: \(error)")
            print("📂 Repository: Starting with empty state")
            projects = []
        }
    }
    
    // MARK: - Basic Project Operations
    
    public func fetchProjects() -> [Project] {
        // 🚨 ADDITIONAL SAFETY: Always deduplicate when fetching to prevent ForEach issues
        var uniqueProjects: [Project] = []
        var seenIDs: Set<UUID> = []
        
        for project in projects {
            if !seenIDs.contains(project.id) {
                uniqueProjects.append(project)
                seenIDs.insert(project.id)
            } else {
                print("⚠️ Repository: Runtime duplicate detected during fetch - ID: \(project.id) (\(project.title))")
            }
        }
        
        // If we found runtime duplicates, clean the internal storage
        if uniqueProjects.count != projects.count {
            print("🔧 Repository: Cleaning \(projects.count - uniqueProjects.count) runtime duplicates from memory")
            projects = uniqueProjects
            saveProjectsToDisk()
        }
        
        return uniqueProjects
    }
    
    public func project(by id: UUID) -> Project? {
        return projects.first { $0.id == id }
    }
    
    public func insert(project: Project) {
        // 🚨 ENHANCED DUPLICATE PROTECTION: Check if project already exists before inserting
        if projects.contains(where: { $0.id == project.id }) {
            print("⚠️ Repository: Attempted to insert duplicate project ID: \(project.id) (\(project.title)) - skipping")
            return
        }
        
        projects.append(project)
        saveProjectsToDisk()
        print("✅ Project inserted and persisted: \(project.title)")
    }
    
    public func delete(project: Project) {
        projects.removeAll { $0.id == project.id }
        saveProjectsToDisk()
        print("✅ Project deleted and persisted: \(project.title)")
    }
    
    // MARK: - Session Operations
    
    public func append(session: ProjectSession, to projectID: UUID) {
        guard let projectIndex = projects.firstIndex(where: { $0.id == projectID }) else {
            print("⚠️ Project not found for ID: \(projectID)")
            return
        }
        
        projects[projectIndex].sessions.append(session)
        saveProjectsToDisk()
        print("✅ Session added and persisted to project: \(projects[projectIndex].title)")
    }
    
    public func deleteSession(sessionID: UUID, from projectID: UUID) {
        guard let projectIndex = projects.firstIndex(where: { $0.id == projectID }) else {
            print("⚠️ Project not found for ID: \(projectID)")
            return
        }
        
        projects[projectIndex].sessions.removeAll { $0.id == sessionID }
        saveProjectsToDisk()
        print("✅ Session deleted and persisted from project: \(projects[projectIndex].title)")
    }
    
    // MARK: - Enhanced Take Management with Scene Organization
    
    public func addTake(_ take: ProjectTake, to sessionID: UUID, in projectID: UUID) {
        guard let projectIndex = projects.firstIndex(where: { $0.id == projectID }),
              let sessionIndex = projects[projectIndex].sessions.firstIndex(where: { $0.id == sessionID }) else {
            print("⚠️ Project or session not found for take: \(take.filePath)")
            return
        }
        
        projects[projectIndex].sessions[sessionIndex].takes.append(take)
        saveProjectsToDisk()
        print("✅ Take added and persisted: \(take.filePath) to scene \(take.sceneNumber), take \(take.takeNumber)")
    }
    
    public func updateTake(_ take: ProjectTake, in sessionID: UUID, in projectID: UUID) {
        guard let projectIndex = projects.firstIndex(where: { $0.id == projectID }),
              let sessionIndex = projects[projectIndex].sessions.firstIndex(where: { $0.id == sessionID }),
              let takeIndex = projects[projectIndex].sessions[sessionIndex].takes.firstIndex(where: { $0.id == take.id }) else {
            print("⚠️ Take not found for update: \(take.filePath)")
            return
        }
        
        projects[projectIndex].sessions[sessionIndex].takes[takeIndex] = take
        saveProjectsToDisk()
        print("✅ Take updated and persisted: \(take.filePath)")
    }
    
    // NEW: SmartFill specific methods for file management integration
    public func updateTakeWithSmartFillPath(takeID: UUID, smartFilledPath: String, in sessionID: UUID, in projectID: UUID) {
        print("🔍 Repository: Attempting SmartFill path update for takeID: \(takeID)")
        print("   🆔 Looking for take in project: \(projectID), session: \(sessionID)")
        
        guard let projectIndex = projects.firstIndex(where: { $0.id == projectID }) else {
            print("❌ Repository: Project not found for SmartFill update - projectID: \(projectID)")
            return
        }
        
        guard let sessionIndex = projects[projectIndex].sessions.firstIndex(where: { $0.id == sessionID }) else {
            print("❌ Repository: Session not found for SmartFill update - sessionID: \(sessionID)")
            return
        }
        
        print("🔍 Repository: Found project and session, searching for take among \(projects[projectIndex].sessions[sessionIndex].takes.count) takes")
        
        // DEBUG: Log all take IDs in the session
        for (index, take) in projects[projectIndex].sessions[sessionIndex].takes.enumerated() {
            print("   Take \(index): ID=\(take.id), filename=\(URL(fileURLWithPath: take.filePath).lastPathComponent)")
        }
        
        guard let takeIndex = projects[projectIndex].sessions[sessionIndex].takes.firstIndex(where: { $0.id == takeID }) else {
            print("❌ Repository: Take not found for SmartFill update - takeID: \(takeID)")
            print("   Available take IDs: \(projects[projectIndex].sessions[sessionIndex].takes.map { $0.id })")
            return
        }
        
        // CRITICAL FIX: Store relative path instead of absolute path
        let relativePath = normalizeToRelativePath(smartFilledPath)
        projects[projectIndex].sessions[sessionIndex].takes[takeIndex].smartFilledFilePath = relativePath
        
        // PERFORMANCE FIX: Invalidate cache when SmartFill path is updated
        ProjectTake.invalidateSmartFillCache(for: takeID)
        
        saveProjectsToDisk()
        print("✅ Repository: Take updated with SmartFill RELATIVE path - takeID: \(takeID)")
        print("📁 Stored relative path: \(relativePath)")
        print("📁 Original absolute path: \(smartFilledPath)")
        
        // Verify the relative path resolves correctly
        let resolvedURL = VideoVariantResolver.urlForRelativePath(relativePath)
        print("🔍 Relative path resolves to: \(resolvedURL.path)")
        print("💾 Resolved file exists: \(FileManager.default.fileExists(atPath: resolvedURL.path))")
    }
    
    // CRITICAL FIX: Helper method to normalize paths to relative format
    private func normalizeToRelativePath(_ path: String) -> String {
        // If it's already a relative path (doesn't start with /), return as-is
        guard path.hasPrefix("/") else {
            return path
        }
        
        // Convert absolute path to relative path
        let url = URL(fileURLWithPath: path)
        return VideoVariantResolver.relativePath(from: url)
    }
    
    public func getSmartFillStatus(for sessionID: UUID, in projectID: UUID) -> SmartFillSessionStatus {
        guard let project = project(by: projectID),
              let session = project.sessions.first(where: { $0.id == sessionID }) else {
            return SmartFillSessionStatus()
        }
        
        let portraitTakes = session.takes.filter { $0.capturedOrientation == .portrait }
        let smartFilledTakes = portraitTakes.filter { $0.hasSmartFilledVersion }
        let pendingTakes = portraitTakes.filter { !$0.hasSmartFilledVersion }
        
        return SmartFillSessionStatus(
            totalPortraitTakes: portraitTakes.count,
            smartFilledTakes: smartFilledTakes.count,
            pendingTakes: pendingTakes.count,
            allPortraitTakes: portraitTakes,
            needsProcessing: !pendingTakes.isEmpty
        )
    }
    
    // NEW: Batch SmartFill processing support
    public func markTakeForBatchSmartFill(takeID: UUID, in sessionID: UUID, in projectID: UUID) {
        // Mark take for batch processing (could use takeNotes or a new field)
        guard let projectIndex = projects.firstIndex(where: { $0.id == projectID }),
              let sessionIndex = projects[projectIndex].sessions.firstIndex(where: { $0.id == sessionID }),
              let takeIndex = projects[projectIndex].sessions[sessionIndex].takes.firstIndex(where: { $0.id == takeID }) else {
            return
        }
        
        let currentNotes = projects[projectIndex].sessions[sessionIndex].takes[takeIndex].takeNotes ?? ""
        if !currentNotes.contains("BATCH_SMARTFILL_PENDING") {
            projects[projectIndex].sessions[sessionIndex].takes[takeIndex].takeNotes = "\(currentNotes) BATCH_SMARTFILL_PENDING".trimmingCharacters(in: .whitespaces)
        }
        saveProjectsToDisk()
        print("📱 Take marked for batch SmartFill processing: \(takeID)")
    }
    
    public func clearBatchSmartFillFlag(takeID: UUID, in sessionID: UUID, in projectID: UUID) {
        guard let projectIndex = projects.firstIndex(where: { $0.id == projectID }),
              let sessionIndex = projects[projectIndex].sessions.firstIndex(where: { $0.id == sessionID }),
              let takeIndex = projects[projectIndex].sessions[sessionIndex].takes.firstIndex(where: { $0.id == takeID }) else {
            return
        }
        
        if let currentNotes = projects[projectIndex].sessions[sessionIndex].takes[takeIndex].takeNotes {
            projects[projectIndex].sessions[sessionIndex].takes[takeIndex].takeNotes = currentNotes.replacingOccurrences(of: "BATCH_SMARTFILL_PENDING", with: "").trimmingCharacters(in: .whitespaces)
            if projects[projectIndex].sessions[sessionIndex].takes[takeIndex].takeNotes?.isEmpty == true {
                projects[projectIndex].sessions[sessionIndex].takes[takeIndex].takeNotes = nil
            }
        }
        saveProjectsToDisk()
    }
    
    public func deleteTake(_ take: ProjectTake, from sessionID: UUID, in projectID: UUID) {
        guard let projectIndex = projects.firstIndex(where: { $0.id == projectID }),
              let sessionIndex = projects[projectIndex].sessions.firstIndex(where: { $0.id == sessionID }) else {
            return
        }
        
        projects[projectIndex].sessions[sessionIndex].takes.removeAll { $0.id == take.id }
        saveProjectsToDisk()
        print("✅ Take deleted and persisted: \(take.filePath)")
    }
    
    // MARK: - Enhanced Scene-based Take Queries
    
    public func takesForScene(_ sceneNumber: Int, in sessionID: UUID, in projectID: UUID) -> [ProjectTake] {
        guard let project = project(by: projectID),
              let session = project.sessions.first(where: { $0.id == sessionID }) else {
            return []
        }
        
        return session.takes.filter { $0.sceneNumber == sceneNumber }
            .sorted { take1, take2 in
                // Sort by takeNumber within scene
                take1.takeNumber < take2.takeNumber
            }
    }
    
    public func takesByScene(in sessionID: UUID, in projectID: UUID) -> [Int: [ProjectTake]] {
        guard let project = project(by: projectID),
              let session = project.sessions.first(where: { $0.id == sessionID }) else {
            return [:]
        }
        
        // Group takes by scene number
        let grouped = Dictionary(grouping: session.takes) { $0.sceneNumber }
        
        // Sort takes within each scene by take number
        var sortedByScene: [Int: [ProjectTake]] = [:]
        for (sceneNumber, takes) in grouped {
            sortedByScene[sceneNumber] = takes.sorted { $0.takeNumber < $1.takeNumber }
        }
        
        return sortedByScene
    }
    
    public func maxSceneNumber(in sessionID: UUID, in projectID: UUID) -> Int {
        guard let project = project(by: projectID),
              let session = project.sessions.first(where: { $0.id == sessionID }) else {
            return 1
        }
        
        let maxScene = session.takes.map { $0.sceneNumber }.max() ?? 1
        return maxScene
    }
    
    // MARK: - Enhanced Slate Management
    
    public func slateTakes(in sessionID: UUID, in projectID: UUID) -> [ProjectTake] {
        guard let project = project(by: projectID),
              let session = project.sessions.first(where: { $0.id == sessionID }) else {
            return []
        }
        
        return session.takes.filter { $0.takeType == .slate }
            .sorted { $0.createdAt < $1.createdAt }
    }
    
    public func keyframePhotoTakes(in sessionID: UUID, in projectID: UUID) -> [ProjectTake] {
        guard let project = project(by: projectID),
              let session = project.sessions.first(where: { $0.id == sessionID }) else {
            return []
        }
        
        // For keyframe photos, we can filter by a specific tag or notes pattern
        // Or add a new TakeType.keyframePhoto if needed
        return session.takes.filter { take in
            take.takeNotes?.contains("keyframe") == true ||
            take.takeNotes?.contains("photo") == true
        }.sorted { $0.createdAt < $1.createdAt }
    }
    
    // MARK: - Enhanced Take Numbering and Organization
    
    public func nextTakeNumber(for sceneNumber: Int, in sessionID: UUID, in projectID: UUID) -> Int {
        let sceneTakes = takesForScene(sceneNumber, in: sessionID, in: projectID)
        let maxTakeNumber = sceneTakes.map { $0.takeNumber }.max() ?? 0
        return maxTakeNumber + 1
    }
    
    public func nextSlateNumber(in sessionID: UUID, in projectID: UUID) -> Int {
        let slateTakesCount = slateTakes(in: sessionID, in: projectID)
        let maxSlateNumber = slateTakesCount.compactMap { $0.slateNumber?.trimmingCharacters(in: .letters) }
            .compactMap { Int($0) }
            .max() ?? 0
        return maxSlateNumber + 1
    }
    
    // 🚨 NEW: SmartFill path migration and recovery system
    public func migrateSmartFillPaths() -> Int {
        print("🔄 Starting SmartFill path migration...")
        var migrationCount = 0
        
        // Get current Documents directory
        guard let currentDocumentsURL = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first else {
            print("❌ Could not get current Documents directory for migration")
            return 0
        }
        
        for projectIndex in projects.indices {
            for sessionIndex in projects[projectIndex].sessions.indices {
                for takeIndex in projects[projectIndex].sessions[sessionIndex].takes.indices {
                    let take = projects[projectIndex].sessions[sessionIndex].takes[takeIndex]
                    
                    guard let originalSmartFillPath = take.smartFilledFilePath,
                          !FileManager.default.fileExists(atPath: originalSmartFillPath) else {
                        continue
                    }
                    
                    // Try to migrate the path
                    let migratedPath = attemptPathMigration(originalPath: originalSmartFillPath, currentDocumentsURL: currentDocumentsURL)
                    
                    if let newPath = migratedPath,
                       FileManager.default.fileExists(atPath: newPath) {
                        
                        // Update the path in the repository
                        projects[projectIndex].sessions[sessionIndex].takes[takeIndex].smartFilledFilePath = newPath
                        migrationCount += 1
                        
                        print("✅ Migrated SmartFill path for take: \(take.id)")
                        print("   🗂️ Old: \(originalSmartFillPath)")
                        print("   📁 New: \(newPath)")
                        
                        // Invalidate cache for this take
                        ProjectTake.invalidateSmartFillCache(for: take.id)
                    }
                }
            }
        }
        
        if migrationCount > 0 {
            print("✅ SmartFill path migration completed: \(migrationCount) paths migrated")
            // Persist the changes to disk
            saveProjectsToDisk()
        } else {
            print("📋 No SmartFill paths needed migration")
        }
        
        return migrationCount
    }
    
    private func attemptPathMigration(originalPath: String, currentDocumentsURL: URL) -> String? {
        let originalURL = URL(fileURLWithPath: originalPath)
        let pathComponents = originalURL.pathComponents
        
        // Check if this looks like a container path
        guard pathComponents.contains("Containers"),
              pathComponents.contains("Data"),
              pathComponents.contains("Application") else {
            return nil
        }
        
        // Method 1: Extract relative path after Documents
        if let documentsIndex = pathComponents.firstIndex(of: "Documents"),
           documentsIndex < pathComponents.count - 1 {
            
            let relativeComponents = Array(pathComponents[(documentsIndex + 1)...])
            let migratedURL = relativeComponents.reduce(currentDocumentsURL) { url, component in
                url.appendingPathComponent(component)
            }
            
            if FileManager.default.fileExists(atPath: migratedURL.path) {
                return migratedURL.path
            }
        }
        
        // Method 2: Look in SmartFill directory by filename
        let smartFillDir = currentDocumentsURL.appendingPathComponent("SmartFill")
        let fileName = originalURL.lastPathComponent
        let alternativeURL = smartFillDir.appendingPathComponent(fileName)
        
        if FileManager.default.fileExists(atPath: alternativeURL.path) {
            return alternativeURL.path
        }
        
        return nil
    }
    
    // 🚨 NEW: SmartFill recovery system - get portrait takes needing SmartFill
    public func getPortraitTakesNeedingSmartFill() -> [(take: ProjectTake, session: ProjectSession, project: Project)] {
        var needsSmartFill: [(ProjectTake, ProjectSession, Project)] = []
        
        for project in projects {
            for session in project.sessions {
                for take in session.takes {
                    // Check if this is a portrait video that needs SmartFill
                    if take.capturedOrientation == .portrait,
                       take.takeType != .exported, // Don't process exported takes
                       (!take.hasSmartFilledVersion || take.smartFilledFilePath == nil) {
                        needsSmartFill.append((take, session, project))
                    }
                }
            }
        }
        
        print("📋 Found \(needsSmartFill.count) portrait takes needing SmartFill regeneration")
        return needsSmartFill
    }
}

// MARK: - Extended Repository Methods
extension InMemoryProjectsRepository {
    
    // NEW: Save merged video method
    public func saveMergedVideo(filePath: String, duration: Double, exportMetadata: ExportMetadata, to sessionID: UUID, in projectID: UUID) {
        let mergedTake = ProjectTake(
            filePath: filePath,
            durationSeconds: duration,
            takeNotes: exportMetadata.exportType.displayName,
            exportMetadata: exportMetadata,
            takeType: .merged
        )
        
        addTake(mergedTake, to: sessionID, in: projectID)
        print("✅ Merged video saved: \(filePath)")
    }
    
    // LEGACY METHODS: Basic implementations for compatibility
    public func archiveSession(sessionID: UUID, in projectID: UUID) {
        // Find and update session
        guard let projectIndex = projects.firstIndex(where: { $0.id == projectID }),
              let sessionIndex = projects[projectIndex].sessions.firstIndex(where: { $0.id == sessionID }) else {
            return
        }
        projects[projectIndex].sessions[sessionIndex].isArchived = true
        saveProjectsToDisk()
    }
    
    public func unarchiveSession(sessionID: UUID, in projectID: UUID) {
        guard let projectIndex = projects.firstIndex(where: { $0.id == projectID }),
              let sessionIndex = projects[projectIndex].sessions.firstIndex(where: { $0.id == sessionID }) else {
            return
        }
        projects[projectIndex].sessions[sessionIndex].isArchived = false
        saveProjectsToDisk()
    }
    
    public func toggleSessionFavorite(sessionID: UUID, in projectID: UUID) {
        guard let projectIndex = projects.firstIndex(where: { $0.id == projectID }),
              let sessionIndex = projects[projectIndex].sessions.firstIndex(where: { $0.id == sessionID }) else {
            return
        }
        projects[projectIndex].sessions[sessionIndex].isFavorite.toggle()
        saveProjectsToDisk()
    }
    
    public func duplicateSession(sessionID: UUID, in projectID: UUID) {
        // Basic implementation - duplicate the session
        guard let project = project(by: projectID),
              let session = project.sessions.first(where: { $0.id == sessionID }) else {
            return
        }
        
        var duplicatedSession = session
        duplicatedSession.id = UUID()
        duplicatedSession.takes = [] // Start with no takes
        append(session: duplicatedSession, to: projectID)
    }
    
    public func exportSession(sessionID: UUID, from projectID: UUID) {
        // Enterprise implementation would trigger actual export
        print("Enterprise export session requested for \(sessionID)")
    }
    
    public func setUnifiedTakeRating(takeID: UUID, sessionID: UUID, projectID: UUID, rating: TakeRating) {
        // Find and update the take rating
        guard let projectIndex = projects.firstIndex(where: { $0.id == projectID }),
              let sessionIndex = projects[projectIndex].sessions.firstIndex(where: { $0.id == sessionID }),
              let takeIndex = projects[projectIndex].sessions[sessionIndex].takes.firstIndex(where: { $0.id == takeID }) else {
            return
        }
        
        projects[projectIndex].sessions[sessionIndex].takes[takeIndex].rating = rating
        saveProjectsToDisk()
    }
    
    public func toggleTakeFavorite(takeID: UUID, in sessionID: UUID, of projectID: UUID) {
        guard let projectIndex = projects.firstIndex(where: { $0.id == projectID }),
              let sessionIndex = projects[projectIndex].sessions.firstIndex(where: { $0.id == sessionID }),
              let takeIndex = projects[projectIndex].sessions[sessionIndex].takes.firstIndex(where: { $0.id == takeID }) else {
            return
        }
        
        let currentRating = projects[projectIndex].sessions[sessionIndex].takes[takeIndex].rating
        let newRating: TakeRating = currentRating == .favorite ? .unrated : .favorite
        projects[projectIndex].sessions[sessionIndex].takes[takeIndex].rating = newRating
        saveProjectsToDisk()
    }
    
    public func exportTake(takeID: UUID, from sessionID: UUID, in projectID: UUID) {
        print("Enterprise export take requested for \(takeID)")
    }
    
    public func deleteTake(takeID: UUID, from sessionID: UUID, in projectID: UUID) {
        guard let projectIndex = projects.firstIndex(where: { $0.id == projectID }),
              let sessionIndex = projects[projectIndex].sessions.firstIndex(where: { $0.id == sessionID }) else {
            return
        }
        
        projects[projectIndex].sessions[sessionIndex].takes.removeAll { $0.id == takeID }
        saveProjectsToDisk()
    }
    
    public func toggleFavorite(project: Project) {
        guard let projectIndex = projects.firstIndex(where: { $0.id == project.id }) else {
            return
        }
        projects[projectIndex].isFavorite.toggle()
        saveProjectsToDisk()
    }
    
    public func toggleArchive(project: Project) {
        guard let projectIndex = projects.firstIndex(where: { $0.id == project.id }) else {
            return
        }
        projects[projectIndex].isArchived.toggle()
        saveProjectsToDisk()
    }
    
    public func toggleComplete(project: Project) {
        guard let projectIndex = projects.firstIndex(where: { $0.id == project.id }) else {
            return
        }
        projects[projectIndex].isCompleted.toggle()
        saveProjectsToDisk()
    }
    
    public func exportProject(_ project: Project) {
        print("Enterprise export project requested for \(project.title)")
    }
    
    // UNIFIED MODEL SUPPORT
    public func getUnifiedVideoMarkers(for takeID: UUID, in sessionID: UUID, of projectID: UUID) -> [UnifiedVideoMarker] {
        // Return empty array for now - unified markers not fully implemented
        return []
    }
    
    public func addUnifiedVideoMarker(_ marker: UnifiedVideoMarker, to takeID: UUID, in sessionID: UUID, of projectID: UUID) {
        // Enterprise implementation would persist markers
        print("Enterprise unified video marker added for take \(takeID)")
    }
    
    // ENABLE UNIFIED MODEL SUPPORT
    public func enableUnifiedModelSupport() {
        print("✅ Enterprise unified model support enabled")
    }
    
    public func addTakeNote(takeID: UUID, in sessionID: UUID, of projectID: UUID, note: String) {
        guard let projectIndex = projects.firstIndex(where: { $0.id == projectID }),
              let sessionIndex = projects[projectIndex].sessions.firstIndex(where: { $0.id == sessionID }),
              let takeIndex = projects[projectIndex].sessions[sessionIndex].takes.firstIndex(where: { $0.id == takeID }) else {
            return
        }
        
        projects[projectIndex].sessions[sessionIndex].takes[takeIndex].takeNotes = note
        saveProjectsToDisk()
    }
    
    public func exportSession(sessionID: UUID, projectID: UUID, takeIDs: [UUID]) {
        print("Enterprise export session requested for \(sessionID) with \(takeIDs.count) takes")
    }
}
