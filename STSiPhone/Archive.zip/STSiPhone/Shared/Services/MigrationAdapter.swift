import Foundation
import SwiftUI

/// Migration Adapter - Enables seamless transition from old to new architecture
/// Provides compatibility layer so existing views continue working during migration
@MainActor
class MigrationAdapter: ObservableObject {
    static let shared = MigrationAdapter()
    
    // MIGRATION FLAGS: Control which views use new vs old systems
    @Published var useUnifiedVideoPlayer = false
    @Published var useUnifiedDataModels = false
    @Published var useConsolidatedExport = false
    
    // FEATURE FLAGS: Enable new features gradually
    @Published var enableAdvancedVideoMarkers = true
    @Published var enableContextSwitching = true
    @Published var enableUnifiedSearch = false
    
    private init() {}
    
    // MARK: - Video Player Migration
    
    /// Get video player for specific view - routes to new or old system
    func getVideoPlayer(for context: String) -> Any {
        if useUnifiedVideoPlayer {
            // Note: VideoPlayerService's switchContext now uses its own enum.
            // This adapter is responsible for mapping the string context.
            VideoPlayerService.shared.switchContext(to: videoServiceContextFromString(context))
            return VideoPlayerService.shared
        } else {
            // Return existing VideoPlayerManager for backward compatibility
            return createLegacyVideoPlayerManager()
        }
    }
    
    /// Converts a string context to the `VideoPlayerContext` used by `UnifiedVideoPlayerView`
    func unifiedPlayerContextFromString(_ context: String) -> VideoPlayerContext {
        switch context {
        case "takePlayer": return .takePreview
        case "fullscreenPlayer": return .fullscreenPlayer
        case "sessionReview": return .sessionReview
        case "export": return .export
        default: return .takePreview
        }
    }
    
    /// Converts a string context to the `VideoContext` used by `VideoPlayerService`
    private func videoServiceContextFromString(_ context: String) -> VideoPlayerService.VideoContext {
        switch context {
        case "takePlayer": return .takePlayer
        case "fullscreenPlayer": return .fullscreenPlayer
        case "timelineEditor": return .timelineEditor
        case "scriptSync": return .scriptSync
        default: return .none
        }
    }
    
    private func createLegacyVideoPlayerManager() -> Any {
        // This would return the old VideoPlayerManager type
        // For now, return the unified service for consistency
        return VideoPlayerService.shared
    }
    
    // MARK: - Data Model Migration
    
    /// Convert between old and new data models transparently
    func convertTake<T>(_ take: Any, to targetType: T.Type) -> T? {
        if useUnifiedDataModels {
            // Use new unified models
            if let enhancedTake = take as? EnhancedTake, targetType == UnifiedTake.self {
                return UnifiedTake(from: enhancedTake) as? T
            }
        }
        
        // Return original for backward compatibility
        return take as? T
    }
    
    /// Batch convert takes
    func convertTakes<T>(_ takes: [Any], to targetType: T.Type) -> [T] {
        return takes.compactMap { convertTake($0, to: targetType) }
    }
    
    // MARK: - Export Migration
    
    /// Route export requests to appropriate system
    func exportTakes(_ takes: [Any], options: Any, completion: @escaping (Result<Any, Error>) -> Void) {
        if useConsolidatedExport {
            // Use new consolidated export system
            print("🚀 MigrationAdapter: Using consolidated export system")
            // Route to ExportEngine.shared
        } else {
            // Use existing export methods
            print("🚀 MigrationAdapter: Using legacy export system")
            // Route to SessionManager or ProjectsRepository export methods
        }
    }
    
    // MARK: - Migration Control
    
    /// Enable unified video player system
    func enableUnifiedVideoPlayer() {
        print("🔄 MigrationAdapter: Enabling unified video player system")
        useUnifiedVideoPlayer = true
    }
    
    /// Enable unified data models
    func enableUnifiedDataModels() {
        print("🔄 MigrationAdapter: Enabling unified data models")
        useUnifiedDataModels = true
    }
    
    /// Enable consolidated export system
    func enableConsolidatedExport() {
        print("🔄 MigrationAdapter: Enabling consolidated export system")
        useConsolidatedExport = true
    }
    
    /// Enable all new systems (full migration)
    func enableAllUnifiedSystems() {
        enableUnifiedVideoPlayer()
        enableUnifiedDataModels()
        enableConsolidatedExport()
        print("✅ MigrationAdapter: All unified systems enabled")
    }
    
    /// Disable all new systems (fallback to legacy)
    func disableAllUnifiedSystems() {
        useUnifiedVideoPlayer = false
        useUnifiedDataModels = false
        useConsolidatedExport = false
        print("↩️ MigrationAdapter: Reverted to legacy systems")
    }
    
    // MARK: - Health Checks
    
    /// Verify all systems are working properly
    func performSystemHealthCheck() -> MigrationHealthReport {
        var report = MigrationHealthReport()
        
        // Test video player system
        if useUnifiedVideoPlayer {
            report.videoPlayerStatus = VideoPlayerService.shared.activeContext != .none ? .healthy : .warning
            report.videoPlayerDetails = "Context: \(VideoPlayerService.shared.activeContext.displayName)"
        } else {
            report.videoPlayerStatus = .legacy
            report.videoPlayerDetails = "Using legacy VideoPlayerManager instances"
        }
        
        // Test data model system
        if useUnifiedDataModels {
            report.dataModelStatus = .healthy
            report.dataModelDetails = "Using UnifiedTake and UnifiedVideoMarker models"
        } else {
            report.dataModelStatus = .legacy
            report.dataModelDetails = "Using EnhancedTake/ProjectTake and VideoMarker/TakeVideoMarker"
        }
        
        // Test export system
        if useConsolidatedExport {
            report.exportStatus = .healthy
            report.exportDetails = "Using consolidated ExportEngine"
        } else {
            report.exportStatus = .legacy
            report.exportDetails = "Using multiple export systems"
        }
        
        print("🏥 MigrationAdapter: Health check completed")
        return report
    }
    
    // MARK: - Feature Management
    
    func isFeatureEnabled(_ feature: String) -> Bool {
        switch feature {
        case "advancedVideoMarkers": return enableAdvancedVideoMarkers
        case "contextSwitching": return enableContextSwitching
        case "unifiedSearch": return enableUnifiedSearch
        default: return false
        }
    }
}

// MARK: - Health Reporting

struct MigrationHealthReport {
    enum SystemStatus {
        case healthy, warning, error, legacy
        
        var displayName: String {
            switch self {
            case .healthy: return "✅ Healthy"
            case .warning: return "⚠️ Warning"
            case .error: return "❌ Error"
            case .legacy: return "📱 Legacy"
            }
        }
    }
    
    var videoPlayerStatus: SystemStatus = .legacy
    var videoPlayerDetails: String = ""
    
    var dataModelStatus: SystemStatus = .legacy
    var dataModelDetails: String = ""
    
    var exportStatus: SystemStatus = .legacy
    var exportDetails: String = ""
    
    var overallStatus: SystemStatus {
        let statuses = [videoPlayerStatus, dataModelStatus, exportStatus]
        
        if statuses.contains(.error) { return .error }
        if statuses.contains(.warning) { return .warning }
        if statuses.allSatisfy({ $0 == .healthy }) { return .healthy }
        return .legacy
    }
    
    func generateReport() -> String {
        return """
        📊 MIGRATION HEALTH REPORT
        
        Overall Status: \(overallStatus.displayName)
        
        🎥 Video Player: \(videoPlayerStatus.displayName)
        \(videoPlayerDetails)
        
        📊 Data Models: \(dataModelStatus.displayName)
        \(dataModelDetails)
        
        📤 Export System: \(exportStatus.displayName)
        \(exportDetails)
        """
    }
}

// MARK: - SwiftUI Integration

/// Migration-aware video player view
struct MigrationVideoPlayerView: View {
    let context: String
    @StateObject private var adapter = MigrationAdapter.shared
    
    var body: some View {
        Group {
            if adapter.useUnifiedVideoPlayer {
                // CORRECTED: Use the correct context mapping function
                UnifiedVideoPlayerView(context: adapter.unifiedPlayerContextFromString(context))
            } else {
                // Use existing video player views
                LegacyVideoPlayerWrapper(context: context)
            }
        }
    }
}

/// Wrapper for existing video player views during migration
struct LegacyVideoPlayerWrapper: View {
    let context: String
    
    var body: some View {
        Text("Legacy Video Player: \(context)")
            .foregroundColor(.gray)
    }
}

// MARK: - Debug & Testing

#if DEBUG
extension MigrationAdapter {
    /// Test migration scenarios
    func runMigrationTests() {
        print("🧪 Running migration tests...")
        
        // Test video player switching
        enableUnifiedVideoPlayer()
        let healthBefore = performSystemHealthCheck()
        
        disableAllUnifiedSystems()
        let healthAfter = performSystemHealthCheck()
        
        print("📋 Migration test results:")
        print("Before: \(healthBefore.overallStatus.displayName)")
        print("After: \(healthAfter.overallStatus.displayName)")
        
        // Reset to safe state
        useUnifiedVideoPlayer = false
    }
}
#endif
