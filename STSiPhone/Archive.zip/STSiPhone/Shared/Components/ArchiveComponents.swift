import SwiftUI

/// Shared components for archive functionality
/// Based on Master Brain entries #160-170 archive system requirements

// MARK: - Archive Option Selection
struct ArchiveOption: Identifiable {
    let id = UUID()
    let title: String
    let description: String
    let icon: String
    var isSelected: Bool = false
}

// MARK: - Archive Options Panel
struct ArchiveOptionsPanel: View {
    @Binding var selectedOptions: Set<String>
    let options: [ArchiveOption]
    
    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("Archive Options")
                .font(.subheadline)
                .fontWeight(.medium)
                .foregroundStyle(.primary)
            
            ForEach(options) { option in
                ArchiveOptionRow(
                    option: option,
                    isSelected: selectedOptions.contains(option.title)
                ) {
                    if selectedOptions.contains(option.title) {
                        selectedOptions.remove(option.title)
                    } else {
                        selectedOptions.insert(option.title)
                    }
                }
            }
        }
        .padding()
        .background(
            RoundedRectangle(cornerRadius: 12)
                .fill(Color(.systemGray6))
        )
    }
}

// MARK: - Archive Option Row
struct ArchiveOptionRow: View {
    let option: ArchiveOption
    let isSelected: Bool
    let onTap: () -> Void
    
    var body: some View {
        Button(action: onTap) {
            HStack(spacing: 12) {
                Image(systemName: option.icon)
                    .font(.caption)
                    .foregroundStyle(isSelected ? .blue : .gray)
                    .frame(width: 16)
                
                VStack(alignment: .leading, spacing: 2) {
                    Text(option.title)
                        .font(.caption)
                        .fontWeight(.medium)
                        .foregroundStyle(.primary)
                    
                    Text(option.description)
                        .font(.caption2)
                        .foregroundStyle(.secondary)
                }
                
                Spacer()
                
                Image(systemName: isSelected ? "checkmark.circle.fill" : "circle")
                    .font(.caption)
                    .foregroundStyle(isSelected ? .blue : .gray)
            }
            .padding(.vertical, 6)
        }
        .buttonStyle(PlainButtonStyle())
    }
}

// MARK: - Archive Action Button
struct ArchiveActionButton: View {
    let title: String
    let icon: String
    let color: Color
    let action: () -> Void
    
    var body: some View {
        Button(action: action) {
            HStack(spacing: 6) {
                Image(systemName: icon)
                    .font(.caption)
                Text(title)
                    .font(.caption)
                    .fontWeight(.medium)
            }
            .foregroundStyle(color)
            .padding(.horizontal, 12)
            .padding(.vertical, 8)
            .background(
                RoundedRectangle(cornerRadius: 8)
                    .fill(color.opacity(0.1))
                    .overlay(
                        RoundedRectangle(cornerRadius: 8)
                            .stroke(color.opacity(0.3), lineWidth: 1)
                    )
            )
        }
        .buttonStyle(PlainButtonStyle())
    }
}

// MARK: - Default Archive Options
extension ArchiveOption {
    static let defaultProjectArchiveOptions: [ArchiveOption] = [
        ArchiveOption(
            title: "Export Videos",
            description: "Include all video files in archive",
            icon: "video.fill"
        ),
        ArchiveOption(
            title: "Export Audio",
            description: "Include audio recordings",
            icon: "mic.fill"
        ),
        ArchiveOption(
            title: "Export Markers",
            description: "Include video markers and notes",
            icon: "bookmark.fill"
        ),
        ArchiveOption(
            title: "High Quality",
            description: "Use original video quality",
            icon: "sparkles"
        ),
        ArchiveOption(
            title: "Metadata",
            description: "Include project and session details",
            icon: "doc.text.fill"
        )
    ]
    
    static let defaultSessionArchiveOptions: [ArchiveOption] = [
        ArchiveOption(
            title: "Export Takes",
            description: "Include all take videos",
            icon: "video.fill"
        ),
        ArchiveOption(
            title: "Export Markers",
            description: "Include video markers",
            icon: "bookmark.fill"
        ),
        ArchiveOption(
            title: "High Quality",
            description: "Use original quality",
            icon: "sparkles"
        )
    ]
}

#Preview {
    VStack(spacing: 20) {
        ArchiveOptionsPanel(
            selectedOptions: .constant(Set(["Export Videos", "High Quality"])),
            options: ArchiveOption.defaultProjectArchiveOptions
        )
        
        HStack(spacing: 12) {
            ArchiveActionButton(
                title: "Archive Project",
                icon: "archivebox.fill",
                color: .blue
            ) {}
            
            ArchiveActionButton(
                title: "Delete Project",
                icon: "trash.fill",
                color: .red
            ) {}
        }
    }
    .padding()
    .background(Color(.systemBackground))
}