import Foundation

// MARK: - Actor Profile Models
struct ActorProfile: Codable {
    var id = UUID()
    
    // Basic Info
    var name: String = ""
    var email: String = ""
    var phone: String = ""
    var sagStatus: SAGStatus = .nonUnion
    var sagNumber: String = ""
    var ageRange: String = ""
    
    // Appearance/Stats
    var height: String = ""
    var weight: String = ""
    var hairColor: String = ""
    var eyeColor: String = ""
    var shirtSize: String = ""
    var pantSize: String = ""
    var shoeSize: String = ""
    
    // Uploads (stored as file names/paths)
    var headshots: [String] = []
    var sizeCards: [String] = []
    var resumes: [String] = []
    
    var createdAt: Date = Date()
    var updatedAt: Date = Date()
    
    // Computed properties for display
    var displayName: String {
        name.isEmpty ? "Anonymous Actor" : name
    }
    
    var sagDisplayStatus: String {
        switch sagStatus {
        case .member:
            return sagNumber.isEmpty ? "SAG-AFTRA Member" : "SAG-AFTRA Member #\(sagNumber)"
        case .eligible:
            return "SAG-AFTRA Eligible"
        case .nonUnion:
            return "Non-Union"
        }
    }
}

enum SAGStatus: String, CaseIterable, Codable {
    case member = "Member"
    case eligible = "Eligible"
    case nonUnion = "Non-Union"
    
    var displayName: String {
        return rawValue
    }
}

// MARK: - Actor Profile Manager
@Observable
class ActorProfileManager {
    private(set) var profile: ActorProfile = ActorProfile()
    private(set) var isProfileComplete: Bool = false
    
    private let userDefaults = UserDefaults.standard
    private let profileKey = "ActorProfile"
    private let completionKey = "ActorProfileComplete"
    
    init() {
        loadProfile()
    }
    
    func saveProfile(_ newProfile: ActorProfile) {
        var updatedProfile = newProfile
        updatedProfile.updatedAt = Date()
        self.profile = updatedProfile
        
        if let encoded = try? JSONEncoder().encode(updatedProfile) {
            userDefaults.set(encoded, forKey: profileKey)
        }
        
        updateCompletionStatus()
    }
    
    func markProfileComplete() {
        isProfileComplete = true
        userDefaults.set(true, forKey: completionKey)
    }
    
    func resetProfile() {
        profile = ActorProfile()
        isProfileComplete = false
        userDefaults.removeObject(forKey: profileKey)
        userDefaults.removeObject(forKey: completionKey)
    }
    
    private func loadProfile() {
        // Load completion status
        isProfileComplete = userDefaults.bool(forKey: completionKey)
        
        // Load profile data
        guard let data = userDefaults.data(forKey: profileKey),
              let decoded = try? JSONDecoder().decode(ActorProfile.self, from: data) else {
            return
        }
        
        profile = decoded
    }
    
    private func updateCompletionStatus() {
        let isComplete = !profile.name.isEmpty && !profile.email.isEmpty
        if isComplete != isProfileComplete {
            markProfileComplete()
        }
    }
}