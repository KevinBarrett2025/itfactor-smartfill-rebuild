import Foundation
import AVFoundation

/// VideoVariantResolver: Single source of truth for video file resolution
/// Handles original vs SmartFill variant selection with proper path resolution
public struct VideoVariantResolver {
    
    // MARK: - Variant Preferences
    
    public enum VariantPreference {
        case originalFirst
        case smartFillIfAvailable
        case explicit(ProjectTake.Variant)
    }
    
    // MARK: - File Resolution Methods
    
    /// Get Documents directory URL (current container)
    public static func documentsURL() -> URL {
        return FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first!
    }
    
    /// Convert absolute path to relative path from Documents directory
    public static func relativePath(from url: URL) -> String {
        let docsURL = documentsURL()
        let prefix = docsURL.path.hasSuffix("/") ? docsURL.path : docsURL.path + "/"
        let path = url.path
        
        if path.hasPrefix(prefix) {
            return String(path.dropFirst(prefix.count))
        }
        
        // If not in Documents, return just the filename (fallback)
        return url.lastPathComponent
    }
    
    /// Convert relative path to absolute URL in current Documents directory
    public static func urlForRelativePath(_ relative: String) -> URL {
        return documentsURL().appendingPathComponent(relative, isDirectory: false)
    }
    
    /// Get original video URL for a take
    public static func originalURL(for take: ProjectTake) -> URL {
        // For now, use the take's filePath directly
        // TODO: This could be enhanced to also store relative paths for original files
        return URL(fileURLWithPath: take.filePath)
    }
    
    /// Get SmartFill video URL for a take (returns nil if doesn't exist)
    public static func smartFillURL(for take: ProjectTake) -> URL? {
        guard let relativePath = take.smartFilledFilePath else { 
            print("🔍 VideoVariantResolver: No smartFilledFilePath for take \(take.id)")
            return nil 
        }
        
        // Try to resolve as relative path first
        let url = urlForRelativePath(relativePath)
        if FileManager.default.fileExists(atPath: url.path) {
            print("✅ VideoVariantResolver: Found SmartFill via relative path: \(url.path)")
            return url
        }
        
        // Fallback: Try as absolute path (for migration compatibility)
        if FileManager.default.fileExists(atPath: relativePath) {
            print("✅ VideoVariantResolver: Found SmartFill via absolute path: \(relativePath)")
            return URL(fileURLWithPath: relativePath)
        }
        
        // Last resort: Try container path migration
        if let migratedURL = attemptContainerPathMigration(originalPath: relativePath) {
            print("✅ VideoVariantResolver: Found SmartFill via container migration: \(migratedURL.path)")
            return migratedURL
        }
        
        print("❌ VideoVariantResolver: SmartFill file not found: \(relativePath)")
        return nil
    }
    
    /// Attempt to migrate container paths to current Documents directory
    private static func attemptContainerPathMigration(originalPath: String) -> URL? {
        let originalURL = URL(fileURLWithPath: originalPath)
        let pathComponents = originalURL.pathComponents
        
        // Check if this looks like a container path
        guard pathComponents.contains("Containers"),
              pathComponents.contains("Data"),
              pathComponents.contains("Application") else {
            return nil
        }
        
        // Extract relative path after Documents
        if let documentsIndex = pathComponents.firstIndex(of: "Documents"),
           documentsIndex < pathComponents.count - 1 {
            
            let relativeComponents = Array(pathComponents[(documentsIndex + 1)...])
            let migratedURL = relativeComponents.reduce(documentsURL()) { url, component in
                url.appendingPathComponent(component)
            }
            
            if FileManager.default.fileExists(atPath: migratedURL.path) {
                return migratedURL
            }
        }
        
        // Try looking in SmartFill directory by filename
        let smartFillDir = documentsURL().appendingPathComponent("SmartFill")
        let fileName = originalURL.lastPathComponent
        let alternativeURL = smartFillDir.appendingPathComponent(fileName)
        
        if FileManager.default.fileExists(atPath: alternativeURL.path) {
            return alternativeURL
        }
        
        return nil
    }
    
    // MARK: - Variant Resolution
    
    /// Get the effective URL for a take based on preference
    public static func effectiveURL(for take: ProjectTake, preference: VariantPreference = .smartFillIfAvailable) -> URL {
        switch preference {
        case .explicit(let variant):
            switch variant {
            case .smartFill:
                return smartFillURL(for: take) ?? originalURL(for: take)
            case .original:
                return originalURL(for: take)
            }
            
        case .smartFillIfAvailable:
            // Check if take has effective variant set to SmartFill
            if take.effectiveVariant == .smartFill, let smartFillURL = smartFillURL(for: take) {
                return smartFillURL
            }
            
            // Otherwise prefer SmartFill if it exists
            if let smartFillURL = smartFillURL(for: take) {
                return smartFillURL
            }
            
            return originalURL(for: take)
            
        case .originalFirst:
            return originalURL(for: take)
        }
    }
    
    /// Check if a take has a valid SmartFill version
    public static func hasSmartFilledVersion(for take: ProjectTake) -> Bool {
        return smartFillURL(for: take) != nil
    }
    
    /// Get variant info for debugging
    public static func variantInfo(for take: ProjectTake) -> String {
        let hasSmartFill = hasSmartFilledVersion(for: take)
        let effectiveURL = effectiveURL(for: take)
        let isUsingSmartFill = smartFillURL(for: take)?.path == effectiveURL.path
        
        return """
        📊 Variant Info for Take \(take.id):
        - Has SmartFill: \(hasSmartFill)
        - Effective Variant: \(take.effectiveVariant.rawValue)
        - Using SmartFill: \(isUsingSmartFill)
        - Effective URL: \(effectiveURL.lastPathComponent)
        - Original Path: \(take.filePath)
        - SmartFill Path: \(take.smartFilledFilePath ?? "nil")
        """
    }
}

// MARK: - ProjectTake Extensions

extension ProjectTake {
    
    /// Effective variant preference for this take
    public enum Variant: String, Codable {
        case original
        case smartFill
    }
    
    /// Current effective variant (defaults to smartFill if available)
    public var effectiveVariant: Variant {
        get {
            // For now, prefer SmartFill if available
            // This could be stored as a field in the future
            return VideoVariantResolver.hasSmartFilledVersion(for: self) ? .smartFill : .original
        }
    }
}