import SwiftUI

struct ContentView: View {
    let repo = InMemoryProjectsRepository()
    @State private var profileManager = ActorProfileManager()
    @State private var showProfileWizard = false
    
    var body: some View {
        Group {
            if profileManager.isProfileComplete {
                HomeScreenView(repo: repo)
            } else {
                Color.clear
                    .onAppear {
                        showProfileWizard = true
                    }
            }
        }
        .fullScreenCover(isPresented: $showProfileWizard) {
            ActorProfileWizard {
                showProfileWizard = false
                profileManager = ActorProfileManager() // Reload to get updated status
            }
        }
    }
}

#Preview {
    ContentView()
}
