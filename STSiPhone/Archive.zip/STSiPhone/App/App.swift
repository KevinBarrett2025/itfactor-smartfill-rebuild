import SwiftUI

@main
struct STSiPhoneApp: App {
    // CORE INTEGRATION FIX: Create repository instance to share across app
    private let repository = InMemoryProjectsRepository()
    
    var body: some Scene {
        WindowGroup {
            // Phase 2 Step 1.1: Beautiful Home UI with backend power
            HomeScreenView(repo: repository)
                .onAppear {
                    print("✅ Repository: Successfully loaded \(repository.fetchProjects().count) projects from disk")
                    print("📂 Repository initialized with \(repository.fetchProjects().count) persisted projects")
                    print("✅ Enterprise unified model support enabled")
                    
                    // 🚨 NEW: Perform SmartFill path migration on app startup
                    Task {
                        await performStartupSmartFillMigration()
                    }
                    
                    // CORE INTEGRATION FIX: Configure SessionManager with repository AND enable unified models
                    SessionManager.shared.configure(with: repository)
                    
                    // CRITICAL FIX: Enable unified models by default for all new sessions
                    SessionManager.shared.enableUnifiedModels()
                    
                    // ENHANCED: Enable unified model support in repository too
                    repository.enableUnifiedModelSupport()
                    
                    print("✅ App Launch: Repository configured, unified models enabled globally")
                }
            
            // Previous implementations (available for reference)
            // ProjectsListView(repo: InMemoryProjectsRepository()) // Step 1 basic navigation
            // DashboardView() // Original wizard-focused dashboard
        }
    }
    
    // 🚨 NEW: Startup SmartFill path migration system
    @MainActor
    private func performStartupSmartFillMigration() {
        print("🔄 Performing startup SmartFill path migration...")
        
        guard let inMemoryRepo = repository as? InMemoryProjectsRepository else {
            print("⚠️ Repository is not InMemoryProjectsRepository, skipping migration")
            return
        }
        
        let migrationCount = inMemoryRepo.migrateSmartFillPaths()
        
        if migrationCount > 0 {
            print("✅ Startup migration completed: \(migrationCount) SmartFill paths migrated")
            
            // Clear the cache to force UI refresh
            ProjectTake.clearSmartFillCache()
            
            // Post notification for UI updates
            NotificationCenter.default.post(
                name: Notification.Name("STSSmartFillPathsMigrated"),
                object: nil,
                userInfo: ["migrationCount": migrationCount]
            )
        } else {
            print("📋 No SmartFill path migration needed")
        }
    }
}
