import SwiftUI
import AVFoundation
import AVKit

/// SwiftUI wrapper for video players with Smart Fill integration
/// INTEGRATION: Seamlessly integrates with existing STS video player infrastructure
public struct SmartFillVideoPlayer: View {
    let take: ProjectTake
    let session: ProjectSession
    let settings: SmartFillSettings
    
    @State private var needsSmartFill: Bool = false
    @State private var isAnalyzing: Bool = true
    
    public init(
        take: ProjectTake,
        session: ProjectSession,
        settings: SmartFillSettings = SmartFillSettings()
    ) {
        self.take = take
        self.session = session
        self.settings = settings
    }
    
    public var body: some View {
        ZStack {
            Color.black.ignoresSafeArea()
            
            if isAnalyzing {
                loadingView
            } else {
                videoPlayerView
            }
        }
        .onAppear {
            analyzeVideoForSmartFill()
        }
    }
    
    @ViewBuilder
    private var loadingView: some View {
        VStack(spacing: 16) {
            ProgressView()
                .scaleEffect(1.5)
                .tint(.white)
            
            Text("Analyzing video...")
                .font(.headline)
                .foregroundColor(.white)
        }
    }
    
    @ViewBuilder
    private var videoPlayerView: some View {
        if needsSmartFill {
            smartFillPlayerView
        } else {
            standardPlayerView
        }
    }
    
    @ViewBuilder
    private var smartFillPlayerView: some View {
        if let videoURL = getVideoURL() {
            SmartFillPreviewView(
                videoURL: videoURL,
                settings: settings
            )
            .overlay(
                smartFillIndicator,
                alignment: .bottomTrailing
            )
        } else {
            errorView
        }
    }
    
    @ViewBuilder
    private var standardPlayerView: some View {
        if let videoURL = getVideoURL() {
            UnifiedVideoPlayerView(url: videoURL)
        } else {
            errorView
        }
    }
    
    @ViewBuilder
    private var smartFillIndicator: some View {
        HStack(spacing: 6) {
            Image(systemName: "rectangle.portrait.on.rectangle.landscape.fill")
                .font(.caption2)
            Text("Smart Fill")
                .font(.caption2)
        }
        .padding(.horizontal, 8)
        .padding(.vertical, 4)
        .background(.ultraThinMaterial, in: Capsule())
        .foregroundStyle(.white)
        .padding()
    }
    
    @ViewBuilder
    private var errorView: some View {
        VStack(spacing: 16) {
            Image(systemName: "exclamationmark.triangle")
                .font(.largeTitle)
                .foregroundColor(.red)
            
            Text("Could not load video")
                .font(.headline)
                .foregroundColor(.white)
                
            Text("The video file may have been moved or deleted")
                .font(.caption)
                .foregroundColor(.gray)
                .multilineTextAlignment(.center)
        }
    }
    
    // MARK: - Analysis Methods
    
    private func analyzeVideoForSmartFill() {
        isAnalyzing = true
        
        Task {
            guard let videoURL = getVideoURL() else {
                await MainActor.run {
                    needsSmartFill = false
                    isAnalyzing = false
                }
                return
            }
            
            // Use modern SmartFillManager to check if needs processing
            let needsProcessing = await SmartFillManager.shared.needsSmartFill(videoURL: videoURL)
            
            await MainActor.run {
                needsSmartFill = needsProcessing && settings.defaultEnabled
                isAnalyzing = false
            }
            
            print("📐 SmartFillVideoPlayer: Video needs SmartFill: \(needsProcessing)")
        }
    }
    
    private func getVideoURL() -> URL? {
        // Try VideoFileManager first
        do {
            let fileName = URL(fileURLWithPath: take.filePath).lastPathComponent
            return try VideoFileManager.shared.getVideoURL(for: fileName)
        } catch {
            print("⚠️ SmartFillVideoPlayer: VideoFileManager couldn't locate file: \(error)")
        }
        
        // Fallback to direct file path
        let url = URL(fileURLWithPath: take.filePath)
        if FileManager.default.fileExists(atPath: url.path) {
            return url
        }
        
        return nil
    }
}

// MARK: - Integration Extensions

extension SmartFillVideoPlayer {
    
    /// Create Smart Fill video player for session integration
    static func create(
        for take: ProjectTake,
        in session: ProjectSession
    ) -> SmartFillVideoPlayer {
        return SmartFillVideoPlayer(
            take: take,
            session: session,
            settings: SmartFillSettings()
        )
    }
}

// MARK: - Preview Provider

#Preview("Portrait Video") {
    let sampleTake = ProjectTake(
        filePath: "/sample/portrait.mov",
        durationSeconds: 30.0,
        capturedOrientation: .portrait
    )
    
    let sampleSession = ProjectSession(
        type: .selfTape,
        primaryOrientation: .landscape,
        smartFillEnabled: true
    )
    
    return SmartFillVideoPlayer(
        take: sampleTake,
        session: sampleSession
    )
    .preferredColorScheme(.dark)
}

#Preview("Landscape Video") {
    let sampleTake = ProjectTake(
        filePath: "/sample/landscape.mov",
        durationSeconds: 45.0,
        capturedOrientation: .landscape
    )
    
    let sampleSession = ProjectSession(
        type: .selfTape,
        primaryOrientation: .landscape,
        smartFillEnabled: true
    )
    
    return SmartFillVideoPlayer(
        take: sampleTake,
        session: sampleSession
    )
    .preferredColorScheme(.dark)
}
