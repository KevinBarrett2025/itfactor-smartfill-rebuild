import AVFoundation
import CoreGraphics
import UIKit

/// Utilities to normalize orientation using each track's preferredTransform.
/// INTEGRATION: Enhanced for SelfTapeStudio video processing pipeline
public enum NormalizeOrientation {

    // MARK: - Core Orientation Utilities
    
    /// Returns the upright extent (size) after applying `preferredTransform`.
    public static func uprightExtent(naturalSize: CGSize, preferred: CGAffineTransform) -> CGSize {
        let rect = CGRect(origin: .zero, size: naturalSize).applying(preferred)
        return CGSize(width: abs(rect.width), height: abs(rect.height))
    }

    /// Builds a transform that rotates to upright (preferred), scales, and centers into `dst`.
    public static func finalTransform(naturalSize: CGSize,
                                      preferred: CGAffineTransform,
                                      scale: CGFloat,
                                      dst: CGSize) -> CGAffineTransform {
        let upright = uprightExtent(naturalSize: naturalSize, preferred: preferred)
        let scaled = CGSize(width: upright.width * scale, height: upright.height * scale)
        let offset = CGPoint(x: (dst.width - scaled.width) * 0.5, y: (dst.height - scaled.height) * 0.5)
        
        // Order: center ∘ scale ∘ preferred
        return CGAffineTransform(translationX: offset.x, y: offset.y)
            .concatenating(CGAffineTransform(scaleX: scale, y: scale))
            .concatenating(preferred)
    }

    /// Computes suggested scales for foreground (fit) and background (fill).
    public static func scalesForFGandBG(naturalSize: CGSize,
                                        preferred: CGAffineTransform,
                                        dst: CGSize) -> (fg: CGFloat, bg: CGFloat) {
        let upright = uprightExtent(naturalSize: naturalSize, preferred: preferred)
        let fg = SmartFillMath.scaleToFit(src: upright, dst: dst)
        let bg = SmartFillMath.scaleToFill(src: upright, dst: dst)
        return (fg, bg)
    }
    
    // MARK: - STS Integration Methods
    
    /// Analyze video orientation from AVAsset for ProjectTake integration
    public static func analyzeVideoOrientation(from asset: AVAsset) async throws -> VideoOrientationAnalysis {
        
        let videoTracks = try await asset.loadTracks(withMediaType: .video)
        guard let videoTrack = videoTracks.first else {
            throw OrientationError.noVideoTrack
        }
        
        let naturalSize = try await videoTrack.load(.naturalSize)
        let preferredTransform = try await videoTrack.load(.preferredTransform)
        let timeRange = try await videoTrack.load(.timeRange)
        
        let uprightSize = uprightExtent(naturalSize: naturalSize, preferred: preferredTransform)
        let orientation = uprightSize.width > uprightSize.height ? VideoOrientation.landscape : VideoOrientation.portrait
        
        let transformType = classifyTransform(preferredTransform)
        
        return VideoOrientationAnalysis(
            capturedOrientation: orientation,
            naturalSize: naturalSize,
            preferredTransform: preferredTransform,
            uprightSize: uprightSize,
            transformType: transformType,
            duration: timeRange.duration.seconds
        )
    }
    
    /// Enhanced transform classification for debugging and optimization
    public static func classifyTransform(_ transform: CGAffineTransform) -> TransformType {
        if transform.isIdentity {
            return .identity
        }
        
        // Check for 90-degree rotations (common in mobile video)
        if abs(transform.a) < 0.1 && abs(transform.d) < 0.1 {
            if transform.b > 0.9 && transform.c < -0.9 {
                return .rotate90Clockwise
            } else if transform.b < -0.9 && transform.c > 0.9 {
                return .rotate90CounterClockwise
            }
        }
        
        // Check for 180-degree rotation
        if abs(transform.a + 1.0) < 0.1 && abs(transform.d + 1.0) < 0.1 &&
           abs(transform.b) < 0.1 && abs(transform.c) < 0.1 {
            return .rotate180
        }
        
        return .custom
    }
    
    /// Create normalized video composition for consistent orientation
    /// UPDATED: Use modern async API for duration
    public static func createNormalizedComposition(
        for asset: AVAsset,
        targetRenderSize: CGSize
    ) async throws -> (AVMutableComposition, AVMutableVideoComposition?) {
        
        let composition = AVMutableComposition()
        
        guard let videoTrack = try await asset.loadTracks(withMediaType: .video).first else {
            throw OrientationError.noVideoTrack
        }
        
        guard let compositionVideoTrack = composition.addMutableTrack(
            withMediaType: .video,
            preferredTrackID: kCMPersistentTrackID_Invalid
        ) else {
            throw OrientationError.compositionCreationFailed
        }
        
        // UPDATED: Use modern async API for duration
        let assetDuration = try await asset.load(.duration)
        let timeRange = CMTimeRange(start: .zero, duration: assetDuration)
        try compositionVideoTrack.insertTimeRange(timeRange, of: videoTrack, at: .zero)
        
        // Add audio track if present
        if let audioTrack = try await asset.loadTracks(withMediaType: .audio).first {
            let compositionAudioTrack = composition.addMutableTrack(
                withMediaType: .audio,
                preferredTrackID: kCMPersistentTrackID_Invalid
            )
            try compositionAudioTrack?.insertTimeRange(timeRange, of: audioTrack, at: .zero)
        }
        
        // Create video composition for orientation normalization
        let naturalSize = try await videoTrack.load(.naturalSize)
        let preferredTransform = try await videoTrack.load(.preferredTransform)
        
        let videoComposition = AVMutableVideoComposition()
        videoComposition.renderSize = targetRenderSize
        videoComposition.frameDuration = CMTime(value: 1, timescale: 30)
        
        let instruction = AVMutableVideoCompositionInstruction()
        instruction.timeRange = timeRange
        
        let layerInstruction = AVMutableVideoCompositionLayerInstruction(assetTrack: compositionVideoTrack)
        
        // Calculate transform for normalization
        let uprightSize = uprightExtent(naturalSize: naturalSize, preferred: preferredTransform)
        let scale = SmartFillMath.scaleToFit(src: uprightSize, dst: targetRenderSize)
        let finalTransform = self.finalTransform(
            naturalSize: naturalSize,
            preferred: preferredTransform,
            scale: scale,
            dst: targetRenderSize
        )
        
        layerInstruction.setTransform(finalTransform, at: .zero)
        instruction.layerInstructions = [layerInstruction]
        videoComposition.instructions = [instruction]
        
        return (composition, videoComposition)
    }
}

// MARK: - Data Structures for STS Integration

// 🚨 SWIFT 6 SENDABILITY: Made VideoOrientationAnalysis Sendable for safe concurrent access
public struct VideoOrientationAnalysis: Sendable {
    public let capturedOrientation: VideoOrientation
    public let naturalSize: CGSize
    public let preferredTransform: CGAffineTransform
    public let uprightSize: CGSize
    public let transformType: TransformType
    public let duration: TimeInterval
    
    // INTEGRATION: Computed properties for STS UI
    public var aspectRatio: CGFloat {
        return uprightSize.width / uprightSize.height
    }
    
    public var isPortraitVideo: Bool {
        return capturedOrientation == .portrait
    }
    
    public var debugDescription: String {
        return """
        Video Orientation Analysis:
        - Captured: \(capturedOrientation)
        - Natural Size: \(naturalSize)
        - Upright Size: \(uprightSize)
        - Transform: \(transformType)
        - Aspect Ratio: \(String(format: "%.2f", aspectRatio))
        - Duration: \(String(format: "%.1f", duration))s
        """
    }
}

// 🚨 SWIFT 6 SENDABILITY: Made TransformType enum Sendable
public enum TransformType: Sendable {
    case identity
    case rotate90Clockwise
    case rotate90CounterClockwise
    case rotate180
    case custom
    
    public var displayName: String {
        switch self {
        case .identity: return "No Rotation"
        case .rotate90Clockwise: return "90° Clockwise"
        case .rotate90CounterClockwise: return "90° Counter-Clockwise"
        case .rotate180: return "180° Rotation"
        case .custom: return "Custom Transform"
        }
    }
}

// 🚨 SWIFT 6 SENDABILITY: Made OrientationError Sendable for safe error handling
public enum OrientationError: LocalizedError, Sendable {
    case noVideoTrack
    case invalidTransform
    case compositionCreationFailed
    
    public var errorDescription: String? {
        switch self {
        case .noVideoTrack:
            return "No video track found in asset"
        case .invalidTransform:
            return "Invalid preferred transform"
        case .compositionCreationFailed:
            return "Failed to create composition"
        }
    }
}

// MARK: - Integration Extensions for Existing STS Types

extension ProjectTake {
    
    /// Analyze orientation for an existing take (migration helper)
    func analyzeOrientation() async throws -> VideoOrientationAnalysis {
        let url = URL(fileURLWithPath: filePath)
        let asset = AVURLAsset(url: url)
        return try await NormalizeOrientation.analyzeVideoOrientation(from: asset)
    }
}

extension VideoPlayerService {
    
    /// Setup player with orientation analysis for Smart Fill compatibility
    func setupPlayerWithOrientationAnalysis(url: URL, context: VideoContext) async {
        do {
            let asset = AVURLAsset(url: url)
            let analysis = try await NormalizeOrientation.analyzeVideoOrientation(from: asset)
            
            print("📐 VideoPlayerService: Orientation analysis completed")
            print("   \(analysis.debugDescription)")
            
            // Store analysis for potential Smart Fill preview
            // This would integrate with Smart Fill preview logic
            
            await MainActor.run {
                setupPlayer(with: url, context: context)
            }
            
        } catch {
            print("❌ VideoPlayerService: Orientation analysis failed: \(error)")
            // Fallback to standard setup
            await MainActor.run {
                setupPlayer(with: url, context: context)
            }
        }
    }
}
