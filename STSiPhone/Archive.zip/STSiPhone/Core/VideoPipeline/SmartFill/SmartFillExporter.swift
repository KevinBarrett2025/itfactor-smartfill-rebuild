import AVFoundation
import CoreImage
import Metal

/// Bakes Smart Portrait Fill + orientation normalization into the export.
/// UPDATED: iOS 18 Bug Workaround - Simplified approach without problematic CIGaussianBlur
public final class SmartFillExporter {
    private let ciContext: CIContext
    private let metalDevice: MTLDevice?
    
    // ENTERPRISE: Settings optimized for iPhone 16 Pro performance
    private let maxConcurrentOperations: Int
    private let enableHardwareAcceleration: Bool
    
    public init(device: MTLDevice? = MTLCreateSystemDefaultDevice(),
                maxConcurrentOperations: Int = 6, // UPDATED: iPhone 16 Pro can handle more concurrent ops
                enableHardwareAcceleration: Bool = true) {
        
        self.metalDevice = device
        self.maxConcurrentOperations = maxConcurrentOperations
        self.enableHardwareAcceleration = enableHardwareAcceleration
        
        if let d = device, enableHardwareAcceleration {
            // UPDATED: iOS 18 optimized Metal configuration for iPhone 16 Pro
            var options: [CIContextOption: Any] = [
                .workingColorSpace: CGColorSpace(name: CGColorSpace.sRGB)!,
                .outputColorSpace: CGColorSpace(name: CGColorSpace.sRGB)!,
                .cacheIntermediates: false, // Optimized for large videos on A18 Pro
                .workingFormat: CIFormat.RGBAh // FIXED: Use compatible format for iOS 18
            ]
            
            // UPDATED: iOS 18 performance hints
            if #available(iOS 18.0, *) {
                options[.priorityRequestLow] = false
                // ENTERPRISE: Enable A18 Pro specific optimizations
                options[.highQualityDownsample] = true
            } else if #available(iOS 17.0, *) {
                options[.priorityRequestLow] = false
            }
            
            self.ciContext = CIContext(mtlDevice: d, options: options)
            print("✅ SmartFillExporter: Initialized with iOS 18 optimized Metal acceleration (A18 Pro)")
        } else {
            self.ciContext = CIContext(options: [
                .workingColorSpace: CGColorSpace(name: CGColorSpace.sRGB)!,
                .outputColorSpace: CGColorSpace(name: CGColorSpace.sRGB)!
            ])
            print("⚠️ SmartFillExporter: Initialized without Metal acceleration")
        }
    }

    /// Build an AVVideoComposition that applies Smart Fill + orientation normalization
    /// ENHANCED: Ensure video playback instead of static images
    public func makeVideoComposition(
        for composition: AVMutableComposition,
        renderSize: CGSize,
        portraitSegments: [CMTimeRange],
        settings: SmartFillSettings = SmartFillSettings(),
        orientationAnalysis: VideoOrientationAnalysis? = nil
    ) async throws -> AVVideoComposition {

        // CRITICAL FIX: Use modern async API with proper video composition for playback
        let videoComposition = try await AVVideoComposition.videoComposition(with: composition) { [weak self] request in
            guard let self = self else {
                // FIXED: Provide fallback instead of error for stability
                request.finish(with: request.sourceImage, context: nil)
                return
            }
            
            self.processFrame(request: request, segments: portraitSegments, settings: settings, orientationAnalysis: orientationAnalysis)
        }
        
        // Create mutable copy for customization
        let mutableComposition = videoComposition.mutableCopy() as! AVMutableVideoComposition
        mutableComposition.renderSize = renderSize
        
        // CRITICAL FIX: Ensure proper frame rate for video playback (not static images)
        mutableComposition.frameDuration = CMTime(value: 1, timescale: 30) // 30fps for smooth playback
        
        // ENHANCED: Add custom compositor instructions for better video processing
        mutableComposition.customVideoCompositorClass = nil // Use default compositor for stability

        // Load video tracks using modern API
        guard let vTrack = composition.tracks(withMediaType: .video).first else {
            print("❌ SmartFillExporter: No video track found in composition")
            return mutableComposition
        }
        
        mutableComposition.sourceTrackIDForFrameTiming = vTrack.trackID
        
        // CRITICAL FIX: Ensure video composition has proper instructions for each time range
        let instruction = AVMutableVideoCompositionInstruction()
        instruction.timeRange = CMTimeRange(start: .zero, duration: composition.duration)
        
        let layerInstruction = AVMutableVideoCompositionLayerInstruction(assetTrack: vTrack)
        instruction.layerInstructions = [layerInstruction]
        
        mutableComposition.instructions = [instruction]
        
        print("🎬 SmartFillExporter: Created video composition for PLAYBACK with \(portraitSegments.count) portrait segments")
        print("   🎯 Frame rate: 30fps for smooth video playback")
        print("   📐 Render size: \(renderSize)")
        print("   ⏱️ Duration: \(CMTimeGetSeconds(composition.duration)) seconds")

        return mutableComposition
    }
    
    // MARK: - Frame Processing - ENHANCED for Video Playback
    
    private func processFrame(
        request: AVAsynchronousCIImageFilteringRequest,
        segments: [CMTimeRange],
        settings: SmartFillSettings,
        orientationAnalysis: VideoOrientationAnalysis? = nil
    ) {
        let time = request.compositionTime
        let inPortrait = segments.contains(where: { $0.containsTime(time) })
        
        let source = request.sourceImage
        let sourceSize = source.extent.size
        
        print("🔧 SmartFill FRAME DEBUG: Time: \(CMTimeGetSeconds(time))s, Portrait: \(inPortrait)")
        print("🔧 SmartFill FRAME DEBUG: Source extent: \(source.extent), isInfinite: \(source.extent.isInfinite)")
        
        // FIXED: Proper extent validation
        guard !source.extent.isInfinite && isValidExtent(sourceSize) else {
            print("❌ SmartFillExporter: Invalid or infinite source extent: \(source.extent)")
            // FIXED: Create fallback image using existing method
            let fallbackImage = createSolidColorFallback(renderSize: settings.defaultRenderSize)
            request.finish(with: fallbackImage, context: ciContext)
            return
        }

        // FIXED: Calculate layout using the actual CIImage dimensions (already oriented)
        let layout = SmartFillMath.calculateSmartFillLayout(
            sourceSize: sourceSize,
            renderSize: settings.defaultRenderSize
        )

        if inPortrait {
            print("🎨 SmartFill: Processing PORTRAIT frame for video playback")
            processPortraitFrameForVideo(
                request: request,
                source: source,
                layout: layout,
                settings: settings,
                sourceImageSize: sourceSize
            )
        } else {
            print("📹 SmartFill: Processing LANDSCAPE frame for video playback")
            processLandscapeFrameForVideo(
                request: request,
                source: source,
                layout: layout
            )
        }
    }
    
    // ENHANCED: Portrait frame processing optimized for video playback
    private func processPortraitFrameForVideo(
        request: AVAsynchronousCIImageFilteringRequest,
        source: CIImage,
        layout: SmartFillLayout,
        settings: SmartFillSettings,
        sourceImageSize: CGSize? = nil
    ) {
        print("🎨 SmartFill VIDEO: Processing portrait frame with background fill")
        
        // FIXED: Proper validation for portrait processing
        guard !source.extent.isInfinite && isValidImage(source) else {
            print("❌ Invalid or infinite source image, using landscape fallback")
            processLandscapeFrameForVideo(request: request, source: source, layout: layout)
            return
        }
        
        do {
            let renderSize = layout.renderSize
            
            print("🎯 SmartFill VIDEO TARGET: Converting portrait video to full landscape format \(renderSize)")
            
            // ENHANCED: Create proper SmartFill background that FILLS the entire background
            let consistentSourceSize = sourceImageSize ?? source.extent.size
            let background = try createProperSmartFillBackground(
                source: source,
                renderSize: renderSize,
                darkenAmount: settings.defaultDarkenAmount,
                blurRadius: settings.defaultBlurRadius,
                sourceImageSize: consistentSourceSize,
                settings: settings // ENTERPRISE: Pass settings for configurable background scale
            )
            
            // FIXED: Validate background before proceeding
            guard !background.extent.isInfinite && isValidImage(background) else {
                print("❌ Invalid or infinite background created, using landscape fallback")
                processLandscapeFrameForVideo(request: request, source: source, layout: layout)
                return
            }
            
            // ENHANCED: Use the correctly calculated layout values for proper SmartFill
            print("🎯 SmartFill VIDEO SCALING: Using SmartFillMath layout calculations")
            print("   📐 Layout render size: \(layout.renderSize)")
            print("   📐 Foreground scale: \(layout.foregroundScale)")
            print("   📐 Foreground size: \(layout.foregroundSize)")
            print("   📐 Foreground offset: \(layout.foregroundOffset)")
            
            // CRITICAL: Apply proper transform for portrait-to-landscape conversion
            let foreground = source.transformed(by: layout.foregroundTransform)
            
            // FIXED: Validate foreground after transformation
            guard !foreground.extent.isInfinite && isValidImage(foreground) else {
                print("❌ Invalid or infinite foreground after transforms, using landscape fallback")
                processLandscapeFrameForVideo(request: request, source: source, layout: layout)
                return
            }
            
            // ENHANCED: Composite foreground over FILLED background - this creates the SmartFill effect!
            let output = foreground.composited(over: background)
            
            // FIXED: Validate composited output
            guard !output.extent.isInfinite && isValidImage(output) else {
                print("❌ Invalid or infinite composited output, using landscape fallback")
                processLandscapeFrameForVideo(request: request, source: source, layout: layout)
                return
            }
            
            // CRITICAL: Ensure final output is EXACTLY the render size
            let finalOutput = output.cropped(to: CGRect(origin: .zero, size: renderSize))
            
            // FIXED: Final validation - ensure we have correct dimensions
            guard !finalOutput.extent.isInfinite && isValidImage(finalOutput) else {
                print("❌ Invalid or infinite final output, using landscape fallback")
                processLandscapeFrameForVideo(request: request, source: source, layout: layout)
                return
            }
            
            // Validate final output dimensions
            let finalSize = finalOutput.extent.size
            guard abs(finalSize.width - renderSize.width) < 1.0 && abs(finalSize.height - renderSize.height) < 1.0 else {
                print("❌ Final output wrong size: \(finalSize) != \(renderSize), using landscape fallback")
                processLandscapeFrameForVideo(request: request, source: source, layout: layout)
                return
            }
            
            print("✅ SmartFill VIDEO SUCCESS: Portrait → Landscape with FILLED background complete!")
            print("   📐 Input: \(consistentSourceSize) → Output: \(finalSize)")
            print("   🎨 Applied gaussian blur background that FILLS entire frame")
            print("   🎯 Full landscape format achieved with NO BLACK BARS: \(renderSize)")
            
            request.finish(with: finalOutput, context: ciContext)
            
        } catch {
            print("❌ SmartFill video processing failed: \(error), using landscape fallback")
            processLandscapeFrameForVideo(request: request, source: source, layout: layout)
        }
    }
    
    // ENHANCED: Landscape frame processing for video playback
    private func processLandscapeFrameForVideo(
        request: AVAsynchronousCIImageFilteringRequest,
        source: CIImage,
        layout: SmartFillLayout
    ) {
        print("📹 SmartFill VIDEO: Processing landscape frame")
        
        // Standard landscape processing with centering for video playback
        let foreground = source.transformed(by: layout.foregroundTransform)
        let output = cropToRenderSize(foreground, renderSize: layout.renderSize)
        
        // FIXED: Validate output before finishing
        let finalOutput = isValidImage(output) ? output : source
        request.finish(with: finalOutput, context: ciContext)
    }
    
    // MARK: - iOS 18 Bug Workaround Portrait Processing
    
    private func processPortraitFrame(
        request: AVAsynchronousCIImageFilteringRequest,
        source: CIImage,
        layout: SmartFillLayout,
        settings: SmartFillSettings,
        sourceImageSize: CGSize? = nil
    ) {
        print("🎨 SmartFill: Processing portrait frame with proper gaussian blur background")
        print("🔧 SmartFill DEBUG: Portrait source extent: \(source.extent), isInfinite: \(source.extent.isInfinite)")
        if let imageSize = sourceImageSize {
            print("🔧 SmartFill DEBUG: Source image size for processing: \(imageSize)")
        }
        
        // FIXED: Proper validation for portrait processing
        guard !source.extent.isInfinite && isValidImage(source) else {
            print("❌ Invalid or infinite source image, using landscape fallback")
            processLandscapeFrame(request: request, source: source, layout: layout)
            return
        }
        
        do {
            let renderSize = layout.renderSize
            
            print("🎯 SmartFill TARGET: Converting portrait video to full landscape format \(renderSize)")
            
            // RESTORED: Create proper SmartFill background with gaussian blur
            let consistentSourceSize = sourceImageSize ?? source.extent.size
            let background = try createProperSmartFillBackground(
                source: source,
                renderSize: renderSize,
                darkenAmount: settings.defaultDarkenAmount,
                blurRadius: settings.defaultBlurRadius,
                sourceImageSize: consistentSourceSize,
                settings: settings // ENTERPRISE: Pass settings for configurable background scale
            )
            
            // FIXED: Validate background before proceeding
            guard !background.extent.isInfinite && isValidImage(background) else {
                print("❌ Invalid or infinite background created, using landscape fallback")
                processLandscapeFrame(request: request, source: source, layout: layout)
                return
            }
            
            // RESTORED: Use the correctly calculated layout values for proper SmartFill
            print("🎯 SmartFill SCALING: Using SmartFillMath layout calculations")
            print("   📐 Layout render size: \(layout.renderSize)")
            print("   📐 Foreground scale: \(layout.foregroundScale)")
            print("   📐 Foreground size: \(layout.foregroundSize)")
            print("   📐 Foreground offset: \(layout.foregroundOffset)")
            
            // CRITICAL: Apply proper transform for portrait-to-landscape conversion
            let foreground = source.transformed(by: layout.foregroundTransform)
            
            // FIXED: Validate foreground after transformation
            guard !foreground.extent.isInfinite && isValidImage(foreground) else {
                print("❌ Invalid or infinite foreground after transforms, using landscape fallback")
                processLandscapeFrame(request: request, source: source, layout: layout)
                return
            }
            
            // RESTORED: Composite foreground over blurred background - this is the actual SmartFill effect!
            let output = foreground.composited(over: background)
            
            // FIXED: Validate composited output
            guard !output.extent.isInfinite && isValidImage(output) else {
                print("❌ Invalid or infinite composited output, using landscape fallback")
                processLandscapeFrame(request: request, source: source, layout: layout)
                return
            }
            
            // CRITICAL: Ensure final output is EXACTLY the render size
            let finalOutput = output.cropped(to: CGRect(origin: .zero, size: renderSize))
            
            // FIXED: Final validation - ensure we have correct dimensions
            guard !finalOutput.extent.isInfinite && isValidImage(finalOutput) else {
                print("❌ Invalid or infinite final output, using landscape fallback")
                processLandscapeFrame(request: request, source: source, layout: layout)
                return
            }
            
            // Validate final output dimensions
            let finalSize = finalOutput.extent.size
            guard abs(finalSize.width - renderSize.width) < 1.0 && abs(finalSize.height - renderSize.height) < 1.0 else {
                print("❌ Final output wrong size: \(finalSize) != \(renderSize), using landscape fallback")
                processLandscapeFrame(request: request, source: source, layout: layout)
                return
            }
            
            print("✅ SmartFill SUCCESS: Portrait → Landscape conversion with gaussian blur complete!")
            print("   📐 Input: \(consistentSourceSize) → Output: \(finalSize)")
            print("   🎨 Applied gaussian blur background with foreground compositing")
            print("   🎯 Full landscape format achieved: \(renderSize)")
            
            request.finish(with: finalOutput, context: ciContext)
            
        } catch {
            print("❌ SmartFill processing failed: \(error), using landscape fallback")
            processLandscapeFrame(request: request, source: source, layout: layout)
        }
    }
    
    private func processLandscapeFrame(
        request: AVAsynchronousCIImageFilteringRequest,
        source: CIImage,
        layout: SmartFillLayout
    ) {
        // Standard landscape processing with centering
        let foreground = source.transformed(by: layout.foregroundTransform)
        let output = cropToRenderSize(foreground, renderSize: layout.renderSize)
        
        // FIXED: Validate output before finishing
        let finalOutput = isValidImage(output) ? output : source
        request.finish(with: finalOutput, context: ciContext)
    }
    
    // MARK: - iOS 18 Bug Workaround Background Creation
    
    private func createSmartFillBackground(
        source: CIImage,
        renderSize: CGSize,
        darkenAmount: CGFloat,
        sourceImageSize: CGSize? = nil  // RENAMED: Now represents the CIImage size, not original video
    ) throws -> CIImage {
        
        print("🔧 iOS 18 WORKAROUND: Creating simple background without blur")
        print("   📐 Source extent: \(source.extent)")
        print("   📐 Render size: \(renderSize)")
        if let imageSize = sourceImageSize {
            print("   📐 Source image size: \(imageSize)")
        }
        
        // FIXED: Check for infinite extent first - iOS 18 bug
        guard !source.extent.isInfinite else {
            print("❌ Source has infinite extent, using fallback")
            return createSolidColorFallback(renderSize: renderSize)
        }
        
        // FIXED: Validate source image
        guard isValidImage(source) else {
            print("❌ Invalid source image, using fallback")
            return createSolidColorFallback(renderSize: renderSize)
        }
        
        // CRITICAL FIX: Use consistent source size - the CIImage extent size
        let sourceSize = sourceImageSize ?? source.extent.size
        let scaleX = renderSize.width / sourceSize.width
        let scaleY = renderSize.height / sourceSize.height
        let backgroundScale = max(scaleX, scaleY)
        
        print("🔧 iOS 18 DEBUG: Background scaling - sourceSize: \(sourceSize), backgroundScale: \(backgroundScale)")
        
        // FIXED: Validate scale values
        guard backgroundScale.isFinite && backgroundScale > 0 else {
            print("❌ Invalid scale values, using fallback")
            return createSolidColorFallback(renderSize: renderSize)
        }
        
        // STEP 2: Scale and center without complex transforms
        let scaledImage = source.transformed(by: CGAffineTransform(scaleX: backgroundScale, y: backgroundScale))
        
        // FIXED: Check for infinite extent after scaling - iOS 18 bug
        guard !scaledImage.extent.isInfinite && isValidImage(scaledImage) else {
            print("❌ Scaled image invalid or infinite, using fallback")
            return createSolidColorFallback(renderSize: renderSize)
        }
        
        // STEP 3: Center using consistent dimensions
        let scaledSize = CGSize(width: sourceSize.width * backgroundScale, height: sourceSize.height * backgroundScale)
        let offsetX = (renderSize.width - scaledSize.width) / 2
        let offsetY = (renderSize.height - scaledSize.height) / 2
        
        // FIXED: Validate offset values
        guard offsetX.isFinite && offsetY.isFinite else {
            print("❌ Invalid offset values, using fallback")
            return createSolidColorFallback(renderSize: renderSize)
        }
        
        let centeredImage = scaledImage.transformed(by: CGAffineTransform(translationX: offsetX, y: offsetY))
        
        // FIXED: Check for infinite extent after translation - iOS 18 bug
        guard !centeredImage.extent.isInfinite && isValidImage(centeredImage) else {
            print("❌ Centered image invalid or infinite, using fallback")
            return createSolidColorFallback(renderSize: renderSize)
        }
        
        // STEP 4: Crop to render size
        let cropRect = CGRect(origin: .zero, size: renderSize)
        let croppedImage = centeredImage.cropped(to: cropRect)
        
        // FIXED: Check for infinite extent after cropping - iOS 18 bug
        guard !croppedImage.extent.isInfinite && isValidImage(croppedImage) else {
            print("❌ Cropped image invalid or infinite, using fallback")
            return createSolidColorFallback(renderSize: renderSize)
        }
        
        // iOS 18 WORKAROUND: Skip blur entirely - just darken slightly
        guard let colorFilter = CIFilter(name: "CIColorControls") else {
            print("✅ iOS 18 WORKAROUND: No filtering, returning cropped")
            return croppedImage // We know this is valid from check above
        }
        
        // Very conservative darkening (no blur due to iOS 18 bugs)
        colorFilter.setValue(croppedImage, forKey: kCIInputImageKey)
        colorFilter.setValue(-0.3, forKey: kCIInputBrightnessKey) // Darken background
        colorFilter.setValue(0.8, forKey: kCIInputSaturationKey)  // Desaturate background
        
        guard let filteredImage = colorFilter.outputImage else {
            print("✅ iOS 18 WORKAROUND: Color filter failed, returning cropped")
            return croppedImage // We know this is valid from check above
        }
        
        // FIXED: Final crop and infinite extent check
        let finalImage = filteredImage.cropped(to: cropRect)
        guard !finalImage.extent.isInfinite && isValidImage(finalImage) else {
            print("❌ Final filtered image invalid or infinite, returning cropped fallback")
            return croppedImage // We know this is valid from check above
        }
        
        print("✅ iOS 18 WORKAROUND: Background created without blur (iOS 18 bug workaround)")
        return finalImage
    }
    
    // MARK: - Proper SmartFill Background Creation (with gaussian blur restored)
    
    private func createProperSmartFillBackground(
        source: CIImage,
        renderSize: CGSize,
        darkenAmount: CGFloat,
        blurRadius: CGFloat,
        sourceImageSize: CGSize? = nil,
        settings: SmartFillSettings // ENTERPRISE: Accept settings for configurable background scale
    ) throws -> CIImage {
        
        print("🎨 SmartFill: Creating proper background with gaussian blur")
        print("   📐 Source extent: \(source.extent)")
        print("   📐 Render size: \(renderSize)")
        print("   🌟 Blur radius: \(blurRadius)")
        print("   🔅 Darken amount: \(darkenAmount)")
        print("   📐 Background scale: \(settings.backgroundScale)x (ENTERPRISE CONFIGURABLE)")
        if let imageSize = sourceImageSize {
            print("   📐 Source image size: \(imageSize)")
        }
        
        // FIXED: Check for infinite extent first
        guard !source.extent.isInfinite else {
            print("❌ Source has infinite extent, using fallback")
            return createSolidColorFallback(renderSize: renderSize)
        }
        
        // FIXED: Validate source image
        guard isValidImage(source) else {
            print("❌ Invalid source image, using fallback")
            return createSolidColorFallback(renderSize: renderSize)
        }
        
        // 🎯 CRITICAL FIX: Calculate dramatically larger background that EXTENDS beyond render boundaries
        let sourceSize = sourceImageSize ?? source.extent.size
        let scaleX = renderSize.width / sourceSize.width
        let scaleY = renderSize.height / sourceSize.height
        
        // 🔥 MASTER BRAIN FIX: Use MUCH more aggressive scaling to ensure COMPLETE edge-to-edge fill
        let baseScale = max(scaleX, scaleY)
        let backgroundScale = baseScale * settings.backgroundScale // This could be 10x or 15x total!
        
        // 🎯 CRITICAL: Calculate extended background size that goes BEYOND render boundaries
        let extendedWidth = renderSize.width * 1.5  // 50% larger than render size
        let extendedHeight = renderSize.height * 1.5 // 50% larger than render size
        let extendedSize = CGSize(width: extendedWidth, height: extendedHeight)
        
        print("🔧 SmartFill EDGE-TO-EDGE SCALING: sourceSize: \(sourceSize), scaleX: \(scaleX), scaleY: \(scaleY)")
        print("🎯 SmartFill ENTERPRISE: Using configurable scale \(settings.backgroundScale)x = \(backgroundScale) total scale")
        print("🚀 SmartFill CRITICAL FIX: Extended background size: \(extendedSize) (beyond render: \(renderSize))")
        print("🎯 SmartFill MASTER BRAIN FIX: DRAMATICALLY LARGER scaling to ELIMINATE BLACK BARS COMPLETELY")
        
        // FIXED: Validate scale values
        guard backgroundScale.isFinite && backgroundScale > 0 else {
            print("❌ Invalid scale values, using fallback")
            return createSolidColorFallback(renderSize: renderSize)
        }
        
        // Scale the image to MASSIVELY OVERFILL the background (eliminates black bars completely)
        let scaledImage = source.transformed(by: CGAffineTransform(scaleX: backgroundScale, y: backgroundScale))
        
        // FIXED: Check for infinite extent after scaling
        guard !scaledImage.extent.isInfinite && isValidImage(scaledImage) else {
            print("❌ Scaled image invalid or infinite, using fallback")
            return createSolidColorFallback(renderSize: renderSize)
        }
        
        // STEP 2: Center the scaled image within the EXTENDED background (not just render size)
        let scaledSize = CGSize(width: sourceSize.width * backgroundScale, height: sourceSize.height * backgroundScale)
        let offsetX = (extendedSize.width - scaledSize.width) / 2
        let offsetY = (extendedSize.height - scaledSize.height) / 2
        
        print("🎯 SmartFill EXTENDED CENTERING: scaledSize: \(scaledSize), extendedOffset: (\(offsetX), \(offsetY))")
        
        // FIXED: Validate offset values
        guard offsetX.isFinite && offsetY.isFinite else {
            print("❌ Invalid offset values, using fallback")
            return createSolidColorFallback(renderSize: renderSize)
        }
        
        let centeredImage = scaledImage.transformed(by: CGAffineTransform(translationX: offsetX, y: offsetY))
        
        // FIXED: Check for infinite extent after translation
        guard !centeredImage.extent.isInfinite && isValidImage(centeredImage) else {
            print("❌ Centered image invalid or infinite, using fallback")
            return createSolidColorFallback(renderSize: renderSize)
        }
        
        // 🚀 CRITICAL FIX: Crop to EXTENDED size first (not render size) to preserve overfill
        let extendedCropRect = CGRect(origin: .zero, size: extendedSize)
        let extendedCroppedImage = centeredImage.cropped(to: extendedCropRect)
        
        // FIXED: Check for infinite extent after cropping
        guard !extendedCroppedImage.extent.isInfinite && isValidImage(extendedCroppedImage) else {
            print("❌ Extended cropped image invalid or infinite, using fallback")
            return createSolidColorFallback(renderSize: renderSize)
        }
        
        // STEP 3: Apply gaussian blur to the EXTENDED background - THIS IS THE KEY SMARTFILL EFFECT!
        guard let gaussianBlur = CIFilter(name: "CIGaussianBlur") else {
            print("❌ Could not create CIGaussianBlur filter, using fallback")
            return createSolidColorFallback(renderSize: renderSize)
        }
        
        gaussianBlur.setValue(extendedCroppedImage, forKey: kCIInputImageKey)
        gaussianBlur.setValue(blurRadius, forKey: kCIInputRadiusKey)
        
        guard let blurredImage = gaussianBlur.outputImage else {
            print("❌ Gaussian blur failed, using extended image without blur")
            return extendedCroppedImage // Fallback to non-blurred extended version
        }
        
        // IMPORTANT: Crop the blurred image back to EXTENDED size (blur can expand extent)
        let blurredExtended = blurredImage.cropped(to: extendedCropRect)
        
        // FIXED: Check for infinite extent after blur and crop
        guard !blurredExtended.extent.isInfinite && isValidImage(blurredExtended) else {
            print("❌ Blurred extended image invalid or infinite, using unblurred extended")
            return extendedCroppedImage // Fallback to non-blurred extended version
        }
        
        // STEP 4: Apply color adjustments (darken and desaturate the background)
        guard let colorControls = CIFilter(name: "CIColorControls") else {
            print("⚠️ Could not create color controls filter, using blurred extended image without color adjustments")
            return blurredExtended
        }
        
        colorControls.setValue(blurredExtended, forKey: kCIInputImageKey)
        colorControls.setValue(-darkenAmount, forKey: kCIInputBrightnessKey) // Darken
        colorControls.setValue(0.7, forKey: kCIInputSaturationKey) // Desaturate
        colorControls.setValue(1.1, forKey: kCIInputContrastKey) // Slight contrast boost
        
        guard let adjustedImage = colorControls.outputImage else {
            print("⚠️ Color adjustments failed, using blurred extended image")
            return blurredExtended
        }
        
        // 🚀 FINAL CRITICAL STEP: Crop from center of EXTENDED background to render size
        // This ensures the background EXTENDS beyond all edges while fitting the render frame
        let finalCropOffsetX = (extendedSize.width - renderSize.width) / 2
        let finalCropOffsetY = (extendedSize.height - renderSize.height) / 2
        let finalCropRect = CGRect(
            x: finalCropOffsetX,
            y: finalCropOffsetY,
            width: renderSize.width,
            height: renderSize.height
        )
        
        let finalBackground = adjustedImage.cropped(to: finalCropRect)
        
        // FIXED: Final validation
        guard !finalBackground.extent.isInfinite && isValidImage(finalBackground) else {
            print("❌ Final background invalid, using blurred extended fallback cropped to render size")
            let fallbackCrop = CGRect(
                x: (extendedSize.width - renderSize.width) / 2,
                y: (extendedSize.height - renderSize.height) / 2,
                width: renderSize.width,
                height: renderSize.height
            )
            return blurredExtended.cropped(to: fallbackCrop)
        }
        
        print("✅ SmartFill: EXTENDED BACKGROUND created with CONFIGURABLE FILL scaling and gaussian blur")
        print("   🎨 Applied gaussian blur (radius: \(blurRadius))")
        print("   🔅 Applied darkening (amount: \(darkenAmount))")
        print("   📐 Background scale: \(settings.backgroundScale)x (total: \(backgroundScale)) - ENTERPRISE ADJUSTABLE")
        print("   🚀 Extended background size: \(extendedSize) → Final size: \(finalBackground.extent.size)")
        print("   🎯 MASTER BRAIN FIX COMPLETE: BLACK BARS ELIMINATED WITH EXTENDED BACKGROUND")
        
        return finalBackground
    }
    
    /// FIXED: Create solid color fallback when image processing fails
    private func createSolidColorFallback(renderSize: CGSize) -> CIImage {
        // Create a simple dark gray background as absolute fallback
        let color = CIColor(red: 0.2, green: 0.2, blue: 0.2, alpha: 1.0)
        let colorImage = CIImage(color: color)
        let cropRect = CGRect(origin: .zero, size: renderSize)
        let croppedFallback = colorImage.cropped(to: cropRect)
        
        print("🛡️ iOS 18 WORKAROUND: Using solid color fallback (\(renderSize.width)x\(renderSize.height))")
        return croppedFallback
    }
    
    private func cropToRenderSize(_ image: CIImage, renderSize: CGSize) -> CIImage {
        let cropRect = CGRect(origin: .zero, size: renderSize)
        return image.cropped(to: cropRect)
    }
    
    // MARK: - iOS 18 Compatible Validation Helpers
    
    /// FIXED: iOS 18 compatible extent validation (replaces extent.isFinite)
    private func isValidExtent(_ size: CGSize) -> Bool {
        return size.width.isFinite &&
               size.height.isFinite &&
               !size.width.isNaN &&
               !size.height.isNaN &&
               size.width > 0 &&
               size.height > 0
    }
    
    /// FIXED: iOS 18 compatible image validation with comprehensive checks
    private func isValidImage(_ image: CIImage) -> Bool {
        let extent = image.extent
        
        // CRITICAL: Check for infinite extent first - iOS 18 bug
        guard !extent.isInfinite else {
            print("🔍 iOS 18 DEBUG: Image has infinite extent")
            return false
        }
        
        return extent.size.width.isFinite &&
               extent.size.height.isFinite &&
               !extent.size.width.isNaN &&
               !extent.size.height.isNaN &&
               extent.size.width > 0 &&
               extent.size.height > 0 &&
               !extent.isEmpty &&
               !extent.isInfinite && // Additional check
               extent.origin.x.isFinite && // Check origin too
               extent.origin.y.isFinite &&
               !extent.origin.x.isNaN &&
               !extent.origin.y.isNaN
    }
}

// MARK: - STS Integration Extensions - UPDATED for iOS 18

public extension SmartFillExporter {
    
    /// Process a single video file with SmartFill optimized for iPhone 16 Pro
    /// UPDATED: iOS 18 Bug Workaround with proper orientation detection
    static func processPortraitVideoFile(
        inputPath: String,
        outputPath: String,
        settings: SmartFillSettings = SmartFillSettings()
    ) async throws -> Bool {
        
        let inputURL = URL(fileURLWithPath: inputPath)
        let outputURL = URL(fileURLWithPath: outputPath)
        let asset = AVURLAsset(url: inputURL)
        
        // FIXED: Analyze video orientation with iOS 18 optimized loading
        let analysis = try await NormalizeOrientation.analyzeVideoOrientation(from: asset)
        
        print("📱 SmartFill: Analyzing single video - \(analysis.capturedOrientation.displayName)")
        print("🔍 SmartFill: Video analysis details:")
        print("   📐 Natural Size: \(analysis.naturalSize)")
        print("   📐 Upright Size: \(analysis.uprightSize)")
        print("   🔄 Transform: \(analysis.transformType.displayName)")
        print("   📱 Is Portrait: \(analysis.isPortraitVideo)")
        
        // FIXED: Use upright size (oriented dimensions) instead of natural size for portrait detection
        guard analysis.isPortraitVideo else {
            print("📹 SmartFill: Video is landscape (upright: \(analysis.uprightSize)), no processing needed")
            return false
        }
        
        print("🔧 SmartFill: Processing portrait video with iOS 18 workarounds...")
        print("   📐 Will process: \(analysis.uprightSize) → \(settings.defaultRenderSize)")
        
        // Create composition for the single video
        let composition = AVMutableComposition()
        
        // Add video track
        guard let videoTrack = composition.addMutableTrack(
            withMediaType: .video,
            preferredTrackID: kCMPersistentTrackID_Invalid
        ) else {
            throw SmartFillError.compositionCreationFailed("Failed to create video track")
        }
        
        // Add audio track
        let audioTrack = composition.addMutableTrack(
            withMediaType: .audio,
            preferredTrackID: kCMPersistentTrackID_Invalid
        )
        
        // Load tracks from source using modern async API
        let videoTracks = try await asset.loadTracks(withMediaType: .video)
        guard let sourceVideoTrack = videoTracks.first else {
            throw SmartFillError.invalidVideoTrack
        }
        
        let duration = try await asset.load(.duration)
        let timeRange = CMTimeRange(start: .zero, duration: duration)
        
        // Insert video
        try videoTrack.insertTimeRange(timeRange, of: sourceVideoTrack, at: .zero)
        
        // Insert audio if available
        if let audioTrack = audioTrack,
           let sourceAudioTrack = try await asset.loadTracks(withMediaType: .audio).first {
            try audioTrack.insertTimeRange(timeRange, of: sourceAudioTrack, at: .zero)
        }
        
        // FIXED: Create SmartFill video composition using oriented size for proper portrait processing
        let portraitSegments = [CMTimeRange(start: .zero, duration: duration)]
        let exporter = SmartFillExporter()
        let videoComposition = try await exporter.makeVideoComposition(
            for: composition,
            renderSize: settings.defaultRenderSize,
            portraitSegments: portraitSegments,
            settings: settings,
            orientationAnalysis: analysis  // NEW: Pass orientation analysis
        )
        
        // UPDATED: iOS 18 optimized export session
        guard let exportSession = AVAssetExportSession(
            asset: composition,
            presetName: AVAssetExportPresetHighestQuality
        ) else {
            throw SmartFillError.compositionCreationFailed("Failed to create export session")
        }
        
        exportSession.outputURL = outputURL
        exportSession.outputFileType = .mov
        exportSession.videoComposition = videoComposition
        
        // UPDATED: iOS 18 compatible export with better progress tracking
        return try await withCheckedThrowingContinuation { continuation in
            exportSession.exportAsynchronously {
                switch exportSession.status {
                case .completed:
                    print("✅ SmartFill: Successfully processed portrait video with iOS 18 workarounds")
                    print("   📐 Processed: \(analysis.uprightSize) → \(settings.defaultRenderSize)")
                    continuation.resume(returning: true)
                case .failed:
                    let error = exportSession.error ?? SmartFillError.compositionCreationFailed("Export failed")
                    print("❌ SmartFill: Export failed: \(error)")
                    continuation.resume(throwing: error)
                case .cancelled:
                    print("⚠️ SmartFill: Export was cancelled")
                    continuation.resume(throwing: SmartFillError.compositionCreationFailed("Export cancelled"))
                default:
                    print("⚠️ SmartFill: Export ended with status: \(exportSession.status)")
                    continuation.resume(throwing: SmartFillError.compositionCreationFailed("Export ended unexpectedly"))
                }
            }
        }
    }
    
    /// Create video composition for STS export pipeline integration
    /// UPDATED: iOS 18 Bug Workarounds
    static func createCompositionForSTSExport(
        takes: [ProjectTake],
        session: ProjectSession,
        settings: SmartFillSettings = SmartFillSettings()
    ) async throws -> (AVMutableComposition, AVVideoComposition) {
        
        let composition = AVMutableComposition()
        var currentTime = CMTime.zero
        var portraitSegments: [CMTimeRange] = []
        
        // Create video and audio tracks
        guard let videoTrack = composition.addMutableTrack(
            withMediaType: .video,
            preferredTrackID: kCMPersistentTrackID_Invalid
        ) else {
            throw SmartFillError.compositionCreationFailed("Failed to create video track")
        }
        
        let audioTrack = composition.addMutableTrack(
            withMediaType: .audio,
            preferredTrackID: kCMPersistentTrackID_Invalid
        )
        
        // Process each take with iOS 18 optimized loading
        for take in takes {
            let url = URL(fileURLWithPath: take.filePath)
            let asset = AVURLAsset(url: url)
            
            // Load video track using modern async API
            let videoTracks = try await asset.loadTracks(withMediaType: .video)
            guard let sourceVideoTrack = videoTracks.first else { continue }
            
            let duration = try await asset.load(.duration)
            let timeRange = CMTimeRange(start: .zero, duration: duration)
            
            // Insert video
            try videoTrack.insertTimeRange(timeRange, of: sourceVideoTrack, at: currentTime)
            
            // Insert audio if available
            if let audioTrack = audioTrack,
               let sourceAudioTrack = try await asset.loadTracks(withMediaType: .audio).first {
                try audioTrack.insertTimeRange(timeRange, of: sourceAudioTrack, at: currentTime)
            }
            
            // Check if this segment needs Smart Fill
            if SmartFillPolicy.shouldApply(for: take, in: session) {
                let segmentRange = CMTimeRange(start: currentTime, duration: duration)
                portraitSegments.append(segmentRange)
                print("📱 SmartFillExporter: Added portrait segment: \(segmentRange)")
            }
            
            currentTime = CMTimeAdd(currentTime, duration)
        }
        
        // Create Smart Fill video composition with iOS 18 workarounds
        let exporter = SmartFillExporter()
        let videoComposition = try await exporter.makeVideoComposition(
            for: composition,
            renderSize: settings.defaultRenderSize,
            portraitSegments: portraitSegments,
            settings: settings
        )
        
        print("✅ SmartFillExporter: Created iOS 18 workaround composition with \(portraitSegments.count) Smart Fill segments")
        
        return (composition, videoComposition)
    }
}

// MARK: - Error Handling

public enum SmartFillError: LocalizedError {
    case filterCreationFailed(String)
    case filterProcessingFailed(String)
    case compositionCreationFailed(String)
    case invalidVideoTrack
    case metalInitializationFailed
    
    public var errorDescription: String? {
        switch self {
        case .filterCreationFailed(let filterName):
            return "Failed to create CoreImage filter: \(filterName)"
        case .filterProcessingFailed(let operation):
            return "Filter processing failed: \(operation)"
        case .compositionCreationFailed(let reason):
            return "Composition creation failed: \(reason)"
        case .invalidVideoTrack:
            return "Invalid video track"
        case .metalInitializationFailed:
            return "Metal initialization failed"
        }
    }
}

// MARK: - Utility Extensions

private extension CMTimeRange {
    func containsTime(_ t: CMTime) -> Bool {
        return t >= start && t < CMTimeAdd(start, duration)
    }
}

// MARK: - Performance Monitoring (Development)

#if DEBUG
private extension SmartFillExporter {
    
    func logPerformanceMetrics(operation: String, startTime: CFAbsoluteTime) {
        let endTime = CFAbsoluteTime(CACurrentMediaTime())
        let duration = endTime - startTime
        
        if duration > 0.1 { // Log operations taking more than 100ms
            print("⏱️ SmartFillExporter: \(operation) took \(String(format: "%.3f", duration))s")
        }
    }
}
#endif
