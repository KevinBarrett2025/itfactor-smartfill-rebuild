import AVFoundation
import CoreImage
import UIKit

/// 🚨 CRITICAL FIX: Preview-compatible SmartFill compositor
/// Uses standard AVVideoComposition without AVVideoCompositionCoreAnimationTool
/// This SOLVES THE CRASH when trying to preview SmartFill videos
/// 🚨 SWIFT 6 FIX: Made Sendable-compliant for safe concurrent access
public final class SmartFillPreviewCompositor: @unchecked Sendable {
    
    // MARK: - Properties
    // 🚨 SWIFT 6: CIContext is not Sendable but we use it in a thread-safe manner
    private let ciContext: CIContext
    private let metalDevice: MTLDevice?
    
    public init(device: MTLDevice? = MTLCreateSystemDefaultDevice()) {
        self.metalDevice = device
        
        if let device = device {
            self.ciContext = CIContext(mtlDevice: device, options: [
                .workingColorSpace: CGColorSpace(name: CGColorSpace.sRGB)!,
                .outputColorSpace: CGColorSpace(name: CGColorSpace.sRGB)!,
                .cacheIntermediates: false
            ])
        } else {
            self.ciContext = CIContext(options: [
                .workingColorSpace: CGColorSpace(name: CGColorSpace.sRGB)!,
                .outputColorSpace: CGColorSpace(name: CGColorSpace.sRGB)!
            ])
        }
        
        print("✅ SmartFillPreviewCompositor: Initialized PREVIEW-COMPATIBLE compositor (no CALayer/AnimationTool)")
    }
    
    // MARK: - Preview-Compatible Public API
    
    /// 🚨 CRITICAL: Create preview-compatible video composition WITHOUT AVVideoCompositionCoreAnimationTool
    /// This is the SAFE method that works with AVPlayerItem for live preview
    public func createPreviewVideoComposition(
        for asset: AVAsset,
        renderSize: CGSize,
        settings: SmartFillSettings = SmartFillSettings()
    ) async throws -> AVVideoComposition {
        
        print("🎬 SmartFillPreviewCompositor: Creating PREVIEW-COMPATIBLE composition (safe for AVPlayerItem)")
        print("   📐 Render size: \(renderSize)")
        print("   🎨 Settings: blur=\(settings.defaultBlurRadius), darken=\(settings.defaultDarkenAmount)")
        
        // Analyze video properties
        let videoAnalysis = try await analyzeVideoProperties(asset: asset)
        print("   🔍 Video analysis: \(videoAnalysis.naturalSize) → \(videoAnalysis.displaySize), portrait: \(videoAnalysis.isPortrait)")
        
        // Create standard video composition (NO AVVideoCompositionCoreAnimationTool)
        let composition = try await createStandardVideoComposition(
            asset: asset,
            videoAnalysis: videoAnalysis,
            renderSize: renderSize,
            settings: settings
        )
        
        print("✅ SmartFillPreviewCompositor: Created SAFE preview composition")
        print("   🔒 Uses standard AVVideoComposition (AVPlayerItem compatible)")
        print("   🎬 No CALayer or AVVideoCompositionCoreAnimationTool")
        print("   📱 Ready for live preview without crashes")
        
        return composition
    }
    
    // MARK: - Video Analysis
    
    private func analyzeVideoProperties(asset: AVAsset) async throws -> VideoAnalysis {
        let videoTracks = try await asset.loadTracks(withMediaType: .video)
        guard let videoTrack = videoTracks.first else {
            throw SmartFillPreviewCompositorError.invalidAsset
        }
        
        let naturalSize = try await videoTrack.load(.naturalSize)
        let preferredTransform = try await videoTrack.load(.preferredTransform)
        let nominalFrameRate = try await videoTrack.load(.nominalFrameRate)
        
        // Calculate display size after transform
        let displaySize = naturalSize.applying(preferredTransform)
        let displayWidth = abs(displaySize.width)
        let displayHeight = abs(displaySize.height)
        
        let isPortrait = displayHeight > displayWidth
        
        return VideoAnalysis(
            naturalSize: naturalSize,
            displaySize: CGSize(width: displayWidth, height: displayHeight),
            preferredTransform: preferredTransform,
            nominalFrameRate: nominalFrameRate,
            isPortrait: isPortrait
        )
    }
    
    // MARK: - Standard Video Composition (Preview-Safe)
    
    /// 🚨 CRITICAL: Create standard video composition WITHOUT CALayer dependencies
    /// This method creates a similar visual effect to the export compositor but using only
    /// standard AVVideoComposition techniques that work with AVPlayerItem
    private func createStandardVideoComposition(
        asset: AVAsset,
        videoAnalysis: VideoAnalysis,
        renderSize: CGSize,
        settings: SmartFillSettings
    ) async throws -> AVMutableVideoComposition {
        
        let videoTracks = try await asset.loadTracks(withMediaType: .video)
        guard let videoTrack = videoTracks.first else {
            throw SmartFillPreviewCompositorError.invalidAsset
        }
        
        let duration = try await asset.load(.duration)
        
        // Create the composition
        let composition = AVMutableVideoComposition()
        composition.renderSize = renderSize
        
        // Set appropriate frame rate
        let targetFrameRate: Int32 = videoAnalysis.nominalFrameRate > 0 ? min(Int32(videoAnalysis.nominalFrameRate), 60) : 30
        composition.frameDuration = CMTime(value: 1, timescale: targetFrameRate)
        
        print("🎬 SmartFillPreviewCompositor: Using \(targetFrameRate)fps for preview")
        
        // 🚨 CRITICAL: Use custom compositor class for background blur effect
        composition.customVideoCompositorClass = SmartFillPreviewCustomCompositor.self
        
        // Create instruction
        let instruction = SmartFillPreviewInstruction()
        instruction.timeRange = CMTimeRange(start: .zero, duration: duration)
        
        // Configure the instruction with our settings
        instruction.renderSize = renderSize
        instruction.settings = settings
        instruction.videoAnalysis = videoAnalysis
        
        // Create layer instruction for the video track
        let layerInstruction = AVMutableVideoCompositionLayerInstruction(assetTrack: videoTrack)
        
        // Apply transform for proper video positioning
        let videoTransform = calculateVideoTransform(
            videoAnalysis: videoAnalysis,
            renderSize: renderSize
        )
        
        layerInstruction.setTransform(videoTransform, at: .zero)
        
        instruction.layerInstructions = [layerInstruction]
        instruction.videoTrackID = videoTrack.trackID
        
        composition.instructions = [instruction]
        
        print("✅ SmartFillPreviewCompositor: Created standard video composition with custom compositor")
        print("   🎨 Custom compositor will handle background blur in preview")
        print("   📐 Video transform: \(videoTransform)")
        
        return composition
    }
    
    // MARK: - Transform Calculations
    
    private func calculateVideoTransform(
        videoAnalysis: VideoAnalysis,
        renderSize: CGSize
    ) -> CGAffineTransform {
        
        if videoAnalysis.isPortrait {
            // For portrait videos, scale and center properly
            let displaySize = videoAnalysis.displaySize
            let scaleX = renderSize.width / displaySize.width
            let scaleY = renderSize.height / displaySize.height
            let scale = min(scaleX, scaleY) // Fit within bounds
            
            // Calculate centering offset
            let scaledWidth = displaySize.width * scale
            let scaledHeight = displaySize.height * scale
            let offsetX = (renderSize.width - scaledWidth) / 2
            let offsetY = (renderSize.height - scaledHeight) / 2
            
            // Combine original transform with our scaling and centering
            var transform = videoAnalysis.preferredTransform
            transform = transform.scaledBy(x: scale, y: scale)
            transform = transform.translatedBy(x: offsetX / scale, y: offsetY / scale)
            
            print("🔧 SmartFillPreviewCompositor: Portrait transform - scale: \(scale), offset: (\(offsetX), \(offsetY))")
            
            return transform
        } else {
            // For landscape videos, use original transform
            return videoAnalysis.preferredTransform
        }
    }
}

// MARK: - Custom Video Compositor for Background Blur

/// 🚨 CRITICAL: Custom video compositor class that handles background blur for PREVIEW
/// This replaces the CALayer approach with a custom compositor that's AVPlayerItem compatible
/// 🚨 SWIFT 6 FIX: Added @unchecked Sendable and nonisolated(unsafe) for AVFoundation compliance
private final class SmartFillPreviewCustomCompositor: NSObject, AVVideoCompositing, @unchecked Sendable {
    
    // 🚨 SWIFT 6 SENDABILITY: Mark pixel buffer attributes as nonisolated(unsafe)
    // AVFoundation reads these off-thread; we keep them immutable after init
    nonisolated(unsafe) var sourcePixelBufferAttributes: [String : Any]? = [
        kCVPixelBufferPixelFormatTypeKey as String: [
            kCVPixelFormatType_420YpCbCr8BiPlanarVideoRange,
            kCVPixelFormatType_32BGRA
        ]
    ]
    
    nonisolated(unsafe) var requiredPixelBufferAttributesForRenderContext: [String : Any] = [
        kCVPixelBufferPixelFormatTypeKey as String: kCVPixelFormatType_32BGRA
    ]
    
    // Use a serial queue for rendering
    private let renderQueue = DispatchQueue(label: "SmartFillPreviewRenderQueue", qos: .userInteractive)
    
    func renderContextChanged(_ newRenderContext: AVVideoCompositionRenderContext) {
        // Update render context if needed
    }
    
    func startRequest(_ asyncVideoCompositionRequest: AVAsynchronousVideoCompositionRequest) {
        renderQueue.async { [weak self] in
            self?.processRequest(asyncVideoCompositionRequest)
        }
    }
    
    private func processRequest(_ request: AVAsynchronousVideoCompositionRequest) {
        guard let instruction = request.videoCompositionInstruction as? SmartFillPreviewInstruction else {
            request.finish(with: NSError(domain: "SmartFillPreviewCompositor", code: -1, userInfo: [NSLocalizedDescriptionKey: "Invalid instruction"]))
            return
        }
        
        // Get the source pixel buffer
        guard let sourceBuffer = request.sourceFrame(byTrackID: instruction.videoTrackID) else {
            request.finish(with: NSError(domain: "SmartFillPreviewCompositor", code: -2, userInfo: [NSLocalizedDescriptionKey: "No source frame"]))
            return
        }
        
        do {
            // Create the output buffer
            guard let outputBuffer = request.renderContext.newPixelBuffer() else {
                request.finish(with: NSError(domain: "SmartFillPreviewCompositor", code: -3, userInfo: [NSLocalizedDescriptionKey: "Cannot create output buffer"]))
                return
            }
            
            // Render the SmartFill effect
            try renderSmartFillEffect(
                sourceBuffer: sourceBuffer,
                outputBuffer: outputBuffer,
                instruction: instruction
            )
            
            request.finish(withComposedVideoFrame: outputBuffer)
            
        } catch {
            request.finish(with: error)
        }
    }
    
    private func renderSmartFillEffect(
        sourceBuffer: CVPixelBuffer,
        outputBuffer: CVPixelBuffer,
        instruction: SmartFillPreviewInstruction
    ) throws {
        
        // Create CIImage from source buffer
        let sourceImage = CIImage(cvPixelBuffer: sourceBuffer)
        
        // Create the background blur effect (simplified for preview)
        let blurredBackground = try createPreviewBackground(
            sourceImage: sourceImage,
            renderSize: instruction.renderSize,
            settings: instruction.settings
        )
        
        // Composite the original video over the blurred background
        let composite = sourceImage.composited(over: blurredBackground)
        
        // Render to output buffer
        let ciContext = CIContext()
        ciContext.render(composite, to: outputBuffer)
    }
    
    private func createPreviewBackground(
        sourceImage: CIImage,
        renderSize: CGSize,
        settings: SmartFillSettings
    ) throws -> CIImage {
        
        // Scale the source image to fill the render size with blur
        let sourceSize = sourceImage.extent.size
        let scaleX = renderSize.width / sourceSize.width
        let scaleY = renderSize.height / sourceSize.height
        let scale = max(scaleX, scaleY) * settings.backgroundScale
        
        let scaledImage = sourceImage.transformed(by: CGAffineTransform(scaleX: scale, y: scale))
        
        // Center the scaled image
        let scaledSize = CGSize(width: sourceSize.width * scale, height: sourceSize.height * scale)
        let offsetX = (renderSize.width - scaledSize.width) / 2
        let offsetY = (renderSize.height - scaledSize.height) / 2
        
        let centeredImage = scaledImage.transformed(by: CGAffineTransform(translationX: offsetX, y: offsetY))
        
        // Crop to render size
        let croppedImage = centeredImage.cropped(to: CGRect(origin: .zero, size: renderSize))
        
        // Apply blur
        guard let blurFilter = CIFilter(name: "CIGaussianBlur") else {
            throw SmartFillPreviewCompositorError.filterCreationFailed("CIGaussianBlur")
        }
        
        blurFilter.setValue(croppedImage, forKey: kCIInputImageKey)
        blurFilter.setValue(settings.defaultBlurRadius, forKey: kCIInputRadiusKey)
        
        guard let blurredImage = blurFilter.outputImage else {
            throw SmartFillPreviewCompositorError.filterProcessingFailed("Gaussian blur")
        }
        
        // Apply darkening
        guard let colorFilter = CIFilter(name: "CIColorControls") else {
            throw SmartFillPreviewCompositorError.filterCreationFailed("CIColorControls")
        }
        
        colorFilter.setValue(blurredImage, forKey: kCIInputImageKey)
        colorFilter.setValue(-settings.defaultDarkenAmount, forKey: kCIInputBrightnessKey)
        
        guard let finalImage = colorFilter.outputImage else {
            throw SmartFillPreviewCompositorError.filterProcessingFailed("Color controls")
        }
        
        return finalImage.cropped(to: CGRect(origin: .zero, size: renderSize))
    }
}

// MARK: - Custom Instruction

private class SmartFillPreviewInstruction: NSObject, AVVideoCompositionInstructionProtocol {
    var timeRange: CMTimeRange = .zero
    var enablePostProcessing: Bool = false
    var containsTweening: Bool = false
    var requiredSourceTrackIDs: [NSValue]?
    var passthroughTrackID: CMPersistentTrackID = kCMPersistentTrackID_Invalid
    var layerInstructions: [AVVideoCompositionLayerInstruction] = []
    
    // Custom properties for SmartFill
    var renderSize: CGSize = .zero
    var settings: SmartFillSettings = SmartFillSettings()
    var videoAnalysis: VideoAnalysis = VideoAnalysis(
        naturalSize: .zero,
        displaySize: .zero,
        preferredTransform: .identity,
        nominalFrameRate: 30,
        isPortrait: false
    )
    var videoTrackID: CMPersistentTrackID = kCMPersistentTrackID_Invalid
    
    override init() {
        super.init()
    }
}

// MARK: - Supporting Types

private struct VideoAnalysis {
    let naturalSize: CGSize
    let displaySize: CGSize
    let preferredTransform: CGAffineTransform
    let nominalFrameRate: Float
    let isPortrait: Bool
}

// MARK: - Error Handling

public enum SmartFillPreviewCompositorError: LocalizedError {
    case invalidAsset
    case filterCreationFailed(String)
    case filterProcessingFailed(String)
    
    public var errorDescription: String? {
        switch self {
        case .invalidAsset:
            return "Invalid video asset for preview"
        case .filterCreationFailed(let filterName):
            return "Failed to create preview filter: \(filterName)"
        case .filterProcessingFailed(let operation):
            return "Preview filter processing failed: \(operation)"
        }
    }
}

// MARK: - Convenience Extensions

public extension SmartFillPreviewCompositor {
    
    /// Convenience method for creating preview compositions
    static func createPreviewComposition(
        for videoURL: URL,
        renderSize: CGSize = CGSize(width: 1920, height: 1080),
        settings: SmartFillSettings = SmartFillSettings()
    ) async throws -> AVVideoComposition {
        
        let asset = AVURLAsset(url: videoURL)
        let compositor = SmartFillPreviewCompositor()
        
        return try await compositor.createPreviewVideoComposition(
            for: asset,
            renderSize: renderSize,
            settings: settings
        )
    }
}

#if DEBUG
// MARK: - Debug Extensions

private extension SmartFillPreviewCompositor {
    func logPerformance(_ operation: String, startTime: CFAbsoluteTime) {
        let duration = CFAbsoluteTime(CACurrentMediaTime()) - startTime
        if duration > 0.05 { // Log if slower than 50ms
            print("⏱️ SmartFillPreviewCompositor: \(operation) took \(String(format: "%.3f", duration))s")
        }
    }
}
#endif
