import AVFoundation
import CoreImage
import UIKit

/// 🚨 EXPORT-ONLY SmartFill compositor using CALayer + AVVideoCompositionCoreAnimationTool
/// ⚠️  WARNING: This compositor CANNOT be used with AVPlayerItem for preview - it will CRASH
/// ⚠️  For preview operations, use SmartFillPreviewCompositor instead
/// This is the CORRECT approach for EXPORT operations that works WITH AVFoundation instead of against it
public final class SmartFillCompositor {
    
    // MARK: - Properties
    private let ciContext: CIContext
    private let metalDevice: MTLDevice?
    
    public init(device: MTLDevice? = MTLCreateSystemDefaultDevice()) {
        self.metalDevice = device
        
        if let device = device {
            self.ciContext = CIContext(mtlDevice: device, options: [
                .workingColorSpace: CGColorSpace(name: CGColorSpace.sRGB)!,
                .outputColorSpace: CGColorSpace(name: CGColorSpace.sRGB)!,
                .cacheIntermediates: false // Optimized for single-frame processing
            ])
        } else {
            self.ciContext = CIContext(options: [
                .workingColorSpace: CGColorSpace(name: CGColorSpace.sRGB)!,
                .outputColorSpace: CGColorSpace(name: CGColorSpace.sRGB)!
            ])
        }
        
        print("✅ SmartFillCompositor: Initialized with industry-standard CALayer approach")
    }
    
    // MARK: - Public API
    
    /// Create SmartFill video composition using industry-standard approach
    /// 🚨 WARNING: This method creates compositions for EXPORT ONLY - do NOT use with AVPlayerItem
    /// 🚨 For preview operations, use SmartFillPreviewCompositor.createPreviewVideoComposition()
    /// This method works WITH AVFoundation instead of fighting it - but only for export operations
    public func createVideoComposition(
        for asset: AVAsset,
        renderSize: CGSize = CGSize.zero, // HANDOFF FIX: Ignore passed renderSize, determine from orientation
        settings: SmartFillSettings = SmartFillSettings()
    ) async throws -> AVVideoComposition {
        
        print("🎯 SmartFillCompositor: Creating video composition using industry-standard approach")
        
        // HANDOFF FIX: Analyze video orientation and properties FIRST
        let videoAnalysis = try await analyzeVideoProperties(asset: asset)
        
        // HANDOFF FIX #1: Choose canvas (renderSize) by input orientation - CRITICAL FIX
        let actualRenderSize: CGSize = videoAnalysis.isPortrait 
            ? CGSize(width: 1080, height: 1920) // Portrait → 1080×1920
            : CGSize(width: 1920, height: 1080) // Landscape → 1920×1080
        
        print("   🔍 Video analysis: \(videoAnalysis.naturalSize) → \(videoAnalysis.displaySize), portrait: \(videoAnalysis.isPortrait)")
        print("   📐 HANDOFF FIX: Render size determined by orientation: \(actualRenderSize)")
        print("   🎨 Settings: blur=\(settings.defaultBlurRadius), darken=\(settings.defaultDarkenAmount), scale=\(settings.backgroundScale)")
        
        // PHASE 2 ENHANCEMENT: Create professional video composition with proper track handling
        let composition = try await createProfessionalVideoComposition(
            asset: asset,
            videoAnalysis: videoAnalysis,
            renderSize: actualRenderSize, // Use orientation-determined size
            settings: settings
        )
        
        // HANDOFF FIX: Create SmartFill layout helper
        let layout = makeSmartFillLayout(natural: videoAnalysis.displaySize, isPortrait: videoAnalysis.isPortrait)
        
        // STEP 1: Extract a single frame to create the blurred background (not frame-by-frame!)
        let backgroundLayer = try await createBlurredBackgroundLayer(
            from: asset,
            videoAnalysis: videoAnalysis,
            renderSize: layout.renderSize, // Use layout's render size
            settings: settings
        )
        
        // STEP 2: Create the layer hierarchy properly with HANDOFF FIXES
        let parentLayer = CALayer()
        parentLayer.frame = CGRect(origin: .zero, size: layout.renderSize)
        
        // HANDOFF FIX #2: Background layer with proper centering
        parentLayer.addSublayer(backgroundLayer)
        
        // HANDOFF FIX #3: Video layer with layout-determined frame
        let videoLayer = CALayer()
        videoLayer.frame = foregroundFrameFromLayout(layout) // Use helper method to get frame
        parentLayer.addSublayer(videoLayer)
        
        // STEP 3: Create the animation tool (this is the KEY difference from our old approach)
        // 🚨 CRITICAL: AVVideoCompositionCoreAnimationTool is for EXPORT ONLY
        // 🚨 Do NOT use this composition with AVPlayerItem - it will crash
        let animationTool = AVVideoCompositionCoreAnimationTool(
            postProcessingAsVideoLayer: videoLayer,
            in: parentLayer
        )
        
        // STEP 4: Apply the animation tool to our composition
        composition.animationTool = animationTool
        
        // HANDOFF FIX: Enhanced logging as specified
        print("✅ SmartFillCompositor: Created EXPORT-ONLY video composition")
        print("   🎬 Using AVVideoCompositionCoreAnimationTool (EXPORT ONLY)")
        print("   ⚠️  WARNING: Do NOT use this with AVPlayerItem - will crash")
        print("   📐 HANDOFF: portrait=\(videoAnalysis.isPortrait) render=\(layout.renderSize)")
        print("   📐 HANDOFF: natural=\(videoAnalysis.displaySize) fgFrame=\(foregroundFrameFromLayout(layout))")
        print("   🎨 HANDOFF: bgGravity=\(backgroundLayer.contentsGravity.rawValue) pos=\(backgroundLayer.position)")
        
        return composition
    }
    
    // HANDOFF FIX: Add SmartFill layout helper as specified in handoff
    private func makeSmartFillLayout(natural: CGSize, isPortrait: Bool) -> SmartFillLayout {
        let renderSize = isPortrait ? CGSize(width: 1080, height: 1920)
                                    : CGSize(width: 1920, height: 1080)
        
        // Use existing SmartFillMath to calculate base layout
        let baseLayout = SmartFillMath.calculateSmartFillLayout(sourceSize: natural, renderSize: renderSize)
        
        // HANDOFF FIX: Override foreground positioning to fit canvas height, centered horizontally
        let scale = renderSize.height / natural.height
        let fw = natural.width * scale
        let fh = renderSize.height
        let fx = (renderSize.width - fw) / 2.0
        
        // Create modified layout with handoff-specified foreground frame
        return SmartFillLayout(
            backgroundScale: baseLayout.backgroundScale,
            foregroundScale: scale,
            backgroundSize: baseLayout.backgroundSize,
            foregroundSize: CGSize(width: fw, height: fh),
            backgroundOffset: baseLayout.backgroundOffset,
            foregroundOffset: CGPoint(x: fx, y: 0),
            renderSize: renderSize
        )
    }
    
    // HANDOFF FIX: Helper to get foreground frame from layout
    private func foregroundFrameFromLayout(_ layout: SmartFillLayout) -> CGRect {
        return CGRect(
            x: layout.foregroundOffset.x,
            y: layout.foregroundOffset.y,
            width: layout.foregroundSize.width,
            height: layout.foregroundSize.height
        )
    }
    
    // MARK: - Phase 2: Professional Video Composition
    
    /// PHASE 2: Analyze video properties for intelligent processing
    private func analyzeVideoProperties(asset: AVAsset) async throws -> VideoAnalysis {
        let videoTracks = try await asset.loadTracks(withMediaType: .video)
        guard let videoTrack = videoTracks.first else {
            throw SmartFillCompositorError.invalidAsset
        }
        
        let naturalSize = try await videoTrack.load(.naturalSize)
        let preferredTransform = try await videoTrack.load(.preferredTransform)
        let nominalFrameRate = try await videoTrack.load(.nominalFrameRate)
        
        // PHASE 2 KEY: Let AVFoundation calculate the display size via transform
        let displaySize = naturalSize.applying(preferredTransform)
        let displayWidth = abs(displaySize.width)
        let displayHeight = abs(displaySize.height)
        
        let isPortrait = displayHeight > displayWidth
        
        return VideoAnalysis(
            naturalSize: naturalSize,
            displaySize: CGSize(width: displayWidth, height: displayHeight),
            preferredTransform: preferredTransform,
            nominalFrameRate: nominalFrameRate,
            isPortrait: isPortrait
        )
    }
    
    /// PHASE 2: Create professional video composition with proper track handling
    private func createProfessionalVideoComposition(
        asset: AVAsset,
        videoAnalysis: VideoAnalysis,
        renderSize: CGSize,
        settings: SmartFillSettings
    ) async throws -> AVMutableVideoComposition {
        
        let videoTracks = try await asset.loadTracks(withMediaType: .video)
        guard let videoTrack = videoTracks.first else {
            throw SmartFillCompositorError.invalidAsset
        }
        
        let duration = try await asset.load(.duration)
        
        // PHASE 2: Professional composition setup
        let composition = AVMutableVideoComposition()
        composition.renderSize = renderSize
        
        // PHASE 2: Intelligent frame rate based on source content
        let targetFrameRate: Int32 = videoAnalysis.nominalFrameRate > 0 ? min(Int32(videoAnalysis.nominalFrameRate), 60) : 30
        composition.frameDuration = CMTime(value: 1, timescale: targetFrameRate)
        
        print("🎬 SmartFillCompositor: Using \(targetFrameRate)fps for optimal quality")
        print("   📐 HANDOFF: Composition render size set to \(renderSize)")
        
        // PHASE 2: Professional video composition instruction
        let instruction = AVMutableVideoCompositionInstruction()
        instruction.timeRange = CMTimeRange(start: .zero, duration: duration)
        
        // HANDOFF FIX #4: Keep identity transform - no extra rotations
        let layerInstruction = AVMutableVideoCompositionLayerInstruction(assetTrack: videoTrack)
        
        // HANDOFF FIX: Simplified transform approach - let CALayer handle positioning
        // The video layer frame is now handled by the layout system, not the composition instruction
        // This ensures we get "baked pixels" with no preferredTransform rotation as specified
        if videoAnalysis.isPortrait {
            // Keep the video at natural size, let the CALayer positioning handle the layout
            // This gives us the "identity transform" behavior specified in the handoff
            layerInstruction.setTransform(CGAffineTransform.identity, at: .zero)
            print("🔄 SmartFillCompositor: HANDOFF FIX - Using identity transform for portrait video")
        } else {
            // For landscape, also use identity to keep baked pixels
            layerInstruction.setTransform(CGAffineTransform.identity, at: .zero)
            print("🔄 SmartFillCompositor: HANDOFF FIX - Using identity transform for landscape video")
        }
        
        instruction.layerInstructions = [layerInstruction]
        composition.instructions = [instruction]
        
        return composition
    }
    
    /// PHASE 2: Calculate proper transform for portrait video in landscape frame
    private func calculatePortraitVideoTransform(
        videoAnalysis: VideoAnalysis,
        renderSize: CGSize
    ) -> CGAffineTransform {
        
        let videoSize = videoAnalysis.naturalSize // Use natural size for transform calculation
        
        // CRITICAL FIX: For portrait videos, we need to handle the rotation properly
        // The video comes in as natural size (e.g., 1920x1080) but is actually rotated
        // We need to scale based on the natural dimensions
        
        let scaleX = renderSize.width / videoSize.height  // Note: height maps to width for rotated video
        let scaleY = renderSize.height / videoSize.width  // Note: width maps to height for rotated video
        let scale = min(scaleX, scaleY) // Fit within frame
        
        // Calculate centering for the natural size
        let scaledWidth = videoSize.height * scale
        let scaledHeight = videoSize.width * scale
        let offsetX = (renderSize.width - scaledWidth) / 2
        let offsetY = (renderSize.height - scaledHeight) / 2
        
        // CRITICAL FIX: Apply the original preferred transform first, then scale and translate
        var transform = videoAnalysis.preferredTransform
        transform = transform.scaledBy(x: scale, y: scale)
        transform = transform.translatedBy(x: offsetX / scale, y: offsetY / scale)
        
        print("🔧 SmartFillCompositor: Portrait transform - scale: \(scale), offset: (\(offsetX), \(offsetY))")
        
        return transform
    }
    
    /// PHASE 2: Calculate video layer frame for CALayer positioning
    private func calculateVideoLayerFrame(
        videoAnalysis: VideoAnalysis,
        renderSize: CGSize
    ) -> CGRect {
        
        if videoAnalysis.isPortrait {
            // CRITICAL FIX: For portrait videos, calculate frame based on display dimensions
            // The display size already accounts for rotation
            let displaySize = videoAnalysis.displaySize
            let scaleX = renderSize.width / displaySize.width
            let scaleY = renderSize.height / displaySize.height
            let scale = min(scaleX, scaleY)
            
            let scaledWidth = displaySize.width * scale
            let scaledHeight = displaySize.height * scale
            let x = (renderSize.width - scaledWidth) / 2
            let y = (renderSize.height - scaledHeight) / 2
            
            print("🔧 SmartFillCompositor: Video layer frame - display: \(displaySize), scaled: (\(scaledWidth), \(scaledHeight)), position: (\(x), \(y))")
            
            return CGRect(x: x, y: y, width: scaledWidth, height: scaledHeight)
        } else {
            // For landscape videos, use full render size
            return CGRect(origin: .zero, size: renderSize)
        }
    }
    
    // MARK: - Enhanced Background Creation
    
    /// Create blurred background layer from a single extracted frame
    /// PHASE 2: Enhanced with video analysis for better frame selection
    private func createBlurredBackgroundLayer(
        from asset: AVAsset,
        videoAnalysis: VideoAnalysis,
        renderSize: CGSize,
        settings: SmartFillSettings
    ) async throws -> CALayer {
        
        print("🎨 SmartFillCompositor: Creating blurred background from single frame")
        
        // PHASE 2: Enhanced frame extraction with video analysis
        let generator = AVAssetImageGenerator(asset: asset)
        generator.appliesPreferredTrackTransform = true // Let AVFoundation handle rotation!
        generator.maximumSize = CGSize(width: 1920, height: 1080) // High quality for background
        
        // PHASE 2: Smart time selection - avoid first/last seconds for better frames
        let duration = try await asset.load(.duration)
        let durationSeconds = CMTimeGetSeconds(duration)
        let extractTime = CMTime(seconds: max(1.0, min(durationSeconds / 2, 5.0)), preferredTimescale: 600)
        
        let cgImage = try await generator.image(at: extractTime).image
        
        // Convert to CIImage for processing
        let sourceImage = CIImage(cgImage: cgImage)
        
        // PHASE 2: Enhanced background processing with video analysis
        let processedBackground = try createProcessedBackground(
            sourceImage: sourceImage,
            videoAnalysis: videoAnalysis,
            renderSize: renderSize,
            settings: settings
        )
        
        // Convert back to CGImage for CALayer
        let finalCGImage = ciContext.createCGImage(processedBackground, from: processedBackground.extent)!
        
        // HANDOFF FIX #2: Create CALayer with proper centering as specified
        let backgroundLayer = CALayer()
        backgroundLayer.frame = CGRect(origin: .zero, size: renderSize)
        backgroundLayer.contents = finalCGImage
        backgroundLayer.contentsGravity = .resizeAspectFill // HANDOFF FIX: Ensure it fills completely
        backgroundLayer.masksToBounds = true // HANDOFF FIX: Prevent overflow
        backgroundLayer.anchorPoint = CGPoint(x: 0.5, y: 0.5) // HANDOFF FIX: Center anchor point
        backgroundLayer.position = CGPoint(x: renderSize.width/2, y: renderSize.height/2) // HANDOFF FIX: Center position
        
        print("✅ SmartFillCompositor: Created blurred background layer with HANDOFF centering")
        print("   📐 Background size: \(renderSize)")
        print("   📐 HANDOFF: bgGravity=\(backgroundLayer.contentsGravity.rawValue) pos=\(backgroundLayer.position)")
        print("   🎨 Applied blur: \(settings.defaultBlurRadius)px, darken: \(settings.defaultDarkenAmount)")
        
        return backgroundLayer
    }
    
    /// Process the background image with blur and scaling
    /// PHASE 2: Enhanced with video analysis for intelligent scaling
    private func createProcessedBackground(
        sourceImage: CIImage,
        videoAnalysis: VideoAnalysis,
        renderSize: CGSize,
        settings: SmartFillSettings
    ) throws -> CIImage {
        
        let sourceSize = sourceImage.extent.size
        print("🔧 SmartFillCompositor: Processing background - source: \(sourceSize) → render: \(renderSize)")
        
        // HANDOFF FIX #2: Center the background and fill the canvas properly
        let scaleX = renderSize.width / sourceSize.width
        let scaleY = renderSize.height / sourceSize.height
        let baseScale = max(scaleX, scaleY) // Use max to ensure complete fill
        
        // HANDOFF FIX: Enhanced scaling with proper centering for background
        let enhancedScale = baseScale * settings.backgroundScale
        
        let scaledImage = sourceImage.transformed(by: CGAffineTransform(scaleX: enhancedScale, y: enhancedScale))
        
        // HANDOFF FIX #2: Center the scaled image properly (this fixes the "bottom of frame" issue)
        let scaledSize = CGSize(width: sourceSize.width * enhancedScale, height: sourceSize.height * enhancedScale)
        let offsetX = (renderSize.width - scaledSize.width) / 2
        let offsetY = (renderSize.height - scaledSize.height) / 2
        
        // CRITICAL: This centering transform ensures we get the CENTER of the image, not bottom
        let centeredImage = scaledImage.transformed(by: CGAffineTransform(translationX: offsetX, y: offsetY))
        
        // Crop to render size to ensure exact dimensions
        let croppedImage = centeredImage.cropped(to: CGRect(origin: .zero, size: renderSize))
        
        // PHASE 2: Enhanced blur with quality optimization
        guard let blurFilter = CIFilter(name: "CIGaussianBlur") else {
            throw SmartFillCompositorError.filterCreationFailed("CIGaussianBlur")
        }
        
        blurFilter.setValue(croppedImage, forKey: kCIInputImageKey)
        blurFilter.setValue(settings.defaultBlurRadius, forKey: kCIInputRadiusKey)
        
        guard let blurredImage = blurFilter.outputImage else {
            throw SmartFillCompositorError.filterProcessingFailed("Gaussian blur")
        }
        
        // PHASE 2: Professional color grading for background
        guard let colorFilter = CIFilter(name: "CIColorControls") else {
            throw SmartFillCompositorError.filterCreationFailed("CIColorControls")
        }
        
        colorFilter.setValue(blurredImage, forKey: kCIInputImageKey)
        colorFilter.setValue(-settings.defaultDarkenAmount, forKey: kCIInputBrightnessKey)
        colorFilter.setValue(0.7, forKey: kCIInputSaturationKey) // Professional desaturation
        colorFilter.setValue(1.1, forKey: kCIInputContrastKey) // Subtle contrast boost
        
        guard let finalImage = colorFilter.outputImage else {
            throw SmartFillCompositorError.filterProcessingFailed("Color controls")
        }
        
        // Final crop to ensure exact render size
        let finalCropped = finalImage.cropped(to: CGRect(origin: .zero, size: renderSize))
        
        print("✅ SmartFillCompositor: HANDOFF FIX - Processed background with centered positioning")
        print("   📐 Enhanced scale: \(enhancedScale) (base: \(baseScale), setting: \(settings.backgroundScale))")
        print("   📐 Center offset: (\(offsetX), \(offsetY)) - this fixes the 'bottom of frame' issue")
        
        return finalCropped
    }
}

// MARK: - Phase 2: Video Analysis Data Structure

/// PHASE 2: Video analysis results for intelligent processing
private struct VideoAnalysis {
    let naturalSize: CGSize
    let displaySize: CGSize
    let preferredTransform: CGAffineTransform
    let nominalFrameRate: Float
    let isPortrait: Bool
}

// MARK: - Error Handling

public enum SmartFillCompositorError: LocalizedError {
    case filterCreationFailed(String)
    case filterProcessingFailed(String)
    case frameExtractionFailed
    case invalidAsset
    
    public var errorDescription: String? {
        switch self {
        case .filterCreationFailed(let filterName):
            return "Failed to create filter: \(filterName)"
        case .filterProcessingFailed(let operation):
            return "Filter processing failed: \(operation)"
        case .frameExtractionFailed:
            return "Failed to extract frame from video"
        case .invalidAsset:
            return "Invalid video asset"
        }
    }
}

// MARK: - Integration Extensions

public extension SmartFillCompositor {
    
    /// Convenience method for STS integration
    /// Creates SmartFill composition for a single video file
    /// 🚨 WARNING: This creates EXPORT-ONLY compositions - do NOT use with AVPlayerItem
    static func createSmartFillComposition(
        for videoURL: URL,
        renderSize: CGSize = CGSize.zero, // HANDOFF FIX: Ignored, determined by orientation
        settings: SmartFillSettings = SmartFillSettings()
    ) async throws -> AVVideoComposition {
        
        print("⚠️  SmartFillCompositor: Creating EXPORT-ONLY composition")
        print("   🚨 WARNING: Do NOT use this with AVPlayerItem - will crash")
        print("   📤 For export operations only")
        print("   🎥 For preview operations, use SmartFillPreviewCompositor instead")
        print("   📐 HANDOFF: Render size determined by video orientation (ignoring passed parameter)")
        
        let asset = AVURLAsset(url: videoURL)
        let compositor = SmartFillCompositor()
        
        return try await compositor.createVideoComposition(
            for: asset,
            renderSize: CGSize.zero, // Will be determined by orientation
            settings: settings
        )
    }
    
    /// 🚨 SAFETY CHECK: Prevent accidental use with AVPlayerItem
    /// This method will throw an error if someone tries to use export composition for preview
    static func validateCompositionUsage(
        composition: AVVideoComposition,
        intendedFor purpose: CompositionPurpose
    ) throws {
        
        if composition.animationTool != nil && purpose == .preview {
            print("🚨 CRITICAL ERROR: Trying to use EXPORT-ONLY composition for preview")
            print("   💥 This will cause AVVideoCompositionCoreAnimationTool crash")
            print("   🔧 Use SmartFillPreviewCompositor.createPreviewVideoComposition() instead")
            
            throw SmartFillCompositorError.invalidAsset
        }
        
        print("✅ SmartFillCompositor: Composition usage validated for \(purpose)")
    }
    
    enum CompositionPurpose {
        case preview
        case export
        
        var description: String {
            switch self {
            case .preview: return "preview (AVPlayerItem)"
            case .export: return "export (AVAssetExportSession)"
            }
        }
    }
}

#if DEBUG
// MARK: - Debug Extensions

private extension SmartFillCompositor {
    func logPerformance(_ operation: String, startTime: CFAbsoluteTime) {
        let duration = CFAbsoluteTime(CACurrentMediaTime()) - startTime
        if duration > 0.1 {
            print("⏱️ SmartFillCompositor: \(operation) took \(String(format: "%.3f", duration))s")
        }
    }
}
#endif
