import AVFoundation
import UIKit

// MARK: - Phase 4: Supporting Types (moved to top for visibility)

public enum CompositorChoice {
    case legacyCompositor
    case newCompositor
    
    var displayName: String {
        switch self {
        case .legacyCompositor: return "Legacy Frame Processing"
        case .newCompositor: return "Industry-Standard Compositor"
        }
    }
}

private struct DeviceCapability {
    let supportsNewCompositor: Bool
    let hasMetalSupport: Bool
    let availableMemoryGB: Double
    let iosVersion: String
}

private struct ReliabilityScore {
    let legacy: Double
    let newCompositor: Double
}

/// PHASE 4: Migration manager for transitioning from old to new SmartFill system
/// Provides A/B testing, smart routing, and gradual rollout capabilities
public final class SmartFillMigrationManager {
    
    // MARK: - Singleton
    public static let shared = SmartFillMigrationManager()
    private init() {
        loadMigrationSettings()
    }
    
    // MARK: - Migration Configuration
    
    /// Migration strategy for different scenarios
    public enum MigrationStrategy {
        case legacyOnly          // Use old system only (safe fallback)
        case newOnly             // Use new system only (full migration)
        case smartRouting        // Automatically choose based on video analysis
        case aBTesting           // Randomly assign for comparison
        case userChoice          // Let user choose via settings
    }
    
    /// Migration status tracking
    public struct MigrationStats {
        var totalProcessed: Int = 0
        var legacySuccess: Int = 0
        var legacyFailures: Int = 0
        var newSuccess: Int = 0
        var newFailures: Int = 0
        var averageLegacyTime: TimeInterval = 0
        var averageNewTime: TimeInterval = 0
        
        var legacySuccessRate: Double {
            guard totalProcessed > 0 else { return 0 }
            return Double(legacySuccess) / Double(legacySuccess + legacyFailures)
        }
        
        var newSuccessRate: Double {
            guard totalProcessed > 0 else { return 0 }
            return Double(newSuccess) / Double(newSuccess + newFailures)
        }
        
        var performanceRatio: Double {
            guard averageLegacyTime > 0 else { return 1.0 }
            return averageLegacyTime / averageNewTime
        }
    }
    
    // MARK: - Properties
    
    @UserDefaultsBacked("smartFillMigrationStrategy", defaultValue: MigrationStrategy.newOnly)
    private var migrationStrategy: MigrationStrategy
    
    @UserDefaultsBacked("smartFillMigrationStats", defaultValue: MigrationStats())
    private var stats: MigrationStats
    
    @UserDefaultsBacked("smartFillMigrationRolloutPercentage", defaultValue: 100)
    private var rolloutPercentage: Int // 🔥 CRITICAL FIX: 100% rollout for new system
    
    private let performanceMonitor = SmartFillPerformanceMonitor()
    
    // MARK: - Phase 4: Smart Routing Logic
    
    /// PHASE 4: Intelligently choose which system to use based on multiple factors
    public func shouldUseNewCompositor(
        for videoURL: URL,
        settings: SmartFillSettings,
        userPreference: Bool? = nil
    ) async -> CompositorChoice {
        
        print("🧠 SmartFillMigrationManager: Analyzing routing decision")
        
        // PHASE 4: Honor explicit user choice first
        if let userChoice = userPreference {
            let choice: CompositorChoice = userChoice ? .newCompositor : .legacyCompositor
            print("   👤 User explicit choice: \(choice)")
            return choice
        }
        
        // PHASE 4: Handle different migration strategies
        switch migrationStrategy {
            
        case .legacyOnly:
            print("   🔒 Strategy: Legacy only")
            return .legacyCompositor
            
        case .newOnly:
            print("   🚀 Strategy: New only")
            return .newCompositor
            
        case .smartRouting:
            return await performSmartRouting(for: videoURL, settings: settings)
            
        case .aBTesting:
            return performABTesting()
            
        case .userChoice:
            // Fall back to settings preference
            let choice: CompositorChoice = settings.useNewCompositor ? .newCompositor : .legacyCompositor
            print("   ⚙️ Strategy: User choice from settings - \(choice)")
            return choice
        }
    }
    
    /// PHASE 4: Smart routing based on video analysis and system capabilities
    private func performSmartRouting(
        for videoURL: URL,
        settings: SmartFillSettings
    ) async -> CompositorChoice {
        
        print("🎯 SmartFillMigrationManager: Performing smart routing analysis")
        
        // PHASE 4: Check if video is suitable for new compositor
        let isPortrait = await SmartFillCompositorIntegration.shouldUseNewCompositor(for: videoURL)
        guard isPortrait else {
            print("   📐 Not portrait video, using legacy (no processing needed)")
            return .legacyCompositor
        }
        
        // PHASE 4: Check device capabilities
        let deviceCapability = analyzeDeviceCapability()
        guard deviceCapability.supportsNewCompositor else {
            print("   📱 Device doesn't support new compositor features, using legacy")
            return .legacyCompositor
        }
        
        // PHASE 4: Check system performance and reliability
        let reliability = calculateReliabilityScore()
        if reliability.newCompositor >= 0.85 && reliability.newCompositor >= reliability.legacy {
            print("   📊 New compositor reliability: \(reliability.newCompositor), choosing new")
            return .newCompositor
        }
        
        // PHASE 4: Gradual rollout - percentage of users get new system
        let rolloutDecision = Int.random(in: 1...100) <= rolloutPercentage
        let choice: CompositorChoice = rolloutDecision ? .newCompositor : .legacyCompositor
        print("   🎲 Rollout decision (\(rolloutPercentage)%): \(choice)")
        
        return choice
    }
    
    /// PHASE 4: A/B testing for comparison purposes
    private func performABTesting() -> CompositorChoice {
        let choice: CompositorChoice = Bool.random() ? .newCompositor : .legacyCompositor
        print("   🧪 A/B Testing: Randomly assigned \(choice)")
        return choice
    }
    
    // MARK: - Phase 4: Device and Performance Analysis
    
    /// PHASE 4: Analyze device capability for new compositor
    private func analyzeDeviceCapability() -> DeviceCapability {
        let device = UIDevice.current
        let processInfo = ProcessInfo.processInfo
        
        // PHASE 4: Check iOS version compatibility
        let supportsModernAVFoundation = processInfo.isOperatingSystemAtLeast(
            OperatingSystemVersion(majorVersion: 15, minorVersion: 0, patchVersion: 0)
        )
        
        // PHASE 4: Check memory availability (simplified check)
        let availableMemory = processInfo.physicalMemory
        let hasEnoughMemory = availableMemory >= 3 * 1024 * 1024 * 1024 // 3GB+
        
        // PHASE 4: Check Metal support
        let hasMetalSupport = MTLCreateSystemDefaultDevice() != nil
        
        let capability = DeviceCapability(
            supportsNewCompositor: supportsModernAVFoundation && hasEnoughMemory && hasMetalSupport,
            hasMetalSupport: hasMetalSupport,
            availableMemoryGB: Double(availableMemory) / (1024 * 1024 * 1024),
            iosVersion: processInfo.operatingSystemVersionString
        )
        
        print("📱 Device capability: Metal=\(hasMetalSupport), Memory=\(String(format: "%.1f", capability.availableMemoryGB))GB, Supports=\(capability.supportsNewCompositor)")
        
        return capability
    }
    
    /// PHASE 4: Calculate reliability scores for both systems
    private func calculateReliabilityScore() -> ReliabilityScore {
        let legacy = stats.legacySuccessRate
        let new = stats.newSuccessRate
        
        return ReliabilityScore(legacy: legacy, newCompositor: new)
    }
    
    // MARK: - Phase 4: Performance Monitoring
    
    /// PHASE 4: Track processing performance and outcomes
    public func trackProcessingResult(
        compositor: CompositorChoice,
        success: Bool,
        processingTime: TimeInterval,
        videoURL: URL
    ) {
        stats.totalProcessed += 1
        
        switch compositor {
        case .legacyCompositor:
            if success {
                stats.legacySuccess += 1
                stats.averageLegacyTime = updateAverageTime(
                    current: stats.averageLegacyTime,
                    new: processingTime,
                    count: stats.legacySuccess
                )
            } else {
                stats.legacyFailures += 1
            }
            
        case .newCompositor:
            if success {
                stats.newSuccess += 1
                stats.averageNewTime = updateAverageTime(
                    current: stats.averageNewTime,
                    new: processingTime,
                    count: stats.newSuccess
                )
            } else {
                stats.newFailures += 1
            }
        }
        
        // Save updated stats
        saveMigrationSettings()
        
        print("📊 SmartFillMigrationManager: Updated stats - Legacy: \(String(format: "%.1f%%", stats.legacySuccessRate * 100)), New: \(String(format: "%.1f%%", stats.newSuccessRate * 100))")
    }
    
    private func updateAverageTime(current: TimeInterval, new: TimeInterval, count: Int) -> TimeInterval {
        guard count > 1 else { return new }
        return (current * Double(count - 1) + new) / Double(count)
    }
    
    // MARK: - Phase 4: Migration Configuration
    
    public func setMigrationStrategy(_ strategy: MigrationStrategy) {
        migrationStrategy = strategy
        saveMigrationSettings()
        print("⚙️ SmartFillMigrationManager: Set migration strategy to \(strategy)")
    }
    
    public func setRolloutPercentage(_ percentage: Int) {
        rolloutPercentage = max(0, min(100, percentage))
        saveMigrationSettings()
        print("📊 SmartFillMigrationManager: Set rollout percentage to \(rolloutPercentage)%")
    }
    
    public func getMigrationStats() -> MigrationStats {
        return stats
    }
    
    public func resetMigrationStats() {
        stats = MigrationStats()
        saveMigrationSettings()
        print("🔄 SmartFillMigrationManager: Reset migration stats")
    }
    
    // MARK: - Private Helpers
    
    private func loadMigrationSettings() {
        // Settings are automatically loaded via @UserDefaultsBacked
        print("📂 SmartFillMigrationManager: Loaded migration settings")
        print("   Strategy: \(migrationStrategy)")
        print("   Rollout: \(rolloutPercentage)%")
        print("   Total processed: \(stats.totalProcessed)")
    }
    
    private func saveMigrationSettings() {
        // Settings are automatically saved via @UserDefaultsBacked
        UserDefaults.standard.synchronize()
    }
}

// MARK: - Phase 4: Performance Monitor

private class SmartFillPerformanceMonitor {
    private var startTimes: [String: CFAbsoluteTime] = [:]
    
    func startTracking(for identifier: String) {
        startTimes[identifier] = CFAbsoluteTime(CACurrentMediaTime())
    }
    
    func endTracking(for identifier: String) -> TimeInterval {
        guard let startTime = startTimes.removeValue(forKey: identifier) else { return 0 }
        return CFAbsoluteTime(CACurrentMediaTime()) - startTime
    }
}

// MARK: - Phase 4: UserDefaults Property Wrapper

@propertyWrapper
private struct UserDefaultsBacked<T: Codable> {
    let key: String
    let defaultValue: T
    
    init(_ key: String, defaultValue: T) {
        self.key = key
        self.defaultValue = defaultValue
    }
    
    var wrappedValue: T {
        get {
            guard let data = UserDefaults.standard.data(forKey: key) else { return defaultValue }
            return (try? JSONDecoder().decode(T.self, from: data)) ?? defaultValue
        }
        set {
            let data = try? JSONEncoder().encode(newValue)
            UserDefaults.standard.set(data, forKey: key)
        }
    }
}

// MARK: - Phase 4: Extensions for Codable Support

extension SmartFillMigrationManager.MigrationStrategy: Codable {}
extension SmartFillMigrationManager.MigrationStats: Codable {}

#if DEBUG
// MARK: - Phase 4: Debug Extensions

public extension SmartFillMigrationManager {
    
    /// Debug method to simulate different scenarios
    func simulateMigrationScenario(_ scenario: String) {
        switch scenario {
        case "high_success_new":
            for _ in 0..<10 {
                trackProcessingResult(compositor: .newCompositor, success: true, processingTime: 2.5, videoURL: URL(fileURLWithPath: "test"))
            }
        case "mixed_results":
            for i in 0..<10 {
                let success = i % 3 != 0  // 70% success rate
                let compositor: CompositorChoice = i % 2 == 0 ? .newCompositor : .legacyCompositor
                trackProcessingResult(compositor: compositor, success: success, processingTime: Double.random(in: 1.5...4.0), videoURL: URL(fileURLWithPath: "test"))
            }
        default:
            print("Unknown scenario: \(scenario)")
        }
    }
    
    /// Debug method to print current status
    func printDebugStatus() {
        let stats = getMigrationStats()
        print("""
        📊 MIGRATION DEBUG STATUS:
        Strategy: \(migrationStrategy)
        Rollout: \(rolloutPercentage)%
        
        LEGACY SYSTEM:
        Success Rate: \(String(format: "%.1f%%", stats.legacySuccessRate * 100))
        Avg Time: \(String(format: "%.2fs", stats.averageLegacyTime))
        Count: \(stats.legacySuccess)/\(stats.legacySuccess + stats.legacyFailures)
        
        NEW SYSTEM:
        Success Rate: \(String(format: "%.1f%%", stats.newSuccessRate * 100))
        Avg Time: \(String(format: "%.2fs", stats.averageNewTime))
        Count: \(stats.newSuccess)/\(stats.newSuccess + stats.newFailures)
        
        PERFORMANCE RATIO: \(String(format: "%.2fx", stats.performanceRatio))
        """)
    }
}
#endif
