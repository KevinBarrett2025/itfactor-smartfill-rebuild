import AVFoundation
import UIKit

/// Integration layer for the new SmartFillCompositor
/// PHASE 2: Enhanced with professional video composition integration
public final class SmartFillCompositorIntegration {
    
    // MARK: - Phase 2: Enhanced Public API
    
    /// PHASE 2: Enhanced compositor test with professional video analysis
    public static func testNewCompositor(
        inputVideoURL: URL,
        outputVideoURL: URL,
        settings: SmartFillSettings = SmartFillSettings()
    ) async throws -> Bool {
        
        print("🧪 SmartFillCompositorIntegration: Testing Phase 2 enhanced compositor")
        
        let asset = AVURLAsset(url: inputVideoURL)
        
        // PHASE 2: Pre-analyze video for intelligent processing
        let shouldProcess = await shouldUseNewCompositor(for: inputVideoURL)
        guard shouldProcess else {
            print("⚠️ Video doesn't need SmartFill processing (already landscape)")
            return false
        }
        
        // STEP 1: Create the new industry-standard composition with Phase 2 enhancements
        let compositor = SmartFillCompositor()
        let videoComposition = try await compositor.createVideoComposition(
            for: asset,
            renderSize: settings.defaultRenderSize,
            settings: settings
        )
        
        // STEP 2: Create professional export session
        guard let exportSession = AVAssetExportSession(
            asset: asset,
            presetName: AVAssetExportPresetHighestQuality
        ) else {
            throw SmartFillCompositorError.invalidAsset
        }
        
        // CRITICAL FIX: Remove existing file if it exists to prevent "file already in use" error
        if FileManager.default.fileExists(atPath: outputVideoURL.path) {
            try? FileManager.default.removeItem(at: outputVideoURL)
            print("🗑️ Removed existing file: \(outputVideoURL.lastPathComponent)")
        }
        
        exportSession.outputURL = outputVideoURL
        exportSession.outputFileType = .mov
        exportSession.videoComposition = videoComposition
        
        // PHASE 2: Enhanced export settings for professional quality
        exportSession.shouldOptimizeForNetworkUse = true
        exportSession.metadata = createProfessionalMetadata()
        
        // STEP 3: Perform the export with progress tracking
        return try await withCheckedThrowingContinuation { continuation in
            exportSession.exportAsynchronously {
                switch exportSession.status {
                case .completed:
                    print("✅ SmartFillCompositorIntegration: Phase 2 compositor test SUCCESSFUL")
                    print("   📊 Export progress: 100%")
                    continuation.resume(returning: true)
                case .failed:
                    let error = exportSession.error ?? SmartFillCompositorError.filterProcessingFailed("Export failed")
                    print("❌ SmartFillCompositorIntegration: Phase 2 compositor test FAILED: \(error)")
                    continuation.resume(throwing: error)
                case .cancelled:
                    print("⚠️ SmartFillCompositorIntegration: Export cancelled")
                    continuation.resume(throwing: SmartFillCompositorError.filterProcessingFailed("Export cancelled"))
                default:
                    print("⚠️ SmartFillCompositorIntegration: Export ended with status: \(exportSession.status)")
                    continuation.resume(throwing: SmartFillCompositorError.filterProcessingFailed("Export ended unexpectedly"))
                }
            }
        }
    }
    
    /// PHASE 2: Enhanced preview player with professional composition
    /// 🚨 CRITICAL FIX: Added modal-friendly parameter to solve KVO timeout crisis
    public static func createPreviewPlayer(
        for videoURL: URL,
        settings: SmartFillSettings = SmartFillSettings(),
        modalFriendly: Bool = false
    ) async throws -> AVPlayer {
        
        print("🎬 SmartFillCompositorIntegration: Creating SAFE preview player (no crash risk)")
        print("   🔧 Modal-friendly mode: \(modalFriendly)")
        
        // 🚨 CRITICAL FIX: Use PREVIEW-COMPATIBLE compositor instead of export compositor
        // This prevents the AVVideoCompositionCoreAnimationTool crash
        let asset = AVURLAsset(url: videoURL)
        
        // Check if this video actually needs SmartFill processing
        let shouldProcess = await shouldUseNewCompositor(for: videoURL)
        
        if shouldProcess && settings.useNewCompositor {
            print("   🎨 Using SmartFill preview compositor (SAFE for AVPlayerItem)")
            
            // 🚨 CRITICAL: Use SmartFillPreviewCompositor (NOT SmartFillCompositor)
            let previewCompositor = SmartFillPreviewCompositor()
            let videoComposition = try await previewCompositor.createPreviewVideoComposition(
                for: asset,
                renderSize: settings.defaultRenderSize,
                settings: settings
            )
            
            let playerItem = AVPlayerItem(asset: asset)
            playerItem.videoComposition = videoComposition
            
            let player = AVPlayer(playerItem: playerItem)
            
            // Configure for modal context if needed
            if modalFriendly {
                player.automaticallyWaitsToMinimizeStalling = false
                print("   🔧 Optimized for modal presentation")
            } else {
                player.automaticallyWaitsToMinimizeStalling = true
            }
            
            print("✅ SmartFillCompositorIntegration: Created SAFE preview player with SmartFill effect")
            print("   🔒 Uses SmartFillPreviewCompositor (AVPlayerItem compatible)")
            print("   🎬 No AVVideoCompositionCoreAnimationTool (no crash risk)")
            
            return player
        } else {
            print("   📺 Creating standard player (no SmartFill needed)")
            
            // Standard player for videos that don't need SmartFill
            let playerItem = AVPlayerItem(asset: asset)
            let player = AVPlayer(playerItem: playerItem)
            
            if modalFriendly {
                player.automaticallyWaitsToMinimizeStalling = false
            }
            
            return player
        }
    }
    
    // 🚨 REMOVED: Old modal-friendly methods that used unsafe compositor
    // All preview operations now use SmartFillPreviewCompositor
    
    // MARK: - Phase 2: Enhanced Analysis and Routing
    
    /// PHASE 2: Enhanced video analysis for intelligent processing decisions
    public static func shouldUseNewCompositor(for videoURL: URL) async -> Bool {
        do {
            let asset = AVURLAsset(url: videoURL)
            let tracks = try await asset.loadTracks(withMediaType: .video)
            
            guard let track = tracks.first else { return false }
            
            let naturalSize = try await track.load(.naturalSize)
            let preferredTransform = try await track.load(.preferredTransform)
            let nominalFrameRate = try await track.load(.nominalFrameRate)
            
            // PHASE 2: Professional video analysis
            let transformedSize = naturalSize.applying(preferredTransform)
            let displayWidth = abs(transformedSize.width)
            let displayHeight = abs(transformedSize.height)
            
            let isPortrait = displayHeight > displayWidth
            let hasReasonableFrameRate = nominalFrameRate > 15 && nominalFrameRate <= 120
            let hasReasonableSize = displayWidth >= 480 && displayHeight >= 640
            
            print("🔍 SmartFillCompositorIntegration: Enhanced video analysis:")
            print("   📐 Natural: \(naturalSize), Display: \(displayWidth)x\(displayHeight)")
            print("   🎬 Frame rate: \(nominalFrameRate)fps, Portrait: \(isPortrait)")
            print("   ✅ Suitable for processing: \(isPortrait && hasReasonableFrameRate && hasReasonableSize)")
            
            return isPortrait && hasReasonableFrameRate && hasReasonableSize
            
        } catch {
            print("❌ SmartFillCompositorIntegration: Error analyzing video: \(error)")
            return false
        }
    }
    
    /// PHASE 2: Professional metadata for exported videos
    private static func createProfessionalMetadata() -> [AVMetadataItem] {
        let creationDate = AVMutableMetadataItem()
        creationDate.identifier = .commonIdentifierCreationDate
        creationDate.value = Date() as NSDate
        
        let software = AVMutableMetadataItem()
        software.identifier = .commonIdentifierSoftware
        software.value = "SelfTapeStudio SmartFill v2.0" as NSString
        
        let description = AVMutableMetadataItem()
        description.identifier = .commonIdentifierDescription
        description.value = "Portrait video optimized for landscape viewing with SmartFill technology" as NSString
        
        return [creationDate, software, description]
    }
    
    // MARK: - Phase 2: Professional Export Integration
    
    /// PHASE 2: Integration point for existing export pipeline
    public static func enhanceExistingExport(
        asset: AVAsset,
        renderSize: CGSize,
        settings: SmartFillSettings
    ) async throws -> AVVideoComposition? {
        
        // Only enhance if it's a portrait video
        let videoURL = (asset as? AVURLAsset)?.url ?? URL(fileURLWithPath: "unknown")
        let shouldEnhance = await shouldUseNewCompositor(for: videoURL)
        
        guard shouldEnhance else {
            print("🔄 SmartFillCompositorIntegration: Video doesn't need enhancement, using standard export")
            return nil
        }
        
        print("🚀 SmartFillCompositorIntegration: Enhancing export with Phase 2 compositor")
        
        let compositor = SmartFillCompositor()
        return try await compositor.createVideoComposition(
            for: asset,
            renderSize: renderSize,
            settings: settings
        )
    }
}

// MARK: - Phase 2: Development/Testing Extensions

#if DEBUG
public extension SmartFillCompositorIntegration {
    
    /// PHASE 2: Enhanced comparison with detailed analysis
    static func compareOldVsNew(
        inputVideoURL: URL,
        settings: SmartFillSettings = SmartFillSettings()
    ) async throws -> (analysis: VideoComparisonAnalysis, newOutputURL: URL) {
        
        let tempDir = FileManager.default.temporaryDirectory
        let newOutputURL = tempDir.appendingPathComponent("smartfill_phase2_\(UUID().uuidString).mov")
        
        print("🔬 SmartFillCompositorIntegration: Phase 2 enhanced comparison analysis")
        
        // Pre-analysis
        let startTime = CFAbsoluteTime(CACurrentMediaTime())
        let shouldProcess = await shouldUseNewCompositor(for: inputVideoURL)
        
        // Test new compositor
        let newSuccess = try await testNewCompositor(
            inputVideoURL: inputVideoURL,
            outputVideoURL: newOutputURL,
            settings: settings
        )
        
        let processingTime = CFAbsoluteTime(CACurrentMediaTime()) - startTime
        
        let analysis = VideoComparisonAnalysis(
            inputURL: inputVideoURL,
            newOutputURL: newOutputURL,
            shouldProcess: shouldProcess,
            newCompositorSuccess: newSuccess,
            processingTime: processingTime,
            settings: settings
        )
        
        print("✅ SmartFillCompositorIntegration: Phase 2 analysis complete")
        print("   ⏱️ Processing time: \(String(format: "%.2f", processingTime))s")
        print("   📁 New output: \(newOutputURL.lastPathComponent)")
        
        return (analysis: analysis, newOutputURL: newOutputURL)
    }
    
    /// PHASE 2: Detailed video comparison analysis
    struct VideoComparisonAnalysis {
        let inputURL: URL
        let newOutputURL: URL
        let shouldProcess: Bool
        let newCompositorSuccess: Bool
        let processingTime: TimeInterval
        let settings: SmartFillSettings
        
        var summary: String {
            return """
            📊 PHASE 2 VIDEO ANALYSIS:
            Input: \(inputURL.lastPathComponent)
            Should Process: \(shouldProcess)
            New Compositor: \(newCompositorSuccess ? "✅ SUCCESS" : "❌ FAILED")
            Processing Time: \(String(format: "%.2f", processingTime))s
            Settings: blur=\(settings.defaultBlurRadius), scale=\(settings.backgroundScale)x
            """
        }
    }
}
#endif
