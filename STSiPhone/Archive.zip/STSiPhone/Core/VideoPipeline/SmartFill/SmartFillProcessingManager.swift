import Foundation
import UIKit
import BackgroundTasks
import AVFoundation

// MARK: - SmartFill Processing Delegate

/// Delegate protocol for SmartFill processing completion callbacks
public protocol SmartFillProcessingDelegate: AnyObject {
    func smartFillDidFinish(takeID: UUID, outputURL: URL)
    func smartFillDidFail(takeID: UUID, error: Error)
}

/// SmartFill Background Processing Manager
/// Handles queued, throttled background processing of portrait videos with proper resource management
@MainActor
public final class SmartFillProcessingManager: ObservableObject {
    public static let shared = SmartFillProcessingManager()
    
    // MARK: - Delegate Support
    public weak var delegate: SmartFillProcessingDelegate?
    
    // MARK: - Job Management
    
    public struct SmartFillJob: Identifiable {
        public let id = UUID()
        public let originalPath: String
        public let outputPath: String
        public let fileName: String
        public let takeID: UUID
        public let sessionID: UUID
        public let projectID: UUID
        public let capturedOrientation: VideoOrientation?
        public let settings: SmartFillSettings
        public let createdAt: Date
        public var retryCount: Int = 0
        public var status: JobStatus = .pending
        public var lastError: Error?
        public var progress: Double = 0.0
        
        public enum JobStatus: String, CaseIterable {
            case pending = "pending"
            case processing = "processing"
            case completed = "completed"
            case failed = "failed"
            case paused = "paused"       // For battery/thermal throttling
            case cancelled = "cancelled"
            
            public var displayName: String {
                switch self {
                case .pending: return "Pending"
                case .processing: return "Processing"
                case .completed: return "Completed"
                case .failed: return "Failed"
                case .paused: return "Paused"
                case .cancelled: return "Cancelled"
                }
            }
            
            public var isActive: Bool {
                return self == .processing || self == .pending
            }
            
            public var isCompleted: Bool {
                return self == .completed || self == .failed || self == .cancelled
            }
        }
    }
    
    // MARK: - State Management
    
    @Published public private(set) var jobs: [SmartFillJob] = []
    @Published public private(set) var isProcessing: Bool = false
    @Published public private(set) var currentJob: SmartFillJob?
    @Published public private(set) var processingPaused: Bool = false
    
    // Resource monitoring
    @Published public private(set) var batteryLevel: Float = 1.0
    @Published public private(set) var thermalState: ProcessInfo.ThermalState = .nominal
    @Published public private(set) var isLowPowerModeEnabled: Bool = false
    
    // Configuration
    private let maxConcurrentJobs: Int = 1  // Serial processing to prevent resource conflicts
    private let maxRetryAttempts: Int = 3
    private let minBatteryLevel: Float = 0.20  // Don't process below 20% battery
    
    // Processing queue
    private let processingQueue = DispatchQueue(label: "com.selftapestudio.smartfill", qos: .utility)
    private var backgroundTask: UIBackgroundTaskIdentifier = .invalid
    
    // Notifications
    public static let jobStatusDidChange = Notification.Name("SmartFillJobStatusDidChange")
    public static let processingDidComplete = Notification.Name("SmartFillProcessingDidComplete")
    public static let processingWasPaused = Notification.Name("SmartFillProcessingWasPaused")
    public static let processingWasResumed = Notification.Name("SmartFillProcessingWasResumed")
    
    private init() {
        setupResourceMonitoring()
        setupBackgroundProcessing()
        
        print("✅ SmartFillProcessingManager: Initialized with queue-based background processing")
    }
    
    // MARK: - Public API
    
    /// Add a SmartFill job to the processing queue
    public func enqueueJob(
        originalPath: String,
        outputPath: String,
        fileName: String,
        takeID: UUID,
        sessionID: UUID,
        projectID: UUID,
        capturedOrientation: VideoOrientation?,
        settings: SmartFillSettings = SmartFillSettings()
    ) {
        // Validate that original file exists
        guard FileManager.default.fileExists(atPath: originalPath) else {
            print("❌ SmartFillProcessingManager: Original file doesn't exist: \(originalPath)")
            return
        }
        
        // Check if we already have a job for this file
        if jobs.contains(where: { $0.originalPath == originalPath && $0.status.isActive }) {
            print("⚠️ SmartFillProcessingManager: Job already exists for \(fileName)")
            return
        }
        
        let job = SmartFillJob(
            originalPath: originalPath,
            outputPath: outputPath,
            fileName: fileName,
            takeID: takeID,
            sessionID: sessionID,
            projectID: projectID,
            capturedOrientation: capturedOrientation,
            settings: settings,
            createdAt: Date()
        )
        
        jobs.append(job)
        
        print("📋 SmartFillProcessingManager: Enqueued job for \(fileName)")
        print("   📁 Input: \(originalPath)")
        print("   📁 Output: \(outputPath)")
        print("   📱 Orientation: \(capturedOrientation?.displayName ?? "Unknown")")
        print("   📊 Queue size: \(jobs.filter { $0.status.isActive }.count)")
        
        // Start processing if not already running
        if !isProcessing {
            startProcessing()
        }
    }
    
    /// Get active jobs for a specific session
    public func getActiveJobs(for sessionID: UUID) -> [SmartFillJob] {
        return jobs.filter { $0.sessionID == sessionID && $0.status.isActive }
    }
    
    /// Get completed jobs for a specific session
    public func getCompletedJobs(for sessionID: UUID) -> [SmartFillJob] {
        return jobs.filter { $0.sessionID == sessionID && $0.status.isCompleted }
    }
    
    /// Cancel all pending jobs for a session
    public func cancelJobs(for sessionID: UUID) {
        for index in jobs.indices {
            if jobs[index].sessionID == sessionID && jobs[index].status == .pending {
                jobs[index].status = .cancelled
            }
        }
        
        print("🚫 SmartFillProcessingManager: Cancelled pending jobs for session \(sessionID)")
    }
    
    /// Pause processing (useful for battery/thermal management)
    public func pauseProcessing() {
        processingPaused = true
        print("⏸️ SmartFillProcessingManager: Processing paused")
        
        NotificationCenter.default.post(name: Self.processingWasPaused, object: nil)
    }
    
    /// Resume processing
    public func resumeProcessing() {
        processingPaused = false
        print("▶️ SmartFillProcessingManager: Processing resumed")
        
        NotificationCenter.default.post(name: Self.processingWasResumed, object: nil)
        
        // Continue processing if we have pending jobs
        if !isProcessing && hasPendingJobs() {
            startProcessing()
        }
    }
    
    /// Force retry a failed job
    public func retryJob(jobID: UUID) {
        guard let index = jobs.firstIndex(where: { $0.id == jobID }),
              jobs[index].status == .failed else {
            print("⚠️ SmartFillProcessingManager: Cannot retry job \(jobID)")
            return
        }
        
        jobs[index].status = .pending
        jobs[index].retryCount = 0
        jobs[index].lastError = nil
        jobs[index].progress = 0.0
        
        print("🔄 SmartFillProcessingManager: Retrying job for \(jobs[index].fileName)")
        
        if !isProcessing {
            startProcessing()
        }
    }
    
    /// Get status summary for UI display
    public var statusSummary: (active: Int, pending: Int, processing: Int, failed: Int) {
        let active = jobs.filter { $0.status.isActive }.count
        let pending = jobs.filter { $0.status == .pending }.count
        let processing = jobs.filter { $0.status == .processing }.count
        let failed = jobs.filter { $0.status == .failed }.count
        
        return (active: active, pending: pending, processing: processing, failed: failed)
    }
    
    // MARK: - Resource Monitoring
    
    private func setupResourceMonitoring() {
        // Battery monitoring
        UIDevice.current.isBatteryMonitoringEnabled = true
        batteryLevel = UIDevice.current.batteryLevel
        
        NotificationCenter.default.addObserver(
            forName: UIDevice.batteryLevelDidChangeNotification,
            object: nil,
            queue: .main
        ) { [weak self] _ in
            self?.batteryLevel = UIDevice.current.batteryLevel
            self?.evaluateResourceConstraints()
        }
        
        // Low power mode monitoring
        isLowPowerModeEnabled = ProcessInfo.processInfo.isLowPowerModeEnabled
        
        NotificationCenter.default.addObserver(
            forName: .NSProcessInfoPowerStateDidChange,
            object: nil,
            queue: .main
        ) { [weak self] _ in
            self?.isLowPowerModeEnabled = ProcessInfo.processInfo.isLowPowerModeEnabled
            self?.evaluateResourceConstraints()
        }
        
        // Thermal state monitoring
        thermalState = ProcessInfo.processInfo.thermalState
        
        NotificationCenter.default.addObserver(
            forName: ProcessInfo.thermalStateDidChangeNotification,
            object: nil,
            queue: .main
        ) { [weak self] _ in
            self?.thermalState = ProcessInfo.processInfo.thermalState
            self?.evaluateResourceConstraints()
        }
        
        // App lifecycle monitoring
        NotificationCenter.default.addObserver(
            forName: UIApplication.willResignActiveNotification,
            object: nil,
            queue: .main
        ) { [weak self] _ in
            self?.handleAppWillResignActive()
        }
        
        NotificationCenter.default.addObserver(
            forName: UIApplication.didBecomeActiveNotification,
            object: nil,
            queue: .main
        ) { [weak self] _ in
            self?.handleAppDidBecomeActive()
        }
    }
    
    private func evaluateResourceConstraints() {
        let shouldPause = batteryLevel < minBatteryLevel ||
                         isLowPowerModeEnabled ||
                         thermalState == .critical ||
                         thermalState == .serious
        
        if shouldPause && !processingPaused {
            print("⚠️ SmartFillProcessingManager: Auto-pausing due to resource constraints")
            print("   🔋 Battery: \(Int(batteryLevel * 100))%")
            print("   🔋 Low Power Mode: \(isLowPowerModeEnabled)")
            print("   🌡️ Thermal State: \(thermalState)")
            pauseProcessing()
        } else if !shouldPause && processingPaused {
            print("✅ SmartFillProcessingManager: Resource constraints cleared, resuming")
            resumeProcessing()
        }
    }
    
    // MARK: - Background Processing
    
    private func setupBackgroundProcessing() {
        // Register background task identifier
        BGTaskScheduler.shared.register(
            forTaskWithIdentifier: "com.selftapestudio.smartfill",
            using: nil
        ) { task in
            self.handleBackgroundTask(task as! BGProcessingTask)
        }
    }
    
    private func handleBackgroundTask(_ task: BGProcessingTask) {
        print("🔄 SmartFillProcessingManager: Background task started")
        
        task.expirationHandler = {
            print("⏰ SmartFillProcessingManager: Background task expired")
            task.setTaskCompleted(success: false)
        }
        
        // Process in background
        Task {
            await self.processBackgroundJobs()
            task.setTaskCompleted(success: true)
        }
    }
    
    private func handleAppWillResignActive() {
        // Request background processing time
        if hasPendingJobs() {
            scheduleBackgroundProcessing()
        }
    }
    
    private func handleAppDidBecomeActive() {
        // Resume foreground processing if needed
        if !isProcessing && hasPendingJobs() && !processingPaused {
            startProcessing()
        }
    }
    
    private func scheduleBackgroundProcessing() {
        let request = BGProcessingTaskRequest(identifier: "com.selftapestudio.smartfill")
        request.requiresNetworkConnectivity = false
        request.requiresExternalPower = false
        request.earliestBeginDate = Date(timeIntervalSinceNow: 5) // Start after 5 seconds
        
        do {
            try BGTaskScheduler.shared.submit(request)
            print("📋 SmartFillProcessingManager: Background processing scheduled")
        } catch {
            print("❌ SmartFillProcessingManager: Failed to schedule background processing: \(error)")
        }
    }
    
    // MARK: - Processing Logic
    
    private func startProcessing() {
        guard !isProcessing, !processingPaused else { return }
        
        isProcessing = true
        
        Task {
            await processJobs()
        }
    }
    
    private func processJobs() async {
        print("🎬 SmartFillProcessingManager: Starting job processing")
        
        while let jobIndex = getNextJobIndex() {
            guard !processingPaused else {
                print("⏸️ SmartFillProcessingManager: Processing paused, stopping")
                break
            }
            
            await processJob(at: jobIndex)
        }
        
        await MainActor.run {
            self.isProcessing = false
            self.currentJob = nil
            print("✅ SmartFillProcessingManager: Job processing completed")
        }
    }
    
    private func processBackgroundJobs() async {
        print("🌙 SmartFillProcessingManager: Processing background jobs")
        
        // Process only the most important jobs in background
        let priorityJobs = jobs.enumerated().filter { (_, job) in
            job.status == .pending && job.retryCount == 0 // Only first-time jobs in background
        }.prefix(3) // Limit to 3 jobs in background
        
        for (index, _) in priorityJobs {
            await processJob(at: index)
        }
    }
    
    private func getNextJobIndex() -> Int? {
        return jobs.firstIndex { $0.status == .pending }
    }
    
    private func processJob(at index: Int) async {
        var job = jobs[index]
        
        await MainActor.run {
            job.status = .processing
            job.progress = 0.0
            self.jobs[index] = job
            self.currentJob = job
        }
        
        print("🎯 SmartFillProcessingManager: Processing \(job.fileName)")
        print("   📁 Input: \(job.originalPath)")
        print("   📁 Output: \(job.outputPath)")
        print("   🔄 Retry count: \(job.retryCount)")
        
        do {
            // 🔥 CRITICAL FIX: Comprehensive input validation with better error messages
            guard FileManager.default.fileExists(atPath: job.originalPath) else {
                throw SmartFillProcessingError.inputFileNotFound
            }
            
            // SAFETY CHECK: Ensure output path is different from input path to prevent overwriting
            guard job.outputPath != job.originalPath else {
                throw SmartFillProcessingError.processingFailed("Output path cannot be the same as input path - would overwrite original!")
            }
            
            // SAFETY CHECK: Validate input file size is reasonable
            if let attributes = try? FileManager.default.attributesOfItem(atPath: job.originalPath),
               let fileSize = attributes[.size] as? Int64 {
                guard fileSize > 1024 * 1024 else { // At least 1MB for video files
                    throw SmartFillProcessingError.processingFailed("Input file too small to be a valid video (\(fileSize) bytes)")
                }
                guard fileSize < 10 * 1024 * 1024 * 1024 else { // Max 10GB for processing
                    throw SmartFillProcessingError.processingFailed("Input file too large for processing (\(String(format: "%.1fGB", Double(fileSize) / 1024 / 1024 / 1024)))")
                }
                print("📊 Input file size: \(String(format: "%.2f MB", Double(fileSize) / 1024 / 1024))")
            }
            
            // 🔥 ENHANCED SAFETY CHECK: Comprehensive video validation to prevent AVFoundation crashes
            let inputURL = URL(fileURLWithPath: job.originalPath)
            let validationAsset = AVURLAsset(url: inputURL)
            
            // Load tracks asynchronously to prevent blocking
            let videoTracks = try await validationAsset.loadTracks(withMediaType: .video)
            guard !videoTracks.isEmpty else {
                throw SmartFillProcessingError.processingFailed("No video tracks found in input file")
            }
            
            let duration = try await validationAsset.load(.duration)
            let durationSeconds = CMTimeGetSeconds(duration)
            guard durationSeconds.isFinite && durationSeconds > 0 else {
                throw SmartFillProcessingError.processingFailed("Invalid video duration: \(durationSeconds)")
            }
            
            // Don't process extremely long videos that could cause memory issues
            guard durationSeconds <= 600 else { // Max 10 minutes
                throw SmartFillProcessingError.processingFailed("Video too long for SmartFill processing (\(Int(durationSeconds)) seconds)")
            }
            
            print("✅ Input validation passed: \(String(format: "%.1f", durationSeconds))s duration")
            
            // Check if we need SmartFill processing
            guard job.capturedOrientation == .portrait else {
                throw SmartFillProcessingError.notPortraitVideo
            }
            
            // 🔥 CRITICAL FIX: Validate settings before processing to prevent filter crashes
            guard job.settings.defaultBlurRadius >= 0 && job.settings.defaultBlurRadius <= 100 else {
                throw SmartFillProcessingError.processingFailed("Invalid blur radius: \(job.settings.defaultBlurRadius)")
            }
            
            guard job.settings.defaultDarkenAmount >= 0 && job.settings.defaultDarkenAmount <= 1.0 else {
                throw SmartFillProcessingError.processingFailed("Invalid darken amount: \(job.settings.defaultDarkenAmount)")
            }
            
            guard job.settings.backgroundScale >= 1.0 && job.settings.backgroundScale <= 20.0 else {
                throw SmartFillProcessingError.processingFailed("Invalid background scale: \(job.settings.backgroundScale)")
            }
            
            guard job.settings.defaultRenderSize.width >= 480 && job.settings.defaultRenderSize.height >= 270 else {
                throw SmartFillProcessingError.processingFailed("Render size too small: \(job.settings.defaultRenderSize)")
            }
            
            guard job.settings.defaultRenderSize.width <= 4320 && job.settings.defaultRenderSize.height <= 2160 else {
                throw SmartFillProcessingError.processingFailed("Render size too large: \(job.settings.defaultRenderSize)")
            }
            
            print("✅ Settings validation passed: Blur=\(job.settings.defaultBlurRadius), Scale=\(job.settings.backgroundScale)")
            
            // SAFETY CHECK: Create output directory if needed (but ensure it's not the input directory)
            let outputURL = URL(fileURLWithPath: job.outputPath)
            let outputDirectory = outputURL.deletingLastPathComponent()
            let inputDirectory = URL(fileURLWithPath: job.originalPath).deletingLastPathComponent()
            
            // Ensure we're not creating files in the same directory without proper naming
            if outputDirectory.path == inputDirectory.path {
                let inputName = URL(fileURLWithPath: job.originalPath).deletingPathExtension().lastPathComponent
                let outputName = outputURL.deletingPathExtension().lastPathComponent
                guard outputName != inputName else {
                    throw SmartFillProcessingError.processingFailed("Output filename too similar to input - risk of overwriting")
                }
            }
            
            // Create output directory safely
            try FileManager.default.createDirectory(at: outputDirectory, withIntermediateDirectories: true)
            
            // 🔥 CRITICAL FIX: Test write permissions before processing
            let testFile = outputDirectory.appendingPathComponent("smartfill_test.tmp")
            do {
                try "test".write(to: testFile, atomically: true, encoding: .utf8)
                try FileManager.default.removeItem(at: testFile)
            } catch {
                throw SmartFillProcessingError.processingFailed("Cannot write to output directory: \(error.localizedDescription)")
            }
            
            // Update progress
            await MainActor.run {
                self.jobs[index].progress = 0.1
            }
            
            print("🎬 Starting SmartFill export with validated inputs and settings...")
            
            // 🔥 CRITICAL FIX: Wrap SmartFill processing in comprehensive error handling
            let wasProcessed: Bool
            do {
                wasProcessed = try await SmartFillExporter.processPortraitVideoFile(
                    inputPath: job.originalPath,
                    outputPath: job.outputPath,
                    settings: job.settings
                )
            } catch {
                // Clean up any partial output immediately
                if FileManager.default.fileExists(atPath: job.outputPath) {
                    try? FileManager.default.removeItem(atPath: job.outputPath)
                }
                throw SmartFillProcessingError.processingFailed("SmartFill export failed: \(error.localizedDescription)")
            }
            
            if wasProcessed {
                // 🔥 CRITICAL FIX: Comprehensive output validation
                guard FileManager.default.fileExists(atPath: job.outputPath) else {
                    throw SmartFillProcessingError.outputFileNotCreated
                }
                
                // ENHANCED: Validate output file size is reasonable
                let outputAttributes = try FileManager.default.attributesOfItem(atPath: job.outputPath)
                let outputSize = outputAttributes[.size] as? Int64 ?? 0
                
                // Output should be reasonably sized
                guard outputSize > 100 * 1024 else { // At least 100KB
                    try? FileManager.default.removeItem(atPath: job.outputPath)
                    throw SmartFillProcessingError.processingFailed("Output file too small (\(outputSize) bytes), likely corrupt")
                }
                
                // 🔥 ENHANCED: Comprehensive video validation to ensure output is playable
                let outputURL = URL(fileURLWithPath: job.outputPath)
                let outputAsset = AVURLAsset(url: outputURL)
                
                do {
                    let outputVideoTracks = try await outputAsset.loadTracks(withMediaType: .video)
                    guard !outputVideoTracks.isEmpty else {
                        try? FileManager.default.removeItem(atPath: job.outputPath)
                        throw SmartFillProcessingError.processingFailed("Output file has no video tracks")
                    }
                    
                    let outputDuration = try await outputAsset.load(.duration)
                    let outputDurationSeconds = CMTimeGetSeconds(outputDuration)
                    guard outputDurationSeconds.isFinite && outputDurationSeconds > 0 else {
                        try? FileManager.default.removeItem(atPath: job.outputPath)
                        throw SmartFillProcessingError.processingFailed("Output video has invalid duration")
                    }
                    
                    // Duration should be approximately the same as input (within 10%)
                    let durationDifference = abs(outputDurationSeconds - durationSeconds) / durationSeconds
                    if durationDifference > 0.1 {
                        print("⚠️ Warning: Output duration significantly different from input (\(String(format: "%.1f", outputDurationSeconds))s vs \(String(format: "%.1f", durationSeconds))s)")
                    }
                    
                    print("✅ Output validation passed: \(String(format: "%.1f", outputDurationSeconds))s, \(String(format: "%.2f MB", Double(outputSize) / 1024 / 1024))")
                    
                } catch {
                    try? FileManager.default.removeItem(atPath: job.outputPath)
                    throw SmartFillProcessingError.processingFailed("Output file validation failed: \(error.localizedDescription)")
                }
                
                await MainActor.run {
                    self.jobs[index].status = .completed
                    self.jobs[index].progress = 1.0
                }
                
                print("✅ SmartFillProcessingManager: Successfully processed \(job.fileName)")
                print("   📊 Output size: \(String(format: "%.2f MB", Double(outputSize) / 1024 / 1024))")
                print("   ✅ Output file validated as playable video")
                
                // Update repository with SmartFill result
                await updateRepositoryWithResult(job: job)
                
                // Post completion notification
                await MainActor.run {
                    NotificationCenter.default.post(
                        name: Self.jobStatusDidChange,
                        object: nil,
                        userInfo: [
                            "jobID": job.id,
                            "status": SmartFillJob.JobStatus.completed.rawValue,
                            "takeID": job.takeID,
                            "sessionID": job.sessionID,
                            "projectID": job.projectID,
                            "smartFillPath": job.outputPath
                        ]
                    )
                }
                
            } else {
                // Video was landscape, no processing needed
                await MainActor.run {
                    self.jobs[index].status = .completed
                    self.jobs[index].progress = 1.0
                }
                
                print("📹 SmartFillProcessingManager: Video was landscape, no processing needed for \(job.fileName)")
            }
            
        } catch {
            print("❌ SmartFillProcessingManager: Failed to process \(job.fileName): \(error)")
            
            // 🔥 CRITICAL SAFETY: Clean up any potentially corrupt output file
            if FileManager.default.fileExists(atPath: job.outputPath) {
                do {
                    try FileManager.default.removeItem(atPath: job.outputPath)
                    print("🗑️ Cleaned up corrupt output file: \(job.outputPath)")
                } catch {
                    print("⚠️ Could not clean up output file: \(error)")
                }
            }
            
            await MainActor.run {
                self.jobs[index].lastError = error
                self.jobs[index].retryCount += 1
                
                if self.jobs[index].retryCount >= self.maxRetryAttempts {
                    self.jobs[index].status = .failed
                    print("💀 SmartFillProcessingManager: Job failed after \(self.maxRetryAttempts) attempts")
                } else {
                    self.jobs[index].status = .pending
                    print("🔄 SmartFillProcessingManager: Will retry (\(self.jobs[index].retryCount)/\(self.maxRetryAttempts))")
                }
                
                // Post failure notification with detailed error info
                NotificationCenter.default.post(
                    name: Self.jobStatusDidChange,
                    object: nil,
                    userInfo: [
                        "jobID": job.id,
                        "status": self.jobs[index].status.rawValue,
                        "takeID": job.takeID,
                        "sessionID": job.sessionID,
                        "projectID": job.projectID,
                        "error": error.localizedDescription,
                        "retryCount": self.jobs[index].retryCount,
                        "maxRetries": self.maxRetryAttempts
                    ]
                )
            }
        }
    }
    
    // CRITICAL FIX: Add comprehensive video file validation
    private func isValidVideoFile(at path: String) -> Bool {
        // Quick file extension check first
        let url = URL(fileURLWithPath: path)
        let pathExtension = url.pathExtension.lowercased()
        let validExtensions = ["mov", "mp4", "m4v", "avi", "mkv"]
        
        guard validExtensions.contains(pathExtension) else {
            print("❌ SmartFillProcessingManager: Invalid video extension: \(pathExtension)")
            return false
        }
        
        // Check file size - video files should be reasonably large
        guard let attributes = try? FileManager.default.attributesOfItem(atPath: path),
              let fileSize = attributes[.size] as? Int64,
              fileSize > 10240 else { // At least 10KB for processed videos
            print("❌ SmartFillProcessingManager: Video file too small or unreadable: \(path)")
            return false
        }
        
        // Enhanced AVAsset validation to ensure it's actually a playable video
        let asset = AVURLAsset(url: url)
        
        // Check for video tracks
        let videoTracks = asset.tracks(withMediaType: .video)
        guard !videoTracks.isEmpty else {
            print("❌ SmartFillProcessingManager: No video tracks found in file: \(url.lastPathComponent)")
            return false
        }
        
        // Check duration validity
        let duration = asset.duration
        let durationSeconds = CMTimeGetSeconds(duration)
        
        guard durationSeconds.isFinite && durationSeconds > 0 else {
            print("❌ SmartFillProcessingManager: Invalid video duration: \(durationSeconds) seconds")
            return false
        }
        
        print("✅ SmartFillProcessingManager: Video file validation passed: \(url.lastPathComponent) (\(String(format: "%.1f", durationSeconds))s, \(String(format: "%.2f MB", Double(fileSize) / 1024 / 1024)))")
        return true
    }
    
    private func updateRepositoryWithResult(job: SmartFillJob) async {
        // Update SessionManager and repository with SmartFill result
        if let repository = await SessionManager.shared.repositoryInstance {
            await MainActor.run {
                print("🔍 SmartFillProcessingManager: Attempting repository update for takeID: \(job.takeID)")
                print("   📁 SmartFill file: \(URL(fileURLWithPath: job.outputPath).lastPathComponent)")
                print("   💾 File exists: \(FileManager.default.fileExists(atPath: job.outputPath))")
                
                // CRITICAL FIX: Convert absolute path to relative path for repository
                let outputURL = URL(fileURLWithPath: job.outputPath)
                let relativePath = VideoVariantResolver.relativePath(from: outputURL)
                
                repository.updateTakeWithSmartFillPath(
                    takeID: job.takeID,
                    smartFilledPath: relativePath,  // Store relative path
                    in: job.sessionID,
                    in: job.projectID
                )
                
                print("✅ Repository updated with SmartFill RELATIVE path for takeID: \(job.takeID)")
                print("📁 Relative SmartFill path: \(relativePath)")
                print("💾 File exists: \(FileManager.default.fileExists(atPath: job.outputPath))")
                
                // ENHANCED: Notify delegate of completion
                self.delegate?.smartFillDidFinish(takeID: job.takeID, outputURL: outputURL)
                
                // ENHANCED: Post completion notification for UI updates
                NotificationCenter.default.post(
                    name: Notification.Name("STSSmartFillCompleted"),
                    object: nil,
                    userInfo: [
                        "takeID": job.takeID,
                        "sessionID": job.sessionID,
                        "projectID": job.projectID,
                        "smartFillPath": job.outputPath,
                        "relativePath": relativePath,  // Include relative path
                        "originalPath": job.originalPath
                    ]
                )
                
                print("📢 Posted STSSmartFillCompleted notification for takeID: \(job.takeID)")
            }
        } else {
            print("❌ SmartFillProcessingManager: No repository available for SmartFill update")
        }
    }
    
    private func hasPendingJobs() -> Bool {
        return jobs.contains { $0.status == .pending }
    }
}

// MARK: - Error Types

public enum SmartFillProcessingError: LocalizedError {
    case inputFileNotFound
    case outputFileNotCreated
    case notPortraitVideo
    case processingFailed(String)
    case resourceConstraints(String)
    
    public var errorDescription: String? {
        switch self {
        case .inputFileNotFound:
            return "Input video file not found"
        case .outputFileNotCreated:
            return "SmartFill output file was not created"
        case .notPortraitVideo:
            return "Video is not portrait orientation"
        case .processingFailed(let reason):
            return "SmartFill processing failed: \(reason)"
        case .resourceConstraints(let reason):
            return "Processing paused due to resource constraints: \(reason)"
        }
    }
}
