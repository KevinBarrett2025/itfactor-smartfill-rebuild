import AVFoundation
import UIKit

/// PHASE 4: Unified interface that bridges old and new SmartFill systems
/// This provides a single API that intelligently routes to the appropriate implementation
public final class SmartFillUnifiedInterface {
    
    // MARK: - Singleton
    public static let shared = SmartFillUnifiedInterface()
    private init() {}
    
    // MARK: - Phase 4: Unified Processing Interface
    
    /// PHASE 4: Process a video with intelligent routing between old/new systems
    /// This is the main entry point that existing code should use
    public func processVideo(
        inputURL: URL,
        outputURL: URL,
        settings: SmartFillSettings = SmartFillSettings(),
        progressCallback: ((Double) -> Void)? = nil
    ) async throws -> SmartFillProcessingResult {
        
        print("🎯 SmartFillUnifiedInterface: Processing video with intelligent routing")
        let startTime = CFAbsoluteTime(CACurrentMediaTime())
        
        // PHASE 4: Determine which compositor to use
        let compositorChoice = await SmartFillMigrationManager.shared.shouldUseNewCompositor(
            for: inputURL,
            settings: settings,
            userPreference: settings.useNewCompositor ? settings.useNewCompositor : nil
        )
        
        print("   📊 Routing decision: \(compositorChoice.displayName)")
        
        var result: SmartFillProcessingResult
        
        do {
            switch compositorChoice {
            case .legacyCompositor:
                result = try await processWithLegacySystem(
                    inputURL: inputURL,
                    outputURL: outputURL,
                    settings: settings,
                    progressCallback: progressCallback
                )
                
            case .newCompositor:
                result = try await processWithNewCompositor(
                    inputURL: inputURL,
                    outputURL: outputURL,
                    settings: settings,
                    progressCallback: progressCallback
                )
            }
            
            let processingTime = CFAbsoluteTime(CACurrentMediaTime()) - startTime
            result.processingTime = processingTime
            result.compositorUsed = compositorChoice
            
            // PHASE 4: Track success for migration analytics
            SmartFillMigrationManager.shared.trackProcessingResult(
                compositor: compositorChoice,
                success: true,
                processingTime: processingTime,
                videoURL: inputURL
            )
            
            print("✅ SmartFillUnifiedInterface: Processing completed successfully")
            print("   ⏱️ Processing time: \(String(format: "%.2f", processingTime))s")
            print("   🎬 Compositor: \(compositorChoice.displayName)")
            
            return result
            
        } catch {
            let processingTime = CFAbsoluteTime(CACurrentMediaTime()) - startTime
            
            // PHASE 4: Track failure for migration analytics
            SmartFillMigrationManager.shared.trackProcessingResult(
                compositor: compositorChoice,
                success: false,
                processingTime: processingTime,
                videoURL: inputURL
            )
            
            print("❌ SmartFillUnifiedInterface: Processing failed with \(compositorChoice.displayName)")
            print("   Error: \(error)")
            
            // PHASE 4: Fallback strategy - if new compositor fails, try legacy
            if compositorChoice == .newCompositor {
                print("🔄 SmartFillUnifiedInterface: Attempting fallback to legacy system")
                
                do {
                    result = try await processWithLegacySystem(
                        inputURL: inputURL,
                        outputURL: outputURL,
                        settings: settings,
                        progressCallback: progressCallback
                    )
                    
                    let fallbackTime = CFAbsoluteTime(CACurrentMediaTime()) - startTime
                    result.processingTime = fallbackTime
                    result.compositorUsed = .legacyCompositor
                    result.wasFallback = true
                    
                    // Track fallback success
                    SmartFillMigrationManager.shared.trackProcessingResult(
                        compositor: .legacyCompositor,
                        success: true,
                        processingTime: fallbackTime,
                        videoURL: inputURL
                    )
                    
                    print("✅ SmartFillUnifiedInterface: Fallback successful")
                    return result
                    
                } catch let fallbackError {
                    // Track fallback failure
                    SmartFillMigrationManager.shared.trackProcessingResult(
                        compositor: .legacyCompositor,
                        success: false,
                        processingTime: CFAbsoluteTime(CACurrentMediaTime()) - startTime,
                        videoURL: inputURL
                    )
                    
                    print("❌ SmartFillUnifiedInterface: Fallback also failed")
                    throw fallbackError
                }
            }
            
            throw error
        }
    }
    
    /// PHASE 4: Create a unified preview that uses the same routing logic
    /// 🚨 CRITICAL FIX: Added modal-friendly parameter to solve preview crisis
    public func createPreviewPlayer(
        for videoURL: URL,
        settings: SmartFillSettings = SmartFillSettings(),
        modalFriendly: Bool = false
    ) async throws -> AVPlayer {
        
        print("🎬 SmartFillUnifiedInterface: Creating SAFE preview with intelligent routing")
        print("   🔧 Modal-friendly mode: \(modalFriendly)")
        
        // PHASE 4: Use same routing logic as processing
        let compositorChoice = await SmartFillMigrationManager.shared.shouldUseNewCompositor(
            for: videoURL,
            settings: settings,
            userPreference: settings.useNewCompositor ? settings.useNewCompositor : nil
        )
        
        switch compositorChoice {
        case .legacyCompositor:
            // PHASE 4: For legacy system, create a simple player without composition
            // (Legacy system doesn't have proper preview support)
            print("   📺 Creating legacy preview (simple player)")
            let asset = AVURLAsset(url: videoURL)
            let playerItem = AVPlayerItem(asset: asset)
            let player = AVPlayer(playerItem: playerItem)
            
            // 🚨 MODAL FIX: Optimize for modal context if needed
            if modalFriendly {
                player.automaticallyWaitsToMinimizeStalling = false
            }
            
            return player
            
        case .newCompositor:
            // 🚨 CRITICAL FIX: Use PREVIEW-SAFE compositor instead of export compositor
            print("   🚀 Creating SAFE preview with SmartFillPreviewCompositor (no crash risk)")
            
            // Route to SAFE preview creation (not the crashy export version)
            return try await createSafePreviewWithSmartFill(
                videoURL: videoURL,
                settings: settings,
                modalFriendly: modalFriendly
            )
        }
    }
    
    /// 🚨 NEW: Safe preview creation using SmartFillPreviewCompositor
    private func createSafePreviewWithSmartFill(
        videoURL: URL,
        settings: SmartFillSettings,
        modalFriendly: Bool
    ) async throws -> AVPlayer {
        
        print("🎬 SmartFillUnifiedInterface: Creating SAFE SmartFill preview")
        
        let asset = AVURLAsset(url: videoURL)
        
        // Use the SAFE preview compositor (not the export-only one)
        let previewCompositor = SmartFillPreviewCompositor()
        let videoComposition = try await previewCompositor.createPreviewVideoComposition(
            for: asset,
            renderSize: settings.defaultRenderSize,
            settings: settings
        )
        
        let playerItem = AVPlayerItem(asset: asset)
        playerItem.videoComposition = videoComposition
        
        let player = AVPlayer(playerItem: playerItem)
        
        // Configure for modal context if needed
        if modalFriendly {
            player.automaticallyWaitsToMinimizeStalling = false
            print("   🔧 Optimized for modal presentation")
        } else {
            player.automaticallyWaitsToMinimizeStalling = true
        }
        
        print("✅ SmartFillUnifiedInterface: Created SAFE preview with SmartFill effect")
        print("   🔒 Uses SmartFillPreviewCompositor (AVPlayerItem compatible)")
        print("   🚫 No AVVideoCompositionCoreAnimationTool (no crash risk)")
        
        return player
    }
    
    // MARK: - Phase 4: System-Specific Processing
    
    /// PHASE 4: Process with the legacy frame-processing system
    private func processWithLegacySystem(
        inputURL: URL,
        outputURL: URL,
        settings: SmartFillSettings,
        progressCallback: ((Double) -> Void)?
    ) async throws -> SmartFillProcessingResult {
        
        print("🔧 SmartFillUnifiedInterface: Processing with legacy frame system")
        
        // PHASE 4: Use the existing SmartFillExporter
        let success = try await SmartFillExporter.processPortraitVideoFile(
            inputPath: inputURL.path,
            outputPath: outputURL.path,
            settings: settings
        )
        
        guard success else {
            throw SmartFillUnifiedInterfaceError.legacyProcessingFailed
        }
        
        return SmartFillProcessingResult(
            inputURL: inputURL,
            outputURL: outputURL,
            success: true,
            compositorUsed: .legacyCompositor,
            processingTime: 0, // Will be set by caller
            wasFallback: false,
            qualityMetrics: nil
        )
    }
    
    /// PHASE 4: Process with the new industry-standard compositor
    private func processWithNewCompositor(
        inputURL: URL,
        outputURL: URL,
        settings: SmartFillSettings,
        progressCallback: ((Double) -> Void)?
    ) async throws -> SmartFillProcessingResult {
        
        print("🚀 SmartFillUnifiedInterface: Processing with new compositor")
        
        // PHASE 4: Use the new SmartFillCompositorIntegration
        let success = try await SmartFillCompositorIntegration.testNewCompositor(
            inputVideoURL: inputURL,
            outputVideoURL: outputURL,
            settings: settings
        )
        
        guard success else {
            throw SmartFillUnifiedInterfaceError.newCompositorProcessingFailed
        }
        
        // PHASE 4: Calculate quality metrics for the new system
        let qualityMetrics = try await calculateQualityMetrics(
            inputURL: inputURL,
            outputURL: outputURL
        )
        
        return SmartFillProcessingResult(
            inputURL: inputURL,
            outputURL: outputURL,
            success: true,
            compositorUsed: .newCompositor,
            processingTime: 0, // Will be set by caller
            wasFallback: false,
            qualityMetrics: qualityMetrics
        )
    }
    
    /// PHASE 4: Calculate quality metrics for processed video
    private func calculateQualityMetrics(
        inputURL: URL,
        outputURL: URL
    ) async throws -> QualityMetrics {
        
        // Basic quality analysis (can be expanded)
        let inputAsset = AVURLAsset(url: inputURL)
        let outputAsset = AVURLAsset(url: outputURL)
        
        let inputTracks = try await inputAsset.loadTracks(withMediaType: .video)
        let outputTracks = try await outputAsset.loadTracks(withMediaType: .video)
        
        guard let inputTrack = inputTracks.first,
              let outputTrack = outputTracks.first else {
            return QualityMetrics(resolutionMatch: false, frameRateMatch: false)
        }
        
        let inputSize = try await inputTrack.load(.naturalSize)
        let outputSize = try await outputTrack.load(.naturalSize)
        let inputFrameRate = try await inputTrack.load(.nominalFrameRate)
        let outputFrameRate = try await outputTrack.load(.nominalFrameRate)
        
        return QualityMetrics(
            resolutionMatch: inputSize.width > 0 && outputSize.width > 0,
            frameRateMatch: abs(inputFrameRate - outputFrameRate) < 1.0
        )
    }
}

// MARK: - Phase 4: Result Types

public struct SmartFillProcessingResult {
    public let inputURL: URL
    public let outputURL: URL
    public let success: Bool
    public var compositorUsed: CompositorChoice
    public var processingTime: TimeInterval
    public var wasFallback: Bool
    public let qualityMetrics: QualityMetrics?
    
    public var summary: String {
        let fallbackNote = wasFallback ? " (fallback)" : ""
        return """
        📊 SmartFill Processing Result:
        Input: \(inputURL.lastPathComponent)
        Output: \(outputURL.lastPathComponent)
        Success: \(success ? "✅" : "❌")
        Compositor: \(compositorUsed.displayName)\(fallbackNote)
        Time: \(String(format: "%.2f", processingTime))s
        Quality: \(qualityMetrics?.summary ?? "N/A")
        """
    }
}

public struct QualityMetrics {
    public let resolutionMatch: Bool
    public let frameRateMatch: Bool
    
    public var summary: String {
        let resolution = resolutionMatch ? "✅" : "❌"
        let frameRate = frameRateMatch ? "✅" : "❌"
        return "Res: \(resolution), FPS: \(frameRate)"
    }
}

// MARK: - Phase 4: Error Handling

public enum SmartFillUnifiedInterfaceError: LocalizedError {
    case legacyProcessingFailed
    case newCompositorProcessingFailed
    case noValidCompositor
    case qualityAnalysisFailed
    
    public var errorDescription: String? {
        switch self {
        case .legacyProcessingFailed:
            return "Legacy SmartFill processing failed"
        case .newCompositorProcessingFailed:
            return "New compositor processing failed"
        case .noValidCompositor:
            return "No valid compositor available"
        case .qualityAnalysisFailed:
            return "Quality analysis failed"
        }
    }
}

// MARK: - Phase 4: Migration Helpers for Existing Code

public extension SmartFillUnifiedInterface {
    
    /// PHASE 4: Drop-in replacement for existing SmartFillExporter calls
    /// This maintains API compatibility while adding intelligent routing
    @available(*, deprecated, message: "Use processVideo(inputURL:outputURL:settings:) instead")
    static func processPortraitVideoFile(
        inputPath: String,
        outputPath: String,
        settings: SmartFillSettings = SmartFillSettings()
    ) async throws -> Bool {
        
        let inputURL = URL(fileURLWithPath: inputPath)
        let outputURL = URL(fileURLWithPath: outputPath)
        
        let result = try await SmartFillUnifiedInterface.shared.processVideo(
            inputURL: inputURL,
            outputURL: outputURL,
            settings: settings
        )
        
        return result.success
    }
    
    /// PHASE 4: Migration helper for SmartFillProcessingManager integration
    func integrateWithExistingProcessor(
        takeID: UUID,
        sessionID: UUID,
        projectID: UUID,
        videoPath: String,
        settings: SmartFillSettings
    ) async throws -> SmartFillProcessingResult {
        
        let inputURL = URL(fileURLWithPath: videoPath)
        let outputDir = FileManager.default.temporaryDirectory.appendingPathComponent("SmartFill")
        let outputURL = outputDir.appendingPathComponent("smartfill_\(takeID.uuidString).mov")
        
        // Ensure output directory exists
        try FileManager.default.createDirectory(at: outputDir, withIntermediateDirectories: true)
        
        // Process with unified interface
        let result = try await processVideo(
            inputURL: inputURL,
            outputURL: outputURL,
            settings: settings
        )
        
        print("🔄 SmartFillUnifiedInterface: Integration complete for take \(takeID)")
        print("   📁 Output: \(outputURL.lastPathComponent)")
        
        return result
    }
}

#if DEBUG
// MARK: - Phase 4: Debug and Testing

public extension SmartFillUnifiedInterface {
    
    /// Debug method to test both systems with the same input
    func compareBothSystems(
        inputURL: URL,
        settings: SmartFillSettings
    ) async -> SystemComparisonResult {
        
        let tempDir = FileManager.default.temporaryDirectory
        let legacyOutputURL = tempDir.appendingPathComponent("legacy_\(UUID().uuidString).mov")
        let newOutputURL = tempDir.appendingPathComponent("new_\(UUID().uuidString).mov")
        
        print("🔬 SmartFillUnifiedInterface: Comparing both systems")
        
        var legacyResult: SmartFillProcessingResult?
        var newResult: SmartFillProcessingResult?
        
        // Test legacy system
        do {
            legacyResult = try await processWithLegacySystem(
                inputURL: inputURL,
                outputURL: legacyOutputURL,
                settings: settings,
                progressCallback: nil
            )
        } catch {
            print("❌ Legacy system failed: \(error)")
        }
        
        // Test new system
        do {
            newResult = try await processWithNewCompositor(
                inputURL: inputURL,
                outputURL: newOutputURL,
                settings: settings,
                progressCallback: nil
            )
        } catch {
            print("❌ New system failed: \(error)")
        }
        
        return SystemComparisonResult(
            inputURL: inputURL,
            legacyResult: legacyResult,
            newResult: newResult
        )
    }
    
    struct SystemComparisonResult {
        let inputURL: URL
        let legacyResult: SmartFillProcessingResult?
        let newResult: SmartFillProcessingResult?
        
        var summary: String {
            return """
            🔬 SYSTEM COMPARISON RESULT:
            Input: \(inputURL.lastPathComponent)
            
            LEGACY SYSTEM:
            \(legacyResult?.summary ?? "❌ Failed")
            
            NEW SYSTEM:
            \(newResult?.summary ?? "❌ Failed")
            
            WINNER: \(winner)
            """
        }
        
        var winner: String {
            guard let legacy = legacyResult, let new = newResult else {
                if legacyResult != nil { return "Legacy (only success)" }
                if newResult != nil { return "New (only success)" }
                return "Both failed"
            }
            
            if new.processingTime < legacy.processingTime {
                return "New System (faster)"
            } else {
                return "Legacy System (faster)"
            }
        }
    }
}
#endif
