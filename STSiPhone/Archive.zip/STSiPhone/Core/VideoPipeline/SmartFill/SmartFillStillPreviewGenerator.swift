import AVFoundation
import CoreImage
import UIKit

/// 🚨 CRITICAL FIX: Still-frame SmartFill preview generator
/// SOLVES: Preview crashes by avoiding AVPlayer/AVPlayerItem entirely
/// Shows SmartFill effect using single frame + Core Image - fast and safe
public struct SmartFillStillPreviewGenerator {
    
    private let asset: AVAsset
    private let context: CIContext
    
    public init(asset: AVAsset) {
        self.asset = asset
        
        // Create optimized CI context for still image processing
        if let metalDevice = MTLCreateSystemDefaultDevice() {
            self.context = CIContext(mtlDevice: metalDevice, options: [
                .workingColorSpace: CGColorSpace(name: CGColorSpace.sRGB)!,
                .outputColorSpace: CGColorSpace(name: CGColorSpace.sRGB)!,
                .cacheIntermediates: false // Don't cache for one-off preview
            ])
        } else {
            self.context = CIContext(options: [
                .workingColorSpace: CGColorSpace(name: CGColorSpace.sRGB)!,
                .outputColorSpace: CGColorSpace(name: CGColorSpace.sRGB)!
            ])
        }
    }
    
    /// Generate SmartFill preview image - NO video players involved
    public func makePreviewImage(
        targetSize: CGSize = CGSize(width: 1920, height: 1080),
        time: CMTime? = nil,
        settings: SmartFillSettings = SmartFillSettings()
    ) async throws -> UIImage {
        
        print("🖼️ SmartFillStillPreviewGenerator: Generating still preview")
        print("   📐 Target size: \(targetSize)")
        print("   ⚙️ Settings: blur=\(settings.defaultBlurRadius), darken=\(settings.defaultDarkenAmount), scale=\(settings.backgroundScale)")
        
        // 1. Extract a frame from the video
        let baseImage = try await extractFrame(at: time, maxSize: targetSize)
        
        // 2. Create SmartFill background (blur + darken + scale)
        let background = try createSmartFillBackground(
            from: baseImage,
            targetSize: targetSize,
            settings: settings
        )
        
        // 3. Create foreground (original video centered and fit)
        let foreground = try createSmartFillForeground(
            from: baseImage,
            targetSize: targetSize
        )
        
        // 4. Composite foreground over background
        let composite = foreground.composited(over: background)
        
        // 5. Render to UIImage
        let finalImage = try renderToUIImage(composite, size: targetSize)
        
        print("✅ SmartFillStillPreviewGenerator: Preview generated successfully")
        return finalImage
    }
    
    // MARK: - Private Implementation
    
    private func extractFrame(at time: CMTime?, maxSize: CGSize) async throws -> CIImage {
        let generator = AVAssetImageGenerator(asset: asset)
        generator.appliesPreferredTrackTransform = true
        generator.maximumSize = maxSize
        
        // Default to 25% through the video for best representative frame
        let extractTime: CMTime
        if let time = time {
            extractTime = time
        } else {
            let duration = try await asset.load(.duration)
            extractTime = CMTimeMultiplyByFloat64(duration, multiplier: 0.25)
        }
        
        print("🎬 SmartFillStillPreviewGenerator: Extracting frame at \(CMTimeGetSeconds(extractTime))s")
        
        return try await withCheckedThrowingContinuation { continuation in
            generator.generateCGImagesAsynchronously(forTimes: [NSValue(time: extractTime)]) { _, cgImage, _, result, error in
                if let error = error {
                    continuation.resume(throwing: error)
                    return
                }
                
                guard let cgImage = cgImage else {
                    continuation.resume(throwing: SmartFillPreviewError.frameExtractionFailed)
                    return
                }
                
                let ciImage = CIImage(cgImage: cgImage)
                continuation.resume(returning: ciImage)
            }
        }
    }
    
    private func createSmartFillBackground(
        from baseImage: CIImage,
        targetSize: CGSize,
        settings: SmartFillSettings
    ) throws -> CIImage {
        
        // 1. Scale to fill (with extra scaling factor)
        let scaledImage = baseImage.smartFillScaled(
            to: targetSize,
            scale: settings.backgroundScale
        )
        
        // 2. Apply Gaussian blur
        guard let blurFilter = CIFilter(name: "CIGaussianBlur") else {
            throw SmartFillPreviewError.filterCreationFailed("CIGaussianBlur")
        }
        
        blurFilter.setValue(scaledImage, forKey: kCIInputImageKey)
        blurFilter.setValue(settings.defaultBlurRadius, forKey: kCIInputRadiusKey)
        
        guard let blurredImage = blurFilter.outputImage else {
            throw SmartFillPreviewError.filterProcessingFailed("Gaussian blur")
        }
        
        // 3. Apply darkening
        guard let colorFilter = CIFilter(name: "CIColorControls") else {
            throw SmartFillPreviewError.filterCreationFailed("CIColorControls")
        }
        
        colorFilter.setValue(blurredImage, forKey: kCIInputImageKey)
        colorFilter.setValue(-settings.defaultDarkenAmount, forKey: kCIInputBrightnessKey)
        
        guard let finalBackground = colorFilter.outputImage else {
            throw SmartFillPreviewError.filterProcessingFailed("Color controls")
        }
        
        // 4. Crop to exact target size
        return finalBackground.cropped(to: CGRect(origin: .zero, size: targetSize))
    }
    
    private func createSmartFillForeground(
        from baseImage: CIImage,
        targetSize: CGSize
    ) throws -> CIImage {
        
        // Scale to fit and center in target canvas
        return baseImage.smartFillAspectFit(in: targetSize)
    }
    
    private func renderToUIImage(_ ciImage: CIImage, size: CGSize) throws -> UIImage {
        let renderRect = CGRect(origin: .zero, size: size)
        
        guard let cgImage = context.createCGImage(ciImage, from: renderRect) else {
            throw SmartFillPreviewError.renderingFailed
        }
        
        return UIImage(cgImage: cgImage)
    }
}

// MARK: - Core Image Extensions for SmartFill

private extension CIImage {
    
    /// Scale image to fill target size with optional extra scaling
    func smartFillScaled(to target: CGSize, scale: CGFloat = 1.0) -> CIImage {
        let sourceSize = extent.size
        
        // Calculate scale to fill target size
        let sx = target.width / sourceSize.width
        let sy = target.height / sourceSize.height
        let fillScale = max(sx, sy) * scale // Apply extra scale factor
        
        // Apply scaling transform
        let scaledImage = transformed(by: CGAffineTransform(scaleX: fillScale, y: fillScale))
        
        // Center crop to target size
        let scaledSize = CGSize(
            width: sourceSize.width * fillScale,
            height: sourceSize.height * fillScale
        )
        
        let offsetX = (scaledSize.width - target.width) * 0.5
        let offsetY = (scaledSize.height - target.height) * 0.5
        
        let cropRect = CGRect(
            x: scaledImage.extent.origin.x + offsetX,
            y: scaledImage.extent.origin.y + offsetY,
            width: target.width,
            height: target.height
        )
        
        return scaledImage.cropped(to: cropRect)
    }
    
    /// Scale image to fit within target size and center with transparent background
    func smartFillAspectFit(in target: CGSize) -> CIImage {
        let sourceSize = extent.size
        
        // Calculate scale to fit within target
        let sx = target.width / sourceSize.width
        let sy = target.height / sourceSize.height
        let fitScale = min(sx, sy)
        
        // Apply scaling
        let scaledImage = transformed(by: CGAffineTransform(scaleX: fitScale, y: fitScale))
        let scaledSize = CGSize(
            width: sourceSize.width * fitScale,
            height: sourceSize.height * fitScale
        )
        
        // Calculate centering offset
        let offsetX = (target.width - scaledSize.width) * 0.5
        let offsetY = (target.height - scaledSize.height) * 0.5
        
        // Center in target canvas
        return scaledImage.transformed(by: CGAffineTransform(
            translationX: offsetX - scaledImage.extent.origin.x,
            y: offsetY - scaledImage.extent.origin.y
        ))
    }
}

// MARK: - Error Handling

public enum SmartFillPreviewError: LocalizedError {
    case frameExtractionFailed
    case filterCreationFailed(String)
    case filterProcessingFailed(String)
    case renderingFailed
    
    public var errorDescription: String? {
        switch self {
        case .frameExtractionFailed:
            return "Failed to extract frame from video"
        case .filterCreationFailed(let filterName):
            return "Failed to create Core Image filter: \(filterName)"
        case .filterProcessingFailed(let operation):
            return "Core Image filter processing failed: \(operation)"
        case .renderingFailed:
            return "Failed to render final preview image"
        }
    }
}

// MARK: - Convenience Extensions

public extension SmartFillStillPreviewGenerator {
    
    /// Quick preview generation from URL
    static func generatePreview(
        from url: URL,
        targetSize: CGSize = CGSize(width: 1920, height: 1080),
        settings: SmartFillSettings = SmartFillSettings()
    ) async throws -> UIImage {
        
        let asset = AVURLAsset(url: url)
        let generator = SmartFillStillPreviewGenerator(asset: asset)
        return try await generator.makePreviewImage(
            targetSize: targetSize,
            settings: settings
        )
    }
}