import Foundation
import UIKit

// MARK: - Settings Integration with STS Architecture
// 🚨 SWIFT 6 SENDABILITY: Made SmartFillSettings Sendable for safe concurrent access
public struct SmartFillSettings: Sendable {
    // ✅ ACTIVATED: Enable SmartFill by default for portrait video processing
    public var defaultEnabled: Bool = true
    public var defaultBlurRadius: CGFloat = 24.0
    public var defaultDarkenAmount: CGFloat = 0.12
    public var defaultRenderSize: CGSize = CGSize(width: 1920, height: 1080)
    
    // 🎯 ENTERPRISE FIX: Adjustable background scaling as requested in Master Brain #275
    // CRITICAL: Replace hardcoded 1.5x with user-configurable 10x default for dramatic edge-to-edge fill
    public var backgroundScale: CGFloat = 10.0
    
    // 🚀 PHASE 3: Enable industry-standard compositor (parallel implementation)
    // 🔥 CRITICAL FIX: Enable new compositor by default - resolves architectural crisis
    public var useNewCompositor: Bool = true
    
    // NEW: Processing priority for batch operations
    public var processingPriority: ProcessingPriority = .userInitiated
    
    // 🚨 SWIFT 6 SENDABILITY: Made ProcessingPriority Sendable
    public enum ProcessingPriority: String, CaseIterable, Sendable {
        case background = "background"
        case userInitiated = "userInitiated"
        case high = "high"
        
        var displayName: String {
            switch self {
            case .background:
                return "Background"
            case .userInitiated:
                return "Normal"
            case .high:
                return "High"
            }
        }
    }
    
    // 🚨 SWIFT 6 SENDABILITY: Made Preset enum Sendable
    // INTEGRATION: Settings presets for user convenience
    public enum Preset: Sendable {
        case subtle
        case medium
        case dramatic
        
        var blurRadius: CGFloat {
            switch self {
            case .subtle: return 12.0
            case .medium: return 24.0
            case .dramatic: return 36.0
            }
        }
        
        var darkenAmount: CGFloat {
            switch self {
            case .subtle: return 0.08
            case .medium: return 0.12
            case .dramatic: return 0.18
            }
        }
    }
    
    public init() {
        // Load from UserDefaults if available
        self.defaultEnabled = UserDefaults.standard.object(forKey: "smartFillEnabled") as? Bool ?? true
        self.defaultBlurRadius = UserDefaults.standard.object(forKey: "smartFillBlurRadius") as? CGFloat ?? 24.0
        self.defaultDarkenAmount = UserDefaults.standard.object(forKey: "smartFillDarkenAmount") as? CGFloat ?? 0.12
        self.backgroundScale = UserDefaults.standard.object(forKey: "smartFillBackgroundScale") as? CGFloat ?? 10.0
        self.useNewCompositor = UserDefaults.standard.object(forKey: "smartFillUseNewCompositor") as? Bool ?? true // 🔥 CRITICAL FIX: Default to true
        
        let savedWidth = UserDefaults.standard.object(forKey: "smartFillRenderWidth") as? CGFloat ?? 1920
        let savedHeight = UserDefaults.standard.object(forKey: "smartFillRenderHeight") as? CGFloat ?? 1080
        self.defaultRenderSize = CGSize(width: savedWidth, height: savedHeight)
        
        let savedPriority = UserDefaults.standard.string(forKey: "smartFillProcessingPriority") ?? "userInitiated"
        self.processingPriority = ProcessingPriority(rawValue: savedPriority) ?? .userInitiated
    }
    
    // NEW: Custom initializer for SmartFillSettingsView
    public init(
        defaultEnabled: Bool,
        defaultBlurRadius: CGFloat,
        defaultDarkenAmount: CGFloat,
        defaultRenderSize: CGSize,
        backgroundScale: CGFloat = 10.0,
        processingPriority: ProcessingPriority = .userInitiated
    ) {
        self.defaultEnabled = defaultEnabled
        self.defaultBlurRadius = defaultBlurRadius
        self.defaultDarkenAmount = defaultDarkenAmount
        self.defaultRenderSize = defaultRenderSize
        self.backgroundScale = backgroundScale
        self.processingPriority = processingPriority
    }
    
    // NEW: Custom initializer with all parameters for SmartFillSettingsView
    public init(
        defaultEnabled: Bool,
        defaultBlurRadius: CGFloat,
        defaultDarkenAmount: CGFloat,
        defaultRenderSize: CGSize,
        backgroundScale: CGFloat = 10.0,
        useNewCompositor: Bool = false,
        processingPriority: ProcessingPriority = .userInitiated
    ) {
        self.defaultEnabled = defaultEnabled
        self.defaultBlurRadius = defaultBlurRadius
        self.defaultDarkenAmount = defaultDarkenAmount
        self.defaultRenderSize = defaultRenderSize
        self.backgroundScale = backgroundScale
        self.useNewCompositor = useNewCompositor
        self.processingPriority = processingPriority
    }
    
    // 🎯 ENTERPRISE: Helper for persisting settings
    public func saveToUserDefaults() {
        UserDefaults.standard.set(defaultEnabled, forKey: "smartFillEnabled")
        UserDefaults.standard.set(defaultBlurRadius, forKey: "smartFillBlurRadius")
        UserDefaults.standard.set(defaultDarkenAmount, forKey: "smartFillDarkenAmount")
        UserDefaults.standard.set(backgroundScale, forKey: "smartFillBackgroundScale")
        UserDefaults.standard.set(useNewCompositor, forKey: "smartFillUseNewCompositor") // PHASE 3: Save compositor preference
        UserDefaults.standard.set(defaultRenderSize.width, forKey: "smartFillRenderWidth")
        UserDefaults.standard.set(defaultRenderSize.height, forKey: "smartFillRenderHeight")
        UserDefaults.standard.set(processingPriority.rawValue, forKey: "smartFillProcessingPriority")
    }
}

// MARK: - Session Extensions for Smart Fill
public extension ProjectSession {
    var inferredPrimaryOrientation: VideoOrientation {
        // INTEGRATION: Determine session orientation from majority of takes
        let landscapeCount = takes.filter { take in
            // Check if we have stored orientation, otherwise infer from filename/metadata
            return inferVideoOrientation(for: take) == .landscape
        }.count
        
        let portraitCount = takes.count - landscapeCount
        
        return portraitCount > landscapeCount ? .portrait : .landscape
    }
    
    var effectiveSmartFillEnabled: Bool {
        // Use stored setting or default to true
        return smartFillEnabled ?? true
    }
    
    private func inferVideoOrientation(for take: ProjectTake) -> VideoOrientation {
        // Use stored orientation if available
        if let stored = take.capturedOrientation {
            return stored
        }
        
        // INTEGRATION: Try to infer orientation from existing take data
        // This is temporary until we add proper orientation capture
        
        // Check if filename suggests orientation
        let fileName = take.filePath.lowercased()
        if fileName.contains("portrait") || fileName.contains("vertical") {
            return .portrait
        }
        if fileName.contains("landscape") || fileName.contains("horizontal") {
            return .landscape
        }
        
        // Default to landscape for backward compatibility
        return .landscape
    }
}

// MARK: - ProjectTake Extensions for Smart Fill
public extension ProjectTake {
    var effectiveCapturedOrientation: VideoOrientation {
        // Use stored orientation or infer from metadata
        return capturedOrientation ?? inferOrientationFromMetadata()
    }
    
    var effectiveSmartFillOverride: TriState {
        // Use stored override or default to inherit
        return overrideSmartFill ?? .inherit
    }
    
    private func inferOrientationFromMetadata() -> VideoOrientation {
        // INTEGRATION: Temporary inference logic
        // Check duration vs typical orientation patterns
        if durationSeconds < 30 && filePath.contains("slate") {
            return .portrait // Slates are often portrait
        }
        
        // Default to landscape for existing takes
        return .landscape
    }
}

// MARK: - Smart Fill Policy Engine
public enum SmartFillPolicy {
    public static func resolve(_ override: TriState?, base: Bool) -> Bool {
        switch override {
        case .some(.on):  return true
        case .some(.off): return false
        default:          return base
        }
    }

    public static func shouldApply(session: ProjectSession, take: ProjectTake, settings: SmartFillSettings) -> Bool {
        let base = session.effectiveSmartFillEnabled
        let wants = resolve(take.effectiveSmartFillOverride, base: base)
        return wants && (session.inferredPrimaryOrientation == .landscape) && (take.effectiveCapturedOrientation == .portrait)
    }
    
    // INTEGRATION: Convenience method for our existing architecture
    public static func shouldApply(for take: ProjectTake, in session: ProjectSession) -> Bool {
        let settings = SmartFillSettings() // Use defaults for now
        return shouldApply(session: session, take: take, settings: settings)
    }
    
    // INTEGRATION: Batch processing for session
    public static func getPortraitTakesNeedingSmartFill(in session: ProjectSession) -> [ProjectTake] {
        return session.takes.filter { take in
            shouldApply(for: take, in: session)
        }
    }
}
