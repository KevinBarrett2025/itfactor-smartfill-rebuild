import AVFoundation
import Foundation

/// Modern export wrapper that provides iOS 18+ async export support with fallback
public enum STSExport {
    
    /// Run export session with modern async/await approach
    /// Uses iOS 18+ native async export when available, falls back to continuation pattern
    public static func run(_ session: AVAssetExportSession) async throws {
        if #available(iOS 18, *) {
            // iOS 18+: Use simple async export (states observation would be done separately if needed)
            try await session.export()
        } else {
            // iOS 17 and earlier: Use continuation-based approach
            try await exportWithContinuation(session)
        }
    }
    
    /// Legacy iOS 17 export with continuation pattern
    private static func exportWithContinuation(_ session: AVAssetExportSession) async throws {
        try await withCheckedThrowingContinuation { (continuation: CheckedContinuation<Void, Error>) in
            session.exportAsynchronously {
                switch session.status {
                case .completed:
                    continuation.resume()
                case .failed:
                    let error = session.error ?? NSError(
                        domain: "STS.Export.Failed",
                        code: -1,
                        userInfo: [NSLocalizedDescriptionKey: "Export failed with unknown error"]
                    )
                    continuation.resume(throwing: error)
                case .cancelled:
                    let error = NSError(
                        domain: "STS.Export.Cancelled",
                        code: -2,
                        userInfo: [NSLocalizedDescriptionKey: "Export was cancelled"]
                    )
                    continuation.resume(throwing: error)
                default:
                    // Unexpected status
                    let error = session.error ?? NSError(
                        domain: "STS.Export.UnexpectedStatus",
                        code: -3,
                        userInfo: [NSLocalizedDescriptionKey: "Export ended with unexpected status: \(session.status.rawValue)"]
                    )
                    continuation.resume(throwing: error)
                }
            }
        }
    }
    
    /// Helper to create export session with modern settings
    public static func createSession(
        asset: AVAsset,
        outputURL: URL,
        presetName: String = AVAssetExportPresetHighestQuality
    ) -> AVAssetExportSession? {
        let session = AVAssetExportSession(asset: asset, presetName: presetName)
        session?.outputURL = outputURL
        session?.outputFileType = .mov // Default to .mov for compatibility
        return session
    }
    
    /// Helper to validate export session before running
    public static func validateSession(_ session: AVAssetExportSession) throws {
        guard let outputURL = session.outputURL else {
            throw NSError(
                domain: "STS.Export.Validation",
                code: -100,
                userInfo: [NSLocalizedDescriptionKey: "Export session missing output URL"]
            )
        }
        
        guard session.asset.isExportable else {
            throw NSError(
                domain: "STS.Export.Validation", 
                code: -101,
                userInfo: [NSLocalizedDescriptionKey: "Asset is not exportable"]
            )
        }
        
        // Ensure output directory exists
        let outputDir = outputURL.deletingLastPathComponent()
        if !FileManager.default.fileExists(atPath: outputDir.path) {
            try FileManager.default.createDirectory(at: outputDir, withIntermediateDirectories: true)
        }
        
        // Remove existing file if present
        if FileManager.default.fileExists(atPath: outputURL.path) {
            try FileManager.default.removeItem(at: outputURL)
        }
    }
    
    /// iOS 18+ export with progress monitoring capability
    @available(iOS 18, *)
    public static func runWithProgress(
        _ session: AVAssetExportSession,
        progressHandler: @escaping (Float) -> Void = { _ in }
    ) async throws {
        
        // Start progress monitoring task
        let progressTask = Task {
            while session.status == .waiting || session.status == .exporting {
                let progress = session.progress
                await MainActor.run {
                    progressHandler(progress)
                }
                
                try? await Task.sleep(nanoseconds: 200_000_000) // 0.2 seconds
            }
        }
        
        // Perform the export
        try await session.export()
        
        // Cancel progress monitoring
        progressTask.cancel()
        
        // Final progress update
        await MainActor.run {
            progressHandler(1.0)
        }
    }
}

// MARK: - Convenience Extensions

public extension AVAssetExportSession {
    
    /// Export using STSExport wrapper with validation
    func exportWithSTS() async throws {
        try STSExport.validateSession(self)
        try await STSExport.run(self)
    }
    
    /// Export using STSExport wrapper with progress monitoring (iOS 18+)
    @available(iOS 18, *)
    func exportWithSTSProgress(
        progressHandler: @escaping (Float) -> Void = { _ in }
    ) async throws {
        try STSExport.validateSession(self)
        try await STSExport.runWithProgress(self, progressHandler: progressHandler)
    }
}
