import Foundation
import AVFoundation
import UIKit

// MARK: - Export Actor for Concurrency Safety

/// Dedicated actor for handling export operations without capturing self in @Sendable closures
/// Isolates export logic from the main actor to prevent race conditions
actor ExportActor {
    private var currentExportSession: AVAssetExportSession?
    private var currentProgressTask: Task<Void, Never>?
    
    // MARK: - Export Operations
    
    func performExport(
        takes: [UnifiedTake],
        options: ExportOptions,
        progressHandler: @Sendable @escaping (Float, String) -> Void
    ) async throws -> [ExportedFile] {
        
        progressHandler(0.0, "Preparing export...")
        
        let exportedFiles: [ExportedFile]
        
        switch options.mode {
        case .separateFiles:
            print("🎬 ExportActor: Starting separate files export")
            exportedFiles = try await exportSeparateFiles(takes: takes, options: options, progressHandler: progressHandler)
        case .mergedVideo:
            print("🎬 ExportActor: Starting merged video export")
            exportedFiles = try await exportMergedVideo(takes: takes, options: options, progressHandler: progressHandler)
        case .mergedWithSlate:
            print("🎬 ExportActor: Starting merged with slate export")
            exportedFiles = try await exportMergedWithSlate(takes: takes, options: options, progressHandler: progressHandler)
        }
        
        progressHandler(1.0, "Export completed!")
        return exportedFiles
    }
    
    // MARK: - Individual Take Export
    
    private func exportSeparateFiles(
        takes: [UnifiedTake],
        options: ExportOptions,
        progressHandler: @Sendable @escaping (Float, String) -> Void
    ) async throws -> [ExportedFile] {
        
        progressHandler(0.1, "Processing individual takes...")
        
        var exportedFiles: [ExportedFile] = []
        let totalTakes = takes.count
        
        for (index, take) in takes.enumerated() {
            let progress = 0.1 + (0.8 * Float(index) / Float(totalTakes))
            progressHandler(progress, "Exporting \(take.fileName)...")
            
            // Resolve file path using VideoFileManager
            let inputURL = try resolveInputURL(for: take)
            
            guard FileManager.default.fileExists(atPath: inputURL.path) else {
                print("❌ ExportActor: Skipping missing file \(take.fileName) at \(inputURL.path)")
                continue
            }
            
            let outputURL = generateOutputURL(for: take, options: options)
            
            var composition: AVMutableComposition?
            var videoComposition: AVMutableVideoComposition?
            
            if options.includeVideoMarkers,
               let markers = options.videoMarkers[take.id.uuidString],
               !markers.isEmpty {
                let result = try await createCompositionWithMarkers(
                    inputURL: inputURL,
                    markers: markers,
                    options: options
                )
                composition = result.composition
                videoComposition = result.videoComposition
            }
            
            let outputFile = try await exportSingleTake(
                take: take,
                inputURL: inputURL,
                outputURL: outputURL,
                composition: composition,
                videoComposition: videoComposition,
                options: options,
                progressHandler: progressHandler
            )
            
            exportedFiles.append(outputFile)
        }
        
        return exportedFiles
    }
    
    private func exportSingleTake(
        take: UnifiedTake,
        inputURL: URL,
        outputURL: URL,
        composition: AVMutableComposition?,
        videoComposition: AVMutableVideoComposition?,
        options: ExportOptions,
        progressHandler: @Sendable @escaping (Float, String) -> Void
    ) async throws -> ExportedFile {
        
        // Create proper composition for separate files to prevent frozen video
        let finalAsset: AVAsset
        let finalVideoComposition: AVMutableVideoComposition?
        
        if let existingComposition = composition {
            finalAsset = existingComposition
            finalVideoComposition = videoComposition
            print("✅ ExportActor: Using existing composition with markers for \(take.fileName)")
        } else {
            print("🔧 ExportActor: Creating composition for separate file \(take.fileName)")
            let (newComposition, newVideoComposition) = try await createSingleTakeComposition(
                inputURL: inputURL,
                take: take,
                options: options
            )
            finalAsset = newComposition
            finalVideoComposition = newVideoComposition
            print("✅ ExportActor: Created new composition for separate file \(take.fileName)")
        }
        
        // 🚨 CRITICAL FIX: Use STSExport wrapper with modern async/await patterns
        guard let exportSession = STSExport.createSession(
            asset: finalAsset,
            outputURL: outputURL,
            presetName: options.quality.avPreset
        ) else {
            throw ExportError.exportConfigurationFailed
        }
        
        exportSession.outputFileType = options.outputFormat.avFileType
        exportSession.shouldOptimizeForNetworkUse = true
        exportSession.videoComposition = finalVideoComposition
        
        print("🎬 ExportActor: Starting export session for separate file \(take.fileName)")
        print("🎬 ExportActor: Output: \(outputURL.path)")
        
        // 🚨 MODERNIZED: Load asset duration using async API
        do {
            let assetDuration = try await finalAsset.load(.duration)
            print("🎬 ExportActor: Asset duration: \(CMTimeGetSeconds(assetDuration))s")
        } catch {
            print("⚠️ ExportActor: Could not load asset duration: \(error)")
        }
        
        // Store reference for cancellation
        currentExportSession = exportSession
        
        // Start progress monitoring
        currentProgressTask = Task {
            await monitorExportProgress(exportSession, progressHandler: progressHandler)
        }
        
        // 🚨 CRITICAL FIX: Use STSExport.run() with proper validation and async patterns
        do {
            try STSExport.validateSession(exportSession)
            try await STSExport.run(exportSession)
            
            // Cancel progress monitoring
            currentProgressTask?.cancel()
            currentProgressTask = nil
            currentExportSession = nil
            
            print("✅ ExportActor: Successfully exported separate file \(take.fileName)")
            return try createExportedFile(
                at: outputURL,
                originalTake: take,
                exportOptions: options
            )
            
        } catch {
            // Cancel progress monitoring on error
            currentProgressTask?.cancel()
            currentProgressTask = nil
            currentExportSession = nil
            
            print("❌ ExportActor: Export failed for \(take.fileName): \(error)")
            throw ExportError.exportFailed(error)
        }
    }
    
    // MARK: - Merged Export
    
    private func exportMergedVideo(
        takes: [UnifiedTake],
        options: ExportOptions,
        progressHandler: @Sendable @escaping (Float, String) -> Void
    ) async throws -> [ExportedFile] {
        
        progressHandler(0.2, "Creating video composition...")
        print("🎬 ExportActor: Starting merged video export with \(takes.count) takes")
        
        // Create composition
        let composition = AVMutableComposition()
        var currentTime = CMTime.zero
        var validTakes: [UnifiedTake] = []
        var skippedTakes: [String] = []
        
        // Add video tracks
        guard let videoTrack = composition.addMutableTrack(
            withMediaType: .video,
            preferredTrackID: kCMPersistentTrackID_Invalid
        ) else {
            throw ExportError.compositionCreationFailed
        }
        
        guard let audioTrack = composition.addMutableTrack(
            withMediaType: .audio,
            preferredTrackID: kCMPersistentTrackID_Invalid
        ) else {
            throw ExportError.compositionCreationFailed
        }
        
        progressHandler(0.4, "Processing takes...")
        print("🎬 ExportActor: Created composition tracks, processing takes...")
        
        for (index, take) in takes.enumerated() {
            let progress = 0.4 + (0.3 * Float(index) / Float(takes.count))
            progressHandler(progress, "Adding take \(index + 1)...")
            
            // Resolve input URL
            let inputURL: URL
            do {
                inputURL = try resolveInputURL(for: take)
            } catch {
                skippedTakes.append(take.fileName)
                continue
            }
            
            guard FileManager.default.fileExists(atPath: inputURL.path) else {
                print("❌ ExportActor: File not found: \(take.fileName)")
                skippedTakes.append(take.fileName)
                continue
            }
            
            let asset = AVURLAsset(url: inputURL)
            
            do {
                let videoTracks = try await asset.loadTracks(withMediaType: .video)
                let audioTracks = try await asset.loadTracks(withMediaType: .audio)
                let duration = try await asset.load(.duration)
                
                print("🎬 ExportActor: \(take.fileName) - Video: \(videoTracks.count), Audio: \(audioTracks.count), Duration: \(CMTimeGetSeconds(duration))s")
                
                // Add video track
                if let videoSourceTrack = videoTracks.first {
                    let timeRange = CMTimeRange(start: .zero, duration: duration)
                    try videoTrack.insertTimeRange(timeRange, of: videoSourceTrack, at: currentTime)
                    print("✅ ExportActor: Added video track for \(take.fileName) at time \(CMTimeGetSeconds(currentTime))s")
                }
                
                // Add audio track
                if let audioSourceTrack = audioTracks.first {
                    let timeRange = CMTimeRange(start: .zero, duration: duration)
                    try audioTrack.insertTimeRange(timeRange, of: audioSourceTrack, at: currentTime)
                    print("✅ ExportActor: Added audio track for \(take.fileName) at time \(CMTimeGetSeconds(currentTime))s")
                }
                
                currentTime = CMTimeAdd(currentTime, duration)
                validTakes.append(take)
                
                print("✅ ExportActor: Successfully processed \(take.fileName)")
                
            } catch {
                print("❌ ExportActor: Failed to process \(take.fileName): \(error)")
                skippedTakes.append(take.fileName)
            }
        }
        
        // Validate we have valid takes
        guard !validTakes.isEmpty else {
            let message = skippedTakes.isEmpty ? "No valid video files found" : "All video files are missing: \(skippedTakes.joined(separator: ", "))"
            throw ExportError.processingFailed(message)
        }
        
        // Generate output filename and URL
        let filename = generateMergedFilename(for: validTakes, options: options)
        let outputURL = getOutputURL(filename: filename)
        
        progressHandler(0.7, "Configuring export session...")
        
        // 🚨 MODERNIZED: Use STSExport wrapper for merged export
        guard let exportSession = STSExport.createSession(
            asset: composition,
            outputURL: outputURL,
            presetName: options.quality.avPreset
        ) else {
            throw ExportError.exportConfigurationFailed
        }
        
        exportSession.outputFileType = options.outputFormat.avFileType
        exportSession.shouldOptimizeForNetworkUse = true
        
        // Store reference for cancellation
        currentExportSession = exportSession
        
        progressHandler(0.8, "Exporting merged video...")
        
        // Start progress monitoring
        currentProgressTask = Task {
            await monitorExportProgress(exportSession, progressHandler: progressHandler)
        }
        
        // 🚨 CRITICAL FIX: Use STSExport.run() with proper validation
        do {
            try STSExport.validateSession(exportSession)
            try await STSExport.run(exportSession)
            
            // Cancel progress monitoring
            currentProgressTask?.cancel()
            currentProgressTask = nil
            currentExportSession = nil
            
            print("✅ ExportActor: Export completed successfully!")
            let exportedFile = try createMergedExportedFile(
                at: outputURL,
                originalTakes: validTakes,
                exportOptions: options
            )
            return [exportedFile]
            
        } catch {
            // Cancel progress monitoring on error
            currentProgressTask?.cancel()
            currentProgressTask = nil
            currentExportSession = nil
            
            print("❌ ExportActor: Export failed: \(error)")
            throw ExportError.exportFailed(error)
        }
    }
    
    private func exportMergedWithSlate(
        takes: [UnifiedTake],
        options: ExportOptions,
        progressHandler: @Sendable @escaping (Float, String) -> Void
    ) async throws -> [ExportedFile] {
        // For now, delegate to regular merged export
        return try await exportMergedVideo(takes: takes, options: options, progressHandler: progressHandler)
    }
    
    // MARK: - Progress Monitoring
    
    private func monitorExportProgress(
        _ exportSession: AVAssetExportSession,
        progressHandler: @Sendable @escaping (Float, String) -> Void
    ) async {
        if #available(iOS 18.0, *) {
            do {
                for await state in exportSession.states(updateInterval: 0.1) {
                    switch state {
                    case .pending:
                        progressHandler(0.0, "Waiting to start...")
                    case .exporting(let progress):
                        let progressValue = Float(progress.fractionCompleted)
                        progressHandler(progressValue, "Exporting... \(Int(progressValue * 100))%")
                    @unknown default:
                        print("⚠️ ExportActor: Unknown export state: \(state)")
                    }
                }
            } catch {
                print("❌ ExportActor: Progress monitoring error: \(error)")
            }
        } else {
            // Legacy progress monitoring
            while exportSession.status == .exporting || exportSession.status == .waiting {
                let progressValue = exportSession.progress
                progressHandler(progressValue, "Exporting... \(Int(progressValue * 100))%")
                
                try? await Task.sleep(nanoseconds: 100_000_000) // 0.1 seconds
            }
            
            // Final status check
            switch exportSession.status {
            case .completed:
                progressHandler(1.0, "Export completed")
            case .failed:
                progressHandler(0.0, "Export failed")
            case .cancelled:
                progressHandler(0.0, "Export cancelled")
            default:
                break
            }
        }
    }
    
    // MARK: - Cancellation
    
    func cancelCurrentExport() {
        currentExportSession?.cancelExport()
        currentProgressTask?.cancel()
        currentProgressTask = nil
        currentExportSession = nil
    }
    
    // MARK: - Utility Methods
    
    private func resolveInputURL(for take: UnifiedTake) throws -> URL {
        do {
            let inputURL = try VideoFileManager.shared.getVideoURL(for: take.fileName)
            print("✅ ExportActor: VideoFileManager found \(take.fileName) at: \(inputURL.path)")
            return inputURL
        } catch {
            let inputURL = URL(fileURLWithPath: take.filePath)
            print("⚠️ ExportActor: VideoFileManager failed, using stored path: \(take.filePath)")
            return inputURL
        }
    }
    
    private func generateOutputURL(for take: UnifiedTake, options: ExportOptions) -> URL {
        let filename = generateFilename(for: take, options: options)
        return getOutputURL(filename: filename)
    }
    
    private func generateFilename(for take: UnifiedTake, options: ExportOptions) -> String {
        let timestamp = DateFormatter.filenameFriendly.string(from: take.createdAt)
        let takeInfo = take.isSlate ? "SLATE" : "Take\(take.takeNumber)"
        return "\(take.projectID.uuidString.prefix(8))_\(takeInfo)_\(timestamp).\(options.outputFormat.fileExtension)"
    }
    
    private func generateMergedFilename(for takes: [UnifiedTake], options: ExportOptions) -> String {
        guard let firstTake = takes.first else {
            return "STS_Export_\(UUID().uuidString.prefix(8)).\(options.outputFormat.fileExtension)"
        }
        
        let timestamp = DateFormatter.filenameFriendly.string(from: Date())
        let projectID = firstTake.projectID.uuidString.prefix(8)
        
        return "\(projectID)_Merged_\(takes.count)takes_\(timestamp).\(options.outputFormat.fileExtension)"
    }
    
    private func getOutputURL(filename: String) -> URL {
        let documentsURL = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first!
        let exportsURL = documentsURL.appendingPathComponent("STS_Exports")
        
        // Create exports directory if it doesn't exist
        try? FileManager.default.createDirectory(at: exportsURL, withIntermediateDirectories: true)
        
        return exportsURL.appendingPathComponent(filename)
    }
    
    // MARK: - Composition Creation
    
    private func createSingleTakeComposition(
        inputURL: URL,
        take: UnifiedTake,
        options: ExportOptions
    ) async throws -> (composition: AVMutableComposition, videoComposition: AVMutableVideoComposition?) {
        
        let asset = AVURLAsset(url: inputURL)
        let composition = AVMutableComposition()
        
        print("🔧 ExportActor: Creating single take composition for \(take.fileName)")
        
        // 🚨 MODERNIZED: Use async AVFoundation APIs instead of deprecated synchronous getters
        let videoTracks = try await asset.loadTracks(withMediaType: .video)
        let audioTracks = try await asset.loadTracks(withMediaType: .audio)
        let duration = try await asset.load(.duration)
        
        print("🔧 ExportActor: Asset loaded - Video tracks: \(videoTracks.count), Audio tracks: \(audioTracks.count), Duration: \(CMTimeGetSeconds(duration))s")
        
        // Validate duration and tracks before composition
        guard CMTimeGetSeconds(duration) > 0 else {
            throw ExportError.processingFailed("Invalid asset duration")
        }
        
        guard let videoSourceTrack = videoTracks.first else {
            throw ExportError.processingFailed("No video track found in \(take.fileName)")
        }
        
        // Create composition tracks
        guard let compositionVideoTrack = composition.addMutableTrack(
            withMediaType: .video,
            preferredTrackID: kCMPersistentTrackID_Invalid
        ) else {
            throw ExportError.compositionCreationFailed
        }
        
        // Enhanced video track insertion with proper time range validation
        let videoTimeRange = CMTimeRange(start: .zero, duration: duration)
        
        do {
            try compositionVideoTrack.insertTimeRange(videoTimeRange, of: videoSourceTrack, at: .zero)
            print("✅ ExportActor: Successfully inserted video track for \(take.fileName)")
        } catch {
            throw ExportError.processingFailed("Video track insertion failed: \(error.localizedDescription)")
        }
        
        // Handle audio track
        if options.includeAudio, let audioSourceTrack = audioTracks.first {
            guard let compositionAudioTrack = composition.addMutableTrack(
                withMediaType: .audio,
                preferredTrackID: kCMPersistentTrackID_Invalid
            ) else {
                print("⚠️ ExportActor: Could not create audio track, continuing with video only")
                return (composition: composition, videoComposition: nil)
            }
            
            let audioTimeRange = CMTimeRange(start: .zero, duration: duration)
            
            do {
                try compositionAudioTrack.insertTimeRange(audioTimeRange, of: audioSourceTrack, at: .zero)
                print("✅ ExportActor: Successfully inserted audio track for \(take.fileName)")
            } catch {
                print("⚠️ ExportActor: Failed to insert audio track for \(take.fileName): \(error), continuing with video only")
            }
        }
        
        // Validate final composition
        do {
            let finalDuration = try await composition.load(.duration)
            guard CMTimeGetSeconds(finalDuration) > 0 else {
                throw ExportError.processingFailed("Composition has invalid duration after track insertion")
            }
            
            print("✅ ExportActor: Single take composition created successfully for \(take.fileName)")
        } catch {
            throw ExportError.processingFailed("Failed to validate composition: \(error.localizedDescription)")
        }
        
        // 🚨 MODERNIZED: Use async API to load preferredTransform
        let preferredTransform = try await videoSourceTrack.load(.preferredTransform)
        let isIdentityTransform = preferredTransform.isIdentity
        
        if isIdentityTransform {
            print("✅ ExportActor: Using simple composition without video composition (identity transform)")
            return (composition: composition, videoComposition: nil)
        } else {
            print("🎨 ExportActor: Creating video composition for transform")
            let videoComposition = try await createVideoComposition(
                for: composition,
                sourceVideoTrack: videoSourceTrack
            )
            return (composition: composition, videoComposition: videoComposition)
        }
    }
    
    private func createVideoComposition(
        for composition: AVMutableComposition,
        sourceVideoTrack: AVAssetTrack
    ) async throws -> AVMutableVideoComposition {
        
        // 🚨 MODERNIZED: Load source track properties using async APIs
        let naturalSize = try await sourceVideoTrack.load(.naturalSize)
        let preferredTransform = try await sourceVideoTrack.load(.preferredTransform)
        
        // Create video composition
        let videoComposition = AVMutableVideoComposition()
        
        // Enhanced render size calculation
        let renderSize = calculateRenderSize(naturalSize: naturalSize, transform: preferredTransform)
        
        videoComposition.renderSize = renderSize
        videoComposition.frameDuration = CMTime(value: 1, timescale: 30) // 30 FPS
        
        // 🚨 MODERNIZED: Get composition video tracks using async API
        let compositionVideoTracks = try await composition.loadTracks(withMediaType: .video)
        guard let compositionVideoTrack = compositionVideoTracks.first else {
            throw ExportError.processingFailed("No composition video track found")
        }
        
        // Create instruction
        let instruction = AVMutableVideoCompositionInstruction()
        
        let compositionDuration = try await composition.load(.duration)
        instruction.timeRange = CMTimeRange(start: .zero, duration: compositionDuration)
        
        // Create layer instruction
        let layerInstruction = AVMutableVideoCompositionLayerInstruction(assetTrack: compositionVideoTrack)
        layerInstruction.setTransform(preferredTransform, at: .zero)
        
        instruction.layerInstructions = [layerInstruction]
        videoComposition.instructions = [instruction]
        
        print("✅ ExportActor: Video composition created with transform applied")
        
        return videoComposition
    }
    
    private func calculateRenderSize(naturalSize: CGSize, transform: CGAffineTransform) -> CGSize {
        let renderSize = naturalSize.applying(transform)
        
        let normalizedSize = CGSize(
            width: abs(renderSize.width),
            height: abs(renderSize.height)
        )
        
        let minSize: CGFloat = 64
        let finalSize = CGSize(
            width: max(normalizedSize.width, minSize),
            height: max(normalizedSize.height, minSize)
        )
        
        return finalSize
    }
    
    private func createCompositionWithMarkers(
        inputURL: URL,
        markers: [VideoMarker],
        options: ExportOptions
    ) async throws -> (composition: AVMutableComposition, videoComposition: AVMutableVideoComposition?) {
        
        let asset = AVURLAsset(url: inputURL)
        let composition = AVMutableComposition()
        
        // UPDATED: Use modern async API for reliable track loading
        let videoTracks = try await asset.loadTracks(withMediaType: .video)
        let audioTracks = try await asset.loadTracks(withMediaType: .audio)
        
        guard let videoTrack = videoTracks.first else {
            throw ExportError.processingFailed("No video track found")
        }
        
        let compositionVideoTrack = composition.addMutableTrack(
            withMediaType: .video,
            preferredTrackID: kCMPersistentTrackID_Invalid
        )
        
        let assetDuration = try await asset.load(.duration)
        
        try compositionVideoTrack?.insertTimeRange(
            CMTimeRange(start: .zero, duration: assetDuration),
            of: videoTrack,
            at: .zero
        )
        
        // Add audio track if present
        if let audioTrack = audioTracks.first,
           options.includeAudio {
            let compositionAudioTrack = composition.addMutableTrack(
                withMediaType: .audio,
                preferredTrackID: kCMPersistentTrackID_Invalid
            )
            
            try compositionAudioTrack?.insertTimeRange(
                CMTimeRange(start: .zero, duration: assetDuration),
                of: audioTrack,
                at: .zero
            )
        }
        
        // Add markers as metadata or chapters
        switch options.markerExportFormat {
        case .chapters, .both:
            addMarkersAsChapters(to: composition, markers: markers)
        case .metadata:
            addMarkersAsMetadata(to: composition, markers: markers)
        case .subtitles:
            break
        }
        
        return (composition: composition, videoComposition: nil)
    }
    
    private func addMarkersAsChapters(to composition: AVMutableComposition, markers: [VideoMarker]) {
        let metadataTrack = composition.addMutableTrack(
            withMediaType: .metadata,
            preferredTrackID: kCMPersistentTrackID_Invalid
        )
        
        for marker in markers {
            let time = CMTime(seconds: marker.timestamp, preferredTimescale: 600)
            let metadataItem = AVMutableMetadataItem()
            metadataItem.identifier = .commonIdentifierTitle
            metadataItem.value = marker.title as NSString
            metadataItem.time = time
            
            if let description = marker.description {
                let descItem = AVMutableMetadataItem()
                descItem.identifier = .commonIdentifierDescription
                descItem.value = description as NSString
                descItem.time = time
            }
        }
    }
    
    private func addMarkersAsMetadata(to composition: AVMutableComposition, markers: [VideoMarker]) {
        print("🏷️ ExportActor: Markers will be preserved in filenames and logs")
        print("📍 Markers to preserve: \(markers.map { "\($0.title) at \($0.timestamp)s" }.joined(separator: ", "))")
    }
    
    private func createExportedFile(
        at url: URL,
        originalTake: UnifiedTake,
        exportOptions: ExportOptions
    ) throws -> ExportedFile {
        let fileSize = try url.resourceValues(forKeys: [.fileSizeKey]).fileSize ?? 0
        
        return ExportedFile(
            url: url,
            filename: url.lastPathComponent,
            fileSize: Int64(fileSize),
            unifiedTakes: [originalTake],
            exportOptions: exportOptions,
            createdAt: Date()
        )
    }
    
    private func createMergedExportedFile(
        at url: URL,
        originalTakes: [UnifiedTake],
        exportOptions: ExportOptions
    ) throws -> ExportedFile {
        let fileSize = try url.resourceValues(forKeys: [.fileSizeKey]).fileSize ?? 0
        
        return ExportedFile(
            url: url,
            filename: url.lastPathComponent,
            fileSize: Int64(fileSize),
            unifiedTakes: originalTakes,
            exportOptions: exportOptions,
            createdAt: Date()
        )
    }
}

/// Professional-grade export engine for Self Tape Studio
/// MODERNIZED: Concurrency-safe with dedicated ExportActor to prevent capture issues
@MainActor
class ExportEngine: ObservableObject {
    static let shared = ExportEngine()
    
    @Published var isExporting = false
    @Published var exportProgress: Float = 0.0
    @Published var currentExportOperation: String = ""
    
    // CONCURRENCY FIX: Use dedicated actor instead of capturing self
    private let exportActor = ExportActor()
    
    private init() {}
    
    // MARK: - Main Export Methods
    
    func exportTakes(
        _ takes: [UnifiedTake],
        options: ExportOptions,
        completion: @escaping (Result<[ExportedFile], ExportError>) -> Void
    ) {
        print("🎬 ExportEngine: exportTakes called with \(takes.count) unified takes")
        print("🎬 ExportEngine: Export mode: \(options.mode.displayName)")
        
        // Set exporting state immediately
        isExporting = true
        exportProgress = 0.0
        currentExportOperation = "Initializing export..."
        
        // CONCURRENCY FIX: Use Task without capturing self
        // Instead, capture only the immutable values we need
        Task { @MainActor in
            do {
                // CONCURRENCY FIX: Pass progress handler that doesn't capture self
                let exportedFiles = try await exportActor.performExport(
                    takes: takes,
                    options: options,
                    progressHandler: { [weak self] progress, operation in
                        Task { @MainActor in
                            self?.updateExportProgress(progress, operation: operation)
                        }
                    }
                )
                
                print("✅ ExportEngine: Export completed with \(exportedFiles.count) files")
                
                // Reset exporting state
                self.isExporting = false
                
                completion(.success(exportedFiles))
                
            } catch {
                print("❌ ExportEngine: Export failed with error: \(error)")
                
                // Reset exporting state on error
                self.isExporting = false
                self.exportProgress = 0.0
                self.currentExportOperation = "Export failed"
                
                completion(.failure(ExportError.processingFailed(error.localizedDescription)))
            }
        }
    }
    
    // MARK: - Progress Updates
    
    private func updateExportProgress(_ progress: Float, operation: String) {
        exportProgress = progress
        currentExportOperation = operation
    }
    
    // MARK: - Utility Methods
    
    func cancelExport() {
        Task {
            await exportActor.cancelCurrentExport()
        }
        
        isExporting = false
        exportProgress = 0.0
        currentExportOperation = "Export cancelled"
    }
}

// MARK: - Export Options
struct ExportOptions: Equatable {
    var mode: ExportMode = .separateFiles
    var quality: ExportQuality = .high
    var outputFormat: OutputFormat = .mp4
    var outputURL: URL?
    var includeSlate: Bool = true
    
    // Video marker export support
    var includeVideoMarkers: Bool = false
    var markerExportFormat: MarkerExportFormat = .chapters
    var videoMarkers: [String: [VideoMarker]] = [:]  // takeID -> markers
    
    // Advanced options
    var customBitrate: Int?
    var customResolution: CGSize?
    var includeAudio: Bool = true
    var audioQuality: AudioQuality = .high
    var customFrameRate: Float?
    var enableHardwareAcceleration: Bool = true
    
    // Equatable conformance
    static func == (lhs: ExportOptions, rhs: ExportOptions) -> Bool {
        lhs.mode == rhs.mode &&
        lhs.quality == rhs.quality &&
        lhs.outputFormat == rhs.outputFormat &&
        lhs.includeSlate == rhs.includeSlate &&
        lhs.includeVideoMarkers == rhs.includeVideoMarkers
    }
}

// MARK: - Export Enums

enum MarkerExportFormat: String, CaseIterable {
    case chapters = "chapters"
    case metadata = "metadata"
    case subtitles = "subtitles"
    case both = "both"
    
    var displayName: String {
        switch self {
        case .chapters:
            return "Video Chapters"
        case .metadata:
            return "Metadata Only"
        case .subtitles:
            return "Subtitle Track"
        case .both:
            return "Chapters + Metadata"
        }
    }
}

enum ExportMode: String, CaseIterable {
    case separateFiles = "separate"
    case mergedVideo = "merged"
    case mergedWithSlate = "mergedWithSlate"
    
    var displayName: String {
        switch self {
        case .separateFiles:
            return "Separate Files"
        case .mergedVideo:
            return "Merged Video"
        case .mergedWithSlate:
            return "Merged with Slate"
        }
    }
    
    var icon: String {
        switch self {
        case .separateFiles:
            return "doc.on.doc"
        case .mergedVideo:
            return "film"
        case .mergedWithSlate:
            return "person.crop.rectangle.stack.fill"
        }
    }
}

enum ExportQuality: String, CaseIterable {
    case low = "low"
    case medium = "medium"
    case high = "high"
    case maximum = "maximum"
    
    var displayName: String {
        switch self {
        case .low:
            return "Low (Smaller File)"
        case .medium:
            return "Medium (Balanced)"
        case .high:
            return "High (Recommended)"
        case .maximum:
            return "Maximum (Largest File)"
        }
    }
    
    var avPreset: String {
        switch self {
        case .low:
            return AVAssetExportPresetLowQuality
        case .medium:
            return AVAssetExportPresetMediumQuality
        case .high:
            return AVAssetExportPresetHighestQuality
        case .maximum:
            return AVAssetExportPresetPassthrough
        }
    }
    
    var estimatedCompressionRatio: Double {
        switch self {
        case .low:
            return 0.3
        case .medium:
            return 0.5
        case .high:
            return 0.7
        case .maximum:
            return 1.0
        }
    }
}

enum AudioQuality: String, CaseIterable {
    case low = "low"
    case medium = "medium"
    case high = "high"
    case lossless = "lossless"
    
    var displayName: String {
        switch self {
        case .low:
            return "Low (64 kbps)"
        case .medium:
            return "Medium (128 kbps)"
        case .high:
            return "High (256 kbps)"
        case .lossless:
            return "Lossless"
        }
    }
    
    var bitrate: Int {
        switch self {
        case .low:
            return 64_000
        case .medium:
            return 128_000
        case .high:
            return 256_000
        case .lossless:
            return 0 // Will use lossless compression
        }
    }
}

enum OutputFormat: String, CaseIterable {
    case mp4 = "mp4"
    case mov = "mov"
    
    var displayName: String {
        switch self {
        case .mp4:
            return "MP4 (Universal)"
        case .mov:
            return "MOV (Apple)"
        }
    }
    
    var fileExtension: String {
        return self.rawValue
    }
    
    var avFileType: AVFileType {
        switch self {
        case .mp4:
            return .mp4
        case .mov:
            return .mov
        }
    }
}

// MARK: - Export Results

struct ExportedFile: Identifiable, Equatable {
    let id = UUID()
    let url: URL
    let filename: String
    let fileSize: Int64
    let unifiedTakes: [UnifiedTake]
    let exportOptions: ExportOptions
    let createdAt: Date
    
    var formattedFileSize: String {
        ByteCountFormatter.string(fromByteCount: fileSize, countStyle: .file)
    }
    
    var isMultiTake: Bool {
        unifiedTakes.count > 1
    }
    
    // Equatable conformance
    static func == (lhs: ExportedFile, rhs: ExportedFile) -> Bool {
        lhs.id == rhs.id && lhs.filename == rhs.filename && lhs.fileSize == rhs.fileSize
    }
}

// MARK: - Export Errors

enum ExportError: LocalizedError {
    case noTakesFound
    case fileNotFound(String)
    case exportConfigurationFailed
    case compositionCreationFailed
    case noValidTakes
    case exportFailed(Error)
    case postProcessingFailed(Error)
    case exportCancelled
    case batchExportFailed([Error])
    case unknownError
    case processingFailed(String)
    
    var errorDescription: String? {
        switch self {
        case .noTakesFound:
            return "No takes found to export"
        case .fileNotFound(let path):
            return "Video file not found: \(path)"
        case .exportConfigurationFailed:
            return "Failed to configure export settings"
        case .compositionCreationFailed:
            return "Failed to create video composition"
        case .noValidTakes:
            return "No valid video files found"
        case .exportFailed(let error):
            return "Export failed: \(error.localizedDescription)"
        case .postProcessingFailed(let error):
            return "Post-processing failed: \(error.localizedDescription)"
        case .exportCancelled:
            return "Export was cancelled"
        case .batchExportFailed(let errors):
            return "Batch export failed (\(errors.count) errors)"
        case .unknownError:
            return "An unknown error occurred during export"
        case .processingFailed(let message):
            return "Processing failed: \(message)"
        }
    }
}

// MARK: - Utility Extensions

extension DateFormatter {
    static let filenameFriendly: DateFormatter = {
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyyMMdd_HHmmss"
        return formatter
    }()
}
